/* ============================================================
   fsm.js — PlayMaker-style visual finite state machine
   Each scene node may own an FSM:
     { enabled, start, states[], transitions[], variables[] }
   States run an ordered list of actions when entered. Transitions
   fire on delay, event, key, key edge or variable condition.
   The runtime in runtime.js drives these objects; the graph UI in
   ui/graph.js edits them.

   Every action only touches the shared scene model or the shared
   runtime, never a renderer, so an FSM behaves identically on
   Three.js, Babylon.js, Native Canvas and third-party engines.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = (M && M.vec) || {};
  const F = (UW.FSM = {});

  let seq = 1;
  const uid = (p) => (p || 'fsm') + Date.now().toString(36).slice(-4) + (seq++).toString(36);

  /* ---------------- metadata helpers ---------------- */
  const CATEGORIES = [
    { id: 'flow', label: 'Flow' },
    { id: 'scene', label: 'Scene & Flow' },
    { id: 'transform', label: 'Transform' },
    { id: 'variables', label: 'Variables & Math' },
    { id: 'string', label: 'String & Text' },
    { id: 'logic', label: 'Logic & Scene' },
    { id: 'gameobject', label: 'GameObject' },
    { id: 'material', label: 'Material & Texture' },
    { id: 'light', label: 'Lighting' },
    { id: 'camera', label: 'Camera' },
    { id: 'physics', label: 'Physics' },
    { id: 'network', label: 'Network & PHP' },
    { id: 'audio', label: 'Audio' },
    { id: 'debug', label: 'Debug & UI' },
    { id: 'rig', label: 'Rig & Animation' },
    { id: 'multiplayer', label: 'Multiplayer' },
    { id: 'storage', label: 'PlayerPrefs & Storage' },
    { id: 'input', label: 'Input' },
    { id: 'time', label: 'Time' },
    { id: 'vector', label: 'Vector & Math' },
    { id: 'ui', label: 'UI & Browser' },
  ];

  const EASINGS = [
    { value: 'linear', label: 'Linear' },
    { value: 'easeIn', label: 'Ease in' },
    { value: 'easeOut', label: 'Ease out' },
    { value: 'easeInOut', label: 'Ease in / out' },
  ];
  const PRESETS = (UW.textures && UW.textures.presets ? UW.textures.presets : [{ id: 'checker', label: 'Checker' }])
    .map((p) => ({ value: p.id, label: p.label }));

  const text = (key, label, def, placeholder, help) => ({ key, label, type: 'text', def, placeholder, help });
  const num = (key, label, def, step, min, max, help) => ({ key, label, type: 'number', def, step, min, max, help });
  const bool = (key, label, def, help) => ({ key, label, type: 'bool', def, help });
  const color = (key, label, def, help) => ({ key, label, type: 'color', def, help });
  const select = (key, label, options, def, help) => ({ key, label, type: 'select', options, def, help });
  const target = () => text('target', 'Target', 'self', 'self / name / id', 'Leave as “self” to affect this object.');
  const duration = () => num('duration', 'Duration', 1, 0.1, 0, 3600, 'Seconds. Use 0 for an instant change.');
  const easing = () => select('easing', 'Easing', EASINGS, 'easeInOut');
  const waitFinish = () => bool('wait', 'Wait for finish', true, 'Hold the remaining actions until the tween completes.');

  const ACTION_TYPES = [
    /* ---------------- flow ---------------- */
    { id: 'log', category: 'flow', label: 'Log message', help: 'Write a line to the editor Console.', params: [
      text('message', 'Message', 'State entered'),
      select('level', 'Level', [{ value: 'info', label: 'Info' }, { value: 'warn', label: 'Warning' }, { value: 'error', label: 'Error' }], 'info'),
    ] },
    { id: 'wait', category: 'flow', label: 'Wait', help: 'Pause the following actions for a number of seconds.', params: [
      num('seconds', 'Seconds', 1, 0.1, 0.01, 3600),
    ] },
    { id: 'sendEvent', category: 'flow', label: 'Send event', help: 'Broadcast an FSM event to every state machine on the scene.', params: [
      text('event', 'Event', 'done'),
    ] },
    { id: 'startFsm', category: 'flow', label: 'Start FSM', help: 'Start another object’s FSM at its start state.', params: [
      target(),
    ] },
    { id: 'stopFsm', category: 'flow', label: 'Stop FSM', help: 'Stop another object’s FSM and cancel its pending actions.', params: [
      target(),
    ] },
    { id: 'restartFsm', category: 'flow', label: 'Restart FSM', help: 'Restart another object’s FSM from its start state.', params: [
      target(),
    ] },
    { id: 'enableFsm', category: 'flow', label: 'Enable / disable FSM', help: 'Toggle another object’s FSM component at runtime.', params: [
      target(),
      bool('enabled', 'Enabled', true),
    ] },

    /* ---------------- scene transitions ---------------- */
    { id: 'loadScene', category: 'scene', label: 'Go to scene', help: 'Replace the running scene with another scene saved in browser storage.', params: [
      text('name', 'Scene', 'Level 2', 'saved scene name'),
      bool('keepPlaying', 'Continue playing', true, 'Enter play mode in the new scene immediately.'),
    ] },
    { id: 'loadSceneUrl', category: 'scene', label: 'Go to scene URL', help: 'Download a scene JSON file (for example from a PHP endpoint) and open it.', params: [
      text('url', 'URL', 'https://example.com/scene.php', 'absolute URL'),
      select('method', 'Method', [{ value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' }], 'GET'),
      text('body', 'Body', '', 'sent with POST'),
      text('headers', 'Headers', '', 'one “Name: value” per line'),
      bool('wait', 'Wait for download', true),
      bool('keepPlaying', 'Continue playing', true),
    ] },
    { id: 'restartScene', category: 'scene', label: 'Restart scene', help: 'Reload the scene that was active when Play started, keeping play mode running.', params: [] },
    { id: 'saveSceneAs', category: 'scene', label: 'Save scene as', help: 'Store the current scene in browser storage under a name (useful before switching scenes).', params: [
      text('name', 'Name', 'Checkpoint', 'saved scene name'),
    ] },
    { id: 'exitPlay', category: 'scene', label: 'Exit to editor', help: 'Stop play mode and restore the scene to its pre-play state.', params: [] },

    /* ---------------- transform ---------------- */
    { id: 'move', category: 'transform', label: 'Move (relative)', help: 'Add a one-off offset to local position.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'rotate', category: 'transform', label: 'Rotate (relative)', help: 'Add a one-off rotation in degrees.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 45, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'setPosition', category: 'transform', label: 'Set position', help: 'Set local position immediately.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0.5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setRotation', category: 'transform', label: 'Set rotation', help: 'Set local Euler rotation in degrees immediately.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 0, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'setScale', category: 'transform', label: 'Set scale', help: 'Set local scale immediately.', params: [
      num('x', 'X', 1, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 1, 0.1), target(),
    ] },
    { id: 'moveTo', category: 'transform', label: 'Move to (tween)', help: 'Smoothly tween local position to an absolute point.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'moveBy', category: 'transform', label: 'Move by (tween)', help: 'Smoothly tween local position by a relative offset.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'rotateTo', category: 'transform', label: 'Rotate to (tween)', help: 'Tween rotation in degrees along the shortest path.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 90, 5), num('z', 'Z', 0, 5),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'scaleTo', category: 'transform', label: 'Scale to (tween)', help: 'Tween local scale to an absolute value.', params: [
      num('x', 'X', 1.5, 0.1), num('y', 'Y', 1.5, 0.1), num('z', 'Z', 1.5, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'lookAt', category: 'transform', label: 'Look at point', help: 'Aim the object’s +Z axis at a world-space point.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0.5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'lookAtObject', category: 'transform', label: 'Look at object', help: 'Aim the object at another object’s current position.', params: [
      target(),
      text('lookAt', 'Look at', 'Main Camera', 'name / id'),
    ] },
    { id: 'resetTransform', category: 'transform', label: 'Reset transform', help: 'Reset position to 0, rotation to 0 and scale to 1.', params: [target()] },
    { id: 'stopMotion', category: 'transform', label: 'Stop tweens', help: 'Cancel all running position/rotation/scale tweens on this FSM.', params: [target()] },

    /* ---------------- variables & math ---------------- */
    { id: 'setVariable', category: 'variables', label: 'Set variable', help: 'Assign a literal value. Numbers are stored as text but compared numerically.', params: [
      text('name', 'Variable', 'score'), text('value', 'Value', '1'),
    ] },
    { id: 'addVariable', category: 'variables', label: 'Add to variable', help: 'Add a numeric amount to a variable.', params: [
      text('name', 'Variable', 'score'), num('value', 'Amount', 1, 0.1),
    ] },
    { id: 'multiplyVariable', category: 'variables', label: 'Multiply variable', help: 'Multiply a variable by a numeric factor.', params: [
      text('name', 'Variable', 'score'), num('value', 'Factor', 2, 0.1),
    ] },
    { id: 'clampVariable', category: 'variables', label: 'Clamp variable', help: 'Keep a variable within a numeric range.', params: [
      text('name', 'Variable', 'score'), num('min', 'Min', 0, 0.1), num('max', 'Max', 100, 0.1),
    ] },
    { id: 'randomFloat', category: 'variables', label: 'Random float', help: 'Store a random decimal number in a variable.', params: [
      text('name', 'Variable', 'chance'), num('min', 'Min', 0, 0.1), num('max', 'Max', 1, 0.1),
    ] },
    { id: 'randomInt', category: 'variables', label: 'Random integer', help: 'Store a random whole number (inclusive range).', params: [
      text('name', 'Variable', 'roll'), num('min', 'Min', 1, 1), num('max', 'Max', 6, 1),
    ] },
    { id: 'toggleVariable', category: 'variables', label: 'Toggle variable', help: 'Flip a boolean-like value between true/false.', params: [
      text('name', 'Variable', 'active'),
    ] },
    { id: 'copyVariable', category: 'variables', label: 'Copy variable', help: 'Copy one FSM variable into another.', params: [
      text('from', 'From', 'score'), text('to', 'To', 'best'),
    ] },
    { id: 'mathOp', category: 'variables', label: 'Math operation', help: 'Apply an arithmetic operation to a variable in place.', params: [
      text('name', 'Variable', 'score'),
      select('op', 'Operation', [
        { value: '+', label: '+' }, { value: '-', label: '−' }, { value: '*', label: '×' },
        { value: '/', label: '÷' }, { value: '%', label: 'Modulo' }, { value: '^', label: 'Power' },
        { value: 'min', label: 'Minimum' }, { value: 'max', label: 'Maximum' },
      ], '+'),
      num('value', 'Value', 1, 0.1),
      text('source', 'Use variable', '', 'optional variable operand'),
    ] },
    { id: 'getTransform', category: 'variables', label: 'Get transform value', help: 'Read position, rotation or scale from an object into a variable.', params: [
      text('name', 'Variable', 'posX'), target(),
      select('property', 'Property', [{ value: 'position', label: 'Position' }, { value: 'rotation', label: 'Rotation' }, { value: 'scale', label: 'Scale' }], 'position'),
      select('axis', 'Axis', [{ value: 'x', label: 'X' }, { value: 'y', label: 'Y' }, { value: 'z', label: 'Z' }], 'x'),
    ] },
    { id: 'getDistance', category: 'variables', label: 'Get distance', help: 'Store the distance between two objects in a variable.', params: [
      text('store', 'Variable', 'distance'), target(), text('other', 'Other', 'Main Camera', 'name / id'),
    ] },
    { id: 'formatString', category: 'variables', label: 'Format string', help: 'Replace {variable} placeholders in a template and store the result.', params: [
      text('template', 'Template', 'Hello {name}, score {score}'),
      text('store', 'Store in', 'message'),
    ] },

    /* ---------------- string & text ---------------- */
    { id: 'stringReplace', category: 'string', label: 'Replace text', help: 'Replace every occurrence of a substring inside a variable.', params: [
      text('variable', 'Variable', 'message'), text('find', 'Find', 'old'), text('replace', 'Replace with', 'new'),
    ] },
    { id: 'splitString', category: 'string', label: 'Split string', help: 'Split a variable by a separator and store one part (0 = first).', params: [
      text('source', 'Source', 'message'), text('separator', 'Separator', ','),
      num('index', 'Part index', 0, 1, 0, 999), text('store', 'Store in', 'part'),
    ] },
    { id: 'stringCase', category: 'string', label: 'Change text case', help: 'Convert a variable to upper case, lower case, trimmed or capitalised.', params: [
      text('variable', 'Variable', 'message'),
      select('mode', 'Mode', [
        { value: 'upper', label: 'UPPER CASE' }, { value: 'lower', label: 'lower case' },
        { value: 'trim', label: 'Trim spaces' }, { value: 'capitalize', label: 'Capitalize' },
      ], 'upper'),
    ] },
    { id: 'convertVariable', category: 'string', label: 'Convert variable', help: 'Convert a variable between text, integer and decimal forms.', params: [
      text('variable', 'Variable', 'score'),
      select('mode', 'Convert to', [
        { value: 'int', label: 'Integer' }, { value: 'float', label: 'Decimal' },
        { value: 'fixed', label: 'Fixed decimals' }, { value: 'text', label: 'Plain text' },
      ], 'int'),
      num('decimals', 'Decimals', 2, 1, 0, 6),
    ] },

    /* ---------------- logic & scene ---------------- */
    { id: 'branch', category: 'logic', label: 'Branch on variable', help: 'Send one of two events depending on a variable comparison.', params: [
      text('variable', 'Variable', 'score'),
      select('op', 'Operator', ['==', '!=', '>', '<', '>=', '<='].map((o) => ({ value: o, label: o })), '>='),
      text('value', 'Value', '10'),
      text('eventTrue', 'If true', 'win'),
      text('eventFalse', 'If false', 'lose'),
    ] },
    { id: 'setAmbient', category: 'logic', label: 'Set ambient light', help: 'Change scene-wide ambient intensity and colour.', params: [
      num('intensity', 'Intensity', 0.42, 0.05, 0, 4),
      color('color', 'Color', '#ffffff'),
    ] },
    { id: 'setFog', category: 'logic', label: 'Set fog', help: 'Enable or configure scene fog at runtime.', params: [
      bool('enabled', 'Enabled', true),
      color('color', 'Color', '#1d2025'),
      num('near', 'Near', 14, 0.5, 0), num('far', 'Far', 70, 1, 0.1),
    ] },

    /* ---------------- GameObject ---------------- */
    { id: 'setVisible', category: 'gameobject', label: 'Set visible', help: 'Show or hide an object (and its children).', params: [
      bool('visible', 'Visible', true), target(),
    ] },
    { id: 'toggleVisible', category: 'gameobject', label: 'Toggle visible', help: 'Invert an object’s visibility.', params: [target()] },
    { id: 'setParent', category: 'gameobject', label: 'Set parent', help: 'Re-parent an object at runtime. Leave Parent empty to move it to the scene root.', params: [
      target(),
      text('parent', 'Parent', '', 'empty = scene root'),
    ] },
    { id: 'setName', category: 'gameobject', label: 'Set object name', help: 'Rename an object at runtime.', params: [
      text('name', 'Name', 'Object'), target(),
    ] },
    { id: 'destroyObject', category: 'gameobject', label: 'Destroy object', help: 'Remove an object (and optionally its children) from the running scene.', params: [
      target(), bool('includeChildren', 'Include children', true),
    ] },
    { id: 'cloneObject', category: 'gameobject', label: 'Clone object', help: 'Create a copy of an object during play, optionally including its FSM.', params: [
      target(),
      text('name', 'New name', '{name} clone', 'supports {name}'),
      num('x', 'Offset X', 0.6, 0.1), num('y', 'Offset Y', 0, 0.1), num('z', 'Offset Z', 0.6, 0.1),
      bool('copyFsm', 'Copy FSM', false),
      text('store', 'Store in variable', 'clone', 'name of the new object'),
    ] },
    { id: 'setActive', category: 'gameobject', label: 'Activate / deactivate', help: 'Turn an object on or off. Inactive objects stop rendering, physics, scripts, behaviors and FSMs — children too.', params: [
      bool('active', 'Activate', true), target(),
    ] },
    { id: 'toggleActive', category: 'gameobject', label: 'Toggle active', help: 'Flip an object between active and inactive.', params: [target()] },
    { id: 'setTag', category: 'gameobject', label: 'Set tag', help: 'Assign a tag to an object so Find and Compare actions can use it.', params: [
      text('tag', 'Tag', 'Enemy'), target(),
    ] },
    { id: 'getTag', category: 'gameobject', label: 'Get tag', help: 'Store an object’s tag in a variable.', params: [
      target(), text('store', 'Store in', 'tag'),
    ] },
    { id: 'findByTag', category: 'gameobject', label: 'Find object by tag', help: 'Find the first active object with a tag and store its name in a variable.', params: [
      text('tag', 'Tag', 'Enemy'), text('store', 'Store in', 'found'),
    ] },
    { id: 'compareTag', category: 'gameobject', label: 'Compare tag', help: 'Compare an object’s tag, store true/false and send a matching event.', params: [
      target(), text('tag', 'Tag', 'Enemy'), text('store', 'Store in', 'match'),
      text('eventTrue', 'If match', 'tagMatch'), text('eventFalse', 'If not', 'tagMismatch'),
    ] },

    /* ---------------- material & texture ---------------- */
    { id: 'setColor', category: 'material', label: 'Set color', help: 'Set the mesh material colour.', params: [color('color', 'Color', '#5b9bd5'), target()] },
    { id: 'setOpacity', category: 'material', label: 'Set opacity', help: 'Set mesh transparency from 0 (invisible) to 1 (opaque).', params: [
      num('opacity', 'Opacity', 0.5, 0.05, 0, 1), target(),
    ] },
    { id: 'setWireframe', category: 'material', label: 'Set wireframe', help: 'Render the mesh as wireframe or solid.', params: [
      bool('wireframe', 'Wireframe', true), target(),
    ] },
    { id: 'setTexturePreset', category: 'material', label: 'Set texture preset', help: 'Replace the mesh texture with a procedural preset.', params: [
      select('preset', 'Preset', PRESETS, 'checker'), target(),
    ] },
    { id: 'setTextureTiling', category: 'material', label: 'Set texture tiling', help: 'Repeat the current (or a default) texture across the UVs.', params: [
      num('x', 'Repeat X', 2, 0.1, 0.05, 16), num('y', 'Repeat Y', 2, 0.1, 0.05, 16), target(),
    ] },
    { id: 'setTextureOffset', category: 'material', label: 'Set texture offset', help: 'Shift the texture across the UVs.', params: [
      num('x', 'Offset X', 0.5, 0.05), num('y', 'Offset Y', 0, 0.05), target(),
    ] },
    { id: 'clearTexture', category: 'material', label: 'Remove texture', help: 'Remove the mesh texture component.', params: [target()] },

    /* ---------------- lighting ---------------- */
    { id: 'setLightColor', category: 'light', label: 'Set light color', help: 'Set the colour of a light object.', params: [color('color', 'Color', '#ffffff'), target()] },
    { id: 'setLightIntensity', category: 'light', label: 'Set light intensity', help: 'Set a light’s brightness.', params: [
      num('intensity', 'Intensity', 1.5, 0.1, 0, 20), target(),
    ] },
    { id: 'setLightRange', category: 'light', label: 'Set light range', help: 'Set point/spot light falloff distance.', params: [
      num('range', 'Range', 18, 0.5, 0.1, 500), target(),
    ] },
    { id: 'setLightAngle', category: 'light', label: 'Set spot angle', help: 'Set a spot light cone angle in degrees.', params: [
      num('angle', 'Angle', 38, 1, 1, 179), target(),
    ] },
    { id: 'setLightPenumbra', category: 'light', label: 'Set spot penumbra', help: 'Soften the spot light edge (0 hard, 1 soft).', params: [
      num('penumbra', 'Penumbra', 0.35, 0.05, 0, 1), target(),
    ] },
    { id: 'toggleLight', category: 'light', label: 'Toggle light', help: 'Turn a light object on or off.', params: [target()] },

    /* ---------------- camera ---------------- */
    { id: 'setCameraFov', category: 'camera', label: 'Set camera FOV', help: 'Change the active game camera field of view.', params: [
      num('fov', 'FOV', 55, 1, 5, 170), target(),
    ] },
    { id: 'setCameraClip', category: 'camera', label: 'Set camera clipping', help: 'Change the near and far clip planes.', params: [
      num('near', 'Near', 0.1, 0.01, 0.001), num('far', 'Far', 600, 1, 0.1), target(),
    ] },
    { id: 'setCameraBg', category: 'camera', label: 'Set camera background', help: 'Change the Game-view background colour.', params: [
      color('color', 'Color', '#1d2025'), target(),
    ] },

    /* ---------------- physics ---------------- */
    { id: 'addImpulse', category: 'physics', label: 'Add impulse', help: 'Add velocity to a rigidbody (divided by its mass).', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setVelocity', category: 'physics', label: 'Set velocity', help: 'Replace a rigidbody’s linear velocity.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setUseGravity', category: 'physics', label: 'Set body gravity', help: 'Toggle gravity for one rigidbody.', params: [
      bool('enabled', 'Use gravity', true), target(),
    ] },
    { id: 'setGravity', category: 'physics', label: 'Set world gravity', help: 'Change gravity for every rigidbody in the scene.', params: [
      num('value', 'Gravity', 9.81, 0.1, 0, 100),
    ] },
    { id: 'addForce', category: 'physics', label: 'Add force', help: 'Push a rigidbody continuously for a number of seconds (force ÷ mass).', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 10, 0.1), num('z', 'Z', 0, 0.1),
      num('seconds', 'Seconds', 0.5, 0.1, 0, 30), target(),
    ] },
    { id: 'setMass', category: 'physics', label: 'Set mass', help: 'Change a rigidbody’s mass.', params: [
      num('mass', 'Mass', 1, 0.1, 0.05, 1000), target(),
    ] },
    { id: 'setRestitution', category: 'physics', label: 'Set bounciness', help: 'Set how much a rigidbody bounces (0 = none, 1 = perfect).', params: [
      num('value', 'Bounciness', 0.3, 0.05, 0, 1), target(),
    ] },
    { id: 'setDrag', category: 'physics', label: 'Set drag', help: 'Slow a rigidbody down over time.', params: [
      num('value', 'Drag', 0.5, 0.1, 0, 20), target(),
    ] },
    { id: 'freezeBody', category: 'physics', label: 'Freeze rigidbody', help: 'Freeze or unfreeze a rigidbody in place.', params: [
      bool('frozen', 'Frozen', true), target(),
    ] },
    { id: 'raycast', category: 'physics', label: 'Raycast', help: 'Cast a ray against scene colliders and store what it hits.', params: [
      num('x', 'Origin X', 0, 0.1), num('y', 'Origin Y', 1, 0.1), num('z', 'Origin Z', 0, 0.1),
      num('dx', 'Direction X', 0, 0.1), num('dy', 'Direction Y', -1, 0.1), num('dz', 'Direction Z', 0, 0.1),
      num('maxDistance', 'Max distance', 50, 1, 0.1, 1000),
      text('storeObject', 'Store hit object', 'hit'), text('storeDistance', 'Store distance', 'hitDistance'),
      bool('ignoreSelf', 'Ignore self', true),
    ] },

    /* ---------------- network / PHP ---------------- */
    { id: 'httpRequest', category: 'network', label: 'HTTP request', help: 'Call an external URL or PHP endpoint, store the response and optionally wait for it.', params: [
      select('method', 'Method', [
        { value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' },
        { value: 'PUT', label: 'PUT' }, { value: 'PATCH', label: 'PATCH' }, { value: 'DELETE', label: 'DELETE' },
      ], 'GET'),
      text('url', 'URL', 'https://example.com/api.php', 'absolute URL'),
      select('contentType', 'Send as', [
        { value: 'none', label: 'No body' }, { value: 'json', label: 'JSON' },
        { value: 'form', label: 'Form fields' }, { value: 'text', label: 'Plain text' },
      ], 'json'),
      text('body', 'Body', '{"action":"hello"}', 'JSON, form fields or plain text'),
      text('headers', 'Headers', '', 'one “Name: value” per line'),
      text('store', 'Store response', 'response'),
      text('storeStatus', 'Store status', 'status'),
      text('doneEvent', 'Success event', 'httpDone'),
      text('errorEvent', 'Failure event', 'httpError'),
      num('timeout', 'Timeout (s)', 15, 1, 1, 120),
      bool('wait', 'Wait for response', true),
    ] },
    { id: 'callPhp', category: 'network', label: 'Call PHP endpoint', help: 'POST form fields to a PHP script and store its response.', params: [
      text('url', 'URL', 'https://example.com/api.php'),
      text('fields', 'Fields', 'name=hero&score=10', 'key=value&key2=value2'),
      text('store', 'Store response', 'response'),
      text('doneEvent', 'Success event', 'phpDone'),
      text('errorEvent', 'Failure event', 'phpError'),
      num('timeout', 'Timeout (s)', 15, 1, 1, 120),
      bool('wait', 'Wait for response', true),
    ] },
    { id: 'jsonGet', category: 'network', label: 'Read JSON value', help: 'Read a dotted path from a JSON variable, for example data.player.name or items[0].id.', params: [
      text('source', 'From variable', 'response'),
      text('path', 'Path', 'data.name', 'dots and [n] indexes'),
      text('store', 'Store in', 'value'),
      text('fallback', 'Fallback', ''),
    ] },
    { id: 'openUrl', category: 'network', label: 'Open URL in browser', help: 'Open a link in a new tab. Popup blockers may ignore calls that are not triggered by a click.', params: [
      text('url', 'URL', 'https://example.com'),
      select('target', 'Target', [{ value: '_blank', label: 'New tab' }, { value: '_self', label: 'Same tab' }], '_blank'),
    ] },

    /* ---------------- audio ---------------- */
    { id: 'playTone', category: 'audio', label: 'Play tone', help: 'Play a short synthesised tone using the browser AudioContext.', params: [
      num('frequency', 'Frequency', 440, 10, 20, 12000),
      num('duration', 'Duration', 0.18, 0.05, 0.03, 10),
      num('volume', 'Volume', 0.18, 0.05, 0, 1),
      select('wave', 'Wave', [{ value: 'sine', label: 'Sine' }, { value: 'square', label: 'Square' }, { value: 'sawtooth', label: 'Sawtooth' }, { value: 'triangle', label: 'Triangle' }], 'sine'),
    ] },
    { id: 'stopAudio', category: 'audio', label: 'Stop all audio', help: 'Close the runtime audio context and stop every tone.', params: [] },

    /* ---------------- debug / UI ---------------- */
    { id: 'toast', category: 'debug', label: 'Show toast', help: 'Show a short notification over the editor.', params: [
      text('message', 'Message', 'Action complete'),
      select('kind', 'Kind', [{ value: 'info', label: 'Info' }, { value: 'ok', label: 'Success' }, { value: 'warn', label: 'Warning' }, { value: 'error', label: 'Error' }], 'info'),
    ] },

    /* ---------------- rig & animation ---------------- */
    { id: 'rigPlay', category: 'rig', label: 'Play rig animation', help: 'Play a procedural clip on an auto-rigged model. The clip is rebuilt every frame from bone rotations, so it works on every renderer.', params: [
      select('clip', 'Clip', [
        { value: 'idle', label: 'Idle' }, { value: 'walk', label: 'Walk' }, { value: 'run', label: 'Run' },
        { value: 'wave', label: 'Wave' }, { value: 'dance', label: 'Dance' }, { value: 'custom', label: 'Custom pose' },
      ], 'idle'),
      num('speed', 'Speed', 1, 0.1, 0, 8),
      target(),
    ] },
    { id: 'rigStop', category: 'rig', label: 'Stop rig animation', help: 'Stop the current clip and return every bone to its rest pose.', params: [target()] },
    { id: 'rigPause', category: 'rig', label: 'Pause rig animation', help: 'Freeze the bones where they are, keeping the current pose.', params: [target()] },
    { id: 'rigResume', category: 'rig', label: 'Resume rig animation', help: 'Continue a paused procedural clip.', params: [target()] },
    { id: 'rigSetSpeed', category: 'rig', label: 'Set rig speed', help: 'Change the playback speed of the current clip.', params: [
      num('speed', 'Speed', 1, 0.1, 0, 8), target(),
    ] },
    { id: 'rigSetBone', category: 'rig', label: 'Set bone rotation', help: 'Set one bone to an absolute local rotation in degrees. Bone names: hips, spine, chest, neck, head, shoulderL/R, upperArmL/R, lowerArmL/R, handL/R, upperLegL/R, lowerLegL/R, footL/R.', params: [
      text('bone', 'Bone', 'head', 'head, upperArmL, lowerLegR …'),
      num('x', 'X', 0, 5), num('y', 'Y', 0, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'rigRotateBone', category: 'rig', label: 'Rotate bone', help: 'Add degrees to a bone’s local rotation (relative).', params: [
      text('bone', 'Bone', 'head', 'head, upperArmL, lowerLegR …'),
      num('x', 'X', 0, 5), num('y', 'Y', 10, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'rigSetBoneScale', category: 'rig', label: 'Set bone scale', help: 'Scale one bone (useful for squash and stretch or cartoon effects).', params: [
      text('bone', 'Bone', 'head'), num('x', 'X', 1, 0.05), num('y', 'Y', 1, 0.05), num('z', 'Z', 1, 0.05), target(),
    ] },
    { id: 'rigResetPose', category: 'rig', label: 'Reset rig pose', help: 'Return every bone of the rig to its rest pose.', params: [target()] },
    { id: 'rigGetBonePosition', category: 'rig', label: 'Get bone world position', help: 'Store the world position of one bone in three variables.', params: [
      text('bone', 'Bone', 'head'),
      text('storeX', 'Store X', 'bx'), text('storeY', 'Store Y', 'by'), text('storeZ', 'Store Z', 'bz'), target(),
    ] },
    { id: 'rigGetBoneRotation', category: 'rig', label: 'Get bone rotation', help: 'Store a bone’s local Euler rotation in three variables.', params: [
      text('bone', 'Bone', 'head'),
      text('storeX', 'Store X', 'rx'), text('storeY', 'Store Y', 'ry'), text('storeZ', 'Store Z', 'rz'), target(),
    ] },
    { id: 'rigGetHeight', category: 'rig', label: 'Get rig height', help: 'Store the measured height of the rig in a variable.', params: [text('store', 'Store in', 'height'), target()] },
    { id: 'rigGetBoneCount', category: 'rig', label: 'Get bone count', help: 'Store how many bones the rig contains.', params: [text('store', 'Store in', 'bones'), target()] },
    { id: 'rigGetClip', category: 'rig', label: 'Get current clip', help: 'Store the name of the clip currently assigned to the rig.', params: [text('store', 'Store in', 'clip'), target()] },
    { id: 'rigHasRig', category: 'rig', label: 'Has rig?', help: 'Store true or false depending on whether the target (or an ancestor) owns an auto-rig.', params: [
      text('store', 'Store in', 'hasRig'), text('eventTrue', 'If true', 'hasRig'), text('eventFalse', 'If false', 'noRig'), target(),
    ] },

    /* ---------------- multiplayer ---------------- */
    { id: 'netConnect', category: 'multiplayer', label: 'Connect to room', help: 'Join the multiplayer room using the local tab transport, a WebSocket relay or WebRTC. Only runs during Play mode.', params: [
      select('transport', 'Transport', [
        { value: 'local', label: 'Local browser tabs' },
        { value: 'postmessage', label: 'Window / iframe bridge' },
        { value: 'webrtc', label: 'WebRTC (manual code)' },
        { value: 'ws', label: 'WebSocket relay' },
      ], 'local'),
      text('room', 'Room', 'My Game'),
      text('url', 'Relay URL', '', 'ws:// or wss:// (WebSocket only)'),
      text('playerName', 'Player name', 'Player'),
    ] },
    { id: 'netDisconnect', category: 'multiplayer', label: 'Disconnect', help: 'Leave the multiplayer room and close the transport.', params: [] },
    { id: 'netIsConnected', category: 'multiplayer', label: 'Is connected?', help: 'Store true or false depending on the connection state, then send a matching event.', params: [
      text('store', 'Store in', 'connected'), text('eventTrue', 'If true', 'online'), text('eventFalse', 'If false', 'offline'),
    ] },
    { id: 'netSendEvent', category: 'multiplayer', label: 'Send network event', help: 'Broadcast a named event with optional text data to every peer.', params: [
      text('event', 'Event', 'ping'), text('data', 'Data', '', 'optional text or JSON'),
    ] },
    { id: 'netRequestSync', category: 'multiplayer', label: 'Request sync', help: 'Ask every peer to resend the state of the objects it owns.', params: [] },
    { id: 'netSendState', category: 'multiplayer', label: 'Push state now', help: 'Immediately send a transform/active/colour snapshot of the objects you own.', params: [] },
    { id: 'netClaim', category: 'multiplayer', label: 'Claim ownership', help: 'Take ownership of a network object. Owners are the peers allowed to drive its transform.', params: [target()] },
    { id: 'netRelease', category: 'multiplayer', label: 'Release ownership', help: 'Give up ownership of a network object.', params: [target()] },
    { id: 'netIsOwner', category: 'multiplayer', label: 'Is owner?', help: 'Store whether this peer owns a network object.', params: [
      text('store', 'Store in', 'isOwner'), text('eventTrue', 'If true', 'owned'), text('eventFalse', 'If false', 'notOwned'), target(),
    ] },
    { id: 'netSpawn', category: 'multiplayer', label: 'Spawn network object', help: 'Replicate an object and its children to every peer, then let them create it in their scene.', params: [target()] },
    { id: 'netDespawn', category: 'multiplayer', label: 'Despawn network object', help: 'Remove a replicated object on every peer.', params: [target()] },
    { id: 'netPeerCount', category: 'multiplayer', label: 'Get peer count', help: 'Store how many remote peers are currently connected.', params: [text('store', 'Store in', 'peers')] },
    { id: 'netGetPeerId', category: 'multiplayer', label: 'Get my peer id', help: 'Store the unique id of this tab/peer.', params: [text('store', 'Store in', 'peerId')] },
    { id: 'netGetOwner', category: 'multiplayer', label: 'Get object owner', help: 'Store the peer id that owns a network object (empty when unowned).', params: [text('store', 'Store in', 'owner'), target()] },
    { id: 'netGetRoom', category: 'multiplayer', label: 'Get room name', help: 'Store the current multiplayer room name.', params: [text('store', 'Store in', 'room')] },
    { id: 'netGetTransport', category: 'multiplayer', label: 'Get transport', help: 'Store the active transport: local, webrtc or ws.', params: [text('store', 'Store in', 'transport')] },
    { id: 'netGetStatus', category: 'multiplayer', label: 'Get network status', help: 'Store a human-readable connection status line.', params: [text('store', 'Store in', 'netStatus')] },
    { id: 'netSetPlayerName', category: 'multiplayer', label: 'Set player name', help: 'Change the display name broadcast to peers.', params: [text('name', 'Name', 'Player')] },
    { id: 'netClaimPlayer', category: 'multiplayer', label: 'Claim player object', help: 'Claim the scene’s Player Object (Window → Multiplayer) as this peer’s avatar.', params: [] },
    { id: 'netGetLastEvent', category: 'multiplayer', label: 'Get last network event', help: 'Store the newest event received from a peer.', params: [
      text('storeName', 'Store event', 'netEvent'), text('storeData', 'Store data', 'netData'), text('storeFrom', 'Store sender', 'netFrom'),
    ] },

    /* ---------------- storage / player prefs ---------------- */
    { id: 'prefSetFloat', category: 'storage', label: 'Save float', help: 'Store a decimal in browser storage under a key (like PlayerPrefs.SetFloat).', params: [
      text('key', 'Key', 'volume'), num('value', 'Value', 1, 0.1),
    ] },
    { id: 'prefGetFloat', category: 'storage', label: 'Load float', help: 'Read a decimal from browser storage, with a fallback when the key is missing.', params: [
      text('key', 'Key', 'volume'), text('store', 'Store in', 'volume'), num('fallback', 'Fallback', 0, 0.1),
    ] },
    { id: 'prefSetInt', category: 'storage', label: 'Save integer', help: 'Store a whole number in browser storage.', params: [
      text('key', 'Key', 'level'), num('value', 'Value', 1, 1),
    ] },
    { id: 'prefGetInt', category: 'storage', label: 'Load integer', help: 'Read a whole number from browser storage.', params: [
      text('key', 'Key', 'level'), text('store', 'Store in', 'level'), num('fallback', 'Fallback', 0, 1),
    ] },
    { id: 'prefSetString', category: 'storage', label: 'Save text', help: 'Store a text value in browser storage.', params: [
      text('key', 'Key', 'playerName'), text('value', 'Value', 'Hero'),
    ] },
    { id: 'prefGetString', category: 'storage', label: 'Load text', help: 'Read a text value from browser storage.', params: [
      text('key', 'Key', 'playerName'), text('store', 'Store in', 'playerName'), text('fallback', 'Fallback', ''),
    ] },
    { id: 'prefSetBool', category: 'storage', label: 'Save flag', help: 'Store a true/false flag in browser storage.', params: [
      text('key', 'Key', 'musicOn'), bool('value', 'Value', true),
    ] },
    { id: 'prefGetBool', category: 'storage', label: 'Load flag', help: 'Read a true/false flag from browser storage.', params: [
      text('key', 'Key', 'musicOn'), text('store', 'Store in', 'musicOn'), bool('fallback', 'Fallback', false),
    ] },
    { id: 'prefHasKey', category: 'storage', label: 'Has saved key?', help: 'Store whether a PlayerPrefs key exists.', params: [
      text('key', 'Key', 'level'), text('store', 'Store in', 'hasKey'),
    ] },
    { id: 'prefDeleteKey', category: 'storage', label: 'Delete saved key', help: 'Remove one PlayerPrefs key.', params: [text('key', 'Key', 'level')] },
    { id: 'prefDeleteAll', category: 'storage', label: 'Delete all saved keys', help: 'Remove every key written by the Save/Load actions.', params: [] },
    { id: 'prefGetKeys', category: 'storage', label: 'List saved keys', help: 'Store a comma-separated list of every PlayerPrefs key.', params: [text('store', 'Store in', 'keys')] },
    { id: 'storeLocalSet', category: 'storage', label: 'LocalStorage set', help: 'Write any text value to localStorage (larger and more general than PlayerPrefs).', params: [
      text('key', 'Key', 'savegame'), text('value', 'Value', '{"level":1}'),
    ] },
    { id: 'storeLocalGet', category: 'storage', label: 'LocalStorage get', help: 'Read any text value from localStorage.', params: [
      text('key', 'Key', 'savegame'), text('store', 'Store in', 'savegame'), text('fallback', 'Fallback', ''),
    ] },
    { id: 'storeLocalDelete', category: 'storage', label: 'LocalStorage delete', help: 'Remove one localStorage key.', params: [text('key', 'Key', 'savegame')] },
    { id: 'storeSessionSet', category: 'storage', label: 'Session set', help: 'Write a value for this browser tab only (sessionStorage).', params: [
      text('key', 'Key', 'tabScore'), text('value', 'Value', '0'),
    ] },
    { id: 'storeSessionGet', category: 'storage', label: 'Session get', help: 'Read a value written with Session set.', params: [
      text('key', 'Key', 'tabScore'), text('store', 'Store in', 'tabScore'), text('fallback', 'Fallback', ''),
    ] },
    { id: 'storeSessionDelete', category: 'storage', label: 'Session delete', help: 'Remove one sessionStorage key.', params: [text('key', 'Key', 'tabScore')] },

    /* ---------------- input ---------------- */
    { id: 'isKeyHeld', category: 'input', label: 'Is key held', help: 'Store true while a key is held down (use “Space”, “a”, “ArrowUp” …).', params: [
      text('key', 'Key', 'Space', 'Space, a, ArrowUp …'), text('store', 'Store in', 'held'),
    ] },
    { id: 'isKeyDown', category: 'input', label: 'Key pressed this frame', help: 'Store true only on the frame a key goes down.', params: [
      text('key', 'Key', 'Space'), text('store', 'Store in', 'pressed'),
    ] },
    { id: 'isKeyUp', category: 'input', label: 'Key released this frame', help: 'Store true only on the frame a key goes up.', params: [
      text('key', 'Key', 'Space'), text('store', 'Store in', 'released'),
    ] },
    { id: 'getAxis', category: 'input', label: 'Get key axis', help: 'Store −1, 0 or 1 from a negative/positive key pair (for example A and D).', params: [
      text('negative', 'Negative key', 'A'), text('positive', 'Positive key', 'D'), text('store', 'Store in', 'moveX'),
    ] },
    { id: 'getMousePosition', category: 'input', label: 'Get mouse position', help: 'Store the pointer position normalised to the viewport (0–1).', params: [
      text('storeX', 'Store X', 'mouseX'), text('storeY', 'Store Y', 'mouseY'),
    ] },
    { id: 'getMouseWorld', category: 'input', label: 'Mouse to world point', help: 'Project the pointer onto a horizontal plane and store the world point.', params: [
      num('planeY', 'Plane Y', 0, 0.1),
      text('storeX', 'Store X', 'worldX'), text('storeY', 'Store Y', 'worldY'), text('storeZ', 'Store Z', 'worldZ'),
    ] },
    { id: 'isMouseDown', category: 'input', label: 'Is mouse button down', help: 'Store whether a mouse button is currently held.', params: [
      select('button', 'Button', [{ value: '0', label: 'Left' }, { value: '1', label: 'Middle' }, { value: '2', label: 'Right' }], '0'),
      text('store', 'Store in', 'mouseDown'),
    ] },
    { id: 'getMouseScroll', category: 'input', label: 'Get mouse wheel', help: 'Store the wheel movement accumulated since the last frame.', params: [
      text('store', 'Store in', 'scroll'),
    ] },
    { id: 'getTouchCount', category: 'input', label: 'Get touch count', help: 'Store how many fingers are on the screen.', params: [text('store', 'Store in', 'touches')] },
    { id: 'getTouchPosition', category: 'input', label: 'Get touch position', help: 'Store one touch position normalised to the viewport.', params: [
      num('index', 'Touch index', 0, 1, 0, 9), text('storeX', 'Store X', 'tx'), text('storeY', 'Store Y', 'ty'),
    ] },
    { id: 'isAnyKey', category: 'input', label: 'Is any key held?', help: 'Store true when at least one key is down.', params: [text('store', 'Store in', 'anyKey')] },
    { id: 'setCursorVisible', category: 'input', label: 'Show / hide cursor', help: 'Hide or show the mouse cursor over the viewport.', params: [bool('visible', 'Cursor visible', true)] },

    /* ---------------- time ---------------- */
    { id: 'getTime', category: 'time', label: 'Get time', help: 'Store the scaled time elapsed since Play started.', params: [text('store', 'Store in', 'time')] },
    { id: 'getDeltaTime', category: 'time', label: 'Get delta time', help: 'Store the time scale–adjusted frame duration in seconds.', params: [text('store', 'Store in', 'dt')] },
    { id: 'getUnscaledDeltaTime', category: 'time', label: 'Get unscaled delta time', help: 'Store the real frame duration, ignoring time scale.', params: [text('store', 'Store in', 'rawDt')] },
    { id: 'getFrameCount', category: 'time', label: 'Get frame count', help: 'Store how many frames have run since Play started.', params: [text('store', 'Store in', 'frames')] },
    { id: 'getRealTime', category: 'time', label: 'Get real time', help: 'Store the current Unix timestamp in milliseconds.', params: [text('store', 'Store in', 'now')] },
    { id: 'setTimeScale', category: 'time', label: 'Set time scale', help: 'Slow down or speed up the simulation (0 freezes it, 1 is normal).', params: [
      num('value', 'Time scale', 1, 0.05, 0, 8),
    ] },
    { id: 'getTimeScale', category: 'time', label: 'Get time scale', help: 'Store the current simulation time scale.', params: [text('store', 'Store in', 'timeScale')] },
    { id: 'getFps', category: 'time', label: 'Get FPS', help: 'Store the smoothed frames-per-second reading of the runtime.', params: [text('store', 'Store in', 'fps')] },

    /* ---------------- vector & math ---------------- */
    { id: 'vecSet', category: 'vector', label: 'Set vector', help: 'Write X/Y/Z components into three variables named <em>prefix</em>X, <em>prefix</em>Y and <em>prefix</em>Z.', params: [
      text('out', 'Result prefix', 'v'), num('x', 'X', 0, 0.1), num('y', 'Y', 0, 0.1), num('z', 'Z', 0, 0.1),
    ] },
    { id: 'vecAdd', category: 'vector', label: 'Add vectors', help: 'Result = A + B (component-wise). Prefixes read and write <em>prefix</em>X/Y/Z variables.', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecSub', category: 'vector', label: 'Subtract vectors', help: 'Result = A − B (component-wise).', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecMul', category: 'vector', label: 'Multiply vectors', help: 'Result = A × B (component-wise).', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecScale', category: 'vector', label: 'Scale vector', help: 'Result = A × scalar.', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), num('scalar', 'Scalar', 2, 0.1),
    ] },
    { id: 'vecDot', category: 'vector', label: 'Dot product', help: 'Store A · B as a single number.', params: [
      text('out', 'Store in', 'dot'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecCross', category: 'vector', label: 'Cross product', help: 'Result = A × B (cross product).', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecLength', category: 'vector', label: 'Vector length', help: 'Store the length (magnitude) of A.', params: [
      text('out', 'Store in', 'length'), text('a', 'A prefix', 'a'),
    ] },
    { id: 'vecNormalize', category: 'vector', label: 'Normalize vector', help: 'Result = A scaled to unit length.', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'),
    ] },
    { id: 'vecDistance', category: 'vector', label: 'Distance between vectors', help: 'Store the distance between points A and B.', params: [
      text('out', 'Store in', 'distance'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'),
    ] },
    { id: 'vecLerp', category: 'vector', label: 'Lerp vectors', help: 'Result = A + (B − A) × t.', params: [
      text('out', 'Result prefix', 'v'), text('a', 'A prefix', 'a'), text('b', 'B prefix', 'b'), num('t', 'T', 0.5, 0.05, 0, 1),
    ] },
    { id: 'vecToAngles', category: 'vector', label: 'Vector to angles', help: 'Convert a direction vector into yaw/pitch (degrees) in three variables.', params: [
      text('out', 'Result prefix', 'angles'), text('a', 'Direction prefix', 'dir'),
    ] },

    /* ---------------- UI & browser ---------------- */
    { id: 'setElementText', category: 'ui', label: 'Set page text', help: 'Set the textContent of a DOM element by CSS selector. Useful for HTML HUD elements around the canvas.', params: [
      text('selector', 'Selector', '#hud-score', 'CSS selector'), text('value', 'Text', 'Score: 0'),
    ] },
    { id: 'setElementHtml', category: 'ui', label: 'Set page HTML', help: 'Replace the innerHTML of a DOM element by CSS selector.', params: [
      text('selector', 'Selector', '#hud', 'CSS selector'), text('value', 'HTML', '<b>Hello</b>'),
    ] },
    { id: 'setElementColor', category: 'ui', label: 'Set element colour', help: 'Set the text colour of a DOM element.', params: [
      text('selector', 'Selector', '#hud-score'), color('color', 'Color', '#ffffff'),
    ] },
    { id: 'setElementVisible', category: 'ui', label: 'Show / hide element', help: 'Toggle display of a DOM element by CSS selector.', params: [
      text('selector', 'Selector', '#hud'), bool('visible', 'Visible', true),
    ] },
    { id: 'setElementStyle', category: 'ui', label: 'Set element style', help: 'Set one inline CSS property on a DOM element.', params: [
      text('selector', 'Selector', '#hud'), text('property', 'Property', 'opacity'), text('value', 'Value', '0.5'),
    ] },
    { id: 'setPageTitle', category: 'ui', label: 'Set page title', help: 'Change the browser tab title (handy for high scores and alerts).', params: [text('title', 'Title', 'WebForge 3D')] },

    /* ---------------- rebindable input & gamepad ---------------- */
    { id: 'isActionDown', category: 'input', label: 'Is action pressed', help: 'Store true while a mapped action is held. Actions: moveForward, moveBack, moveLeft, moveRight, jump, fire, interact, sprint, crouch, pause, cameraToggle, reload. Keyboard and gamepad both work.', params: [
      text('action', 'Action', 'jump', 'moveForward / jump / fire …'), text('store', 'Store in', 'pressed'),
    ] },
    { id: 'isActionPressed', category: 'input', label: 'Action pressed this frame', help: 'Store true only on the frame a mapped action goes down (keyboard or gamepad button / stick).', params: [
      text('action', 'Action', 'jump'), text('store', 'Store in', 'pressedNow'),
    ] },
    { id: 'getActionValue', category: 'input', label: 'Get action value', help: 'Store an analog value from 0 to 1 for a mapped action (triggers and sticks report partial values).', params: [
      text('action', 'Action', 'fire'), text('store', 'Store in', 'value'),
    ] },
    { id: 'getInputAxis', category: 'input', label: 'Get input axis', help: 'Store a combined keyboard + controller axis. Axes: moveX, moveY, lookX, lookY.', params: [
      select('axis', 'Axis', [
        { value: 'moveX', label: 'Move X (strafe)' },
        { value: 'moveY', label: 'Move Y (forward)' },
        { value: 'lookX', label: 'Look X' },
        { value: 'lookY', label: 'Look Y' },
      ], 'moveX'),
      text('store', 'Store in', 'axisX'),
    ] },
    { id: 'isGamepadConnected', category: 'input', label: 'Is gamepad connected', help: 'Store whether a controller is currently available through the Gamepad API.', params: [text('store', 'Store in', 'pad')] },
    { id: 'getGamepadButton', category: 'input', label: 'Get gamepad button', help: 'Store true when the button index is pressed. Standard mapping: 0 A/Cross, 1 B/Circle, 2 X/Square, 3 Y/Triangle, 4 LB, 5 RB, 6 LT, 7 RT, 8 Back, 9 Start.', params: [
      num('index', 'Button index', 0, 1, 0, 19), text('store', 'Store in', 'padButton'),
    ] },
    { id: 'getGamepadTrigger', category: 'input', label: 'Get trigger value', help: 'Store the analog value (0–1) of the left or right trigger.', params: [
      select('side', 'Trigger', [{ value: 'left', label: 'Left (LT / L2)' }, { value: 'right', label: 'Right (RT / R2)' }], 'right'),
      text('store', 'Store in', 'trigger'),
    ] },
    { id: 'vibrateGamepad', category: 'input', label: 'Vibrate gamepad', help: 'Rumble the connected controller when the browser supports the vibration actuator.', params: [
      num('strength', 'Strength', 0.6, 0.1, 0, 1), num('duration', 'Duration (ms)', 220, 50, 10, 5000),
    ] },
    { id: 'rebindAction', category: 'input', label: 'Rebind action (prompt)', help: 'Ask the player to press a key, then bind that key to the action in the settings map (saved in the browser).', params: [
      text('action', 'Action', 'jump'),
    ] },

    /* ---------------- Unity UI elements ---------------- */
    { id: 'uiSetText', category: 'ui', label: 'UI: set text', help: 'Set the text of a Canvas UI element by name or id. Works for Text, Button, Input and Dropdown labels.', params: [
      text('ref', 'UI element', 'Score Text', 'name or id'), text('value', 'Text', 'SCORE 10'),
    ] },
    { id: 'uiSetValue', category: 'ui', label: 'UI: set value', help: 'Set the numeric value of a Slider or Progress Bar.', params: [
      text('ref', 'UI element', 'Health Bar'), num('value', 'Value', 50, 1),
    ] },
    { id: 'uiGetValue', category: 'ui', label: 'UI: get value', help: 'Store the current value of a UI element (text, number, checked state or selected option).', params: [
      text('ref', 'UI element', 'Name Input'), text('store', 'Store in', 'uiValue'),
    ] },
    { id: 'uiSetChecked', category: 'ui', label: 'UI: set toggle', help: 'Turn a Toggle element on or off.', params: [
      text('ref', 'UI element', 'Sound Toggle'), bool('checked', 'Checked', true),
    ] },
    { id: 'uiSetVisible', category: 'ui', label: 'UI: show / hide', help: 'Show or hide a Canvas UI element by name or id.', params: [
      text('ref', 'UI element', 'Score Text'), bool('visible', 'Visible', true),
    ] },
    { id: 'uiClick', category: 'ui', label: 'UI: click element', help: 'Fire the click event / transition of a Button programmatically.', params: [
      text('ref', 'UI element', 'Play Button'),
    ] },
    { id: 'uiSetProgress', category: 'ui', label: 'UI: set progress', help: 'Set a Progress Bar fill from 0 to 100 percent.', params: [
      text('ref', 'UI element', 'Loading Bar'), num('percent', 'Percent', 50, 1, 0, 100),
    ] },
    { id: 'uiSetColor', category: 'ui', label: 'UI: set colour', help: 'Set the text colour of a UI element.', params: [
      text('ref', 'UI element', 'Title'), color('color', 'Color', '#ffffff'),
    ] },
    { id: 'uiSetOpacity', category: 'ui', label: 'UI: set opacity', help: 'Fade any Canvas UI element.', params: [
      text('ref', 'UI element', 'HUD Panel'), num('opacity', 'Opacity', 0.5, 0.05, 0, 1),
    ] },
    { id: 'uiSetInteractable', category: 'ui', label: 'UI: set interactable', help: 'Enable or disable clicks and typing on a UI element.', params: [
      text('ref', 'UI element', 'Play Button'), bool('interactable', 'Interactable', true),
    ] },

    /* ---------------- second camera & scene changer ---------------- */
    { id: 'setSecondCamera', category: 'camera', label: 'Second camera: set', help: 'Configure the in-game picture-in-picture camera (the first camera object flagged as Secondary).', params: [
      bool('enabled', 'Show PiP', true),
      select('corner', 'Corner', [
        { value: 'topLeft', label: 'Top left' }, { value: 'topRight', label: 'Top right' },
        { value: 'bottomLeft', label: 'Bottom left' }, { value: 'bottomRight', label: 'Bottom right' },
      ], 'bottomRight'),
      num('width', 'Width', 320, 10, 120, 960), num('height', 'Height', 200, 10, 80, 640),
    ] },
    { id: 'toggleSecondCamera', category: 'camera', label: 'Second camera: toggle', help: 'Show or hide the picture-in-picture preview and store the new state.', params: [
      text('store', 'Store in', 'pipVisible'),
    ] },
    { id: 'showSceneMenu', category: 'scene', label: 'Scene changer: show / hide', help: 'Show or hide the in-game Scene Changer menu (the first object with a Scene Changer component).', params: [
      bool('visible', 'Visible', true),
    ] },
    { id: 'sceneChangerAdd', category: 'scene', label: 'Scene changer: add scene', help: 'Append a scene name to the in-game scene menu.', params: [
      text('scene', 'Scene name', 'Sample Scene'),
    ] },

    /* ---------------- Audio Source objects ---------------- */
    { id: 'playSource', category: 'audio', label: 'Audio: play source', help: 'Play an Audio Source object by name or id.', params: [
      text('target', 'Audio source', 'Audio Source', 'name or id'),
    ] },
    { id: 'stopSource', category: 'audio', label: 'Audio: stop source', help: 'Stop an Audio Source object by name or id.', params: [
      text('target', 'Audio source', 'Audio Source'),
    ] },
    { id: 'setSourceVolume', category: 'audio', label: 'Audio: set volume', help: 'Change the volume of an Audio Source and restart it if it is playing.', params: [
      text('target', 'Audio source', 'Audio Source'), num('volume', 'Volume', 0.5, 0.05, 0, 1),
    ] },
    { id: 'isSourcePlaying', category: 'audio', label: 'Audio: is playing?', help: 'Store true when an Audio Source is currently playing.', params: [
      text('target', 'Audio source', 'Audio Source'), text('store', 'Store in', 'playing'),
    ] },
  ];

  const TRIGGER_TYPES = [
    { id: 'auto', label: 'After delay' },
    { id: 'event', label: 'On event' },
    { id: 'key', label: 'While key held' },
    { id: 'keyDown', label: 'On key down' },
    { id: 'keyUp', label: 'On key up' },
    { id: 'variable', label: 'On variable' },
  ];
  const OPS = ['==', '!=', '>', '<', '>=', '<='];

  F.categories = CATEGORIES;
  F.actionTypes = ACTION_TYPES;
  F.triggerTypes = TRIGGER_TYPES;
  F.easings = EASINGS;
  F.ops = OPS;
  F.uid = uid;

  F.categoryMeta = (id) => CATEGORIES.find((c) => c.id === id) || CATEGORIES[0];
  F.actionMeta = (id) => ACTION_TYPES.find((a) => a.id === id) || ACTION_TYPES[0];
  F.triggerMeta = (id) => TRIGGER_TYPES.find((t) => t.id === id) || TRIGGER_TYPES[0];

  F.actionsInCategory = function (id) {
    return ACTION_TYPES.filter((a) => a.category === id);
  };

  /* Search helper used by the Action Library browser and the docs. */
  F.searchActions = function (query, category) {
    const q = String(query == null ? '' : query).trim().toLowerCase();
    const terms = q ? q.split(/\s+/) : [];
    return ACTION_TYPES.filter((a) => {
      if (category && a.category !== category) return false;
      if (!terms.length) return true;
      const hay = [
        a.label, a.id, a.help || '', a.category,
        (a.params || []).map((p) => (p.label || '') + ' ' + (p.key || '') + ' ' + (p.help || '')).join(' '),
      ].join(' ').toLowerCase();
      return terms.every((term) => hay.indexOf(term) >= 0);
    });
  };
  F.actionCount = ACTION_TYPES.length;

  F.defaultActionParams = function (type) {
    const meta = F.actionMeta(type);
    const out = {};
    for (const p of meta.params) out[p.key] = p.def;
    return out;
  };

  F.defaultAction = function (type) {
    const id = type || 'log';
    return { type: id, params: F.defaultActionParams(id) };
  };

  F.defaultState = function (name, x, y) {
    return {
      id: uid('s'),
      name: name || 'New State',
      x: x != null ? x : 40,
      y: y != null ? y : 60,
      actions: [],
    };
  };

  F.defaultTransition = function (from, to) {
    return {
      id: uid('t'),
      from: from || null,
      to: to || null,
      trigger: 'auto',
      delay: 1,
      event: 'done',
      key: 'Space',
      variable: '',
      op: '==',
      value: '',
    };
  };

  F.defaults = function () {
    const s = F.defaultState('Idle', 46, 62);
    return {
      enabled: true,
      start: s.id,
      states: [s],
      transitions: [],
      variables: [{ name: 'score', value: '0' }],
    };
  };

  F.state = (fsm, id) => (fsm && fsm.states ? fsm.states.find((s) => s.id === id) : null);

  const validColor = (v) => typeof v === 'string' && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim());

  F.normalize = function (fsm) {
    if (!fsm || typeof fsm !== 'object' || !Array.isArray(fsm.states)) return null;
    const seen = new Set();
    fsm.states = fsm.states.map((s, i) => {
      const st = {
        id: s && s.id && !seen.has(s.id) ? s.id : uid('s'),
        name: (s && s.name) || 'State ' + (i + 1),
        x: Number.isFinite(s && s.x) ? Math.max(0, Math.min(4000, s.x)) : 40 + (i % 4) * 190,
        y: Number.isFinite(s && s.y) ? Math.max(0, Math.min(3000, s.y)) : 60 + Math.floor(i / 4) * 110,
        actions: Array.isArray(s && s.actions) ? s.actions : [],
      };
      seen.add(st.id);
      st.actions = st.actions.map((a) => {
        const known = a && ACTION_TYPES.some((x) => x.id === a.type);
        const type = known ? a.type : 'log';
        const meta = F.actionMeta(type);
        const params = Object.assign({}, F.defaultActionParams(type), (a && a.params) || {});
        for (const p of meta.params) {
          const v = params[p.key];
          if (p.type === 'number') {
            let v2 = +v;
            if (!Number.isFinite(v2)) v2 = +p.def;
            if (!Number.isFinite(v2)) v2 = 0;
            if (p.min != null) v2 = Math.max(p.min, v2);
            if (p.max != null) v2 = Math.min(p.max, v2);
            params[p.key] = v2;
          } else if (p.type === 'bool') {
            params[p.key] = v !== false && v !== 'false' && v !== 0 && v !== '0';
          } else if (p.type === 'color') {
            params[p.key] = validColor(v) ? v : p.def;
          } else if (p.type === 'select') {
            const ok = (p.options || []).some((o) => o.value === v);
            params[p.key] = ok ? v : p.def;
          } else {
            params[p.key] = v != null ? String(v) : p.def;
          }
        }
        return { type, params };
      });
      return st;
    });
    if (!fsm.states.length) fsm.states.push(F.defaultState('Idle', 46, 62));
    const ids = new Set(fsm.states.map((s) => s.id));
    if (!fsm.start || !ids.has(fsm.start)) fsm.start = fsm.states[0].id;

    fsm.transitions = (Array.isArray(fsm.transitions) ? fsm.transitions : []).filter(
      (t) => t && ids.has(t.from) && ids.has(t.to)
    ).map((t) => ({
      id: t.id || uid('t'),
      from: t.from,
      to: t.to,
      trigger: TRIGGER_TYPES.some((x) => x.id === t.trigger) ? t.trigger : 'auto',
      delay: Number.isFinite(t.delay) ? t.delay : 1,
      event: t.event || 'done',
      key: t.key || 'Space',
      variable: t.variable || '',
      op: OPS.indexOf(t.op) >= 0 ? t.op : '==',
      value: t.value != null ? String(t.value) : '',
    }));
    const tseen = new Set();
    for (const t of fsm.transitions) {
      if (tseen.has(t.id)) t.id = uid('t');
      tseen.add(t.id);
    }

    fsm.variables = (Array.isArray(fsm.variables) ? fsm.variables : []).map((v) => ({
      name: (v && v.name) || 'var',
      value: v && v.value != null ? String(v.value) : '0',
    }));
    fsm.enabled = fsm.enabled !== false;
    return fsm;
  };

  F.summary = function (fsm) {
    if (!fsm) return 'not configured';
    return (fsm.states ? fsm.states.length : 0) + ' states · ' +
      (fsm.transitions ? fsm.transitions.length : 0) + ' transitions';
  };

  /* ---------------- comparison / value helpers ---------------- */
  function toNumber(v) {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : null;
  }

  function compare(a, b, op) {
    const na = toNumber(a);
    const nb = toNumber(b);
    const x = na != null && nb != null ? na : String(a);
    const y = na != null && nb != null ? nb : String(b);
    switch (op) {
      case '!=': return x !== y;
      case '>': return x > y;
      case '<': return x < y;
      case '>=': return x >= y;
      case '<=': return x <= y;
      default: return x === y;
    }
  }
  F.compare = compare;

  const n = (v, d) => {
    const x = parseFloat(v);
    return Number.isFinite(x) ? x : (d == null ? 0 : d);
  };
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  function ease(name, t) {
    t = clamp(t, 0, 1);
    switch (name) {
      case 'linear': return t;
      case 'easeIn': return t * t * t;
      case 'easeOut': return 1 - Math.pow(1 - t, 3);
      default: return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }
  }

  function findNode(runtime, ref) {
    const ed = runtime.editor;
    const key = String(ref == null ? '' : ref).trim();
    if (!key || key.toLowerCase() === 'self') return null;
    return ed.scene.nodes.find((x) => x.id === key || x.name === key) || null;
  }

  function actionTarget(node, runtime, p) {
    const ref = String((p && p.target) || 'self').trim();
    if (!ref || ref.toLowerCase() === 'self') return node;
    if (ref.toLowerCase() === 'parent') return node.parent ? runtime.editor.node(node.parent) : null;
    return findNode(runtime, ref);
  }

  function cameraFor(node, runtime, p) {
    const hit = actionTarget(node, runtime, p);
    if (hit && hit.type === 'camera' && hit.camera) return hit;
    return runtime.editor.scene.nodes.find((x) => x.type === 'camera' && x.visible && x.camera) || null;
  }

  function textureFor(node, create) {
    if (!node || !node.mesh) return null;
    let tex = UW.textures.normalize(node.mesh.texture);
    if (!tex && create) tex = UW.textures.defaultTexture('checker');
    if (tex) node.mesh.texture = tex;
    return tex;
  }

  function bodyFor(runtime, node) {
    return runtime.bodies.find((b) => b.node === node) || null;
  }

  function runnerFor(runtime, node, create) {
    let runner = runtime.fsmRunners.find((r) => r.node === node);
    if (!runner && create && typeof runtime.spawnRunner === 'function') {
      runner = runtime.spawnRunner(node);
    }
    return runner || null;
  }

  /* ---------------- tween helpers ---------------- */
  function vectorTween(node, key, to, durationSeconds, easingName, relative) {
    const from = node.transform[key].slice();
    const target = relative ? [from[0] + to[0], from[1] + to[1], from[2] + to[2]] : to.slice();
    if (key === 'rotation' && !relative) {
      for (let i = 0; i < 3; i++) {
        let delta = ((target[i] - from[i] + 540) % 360) - 180;
        target[i] = from[i] + delta;
      }
    }
    const seconds = Math.max(0.001, n(durationSeconds, 1));
    const tw = {
      node,
      kind: key,
      elapsed: 0,
      done: false,
      cancelled: false,
      update(dt) {
        if (tw.done || tw.cancelled) return;
        tw.elapsed += dt;
        const t = ease(easingName, Math.min(1, tw.elapsed / seconds));
        node.transform[key] = [
          M.lerp(from[0], target[0], t),
          M.lerp(from[1], target[1], t),
          M.lerp(from[2], target[2], t),
        ];
        if (tw.elapsed >= seconds) {
          node.transform[key] = target.slice();
          tw.done = true;
        }
      },
    };
    if (seconds <= 0.001) {
      node.transform[key] = target.slice();
      tw.done = true;
    }
    return tw;
  }

  function lookAtPoint(t, x, y, z) {
    const dx = x - t.position[0];
    const dy = y - t.position[1];
    const dz = z - t.position[2];
    const yaw = Math.atan2(dx, dz) * M.RAD;
    const pitch = -Math.atan2(dy, Math.hypot(dx, dz)) * M.RAD;
    t.rotation = [pitch, yaw, 0];
  }

  /* ---------------- network helpers ---------------- */
  function parseHeaders(raw) {
    const out = {};
    String(raw || '').split(/\r?\n/).forEach((line) => {
      const i = line.indexOf(':');
      if (i <= 0) return;
      const key = line.slice(0, i).trim();
      const val = line.slice(i + 1).trim();
      if (key) out[key] = val;
    });
    return out;
  }

  function requestBody(contentType, body) {
    if (contentType === 'none' || body == null || body === '') return null;
    if (contentType === 'json' || contentType === 'text') return String(body);
    // form: accept both "a=1&b=2" and one "a=1" per line
    return String(body).split(/\r?\n/).filter((l) => l.trim()).join('&');
  }

  function jsonValue(text, path) {
    let data;
    try { data = JSON.parse(text); } catch (e) { return undefined; }
    if (!path) return data;
    const parts = String(path).replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
    let cur = data;
    for (const key of parts) {
      if (cur == null) return undefined;
      cur = cur[key];
    }
    return cur;
  }

  function formatTemplate(template, vars) {
    return String(template == null ? '' : template).replace(/\{([A-Za-z0-9_.-]+)\}/g, (m, key) => (
      vars[key] != null ? String(vars[key]) : ''
    ));
  }

  function emitEventSafe(runtime, name) {
    const evt = String(name == null ? '' : name).trim();
    if (evt) runtime.emitEvent(evt);
  }

  /* ---------------- rig / network / storage / vector helpers ---------------- */
  function rigRootFor(runtime, node) {
    let n = node;
    let guard = 0;
    while (n && guard++ < 64) {
      if (n.rig && n.rig.bones) return n;
      if (n.bone && n.bone.rig) {
        const root = runtime.editor.node(n.bone.rig);
        if (root && root.rig) return root;
      }
      n = n.parent ? runtime.editor.node(n.parent) : null;
    }
    return null;
  }

  function boneNode(scene, root, role) {
    if (!root || !root.rig || !root.rig.bones) return null;
    const id = root.rig.bones[String(role || '').trim()];
    return id ? UW.scene.find(scene, id) : null;
  }

  function ensureNet(runtime) {
    if (runtime.net) return runtime.net;
    if (!UW.Net || typeof UW.Net.createRuntime !== 'function') return null;
    runtime.net = UW.Net.createRuntime(runtime);
    return runtime.net;
  }

  function netNodeFor(runtime, node) {
    if (node && node.network) return node;
    let n = node;
    let guard = 0;
    while (n && guard++ < 64) {
      if (n.network) return n;
      n = n.parent ? runtime.editor.node(n.parent) : null;
    }
    return null;
  }

  const PREF_PREFIX = 'wf3d.prefs.';
  function safeStore(kind) {
    try {
      if (kind === 'session') return window.sessionStorage || null;
      return window.localStorage || null;
    } catch (e) {
      return null;
    }
  }
  function prefKey(kind, key) {
    return kind === 'rawLocal' ? String(key) : (kind === 'rawSession' ? String(key) : PREF_PREFIX + String(key));
  }
  function prefRead(kind, key) {
    const store = safeStore(kind === 'session' || kind === 'rawSession' ? 'session' : 'local');
    if (!store || key == null || key === '') return null;
    try { return store.getItem(prefKey(kind, key)); } catch (e) { return null; }
  }
  function prefWrite(kind, key, value) {
    const store = safeStore(kind === 'session' || kind === 'rawSession' ? 'session' : 'local');
    if (!store || key == null || key === '') return false;
    try {
      store.setItem(prefKey(kind, key), String(value));
      return true;
    } catch (e) {
      runtime_log_storage_error();
      return false;
    }
  }
  function runtime_log_storage_error() {
    try { console.warn('[FSM] Browser storage is full or blocked.'); } catch (e) { /* ignore */ }
  }
  function prefDelete(kind, key) {
    const store = safeStore(kind === 'session' || kind === 'rawSession' ? 'session' : 'local');
    if (!store || key == null || key === '') return false;
    try { store.removeItem(prefKey(kind, key)); return true; } catch (e) { return false; }
  }
  function prefKeys() {
    const store = safeStore('local');
    if (!store) return [];
    const out = [];
    try {
      for (let i = 0; i < store.length; i++) {
        const key = store.key(i);
        if (key && key.indexOf(PREF_PREFIX) === 0) out.push(key.slice(PREF_PREFIX.length));
      }
    } catch (e) { /* ignore */ }
    return out;
  }

  function varNum(runner, key) {
    const x = parseFloat(runner.vars[key]);
    return Number.isFinite(x) ? x : 0;
  }
  function vecRead(runner, prefix) {
    const p = String(prefix == null || prefix === '' ? 'v' : prefix).trim();
    return [varNum(runner, p + 'X'), varNum(runner, p + 'Y'), varNum(runner, p + 'Z')];
  }
  function vecWrite(runner, prefix, v) {
    const p = String(prefix == null || prefix === '' ? 'v' : prefix).trim();
    runner.vars[p + 'X'] = String(M.round(v[0], 5));
    runner.vars[p + 'Y'] = String(M.round(v[1], 5));
    runner.vars[p + 'Z'] = String(M.round(v[2], 5));
  }
  function qs(selector) {
    try {
      const sel = String(selector == null ? '' : selector).trim();
      return sel ? document.querySelector(sel) : null;
    } catch (e) {
      return null;
    }
  }
  function isReadableBackup(kind, key) {
    return !!prefRead(kind, key);
  }

  /* ---------------- runtime runner ---------------- */
  F.createRunner = function (node, runtime, force) {
    const fsm = F.normalize(node.fsm);
    if (!fsm || (!fsm.enabled && !force)) return null;
    const ed = runtime.editor;
    const vars = {};
    for (const v of fsm.variables) vars[v.name] = v.value;

    const runner = {
      node,
      fsm,
      vars,
      current: fsm.start,
      stateTime: 0,
      entered: false,
      active: false,
      queue: [],
      wait: 0,
      waitTween: null,
      waitRequest: null,
      tweens: [],
      _pumping: false,
      _restart: false,

      start() {
        if (this._pumping) { this._restart = true; return; }
        this.active = true;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.stopTweens();
        this.stateTime = 0;
        this.enter(fsm.start);
      },

      stop() {
        this.active = false;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.stopTweens();
      },

      stopTweens() {
        for (const tw of this.tweens) { tw.cancelled = true; tw.done = true; }
        this.tweens.length = 0;
        this.waitTween = null;
      },

      enter(id) {
        const st = F.state(fsm, id);
        if (!st) return;
        this.current = id;
        this.stateTime = 0;
        this.entered = true;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.queue = st.actions.slice();
        this.pump(0);
      },

      pump(dt) {
        if (!this.active || this._pumping) return;
        this._pumping = true;
        let guard = 0;
        while (this.active && this.queue.length && guard++ < 512) {
          if (this.waitRequest) {
            if (!this.waitRequest.settled) break;
            this.waitRequest = null;
          }
          if (this.waitTween) {
            if (!this.waitTween.done) break;
            this.waitTween = null;
          }
          if (this.wait > 0) {
            this.wait -= dt;
            if (this.wait > 0) break;
            this.wait = 0;
          }
          const action = this.queue.shift();
          let res = null;
          try {
            res = F.runAction(action, node, runtime, this);
          } catch (err) {
            ed.log('error', '[FSM] ' + node.name + ': action "' + action.type + '" failed — ' + (err && err.message ? err.message : err));
          }
          if (res && res.wait != null) {
            this.wait = Math.max(0, n(res.wait, 0));
            if (this.wait > 0) break;
          }
          if (res && res.request) {
            if (res.block && !res.request.settled) {
              this.waitRequest = res.request;
              break;
            }
          }
          if (res && res.tween) {
            const tw = res.tween;
            for (const old of this.tweens) {
              if (old.node === tw.node && old.kind === tw.kind) {
                old.cancelled = true;
                old.done = true;
              }
            }
            this.tweens.push(tw);
            if (res.block && !tw.done) {
              this.waitTween = tw;
              break;
            }
          }
        }
        this._pumping = false;
        if (this._restart) {
          this._restart = false;
          this.start();
        }
      },

      updateTweens(dt) {
        for (const tw of this.tweens) {
          if (!tw.done && !tw.cancelled) tw.update(dt);
        }
        this.tweens = this.tweens.filter((tw) => !tw.done || tw === this.waitTween);
      },

      update(dt) {
        if (!this.active) return;
        this.stateTime += dt;
        this.updateTweens(dt);
        this.pump(dt);
        if (!this.active) return;
        const list = fsm.transitions.filter((t) => t.from === this.current);
        for (const tr of list) {
          if (!this.ready(tr)) continue;
          if (tr.trigger === 'event') this.consumeEvent(tr.event);
          this.enter(tr.to);
          break;
        }
      },

      ready(tr) {
        if (tr.trigger === 'auto') return this.stateTime >= (Number(tr.delay) || 0);
        if (tr.trigger === 'event') return this.hasEvent(tr.event);
        if (tr.trigger === 'key') return runtime.pressedKeys.has(tr.key);
        if (tr.trigger === 'keyDown') return runtime.keysDown.has(tr.key);
        if (tr.trigger === 'keyUp') return runtime.keysUp.has(tr.key);
        if (tr.trigger === 'variable') {
          if (!tr.variable) return false;
          return compare(this.vars[tr.variable], tr.value, tr.op);
        }
        return false;
      },

      hasEvent(name) {
        for (const e of runtime.fsmEvents) {
          if (e.name === name && !e.taken.has(this)) return true;
        }
        return false;
      },

      consumeEvent(name) {
        for (const e of runtime.fsmEvents) {
          if (e.name === name && !e.taken.has(this)) {
            e.taken.add(this);
            return;
          }
        }
      },

      event(name) {
        /* events are read from the runtime queue each frame */
      },
    };

    return runner;
  };

  /* ---------------- actions ---------------- */
  F.runAction = function (action, node, runtime, runner) {
    const p = action.params || {};
    const ed = runtime.editor;
    const t = node.transform;
    const getTarget = () => actionTarget(node, runtime, p) || node;

    switch (action.type) {
      case 'log': {
        const level = p.level === 'warn' || p.level === 'error' ? p.level : 'info';
        ed.log(level, '[FSM] ' + node.name + ': ' + (p.message || ''));
        break;
      }
      case 'wait':
        return { wait: Math.max(0.01, n(p.seconds, 1)) };
      case 'sendEvent':
        if (p.event) runtime.emitEvent(p.event);
        break;
      case 'startFsm': {
        const targetNode = getTarget();
        const targetRunner = runnerFor(runtime, targetNode, true);
        if (targetRunner) targetRunner.start();
        break;
      }
      case 'stopFsm': {
        const targetRunner = runnerFor(runtime, getTarget(), false);
        if (targetRunner) targetRunner.stop();
        break;
      }
      case 'restartFsm': {
        const targetRunner = runnerFor(runtime, getTarget(), true);
        if (targetRunner) {
          targetRunner.stop();
          targetRunner.start();
        }
        break;
      }
      case 'enableFsm': {
        const targetNode = getTarget();
        if (!targetNode.fsm) break;
        targetNode.fsm.enabled = p.enabled !== false;
        if (targetNode.fsm.enabled) {
          const targetRunner = runnerFor(runtime, targetNode, true);
          if (targetRunner && !targetRunner.active) targetRunner.start();
        } else {
          const targetRunner = runnerFor(runtime, targetNode, false);
          if (targetRunner) targetRunner.stop();
        }
        break;
      }

      case 'loadScene': {
        const name = String(p.name || '').trim();
        if (!name) break;
        if (!ed.gotoScene(name, { play: p.keepPlaying !== false })) {
          ed.log('warn', '[FSM] Scene "' + name + '" was not found in browser storage.');
        }
        break;
      }
      case 'loadSceneUrl': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const headers = parseHeaders(p.headers);
        const req = runtime.request({
          url,
          method: String(p.method || 'GET').toUpperCase(),
          body: requestBody('json', p.body),
          headers,
          timeout: 20,
          onDone: (res) => {
            if (res.error) {
              ed.log('warn', '[FSM] Could not download scene "' + url + '": ' + res.error);
              emitEventSafe(runtime, 'sceneError');
              return;
            }
            let data = null;
            try { data = JSON.parse(res.data); } catch (e) { /* ignore */ }
            if (!data || !Array.isArray(data.nodes)) {
              ed.log('error', '[FSM] "' + url + '" did not return a valid scene JSON file.');
              emitEventSafe(runtime, 'sceneError');
              return;
            }
            ed.gotoSceneData(data, { play: p.keepPlaying !== false });
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'restartScene':
        ed.restartScene();
        break;
      case 'saveSceneAs':
        if (p.name) ed.saveScene(String(p.name));
        break;
      case 'exitPlay':
        ed.stop();
        break;

      case 'move': {
        const t2 = getTarget().transform;
        t2.position = [t2.position[0] + n(p.x), t2.position[1] + n(p.y), t2.position[2] + n(p.z)];
        break;
      }
      case 'rotate': {
        const t2 = getTarget().transform;
        t2.rotation = [t2.rotation[0] + n(p.x), t2.rotation[1] + n(p.y), t2.rotation[2] + n(p.z)];
        break;
      }
      case 'setPosition': {
        getTarget().transform.position = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setRotation': {
        getTarget().transform.rotation = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setScale': {
        getTarget().transform.scale = [n(p.x, 1), n(p.y, 1), n(p.z, 1)];
        break;
      }
      case 'moveTo':
      case 'moveBy': {
        const targetNode = getTarget();
        const tw = vectorTween(targetNode, 'position', [n(p.x), n(p.y), n(p.z)], p.duration, p.easing || 'easeInOut', action.type === 'moveBy');
        return { tween: tw, block: p.wait !== false };
      }
      case 'rotateTo':
      case 'scaleTo': {
        const targetNode = getTarget();
        const key = action.type === 'rotateTo' ? 'rotation' : 'scale';
        const tw = vectorTween(targetNode, key, [n(p.x, key === 'scale' ? 1 : 0), n(p.y, key === 'scale' ? 1 : 0), n(p.z, key === 'scale' ? 1 : 0)], p.duration, p.easing || 'easeInOut', false);
        return { tween: tw, block: p.wait !== false };
      }
      case 'lookAt': {
        lookAtPoint(getTarget().transform, n(p.x), n(p.y), n(p.z));
        break;
      }
      case 'lookAtObject': {
        const targetNode = getTarget();
        const other = findNode(runtime, p.lookAt);
        if (other) {
          const q = other.transform.position;
          lookAtPoint(targetNode.transform, q[0], q[1], q[2]);
        }
        break;
      }
      case 'resetTransform': {
        const t2 = getTarget().transform;
        t2.position = [0, 0, 0];
        t2.rotation = [0, 0, 0];
        t2.scale = [1, 1, 1];
        break;
      }
      case 'stopMotion':
        runner.stopTweens();
        break;

      case 'setVariable':
        if (p.name) runner.vars[p.name] = p.value != null ? String(p.value) : '';
        break;
      case 'addVariable':
        if (p.name) runner.vars[p.name] = String(M.round(n(runner.vars[p.name], 0) + n(p.value), 4));
        break;
      case 'multiplyVariable':
        if (p.name) runner.vars[p.name] = String(M.round(n(runner.vars[p.name], 0) * n(p.value, 1), 4));
        break;
      case 'clampVariable':
        if (p.name) {
          const a = Math.min(n(p.min), n(p.max));
          const b = Math.max(n(p.min), n(p.max));
          runner.vars[p.name] = String(M.round(clamp(n(runner.vars[p.name], 0), a, b), 4));
        }
        break;
      case 'randomFloat': {
        if (!p.name) break;
        const a = n(p.min), b = n(p.max, 1);
        const lo = Math.min(a, b), hi = Math.max(a, b);
        runner.vars[p.name] = String(M.round(lo + Math.random() * (hi - lo), 4));
        break;
      }
      case 'randomInt': {
        if (!p.name) break;
        const a = Math.round(n(p.min)), b = Math.round(n(p.max, 1));
        const lo = Math.min(a, b), hi = Math.max(a, b);
        runner.vars[p.name] = String(lo + Math.floor(Math.random() * (hi - lo + 1)));
        break;
      }
      case 'toggleVariable': {
        if (!p.name) break;
        const old = String(runner.vars[p.name] == null ? 'false' : runner.vars[p.name]).toLowerCase();
        const on = old === 'true' || old === '1';
        runner.vars[p.name] = on ? 'false' : 'true';
        break;
      }
      case 'copyVariable':
        if (p.to) runner.vars[p.to] = runner.vars[p.from] != null ? String(runner.vars[p.from]) : '';
        break;
      case 'mathOp': {
        if (!p.name) break;
        const current = n(runner.vars[p.name], 0);
        const operand = p.source ? n(runner.vars[p.source], 0) : n(p.value, 0);
        let out = current;
        switch (p.op) {
          case '-': out = current - operand; break;
          case '*': out = current * operand; break;
          case '/':
            if (operand === 0) { ed.log('warn', '[FSM] Division by zero ignored.'); break; }
            out = current / operand;
            break;
          case '%':
            if (operand === 0) { ed.log('warn', '[FSM] Modulo by zero ignored.'); break; }
            out = current % operand;
            break;
          case '^': out = Math.pow(current, operand); break;
          case 'min': out = Math.min(current, operand); break;
          case 'max': out = Math.max(current, operand); break;
          default: out = current + operand;
        }
        runner.vars[p.name] = String(M.round(out, 6));
        break;
      }
      case 'getDistance': {
        const a = getTarget();
        const b = findNode(runtime, p.other);
        if (!p.store || !a || !b) break;
        const pa = a.transform.position;
        const pb = b.transform.position;
        runner.vars[p.store] = String(M.round(Math.hypot(pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]), 4));
        break;
      }
      case 'formatString':
        if (p.store) runner.vars[p.store] = formatTemplate(p.template, runner.vars);
        break;

      case 'stringReplace':
        if (p.variable) {
          const old = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
          runner.vars[p.variable] = old.split(String(p.find == null ? '' : p.find)).join(String(p.replace == null ? '' : p.replace));
        }
        break;
      case 'splitString': {
        const src = runner.vars[p.source] != null ? String(runner.vars[p.source]) : '';
        const parts = src.split(String(p.separator == null ? ',' : p.separator));
        const idx = Math.max(0, Math.round(n(p.index, 0)));
        if (p.store) runner.vars[p.store] = parts[idx] != null ? parts[idx] : '';
        break;
      }
      case 'stringCase': {
        if (!p.variable) break;
        const raw = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
        if (p.mode === 'lower') runner.vars[p.variable] = raw.toLowerCase();
        else if (p.mode === 'trim') runner.vars[p.variable] = raw.trim();
        else if (p.mode === 'capitalize') runner.vars[p.variable] = raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : raw;
        else runner.vars[p.variable] = raw.toUpperCase();
        break;
      }
      case 'convertVariable': {
        if (!p.variable) break;
        const raw = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
        if (p.mode === 'text') runner.vars[p.variable] = raw;
        else if (p.mode === 'float') runner.vars[p.variable] = String(M.round(n(raw, 0), 6));
        else if (p.mode === 'fixed') runner.vars[p.variable] = n(raw, 0).toFixed(Math.round(clamp(n(p.decimals, 2), 0, 6)));
        else runner.vars[p.variable] = String(Math.round(n(raw, 0)));
        break;
      }
      case 'getTransform': {
        if (!p.name) break;
        const val = getTarget().transform[p.property] || [0, 0, 0];
        const idx = p.axis === 'y' ? 1 : p.axis === 'z' ? 2 : 0;
        runner.vars[p.name] = String(M.round(val[idx], 4));
        break;
      }
      case 'branch': {
        const on = compare(runner.vars[p.variable], p.value, p.op);
        const evt = on ? p.eventTrue : p.eventFalse;
        if (evt) runtime.emitEvent(evt);
        break;
      }
      case 'setAmbient': {
        const env = ed.scene.env || (ed.scene.env = UW.scene.defaultEnv());
        env.ambient = clamp(n(p.intensity, 0.42), 0, 4);
        env.ambientColor = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setFog': {
        const env = ed.scene.env || (ed.scene.env = UW.scene.defaultEnv());
        env.fogEnabled = p.enabled !== false;
        env.fogColor = validColor(p.color) ? p.color : env.fogColor || '#1d2025';
        env.fogNear = Math.max(0, n(p.near, env.fogNear != null ? env.fogNear : 14));
        env.fogFar = Math.max(env.fogNear + 0.01, n(p.far, env.fogFar != null ? env.fogFar : 70));
        break;
      }

      case 'setVisible': {
        const targetNode = getTarget();
        targetNode.visible = p.visible !== false;
        break;
      }
      case 'toggleVisible': {
        const targetNode = getTarget();
        targetNode.visible = targetNode.visible === false;
        break;
      }
      case 'setParent': {
        const targetNode = getTarget();
        const raw = String(p.parent || '').trim();
        if (!raw) {
          targetNode.parent = null;
          break;
        }
        const parent = findNode(runtime, raw);
        if (!parent || parent.id === targetNode.id) break;
        const descendants = UW.scene.descendants(ed.scene, targetNode.id).map((x) => x.id);
        if (descendants.indexOf(parent.id) >= 0) break;
        targetNode.parent = parent.id;
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        break;
      }
      case 'setName': {
        const targetNode = getTarget();
        const name = String(p.name || '').trim();
        if (name) targetNode.name = name;
        break;
      }
      case 'destroyObject': {
        const targetNode = getTarget();
        if (!targetNode || targetNode === node && ed.scene.nodes.length <= 1) break;
        const doomed = new Set([targetNode.id]);
        if (p.includeChildren !== false) {
          for (const d of UW.scene.descendants(ed.scene, targetNode.id)) doomed.add(d.id);
        }
        ed.scene.nodes = ed.scene.nodes.filter((n) => !doomed.has(n.id));
        if (ed.selected && doomed.has(ed.selected)) ed.selected = null;
        if (typeof runtime.removeNodes === 'function') runtime.removeNodes(doomed);
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        ed.touch(true);
        break;
      }
      case 'cloneObject': {
        const source = getTarget();
        const clone = UW.scene.cloneSubtree(ed.scene, source.id);
        if (!clone) break;
        if (p.copyFsm !== true) for (const n of clone.nodes) delete n.fsm;
        const rawName = String(p.name || '{name} clone');
        const name = formatTemplate(rawName, { name: source.name }) || source.name + ' clone';
        clone.root.name = UW.scene.uniqueName(ed.scene, name);
        clone.root.transform.position = [
          clone.root.transform.position[0] + n(p.x, 0),
          clone.root.transform.position[1] + n(p.y, 0),
          clone.root.transform.position[2] + n(p.z, 0),
        ];
        ed.scene.nodes.push(...clone.nodes);
        if (p.store) runner.vars[p.store] = clone.root.name;
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        if (clone.root.fsm && typeof runtime.spawnRunner === 'function') {
          const clonedRunner = runtime.spawnRunner(clone.root);
          if (clonedRunner && runtime.isActive && runtime.isActive(clone.root)) clonedRunner.start();
        }
        ed.touch(true);
        break;
      }
      case 'setActive': {
        const targetNode = getTarget();
        const next = p.active !== false;
        if (targetNode.active === next) break;
        targetNode.active = next;
        if (typeof runtime.refreshActive === 'function') runtime.refreshActive();
        ed.touch(true);
        break;
      }
      case 'toggleActive': {
        const targetNode = getTarget();
        targetNode.active = targetNode.active === false;
        if (typeof runtime.refreshActive === 'function') runtime.refreshActive();
        ed.touch(true);
        break;
      }
      case 'setTag': {
        const targetNode = getTarget();
        targetNode.tag = String(p.tag == null ? '' : p.tag).trim();
        ed.touch(true);
        break;
      }
      case 'getTag': {
        const targetNode = getTarget();
        if (p.store) runner.vars[p.store] = targetNode.tag || '';
        break;
      }
      case 'findByTag': {
        const hit = UW.scene.findByTag(ed.scene, String(p.tag == null ? '' : p.tag));
        if (p.store) runner.vars[p.store] = hit ? hit.name : '';
        break;
      }
      case 'compareTag': {
        const targetNode = getTarget();
        const own = String(targetNode.tag == null ? '' : targetNode.tag).trim().toLowerCase();
        const want = String(p.tag == null ? '' : p.tag).trim().toLowerCase();
        const match = own === want;
        if (p.store) runner.vars[p.store] = match ? 'true' : 'false';
        emitEventSafe(runtime, match ? p.eventTrue : p.eventFalse);
        break;
      }

      case 'setColor': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.color = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setOpacity': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.opacity = clamp(n(p.opacity, 1), 0, 1);
        break;
      }
      case 'setWireframe': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.wireframe = p.wireframe !== false;
        break;
      }
      case 'setTexturePreset': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.texture = UW.textures.defaultTexture(p.preset || 'checker');
        break;
      }
      case 'setTextureTiling': {
        const tex = textureFor(getTarget(), true);
        if (tex) {
          tex.tiling = [clamp(n(p.x, 1), 0.05, 16), clamp(n(p.y, 1), 0.05, 16)];
          tex.enabled = true;
        }
        break;
      }
      case 'setTextureOffset': {
        const tex = textureFor(getTarget(), true);
        if (tex) {
          tex.offset = [n(p.x), n(p.y)];
          tex.enabled = true;
        }
        break;
      }
      case 'clearTexture': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.texture = null;
        break;
      }

      case 'setLightColor': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.color = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setLightIntensity': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.intensity = clamp(n(p.intensity, 1), 0, 20);
        break;
      }
      case 'setLightRange': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.range = clamp(n(p.range, 12), 0.1, 500);
        break;
      }
      case 'setLightAngle': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.angle = clamp(n(p.angle, 38), 1, 179);
        break;
      }
      case 'setLightPenumbra': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.penumbra = clamp(n(p.penumbra, 0.35), 0, 1);
        break;
      }
      case 'toggleLight': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.visible = targetNode.visible === false;
        break;
      }

      case 'setCameraFov': {
        const cam = cameraFor(node, runtime, p);
        if (cam) cam.camera.fov = clamp(n(p.fov, 55), 5, 170);
        break;
      }
      case 'setCameraClip': {
        const cam = cameraFor(node, runtime, p);
        if (cam) {
          const near = clamp(n(p.near, 0.1), 0.001, 100);
          cam.camera.near = near;
          cam.camera.far = Math.max(near + 0.01, n(p.far, 600));
        }
        break;
      }
      case 'setCameraBg': {
        const cam = cameraFor(node, runtime, p);
        if (cam) cam.camera.bg = validColor(p.color) ? p.color : '#1d2025';
        break;
      }

      case 'addImpulse': {
        const body = bodyFor(runtime, getTarget());
        if (body) {
          const inv = 1 / Math.max(0.05, body.mass || 1);
          body.vel[0] += n(p.x) * inv;
          body.vel[1] += n(p.y) * inv;
          body.vel[2] += n(p.z) * inv;
        }
        break;
      }
      case 'setVelocity': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.vel = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setUseGravity': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.useGravity = p.enabled !== false;
        break;
      }
      case 'setGravity':
        runtime.gravity = clamp(n(p.value, 9.81), 0, 100);
        break;
      case 'addForce': {
        const body = bodyFor(runtime, getTarget());
        if (!body) break;
        const seconds = Math.max(0, n(p.seconds, 0.5));
        if (seconds <= 0.001) {
          const inv = 1 / Math.max(0.05, body.mass || 1);
          body.vel[0] += n(p.x) * inv;
          body.vel[1] += n(p.y) * inv;
          body.vel[2] += n(p.z) * inv;
        } else {
          body.force = [n(p.x), n(p.y), n(p.z)];
          body.forceTime = seconds;
        }
        break;
      }
      case 'setMass': {
        const body = bodyFor(runtime, getTarget());
        const mass = clamp(n(p.mass, 1), 0.05, 1000);
        const targetNode = getTarget();
        if (body) body.mass = mass;
        if (targetNode.rigidbody) targetNode.rigidbody.mass = mass;
        break;
      }
      case 'setRestitution': {
        const body = bodyFor(runtime, getTarget());
        const value = clamp(n(p.value, 0.3), 0, 1);
        const targetNode = getTarget();
        if (body) body.restitution = value;
        if (targetNode.rigidbody) targetNode.rigidbody.restitution = value;
        break;
      }
      case 'setDrag': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.drag = clamp(n(p.value, 0), 0, 20);
        break;
      }
      case 'freezeBody': {
        const body = bodyFor(runtime, getTarget());
        if (body) {
          body.frozen = p.frozen !== false;
          if (body.frozen) body.vel = [0, 0, 0];
        }
        break;
      }
      case 'raycast': {
        const origin = [n(p.x), n(p.y), n(p.z)];
        const dir = [n(p.dx), n(p.dy, -1), n(p.dz)];
        const distance = Math.max(0.1, n(p.maxDistance, 50));
        const ignore = p.ignoreSelf !== false ? getTarget() : null;
        const hit = runtime.raycast ? runtime.raycast(origin, dir, distance, ignore ? ignore.id : null) : null;
        if (p.storeObject) runner.vars[p.storeObject] = hit ? hit.node.name : '';
        if (p.storeDistance) runner.vars[p.storeDistance] = hit ? String(M.round(hit.distance, 3)) : '';
        break;
      }

      case 'httpRequest': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const contentType = p.contentType || 'json';
        const headers = parseHeaders(p.headers);
        const hasType = Object.keys(headers).some((k) => k.toLowerCase() === 'content-type');
        if (!hasType && contentType === 'json') headers['Content-Type'] = 'application/json';
        if (!hasType && contentType === 'form') headers['Content-Type'] = 'application/x-www-form-urlencoded';
        if (!hasType && contentType === 'text') headers['Content-Type'] = 'text/plain';
        const req = runtime.request({
          url,
          method: String(p.method || 'GET').toUpperCase(),
          headers,
          body: requestBody(contentType, p.body),
          timeout: p.timeout,
          onDone: (res) => {
            if (p.store) runner.vars[p.store] = res.error ? '' : String(res.data == null ? '' : res.data);
            if (p.storeStatus) runner.vars[p.storeStatus] = String(res.status || 0);
            if (res.error) {
              ed.log('warn', '[FSM] HTTP ' + (p.method || 'GET') + ' ' + url + ' failed: ' + res.error);
              emitEventSafe(runtime, p.errorEvent);
            } else {
              ed.log('info', '[FSM] HTTP ' + (p.method || 'GET') + ' ' + url + ' → ' + res.status);
              emitEventSafe(runtime, p.doneEvent);
            }
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'callPhp': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const body = requestBody('form', p.fields);
        const req = runtime.request({
          url,
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body,
          timeout: p.timeout,
          onDone: (res) => {
            if (p.store) runner.vars[p.store] = res.error ? '' : String(res.data == null ? '' : res.data);
            if (res.error) {
              ed.log('warn', '[FSM] PHP call ' + url + ' failed: ' + res.error);
              emitEventSafe(runtime, p.errorEvent);
            } else {
              ed.log('info', '[FSM] PHP call ' + url + ' → ' + res.status);
              emitEventSafe(runtime, p.doneEvent);
            }
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'jsonGet': {
        const text = runner.vars[p.source] != null ? String(runner.vars[p.source]) : '';
        let value;
        try { value = jsonValue(text, p.path); } catch (e) { value = undefined; }
        if (value === undefined || value === null) value = p.fallback != null ? p.fallback : '';
        if (p.store) runner.vars[p.store] = typeof value === 'object' ? JSON.stringify(value) : String(value);
        break;
      }
      case 'openUrl': {
        const url = String(p.url || '').trim();
        if (!url) break;
        try { window.open(url, p.target === '_self' ? '_self' : '_blank', 'noopener'); } catch (e) { /* ignore */ }
        break;
      }

      case 'playTone':
        runtime.playTone(n(p.frequency, 440), n(p.duration, 0.18), clamp(n(p.volume, 0.18), 0, 1), p.wave || 'sine');
        break;
      case 'stopAudio':
        runtime.stopAudio();
        break;

      case 'toast':
        if (UW.UI && typeof UW.UI.toast === 'function') UW.UI.toast(p.message || '', p.kind || 'info');
        else ed.log('info', '[FSM] ' + (p.message || ''));
        break;

      /* ---------------- rig & animation ---------------- */
      case 'rigPlay': {
        const root = rigRootFor(runtime, getTarget());
        if (!root || !root.rig) break;
        const anim = root.rigAnim || (root.rigAnim = { enabled: true, playing: true, clip: 'idle', speed: 1, custom: {} });
        anim.enabled = true;
        anim.playing = true;
        anim.clip = p.clip || 'idle';
        anim.speed = clamp(n(p.speed, 1), 0, 8);
        break;
      }
      case 'rigStop': {
        const root = rigRootFor(runtime, getTarget());
        if (!root || !root.rig) break;
        if (root.rigAnim) root.rigAnim.playing = false;
        if (UW.rig) UW.rig.resetPose(ed.scene, root);
        break;
      }
      case 'rigPause': {
        const root = rigRootFor(runtime, getTarget());
        if (root && root.rigAnim) root.rigAnim.playing = false;
        break;
      }
      case 'rigResume': {
        const root = rigRootFor(runtime, getTarget());
        if (root && root.rigAnim) { root.rigAnim.enabled = true; root.rigAnim.playing = true; }
        break;
      }
      case 'rigSetSpeed': {
        const root = rigRootFor(runtime, getTarget());
        if (root && root.rigAnim) root.rigAnim.speed = clamp(n(p.speed, 1), 0, 8);
        break;
      }
      case 'rigSetBone': {
        const root = rigRootFor(runtime, getTarget());
        if (!root || !UW.rig) break;
        UW.rig.setBoneRotation(ed.scene, root, String(p.bone || '').trim(), n(p.x), n(p.y), n(p.z), false);
        break;
      }
      case 'rigRotateBone': {
        const root = rigRootFor(runtime, getTarget());
        if (!root || !UW.rig) break;
        UW.rig.setBoneRotation(ed.scene, root, String(p.bone || '').trim(), n(p.x), n(p.y), n(p.z), true);
        break;
      }
      case 'rigSetBoneScale': {
        const root = rigRootFor(runtime, getTarget());
        const bone = boneNode(ed.scene, root, p.bone);
        if (bone) bone.transform.scale = [n(p.x, 1), n(p.y, 1), n(p.z, 1)];
        break;
      }
      case 'rigResetPose': {
        const root = rigRootFor(runtime, getTarget());
        if (root && UW.rig) UW.rig.resetPose(ed.scene, root);
        break;
      }
      case 'rigGetBonePosition': {
        const root = rigRootFor(runtime, getTarget());
        const pos = root && UW.rig ? UW.rig.worldBone(ed.scene, root, p.bone) : null;
        if (!pos) break;
        if (p.storeX) runner.vars[p.storeX] = String(M.round(pos[0], 4));
        if (p.storeY) runner.vars[p.storeY] = String(M.round(pos[1], 4));
        if (p.storeZ) runner.vars[p.storeZ] = String(M.round(pos[2], 4));
        break;
      }
      case 'rigGetBoneRotation': {
        const root = rigRootFor(runtime, getTarget());
        const bone = boneNode(ed.scene, root, p.bone);
        if (!bone) break;
        const rr = bone.transform.rotation;
        if (p.storeX) runner.vars[p.storeX] = String(M.round(rr[0], 3));
        if (p.storeY) runner.vars[p.storeY] = String(M.round(rr[1], 3));
        if (p.storeZ) runner.vars[p.storeZ] = String(M.round(rr[2], 3));
        break;
      }
      case 'rigGetHeight': {
        const root = rigRootFor(runtime, getTarget());
        if (p.store) runner.vars[p.store] = String(root && root.rig ? M.round(root.rig.height || 0, 3) : 0);
        break;
      }
      case 'rigGetBoneCount': {
        const root = rigRootFor(runtime, getTarget());
        if (p.store) runner.vars[p.store] = String(root && root.rig ? Object.keys(root.rig.bones).length : 0);
        break;
      }
      case 'rigGetClip': {
        const root = rigRootFor(runtime, getTarget());
        if (p.store) runner.vars[p.store] = root && root.rigAnim ? String(root.rigAnim.clip || 'none') : 'none';
        break;
      }
      case 'rigHasRig': {
        const root = rigRootFor(runtime, getTarget());
        const has = !!(root && root.rig);
        if (p.store) runner.vars[p.store] = has ? 'true' : 'false';
        emitEventSafe(runtime, has ? p.eventTrue : p.eventFalse);
        break;
      }

      /* ---------------- multiplayer ---------------- */
      case 'netConnect': {
        const net = ensureNet(runtime);
        if (!net) break;
        const cfg = ed.scene.network || (ed.scene.network = UW.scene.defaultNetwork());
        cfg.transport = p.transport || 'local';
        cfg.room = String(p.room || cfg.room || 'My Game');
        cfg.url = String(p.url || cfg.url || '');
        cfg.playerName = String(p.playerName || cfg.playerName || 'Player');
        net.connect({ transport: cfg.transport, room: cfg.room, url: cfg.url, playerName: cfg.playerName });
        break;
      }
      case 'netDisconnect': {
        if (runtime.net) runtime.net.disconnect();
        break;
      }
      case 'netIsConnected': {
        const on = !!(runtime.net && runtime.net.connected);
        if (p.store) runner.vars[p.store] = on ? 'true' : 'false';
        emitEventSafe(runtime, on ? p.eventTrue : p.eventFalse);
        break;
      }
      case 'netSendEvent': {
        if (runtime.net) runtime.net.sendEvent(p.event, p.data == null ? null : p.data);
        break;
      }
      case 'netRequestSync':
        if (runtime.net) runtime.net.requestSync();
        break;
      case 'netSendState':
        if (runtime.net && runtime.net.pushState) runtime.net.pushState();
        else if (runtime.net && runtime.net._sendSnapshot) runtime.net._sendSnapshot(true);
        break;
      case 'netClaim': {
        const targetNode = netNodeFor(runtime, getTarget());
        if (runtime.net && targetNode) runtime.net.claim(targetNode);
        break;
      }
      case 'netRelease': {
        const targetNode = netNodeFor(runtime, getTarget());
        if (runtime.net && targetNode) runtime.net.release(targetNode);
        break;
      }
      case 'netIsOwner': {
        const targetNode = netNodeFor(runtime, getTarget());
        const owns = !runtime.net ? true : !!(targetNode && runtime.net.isOwner(targetNode));
        if (p.store) runner.vars[p.store] = owns ? 'true' : 'false';
        emitEventSafe(runtime, owns ? p.eventTrue : p.eventFalse);
        break;
      }
      case 'netSpawn': {
        const targetNode = netNodeFor(runtime, getTarget());
        if (runtime.net && targetNode) runtime.net.spawn(targetNode);
        break;
      }
      case 'netDespawn': {
        const targetNode = netNodeFor(runtime, getTarget());
        if (runtime.net && targetNode) runtime.net.despawn(targetNode);
        break;
      }
      case 'netPeerCount':
        if (p.store) runner.vars[p.store] = String(runtime.net ? runtime.net.peers.size : 0);
        break;
      case 'netGetPeerId':
        if (p.store) runner.vars[p.store] = runtime.net ? runtime.net.peerId : '';
        break;
      case 'netGetOwner': {
        const targetNode = netNodeFor(runtime, getTarget());
        if (p.store) runner.vars[p.store] = targetNode && targetNode.network ? String(targetNode.network.owner || '') : '';
        break;
      }
      case 'netGetRoom':
        if (p.store) runner.vars[p.store] = runtime.net ? runtime.net.room : String((ed.scene.network || {}).room || '');
        break;
      case 'netGetTransport':
        if (p.store) runner.vars[p.store] = runtime.net ? runtime.net.transport : String((ed.scene.network || {}).transport || 'local');
        break;
      case 'netGetStatus':
        if (p.store) runner.vars[p.store] = runtime.net ? runtime.net.statusText : 'offline';
        break;
      case 'netSetPlayerName': {
        const name = String(p.name || '').trim().slice(0, 32);
        if (!name) break;
        if (runtime.net) runtime.net.name = name;
        if (ed.scene.network) ed.scene.network.playerName = name;
        break;
      }
      case 'netClaimPlayer': {
        if (!runtime.net) break;
        const wanted = String((ed.scene.network || {}).playerObject || '').trim();
        const playerNode = wanted
          ? ed.scene.nodes.find((x) => x.network && (x.id === wanted || x.name === wanted))
          : null;
        if (playerNode) runtime.net.claim(playerNode);
        break;
      }
      case 'netGetLastEvent': {
        const last = runtime.net ? runtime.net.lastEvent : null;
        if (p.storeName) runner.vars[p.storeName] = last ? String(last.name || '') : '';
        if (p.storeData) runner.vars[p.storeData] = last && last.data != null ? String(last.data) : '';
        if (p.storeFrom) runner.vars[p.storeFrom] = last ? String(last.from || '') : '';
        break;
      }

      /* ---------------- player prefs & storage ---------------- */
      case 'prefSetFloat':
        prefWrite('prefs', p.key, String(M.round(n(p.value, 1), 6)));
        break;
      case 'prefGetFloat': {
        const raw = prefRead('prefs', p.key);
        const value = raw != null && Number.isFinite(parseFloat(raw)) ? parseFloat(raw) : n(p.fallback, 0);
        if (p.store) runner.vars[p.store] = String(M.round(value, 6));
        break;
      }
      case 'prefSetInt':
        prefWrite('prefs', p.key, String(Math.round(n(p.value, 1))));
        break;
      case 'prefGetInt': {
        const raw = prefRead('prefs', p.key);
        const value = raw != null && Number.isFinite(parseFloat(raw)) ? Math.round(parseFloat(raw)) : Math.round(n(p.fallback, 0));
        if (p.store) runner.vars[p.store] = String(value);
        break;
      }
      case 'prefSetString':
        prefWrite('prefs', p.key, p.value == null ? '' : String(p.value));
        break;
      case 'prefGetString': {
        const raw = prefRead('prefs', p.key);
        if (p.store) runner.vars[p.store] = raw != null ? raw : String(p.fallback == null ? '' : p.fallback);
        break;
      }
      case 'prefSetBool':
        prefWrite('prefs', p.key, p.value !== false ? 'true' : 'false');
        break;
      case 'prefGetBool': {
        const raw = prefRead('prefs', p.key);
        const value = raw == null
          ? p.fallback === true
          : ['true', '1', 'yes', 'on'].indexOf(String(raw).toLowerCase()) >= 0;
        if (p.store) runner.vars[p.store] = value ? 'true' : 'false';
        break;
      }
      case 'prefHasKey': {
        const store = safeStore('local');
        let has = false;
        try { has = !!store && store.getItem(PREF_PREFIX + String(p.key || '')) !== null; } catch (e) { has = false; }
        if (p.store) runner.vars[p.store] = has ? 'true' : 'false';
        break;
      }
      case 'prefDeleteKey':
        prefDelete('prefs', p.key);
        break;
      case 'prefDeleteAll': {
        const list = prefKeys();
        for (const key of list) prefDelete('prefs', key);
        break;
      }
      case 'prefGetKeys':
        if (p.store) runner.vars[p.store] = prefKeys().join(', ');
        break;
      case 'storeLocalSet':
        prefWrite('rawLocal', p.key, p.value == null ? '' : String(p.value));
        break;
      case 'storeLocalGet': {
        const raw = prefRead('rawLocal', p.key);
        if (p.store) runner.vars[p.store] = raw != null ? raw : String(p.fallback == null ? '' : p.fallback);
        break;
      }
      case 'storeLocalDelete':
        prefDelete('rawLocal', p.key);
        break;
      case 'storeSessionSet':
        prefWrite('rawSession', p.key, p.value == null ? '' : String(p.value));
        break;
      case 'storeSessionGet': {
        const raw = prefRead('rawSession', p.key);
        if (p.store) runner.vars[p.store] = raw != null ? raw : String(p.fallback == null ? '' : p.fallback);
        break;
      }
      case 'storeSessionDelete':
        prefDelete('rawSession', p.key);
        break;

      /* ---------------- input ---------------- */
      case 'isKeyHeld':
        if (p.store) runner.vars[p.store] = runtime.pressedKeys.has(String(p.key || '')) ? 'true' : 'false';
        break;
      case 'isKeyDown':
        if (p.store) runner.vars[p.store] = runtime.keysDown.has(String(p.key || '')) ? 'true' : 'false';
        break;
      case 'isKeyUp':
        if (p.store) runner.vars[p.store] = runtime.keysUp.has(String(p.key || '')) ? 'true' : 'false';
        break;
      case 'getAxis': {
        const neg = runtime.pressedKeys.has(String(p.negative || ''));
        const pos = runtime.pressedKeys.has(String(p.positive || ''));
        if (p.store) runner.vars[p.store] = String(pos && !neg ? 1 : neg && !pos ? -1 : 0);
        break;
      }
      case 'getMousePosition': {
        const mouse = runtime.mouse || { nx: 0, ny: 0 };
        if (p.storeX) runner.vars[p.storeX] = String(M.round(mouse.nx || 0, 4));
        if (p.storeY) runner.vars[p.storeY] = String(M.round(mouse.ny || 0, 4));
        break;
      }
      case 'getMouseWorld': {
        const mouse = runtime.mouse || { px: 0, py: 0 };
        const app = UW.app;
        if (!app || !app.cameraRig || typeof app.cameraRig.ray !== 'function') break;
        const ray = app.cameraRig.ray(mouse.px || 0, mouse.py || 0);
        const planeY = n(p.planeY, 0);
        if (Math.abs(ray.dir[1]) < 1e-6) break;
        const tt = (planeY - ray.origin[1]) / ray.dir[1];
        if (tt < 0) break;
        const point = [
          ray.origin[0] + ray.dir[0] * tt,
          ray.origin[1] + ray.dir[1] * tt,
          ray.origin[2] + ray.dir[2] * tt,
        ];
        if (p.storeX) runner.vars[p.storeX] = String(M.round(point[0], 3));
        if (p.storeY) runner.vars[p.storeY] = String(M.round(point[1], 3));
        if (p.storeZ) runner.vars[p.storeZ] = String(M.round(point[2], 3));
        break;
      }
      case 'isMouseDown': {
        const btn = Math.round(clamp(n(p.button, 0), 0, 2));
        const down = !!(runtime.mouse && runtime.mouse.buttons && runtime.mouse.buttons.has(btn));
        if (p.store) runner.vars[p.store] = down ? 'true' : 'false';
        break;
      }
      case 'getMouseScroll':
        if (p.store) runner.vars[p.store] = String(M.round(runtime.mouse ? runtime.mouse.scroll || 0 : 0, 3));
        break;
      case 'getTouchCount':
        if (p.store) runner.vars[p.store] = String(runtime.mouse && runtime.mouse.touches ? runtime.mouse.touches.length : 0);
        break;
      case 'getTouchPosition': {
        const idx = Math.round(clamp(n(p.index, 0), 0, 9));
        const touch = runtime.mouse && runtime.mouse.touches ? runtime.mouse.touches[idx] : null;
        if (p.storeX) runner.vars[p.storeX] = touch ? String(M.round(touch.nx, 4)) : '-1';
        if (p.storeY) runner.vars[p.storeY] = touch ? String(M.round(touch.ny, 4)) : '-1';
        break;
      }
      case 'isAnyKey':
        if (p.store) runner.vars[p.store] = runtime.pressedKeys.size ? 'true' : 'false';
        break;
      case 'setCursorVisible': {
        const viewport = UW.app && UW.app.viewport;
        if (viewport) viewport.style.cursor = p.visible === false ? 'none' : '';
        break;
      }

      /* ---------------- time ---------------- */
      case 'getTime':
        if (p.store) runner.vars[p.store] = String(M.round(runtime.time, 4));
        break;
      case 'getDeltaTime':
        if (p.store) runner.vars[p.store] = String(M.round(runtime.lastDt || 0, 5));
        break;
      case 'getUnscaledDeltaTime':
        if (p.store) runner.vars[p.store] = String(M.round(runtime.lastRawDt || 0, 5));
        break;
      case 'getFrameCount':
        if (p.store) runner.vars[p.store] = String(runtime.frame || 0);
        break;
      case 'getRealTime':
        if (p.store) runner.vars[p.store] = String(Date.now());
        break;
      case 'setTimeScale':
        runtime.timeScale = clamp(n(p.value, 1), 0, 8);
        break;
      case 'getTimeScale':
        if (p.store) runner.vars[p.store] = String(M.round(runtime.timeScale != null ? runtime.timeScale : 1, 3));
        break;
      case 'getFps':
        if (p.store) runner.vars[p.store] = String(Math.round(runtime.fps || 0));
        break;

      /* ---------------- vector & math ---------------- */
      case 'vecSet':
        vecWrite(runner, p.out || 'v', [n(p.x), n(p.y), n(p.z)]);
        break;
      case 'vecAdd': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        vecWrite(runner, p.out || 'v', [a[0] + b[0], a[1] + b[1], a[2] + b[2]]);
        break;
      }
      case 'vecSub': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        vecWrite(runner, p.out || 'v', [a[0] - b[0], a[1] - b[1], a[2] - b[2]]);
        break;
      }
      case 'vecMul': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        vecWrite(runner, p.out || 'v', [a[0] * b[0], a[1] * b[1], a[2] * b[2]]);
        break;
      }
      case 'vecScale': {
        const a = vecRead(runner, p.a), s = n(p.scalar, 1);
        vecWrite(runner, p.out || 'v', [a[0] * s, a[1] * s, a[2] * s]);
        break;
      }
      case 'vecDot': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        if (p.out) runner.vars[p.out] = String(M.round(V.dot(a, b), 6));
        break;
      }
      case 'vecCross': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        vecWrite(runner, p.out || 'v', V.cross(a, b));
        break;
      }
      case 'vecLength': {
        const a = vecRead(runner, p.a);
        if (p.out) runner.vars[p.out] = String(M.round(V.len(a), 6));
        break;
      }
      case 'vecNormalize': {
        const a = vecRead(runner, p.a);
        vecWrite(runner, p.out || 'v', V.norm(a));
        break;
      }
      case 'vecDistance': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        if (p.out) runner.vars[p.out] = String(M.round(V.dist(a, b), 6));
        break;
      }
      case 'vecLerp': {
        const a = vecRead(runner, p.a), b = vecRead(runner, p.b);
        vecWrite(runner, p.out || 'v', V.lerp(a, b, clamp(n(p.t, 0.5), 0, 1)));
        break;
      }
      case 'vecToAngles': {
        const a = vecRead(runner, p.a);
        const yaw = Math.atan2(a[0], a[2]) * M.RAD;
        const pitch = -Math.atan2(a[1], Math.hypot(a[0], a[2])) * M.RAD;
        vecWrite(runner, p.out || 'angles', [yaw, pitch, 0]);
        break;
      }

      /* ---------------- UI & browser ---------------- */
      case 'setElementText': {
        const el = qs(p.selector);
        if (el) el.textContent = p.value == null ? '' : String(p.value);
        else ed.log('warn', '[FSM] No page element matches "' + (p.selector || '') + '".');
        break;
      }
      case 'setElementHtml': {
        const el = qs(p.selector);
        if (el) el.innerHTML = p.value == null ? '' : String(p.value);
        break;
      }
      case 'setElementColor': {
        const el = qs(p.selector);
        if (el) el.style.color = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setElementVisible': {
        const el = qs(p.selector);
        if (el) el.style.display = p.visible === false ? 'none' : '';
        break;
      }
      case 'setElementStyle': {
        const el = qs(p.selector);
        if (!el) break;
        const prop = String(p.property || '').trim();
        if (!prop) break;
        try {
          if (prop.indexOf('--') === 0) el.style.setProperty(prop, String(p.value == null ? '' : p.value));
          else el.style[prop] = String(p.value == null ? '' : p.value);
        } catch (e) { /* ignore invalid property */ }
        break;
      }
      case 'setPageTitle':
        if (p.title != null) document.title = String(p.title);
        break;

      /* ---------------- rebindable input & gamepad ---------------- */
      case 'isActionDown': {
        const a = UW.input ? UW.input.action(runtime, String(p.action || '')) : null;
        if (p.store) runner.vars[p.store] = a && a.down ? 'true' : 'false';
        break;
      }
      case 'isActionPressed': {
        const a = UW.input ? UW.input.action(runtime, String(p.action || '')) : null;
        if (p.store) runner.vars[p.store] = a && a.pressed ? 'true' : 'false';
        break;
      }
      case 'getActionValue': {
        const a = UW.input ? UW.input.action(runtime, String(p.action || '')) : null;
        if (p.store) runner.vars[p.store] = String(M.round(a ? a.value : 0, 3));
        break;
      }
      case 'getInputAxis': {
        const axes = runtime.inputState && runtime.inputState.axes ? runtime.inputState.axes : {};
        if (p.store) runner.vars[p.store] = String(M.round(Number(axes[p.axis]) || 0, 3));
        break;
      }
      case 'isGamepadConnected': {
        const pad = UW.input ? UW.input.padState() : null;
        if (p.store) runner.vars[p.store] = pad && pad.connected ? 'true' : 'false';
        break;
      }
      case 'getGamepadButton': {
        const idx = Math.round(clamp(n(p.index, 0), 0, 19));
        const pad = UW.input ? UW.input.padState() : null;
        const b = pad && pad.buttons ? pad.buttons[idx] : null;
        if (p.store) runner.vars[p.store] = b && (b.pressed || b.value > 0.5) ? 'true' : 'false';
        break;
      }
      case 'getGamepadTrigger': {
        const t = runtime.inputState && runtime.inputState.triggers ? runtime.inputState.triggers : { left: 0, right: 0 };
        if (p.store) runner.vars[p.store] = String(M.round(p.side === 'left' ? t.left : t.right, 3));
        break;
      }
      case 'vibrateGamepad':
        if (UW.input) UW.input.vibrate(clamp(n(p.strength, 0.6), 0, 1), clamp(n(p.duration, 220), 10, 5000));
        break;
      case 'rebindAction': {
        const actionName = String(p.action || '').trim();
        if (!actionName || !UW.input) break;
        ed.log('info', '[Input] Press the new key for "' + actionName + '"…');
        UW.input.listenKey((code) => {
          const cfg = UW.input.get();
          if (!cfg.actions[actionName]) cfg.actions[actionName] = { keys: [], pad: [], axis: null };
          cfg.actions[actionName].keys = [code];
          UW.input.save(cfg);
          ed.log('info', '[Input] "' + actionName + '" is now bound to ' + UW.input.keyLabel(code) + '.');
        });
        break;
      }

      /* ---------------- Unity UI elements ---------------- */
      case 'uiSetText':
        if (UW.unityui) UW.unityui.setValue(ed, p.ref, p.value == null ? '' : String(p.value));
        break;
      case 'uiSetValue':
        if (UW.unityui) UW.unityui.setValue(ed, p.ref, n(p.value, 0));
        break;
      case 'uiGetValue':
        if (p.store) runner.vars[p.store] = UW.unityui ? UW.unityui.getValue(ed, p.ref) : '';
        break;
      case 'uiSetChecked':
        if (UW.unityui) UW.unityui.setValue(ed, p.ref, p.checked !== false);
        break;
      case 'uiSetVisible':
        if (UW.unityui) UW.unityui.setVisible(ed, p.ref, p.visible !== false);
        break;
      case 'uiClick':
        if (UW.unityui) UW.unityui.click(ed, p.ref);
        break;
      case 'uiSetProgress': {
        const nodeRef = UW.unityui ? UW.unityui.find(ed, p.ref) : null;
        if (nodeRef && nodeRef.ui) {
          const ui = nodeRef.ui;
          const pct = clamp(n(p.percent, 50), 0, 100) / 100;
          ui.value = ui.min + (ui.max - ui.min) * pct;
          UW.unityui.invalidate();
        }
        break;
      }
      case 'uiSetColor': {
        const nodeRef = UW.unityui ? UW.unityui.find(ed, p.ref) : null;
        if (nodeRef && nodeRef.ui) {
          nodeRef.ui.color = validColor(p.color) ? p.color : '#ffffff';
          UW.unityui.invalidate();
        }
        break;
      }
      case 'uiSetOpacity': {
        const nodeRef = UW.unityui ? UW.unityui.find(ed, p.ref) : null;
        if (nodeRef && nodeRef.ui) {
          nodeRef.ui.opacity = clamp(n(p.opacity, 0.5), 0, 1);
          UW.unityui.invalidate();
        }
        break;
      }
      case 'uiSetInteractable': {
        const nodeRef = UW.unityui ? UW.unityui.find(ed, p.ref) : null;
        if (nodeRef && nodeRef.ui) {
          nodeRef.ui.interactable = p.interactable !== false;
          UW.unityui.invalidate();
        }
        break;
      }

      /* ---------------- second camera & scene changer ---------------- */
      case 'setSecondCamera': {
        let camNode = UW.SecondCamera ? UW.SecondCamera.find(ed) : null;
        if (!camNode) camNode = ed.scene.nodes.find((x) => x.type === 'camera' && x.visible !== false);
        if (!camNode || !camNode.camera) break;
        camNode.camera.secondary = true;
        const pip = camNode.camera.pip || (camNode.camera.pip = {});
        pip.enabled = p.enabled !== false;
        if (['topLeft', 'topRight', 'bottomLeft', 'bottomRight'].indexOf(p.corner) >= 0) pip.corner = p.corner;
        pip.width = clamp(n(p.width, 320), 120, 960);
        pip.height = clamp(n(p.height, 200), 80, 640);
        if (UW.SecondCamera) UW.SecondCamera.setEnabled(true);
        break;
      }
      case 'toggleSecondCamera': {
        const camNode = UW.SecondCamera ? UW.SecondCamera.find(ed) : null;
        if (!camNode || !camNode.camera) break;
        const pip = camNode.camera.pip || (camNode.camera.pip = { enabled: false, corner: 'bottomRight', width: 320, height: 200 });
        pip.enabled = !pip.enabled;
        if (UW.SecondCamera) UW.SecondCamera.setEnabled(true);
        if (p.store) runner.vars[p.store] = pip.enabled ? 'true' : 'false';
        break;
      }
      case 'showSceneMenu': {
        const changerNode = UW.scenes && UW.scenes.changer ? UW.scenes.changer(ed.scene) : null;
        if (!changerNode) break;
        changerNode.sceneChanger.enabled = p.visible !== false;
        changerNode.sceneChanger.visible = p.visible !== false;
        break;
      }
      case 'sceneChangerAdd': {
        const changerNode = UW.scenes && UW.scenes.changer ? UW.scenes.changer(ed.scene) : null;
        if (!changerNode) break;
        const name = String(p.scene || '').trim();
        if (!name) break;
        const list = changerNode.sceneChanger.scenes || (changerNode.sceneChanger.scenes = []);
        if (list.indexOf(name) < 0 && list.length < 32) list.push(name);
        break;
      }

      /* ---------------- Audio Source objects ---------------- */
      case 'playSource':
        runtime.playSource(p.target);
        break;
      case 'stopSource':
        runtime.stopSource(p.target);
        break;
      case 'setSourceVolume': {
        const rec = runtime.audioRecord(p.target);
        if (!rec) break;
        const wasPlaying = !!rec.handle;
        rec.node.audio.volume = clamp(n(p.volume, 0.5), 0, 1);
        if (wasPlaying) runtime._startAudio(rec);
        break;
      }
      case 'isSourcePlaying': {
        if (p.store) runner.vars[p.store] = runtime.isSourcePlaying(p.target) ? 'true' : 'false';
        break;
      }
      default:
        break;
    }
    return null;
  };
})();
