/* ============================================================
   scene.js — scene model, defaults, transforms and serialization
   The scene is a flat list of nodes with parent links, serialized
   to plain JSON (which is also the format the plugin API speaks).
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  let seq = 1;
  const uid = () => 'n' + Date.now().toString(36).slice(-4) + (seq++).toString(36);

  const S = (UW.scene = {});

  S.uid = uid;

  S.defaultEnv = function () {
    return {
      ambient: 0.42,
      ambientColor: '#ffffff',
      showGrid: true,
      fogEnabled: false,
      fogColor: '#1d2025',
      fogNear: 14,
      fogFar: 70,
    };
  };

  S.defaultNetwork = function () {
    return {
      transport: 'local',
      room: 'My Game',
      url: '',
      autoConnect: false,
      playerName: 'Player',
      playerObject: '',
    };
  };

  S.makeNode = function (partial) {
    const n = {
      id: uid(),
      name: 'GameObject',
      parent: null,
      type: 'empty',
      visible: true,
      tag: '',
      active: true,
      transform: {
        position: [0, 0, 0],
        rotation: [0, 0, 0],
        scale: [1, 1, 1],
      },
      behaviors: [],
    };
    if (partial) {
      // never let an explicitly-undefined field clobber a default
      // (e.g. makeNode({ transform: undefined }) keeps the identity transform)
      for (const key of Object.keys(partial)) {
        if (partial[key] !== undefined) n[key] = partial[key];
      }
      if (partial.transform) {
        n.transform = {
          position: (partial.transform.position || [0, 0, 0]).slice(),
          rotation: (partial.transform.rotation || [0, 0, 0]).slice(),
          scale: (partial.transform.scale || [1, 1, 1]).slice(),
        };
      }
    }
    n.behaviors = n.behaviors || [];
    return n;
  };

  S.createNode = function (kind, opts = {}) {
    const base = {
      name: opts.name || 'GameObject',
      parent: opts.parent || null,
      transform: {
        position: (opts.position || [0, 0, 0]).slice(),
        rotation: (opts.rotation || [0, 0, 0]).slice(),
        scale: (opts.scale || [1, 1, 1]).slice(),
      },
    };
    if (opts.id) base.id = opts.id;

    if (kind === 'light' || kind === 'light.directional' || kind === 'light.point' || kind === 'light.spot') {
      const spot = kind === 'light.spot';
      const point = kind === 'light.point';
      base.type = 'light';
      base.name = opts.name || (spot ? 'Spot Light' : point ? 'Point Light' : 'Directional Light');
      base.light = {
        kind: spot ? 'spot' : point ? 'point' : 'directional',
        color: opts.color || (spot ? '#fff2d6' : point ? '#ffd7a0' : '#fff4e2'),
        intensity: spot ? 1.7 : point ? 1.4 : 1.05,
        range: spot ? 18 : 14,
        angle: 38,
        penumbra: 0.35,
      };
      return S.makeNode(base);
    }

    if (kind === 'camera') {
      base.type = 'camera';
      base.name = opts.name || 'Main Camera';
      base.camera = Object.assign({ fov: 55, near: 0.1, far: 600, bg: '#1d2025', secondary: false, pip: { enabled: false, corner: 'bottomRight', width: 320, height: 200 } }, opts.camera || {});
      return S.makeNode(base);
    }

    if (kind === 'ui') {
      base.type = 'ui';
      base.name = opts.name || 'UI Element';
      base.ui = UW.unityui ? UW.unityui.createComponent(opts.uiKind || (opts.ui && opts.ui.kind) || 'panel', opts.ui || {}) : null;
      return S.makeNode(base);
    }

    if (kind === 'audio') {
      base.type = 'audio';
      base.name = opts.name || 'Audio Source';
      base.audio = Object.assign({
        kind: 'tone', src: '', frequency: 440, volume: 0.25,
        loop: false, playOnAwake: true, playing: true,
        wave: 'sine', duration: 0.3,
      }, opts.audio || {});
      return S.makeNode(base);
    }

    if (kind === 'sceneChanger') {
      base.type = 'empty';
      base.name = opts.name || 'Scene Changer';
      base.sceneChanger = Object.assign(
        UW.scenes && UW.scenes.changerDefaults ? UW.scenes.changerDefaults() : {
          enabled: true, title: 'SCENE CHANGER', scenes: ['Sample Scene'], visible: true, showInEditor: true,
        },
        opts.sceneChanger || {}
      );
      return S.makeNode(base);
    }

    if (kind === 'empty') {
      base.type = 'empty';
      base.name = opts.name || 'Empty';
      return S.makeNode(base);
    }

    base.type = 'mesh';
    const shape = kind === 'quad' ? 'plane' : kind;
    base.name = opts.name || UW.geom.shapeLabel(shape);
    base.mesh = {
      shape,
      color: opts.color || '#c9ced6',
      roughness: opts.roughness != null ? opts.roughness : 0.6,
      metalness: opts.metalness != null ? opts.metalness : 0.08,
      wireframe: false,
      opacity: 1,
      texture: null,
    };
    if (opts.mesh && typeof opts.mesh === 'object') Object.assign(base.mesh, opts.mesh, { shape });
    return S.makeNode(base);
  };

  S.defaultScene = function () {
    const ground = S.createNode('plane', {
      id: 'n_ground',
      name: 'Ground',
      position: [0, 0, 0],
      scale: [26, 1, 26],
    });
    ground.mesh.color = '#343941';
    ground.mesh.roughness = 0.95;
    ground.mesh.metalness = 0;

    const cube = S.createNode('cube', {
      id: 'n_cube',
      name: 'Cube',
      position: [0, 0.5, 0],
    });
    cube.mesh.color = '#c7cdd6';
    cube.rigidbody = { mass: 1, useGravity: true, restitution: 0.25 };

    const sphere = S.createNode('sphere', {
      id: 'n_sphere',
      name: 'Sphere',
      position: [-2.4, 0.5, 1.55],
    });
    sphere.mesh.color = '#5b9bd5';
    sphere.mesh.roughness = 0.3;
    sphere.mesh.metalness = 0.35;
    sphere.behaviors.push({ id: uid(), kind: 'spin', params: { x: 0, y: 55, z: 0 } });

    const cylinder = S.createNode('cylinder', {
      id: 'n_cylinder',
      name: 'Falling Cylinder',
      position: [2.4, 2.6, 1.45],
    });
    cylinder.mesh.color = '#d9a441';
    cylinder.mesh.metalness = 0.45;
    cylinder.mesh.roughness = 0.35;
    cylinder.rigidbody = { mass: 1.4, useGravity: true, restitution: 0.42 };

    const torus = S.createNode('torus', {
      id: 'n_torus',
      name: 'Torus',
      position: [1.7, 0.16, -1.7],
      rotation: [0, 0, 0],
      scale: [0.9, 0.9, 0.9],
    });
    torus.mesh.color = '#9d86e0';
    torus.mesh.metalness = 0.3;

    const light = S.createNode('light.directional', {
      id: 'n_light',
      name: 'Directional Light',
      position: [4, 6, 4],
      rotation: [52, -34, 0],
    });

    const camera = S.createNode('camera', {
      id: 'n_camera',
      name: 'Main Camera',
      position: [0, 1.9, 7.4],
    });

    return {
      version: 1,
      name: 'Sample Scene',
      env: S.defaultEnv(),
      nodes: [light, camera, ground, cube, sphere, cylinder, torus],
    };
  };

  S.emptyScene = function () {
    return {
      version: 1,
      name: 'Untitled Scene',
      env: S.defaultEnv(),
      nodes: [S.createNode('camera', { name: 'Main Camera', position: [0, 1.9, 7.4] }), S.createNode('light.directional')],
    };
  };

  S.find = (scene, id) => scene.nodes.find((n) => n.id === id) || null;

  /* Effective "is this object on" map: a node is inactive when it or any
     ancestor has active === false (Unity GameObject semantics). */
  S.activeMap = function (scene) {
    const map = new Map();
    const kids = new Map();
    for (const n of scene.nodes) {
      const p = n.parent || '__root__';
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p).push(n);
    }
    const walk = (parentId, parentActive) => {
      for (const n of kids.get(parentId) || []) {
        const active = parentActive && n.active !== false;
        map.set(n.id, active);
        walk(n.id, active);
      }
    };
    walk('__root__', true);
    return map;
  };

  S.isActive = function (scene, node) {
    let n = node;
    let guard = 0;
    while (n && guard++ < 64) {
      if (n.active === false) return false;
      n = n.parent ? S.find(scene, n.parent) : null;
    }
    return true;
  };

  /* First active object carrying the given tag (case-insensitive, trimmed).
     Like Unity's FindGameObjectWithTag, inactive objects are skipped. */
  S.findByTag = function (scene, tag) {
    const key = String(tag == null ? '' : tag).trim().toLowerCase();
    if (!key) return null;
    const active = S.activeMap(scene);
    return scene.nodes.find((n) =>
      String(n.tag == null ? '' : n.tag).trim().toLowerCase() === key && active.get(n.id) !== false
    ) || null;
  };

  S.children = (scene, parentId) => scene.nodes.filter((n) => (n.parent || null) === (parentId || null));

  S.descendants = function (scene, id) {
    const out = [];
    const walk = (pid) => {
      for (const c of scene.nodes) {
        if ((c.parent || null) === pid) {
          out.push(c);
          walk(c.id);
        }
      }
    };
    walk(id);
    return out;
  };

  S.path = function (scene, id) {
    const out = [];
    let n = S.find(scene, id);
    let guard = 0;
    while (n && guard++ < 64) {
      out.unshift(n);
      n = n.parent ? S.find(scene, n.parent) : null;
    }
    return out;
  };

  S.localMatrix = (node) => M.mat4.compose(node.transform.position, node.transform.rotation, node.transform.scale);

  /* Split a matrix into position / Euler rotation / scale. The Euler order
     matches M.mat4.compose (R = Rz * Ry * Rx). */
  S.decompose = function (m) {
    const sx = Math.hypot(m[0], m[1], m[2]) || 1;
    const sy = Math.hypot(m[4], m[5], m[6]) || 1;
    const sz = Math.hypot(m[8], m[9], m[10]) || 1;
    const r00 = m[0] / sx, r10 = m[1] / sx, r20 = m[2] / sx;
    const r01 = m[4] / sy, r11 = m[5] / sy, r21 = m[6] / sy;
    const r02 = m[8] / sz, r12 = m[9] / sz, r22 = m[10] / sz;
    const yy = M.clamp(-r20, -1, 1);
    const y = Math.asin(yy);
    let x, z;
    if (Math.abs(yy) > 0.999999) {
      x = Math.atan2(-r12, r11);
      z = 0;
    } else {
      x = Math.atan2(r21, r22);
      z = Math.atan2(r10, r00);
    }
    return {
      position: [m[12], m[13], m[14]],
      rotation: [x * M.RAD, y * M.RAD, z * M.RAD],
      scale: [sx, sy, sz],
    };
  };

  /* Move an object under a new parent without changing its world placement. */
  S.reparentPreserve = function (scene, id, parentId) {
    const node = S.find(scene, id);
    if (!node) return false;
    const nextParent = parentId ? S.find(scene, parentId) : null;
    if (parentId && !nextParent) return false;
    if (nextParent && nextParent.id === id) return false;
    if (nextParent && S.descendants(scene, id).some((d) => d.id === nextParent.id)) return false;
    const world = S.worldMatrices(scene);
    const nodeWorld = world.get(id);
    if (!nodeWorld) return false;
    const parentWorld = nextParent ? world.get(nextParent.id) : M.mat4.identity();
    const local = M.mat4.mul(M.mat4.invert(parentWorld || M.mat4.identity()), nodeWorld);
    node.transform = S.decompose(local);
    node.parent = nextParent ? nextParent.id : null;
    return true;
  };

  S.worldMatrices = function (scene) {
    const map = new Map();
    const kids = new Map();
    for (const n of scene.nodes) {
      const p = n.parent || '__root__';
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p).push(n);
    }
    const walk = (parentId, parentMat) => {
      const list = kids.get(parentId) || [];
      for (const n of list) {
        const world = M.mat4.mul(parentMat, S.localMatrix(n));
        map.set(n.id, world);
        walk(n.id, world);
      }
    };
    walk('__root__', M.mat4.identity());
    return map;
  };

  S.bounds = function (node) {
    if (node.type === 'mesh') return UW.geom.forNode(node).bounds;
    if (node.type === 'light') return { min: [-0.18, -0.18, -0.18], max: [0.18, 0.18, 0.18] };
    if (node.type === 'camera') return { min: [-0.22, -0.22, -0.22], max: [0.22, 0.22, 0.22] };
    return { min: [-0.25, -0.25, -0.25], max: [0.25, 0.25, 0.25] };
  };

  S.worldBounds = function (node, worldMat) {
    const b = S.bounds(node);
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < 8; i++) {
      const p = [
        i & 1 ? b.max[0] : b.min[0],
        i & 2 ? b.max[1] : b.min[1],
        i & 4 ? b.max[2] : b.min[2],
      ];
      const w = M.mat4.point(worldMat, p);
      for (let a = 0; a < 3; a++) {
        if (w[a] < min[a]) min[a] = w[a];
        if (w[a] > max[a]) max[a] = w[a];
      }
    }
    return { min, max, center: [(min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2] };
  };

  S.icon = function (node) {
    if (node.bone) return 'i-rig';
    if (node.network) return 'i-net';
    if (node.sceneChanger) return 'i-scene';
    if (node.type === 'ui') return 'i-ui';
    if (node.type === 'audio') return 'i-audio';
    if (node.type === 'light') return 'i-light';
    if (node.type === 'camera') return 'i-camera';
    if (node.type === 'mesh') {
      const s = node.mesh.shape;
      if (s === 'sphere' || s === 'torus' || s === 'capsule') return 'i-sphere';
      if (s === 'plane') return 'i-grid';
      return 'i-cube';
    }
    return 'i-cube';
  };

  S.cloneSubtree = function (scene, id) {
    const root = S.find(scene, id);
    if (!root) return null;
    const idMap = new Map();
    const nodes = [root, ...S.descendants(scene, id)];
    const clones = nodes.map((n) => {
      const c = JSON.parse(JSON.stringify(n));
      c.id = uid();
      idMap.set(n.id, c.id);
      return c;
    });
    clones.forEach((c) => {
      if (c.parent && idMap.has(c.parent)) c.parent = idMap.get(c.parent);
      else if (c.id !== clones[0].id) c.parent = clones[0].id;
    });
    clones[0].parent = root.parent || null;
    clones[0].name = root.name + ' (1)';
    clones[0].transform.position = clones[0].transform.position.slice();
    clones[0].transform.position[0] += 0.6;
    clones[0].transform.position[2] += 0.6;
    return { root: clones[0], nodes: clones };
  };

  S.normalize = function (scene) {
    if (!scene || !Array.isArray(scene.nodes)) throw new Error('Not a valid scene file');
    scene.version = 1;
    const env = Object.assign(S.defaultEnv(), scene.env || {});
    env.ambient = Number.isFinite(+env.ambient) ? M.clamp(+env.ambient, 0, 2) : 0.42;
    env.ambientColor = /^#[0-9a-f]{6}$/i.test(env.ambientColor || '') ? env.ambientColor : '#ffffff';
    env.showGrid = env.showGrid !== false;
    env.fogEnabled = env.fogEnabled === true;
    env.fogColor = /^#[0-9a-f]{6}$/i.test(env.fogColor || '') ? env.fogColor : '#1d2025';
    env.fogNear = Number.isFinite(+env.fogNear) ? Math.max(0, +env.fogNear) : 14;
    env.fogFar = Number.isFinite(+env.fogFar) ? Math.max(env.fogNear + 0.1, +env.fogFar) : 70;
    env.fogNear = Math.min(env.fogNear, env.fogFar - 0.1);
    scene.env = env;
    scene.nodes = scene.nodes.map((n) => {
      const node = S.makeNode(n);
      if (!node.transform) node.transform = { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] };
      node.transform.position = node.transform.position || [0, 0, 0];
      node.transform.rotation = node.transform.rotation || [0, 0, 0];
      node.transform.scale = node.transform.scale || [1, 1, 1];
      node.visible = node.visible !== false;
      node.tag = typeof node.tag === 'string' ? node.tag.trim ? node.tag : '' : '';
      node.active = node.active !== false;
      node.behaviors = node.behaviors || [];
      if (node.type === 'mesh' && !node.mesh) node.mesh = { shape: 'cube', color: '#c9ced6', roughness: .6, metalness: .08, opacity: 1 };
      if (node.mesh) {
        node.mesh.shape = node.mesh.shape || 'cube';
        node.mesh.color = node.mesh.color || '#c9ced6';
        node.mesh.roughness = node.mesh.roughness != null ? node.mesh.roughness : .6;
        node.mesh.metalness = node.mesh.metalness != null ? node.mesh.metalness : .08;
        node.mesh.opacity = node.mesh.opacity != null ? node.mesh.opacity : 1;
        node.mesh.texture = UW.textures ? UW.textures.normalize(node.mesh.texture) : (node.mesh.texture || null);
        if (node.mesh.shape === 'model') {
          node.mesh.modelId = node.mesh.modelId != null ? node.mesh.modelId : null;
          node.mesh.meshIndex = Math.max(0, node.mesh.meshIndex | 0);
          node.mesh.primitiveIndex = Math.max(0, node.mesh.primitiveIndex | 0);
        }
      }
      if (node.type === 'light' && node.light) {
        const kinds = ['directional', 'point', 'spot'];
        if (kinds.indexOf(node.light.kind) < 0) node.light.kind = 'directional';
        node.light.color = node.light.color || '#fff4e2';
        node.light.intensity = node.light.intensity != null ? node.light.intensity : 1;
        node.light.range = node.light.range != null ? node.light.range : 14;
        node.light.angle = node.light.angle != null ? node.light.angle : 38;
        node.light.penumbra = node.light.penumbra != null ? node.light.penumbra : 0.35;
      }
      if (node.fsm && UW.FSM) {
        const fsm = UW.FSM.normalize(node.fsm);
        if (fsm) node.fsm = fsm;
        else delete node.fsm;
      }
      if (node.rig && typeof node.rig === 'object') {
        const rig = node.rig;
        rig.kind = rig.kind === 'humanoid' ? 'humanoid' : 'humanoid';
        rig.bones = rig.bones && typeof rig.bones === 'object' ? rig.bones : {};
        for (const key of Object.keys(rig.bones)) {
          if (typeof rig.bones[key] !== 'string' || !rig.bones[key]) delete rig.bones[key];
        }
        rig.bindings = Array.isArray(rig.bindings)
          ? rig.bindings.filter((b) => b && typeof b.nodeId === 'string').map((b) => ({
            nodeId: b.nodeId,
            parent: typeof b.parent === 'string' ? b.parent : null,
          }))
          : [];
        rig.height = Number.isFinite(+rig.height) && +rig.height > 0 ? +rig.height : 1;
        rig.autoBound = rig.autoBound === true;
      } else if (node.rig !== undefined) {
        delete node.rig;
      }
      if (node.bone && typeof node.bone === 'object') {
        const rest = node.bone.rest && typeof node.bone.rest === 'object' ? node.bone.rest : {};
        node.bone = {
          role: typeof node.bone.role === 'string' ? node.bone.role : 'bone',
          rig: typeof node.bone.rig === 'string' ? node.bone.rig : null,
          side: node.bone.side === 'L' || node.bone.side === 'R' ? node.bone.side : '',
          rest: {
            position: Array.isArray(rest.position) ? rest.position.slice(0, 3).map(Number) : [0, 0, 0],
            rotation: Array.isArray(rest.rotation) ? rest.rotation.slice(0, 3).map(Number) : [0, 0, 0],
            scale: Array.isArray(rest.scale) ? rest.scale.slice(0, 3).map(Number) : [1, 1, 1],
          },
        };
      } else if (node.bone !== undefined) {
        delete node.bone;
      }
      if (node.rigAnim && typeof node.rigAnim === 'object') {
        const anim = node.rigAnim;
        const clips = UW.rig && UW.rig.clipIds
          ? UW.rig.clipIds
          : ['none', 'idle', 'walk', 'run', 'wave', 'dance', 'jump', 'crouch', 'punch', 'kick', 'swim', 'fly', 'sit', 'custom'];
        node.rigAnim = {
          enabled: anim.enabled !== false,
          playing: anim.playing !== false,
          clip: clips.indexOf(anim.clip) >= 0 ? anim.clip : 'idle',
          speed: Number.isFinite(+anim.speed) ? M.clamp(+anim.speed, 0, 8) : 1,
          custom: anim.custom && typeof anim.custom === 'object' ? anim.custom : {},
        };
      } else if (node.rigAnim !== undefined) {
        delete node.rigAnim;
      }
      if (node.network && typeof node.network === 'object') {
        const net = node.network;
        node.network = {
          netId: typeof net.netId === 'string' && net.netId ? net.netId : 'net_' + uid(),
          owner: typeof net.owner === 'string' ? net.owner : '',
          syncPosition: net.syncPosition !== false,
          syncRotation: net.syncRotation !== false,
          syncScale: net.syncScale === true,
          syncActive: net.syncActive !== false,
          syncColor: net.syncColor !== false,
          interpolation: Number.isFinite(+net.interpolation) ? M.clamp(+net.interpolation, 0, 2) : 0.12,
          autoOwn: net.autoOwn === true,
        };
      } else if (node.network !== undefined) {
        delete node.network;
      }
      if (node.type === 'ui') {
        if (!node.ui || typeof node.ui !== 'object') node.ui = { kind: 'panel' };
        if (UW.unityui) node.ui = UW.unityui.normalize(node.ui);
        else {
          node.ui.kind = node.ui.kind || 'panel';
          node.ui.visible = node.ui.visible !== false;
        }
      } else if (node.ui !== undefined) {
        delete node.ui;
      }
      if (node.type === 'audio') {
        const au = node.audio && typeof node.audio === 'object' ? node.audio : {};
        node.audio = {
          kind: au.kind === 'file' ? 'file' : 'tone',
          src: typeof au.src === 'string' ? au.src : '',
          frequency: Number.isFinite(+au.frequency) ? M.clamp(+au.frequency, 20, 12000) : 440,
          volume: Number.isFinite(+au.volume) ? M.clamp(+au.volume, 0, 1) : 0.25,
          loop: au.loop === true,
          playOnAwake: au.playOnAwake !== false,
          playing: au.playing !== false,
          wave: ['sine', 'square', 'sawtooth', 'triangle'].indexOf(au.wave) >= 0 ? au.wave : 'sine',
          duration: Number.isFinite(+au.duration) ? M.clamp(+au.duration, 0.05, 30) : 0.3,
        };
      } else if (node.audio !== undefined) {
        delete node.audio;
      }
      if (node.sceneChanger && typeof node.sceneChanger === 'object') {
        const sc = node.sceneChanger;
        const defaults = UW.scenes && UW.scenes.changerDefaults
          ? UW.scenes.changerDefaults()
          : { title: 'SCENE CHANGER', scenes: [], visible: true, showInEditor: true };
        node.sceneChanger = {
          enabled: sc.enabled !== false,
          visible: sc.visible !== false,
          showInEditor: sc.showInEditor !== false,
          title: typeof sc.title === 'string' && sc.title.trim() ? sc.title.slice(0, 48) : defaults.title,
          scenes: Array.isArray(sc.scenes)
            ? sc.scenes.filter((s) => typeof s === 'string' && s.trim()).map((s) => s.trim().slice(0, 64)).slice(0, 32)
            : defaults.scenes.slice(),
        };
        if (!node.sceneChanger.scenes.length) node.sceneChanger.scenes = defaults.scenes.slice();
      } else if (node.sceneChanger !== undefined) {
        delete node.sceneChanger;
      }
      if (node.type === 'camera' && node.camera && typeof node.camera === 'object') {
        const cam = node.camera;
        cam.fov = Number.isFinite(+cam.fov) ? M.clamp(+cam.fov, 5, 170) : 55;
        cam.near = Number.isFinite(+cam.near) ? Math.max(0.001, +cam.near) : 0.1;
        cam.far = Number.isFinite(+cam.far) ? Math.max(cam.near + 0.01, +cam.far) : 600;
        cam.bg = /^#[0-9a-f]{6}$/i.test(cam.bg || '') ? cam.bg : '#1d2025';
        cam.secondary = cam.secondary === true;
        const pip = cam.pip && typeof cam.pip === 'object' ? cam.pip : {};
        cam.pip = {
          enabled: pip.enabled === true,
          corner: ['topLeft', 'topRight', 'bottomLeft', 'bottomRight'].indexOf(pip.corner) >= 0 ? pip.corner : 'bottomRight',
          width: Number.isFinite(+pip.width) ? M.clamp(+pip.width, 120, 960) : 320,
          height: Number.isFinite(+pip.height) ? M.clamp(+pip.height, 80, 640) : 200,
        };
      }
      return node;
    });
    // repair dangling parent links
    const ids = new Set(scene.nodes.map((n) => n.id));
    scene.nodes.forEach((n) => {
      if (n.parent && !ids.has(n.parent)) n.parent = null;
    });
    // repair rig records that point at removed bones
    for (const n of scene.nodes) {
      if (!n.rig) continue;
      for (const key of Object.keys(n.rig.bones)) {
        if (!ids.has(n.rig.bones[key])) delete n.rig.bones[key];
      }
      n.rig.bindings = n.rig.bindings.filter((b) => ids.has(b.nodeId));
      if (!Object.keys(n.rig.bones).length) delete n.rig;
    }
    for (const n of scene.nodes) {
      if (n.rigAnim && !n.rig) delete n.rigAnim;
      if (n.bone && (!n.bone.rig || !ids.has(n.bone.rig) || !S.find(scene, n.bone.rig))) delete n.bone;
    }
    scene.network = Object.assign(S.defaultNetwork(), scene.network && typeof scene.network === 'object' ? scene.network : {});
    const netCfg = scene.network;
    netCfg.transport = ['local', 'webrtc', 'ws', 'postmessage'].indexOf(netCfg.transport) >= 0 ? netCfg.transport : 'local';
    netCfg.room = typeof netCfg.room === 'string' && netCfg.room.trim() ? netCfg.room.trim().slice(0, 64) : 'My Game';
    netCfg.url = typeof netCfg.url === 'string' ? netCfg.url.trim() : '';
    netCfg.autoConnect = netCfg.autoConnect === true;
    netCfg.playerName = typeof netCfg.playerName === 'string' ? netCfg.playerName.slice(0, 32) : 'Player';
    netCfg.playerObject = typeof netCfg.playerObject === 'string' ? netCfg.playerObject : '';
    // imported models: keep valid records and warm the parser cache
    scene.models = Array.isArray(scene.models)
      ? scene.models.filter((m) => m && typeof m.id === 'string' && m.id && typeof m.data === 'string' && /^data:/i.test(m.data))
      : [];
    if (UW.models && scene.models.length) {
      try { UW.models.warm(scene); } catch (e) { console.warn('[WebForge] Model cache warm-up failed: ' + (e.message || e)); }
    }
    return scene;
  };

  S.uniqueName = function (scene, base, excludeId) {
    const names = new Set(
      scene.nodes.filter((n) => n.id !== excludeId).map((n) => n.name)
    );
    if (!names.has(base)) return base;
    let i = 1;
    while (names.has(base + ' (' + i + ')')) i++;
    return base + ' (' + i + ')';
  };

  S.stats = function (scene) {
    let tris = 0;
    const active = S.activeMap(scene);
    for (const n of scene.nodes) {
      if (!n.visible || active.get(n.id) === false || n.type !== 'mesh') continue;
      tris += UW.geom.forNode(n).positions.length / 9;
    }
    return { objects: scene.nodes.length, triangles: tris, models: (scene.models || []).length };
  };
})();
