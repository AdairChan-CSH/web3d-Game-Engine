# WebForge 3D

A Unity-inspired 3D scene editor that runs in the browser using **only HTML, CSS and vanilla JavaScript**.

There is no build step, no Node.js, no Python, no database and no web server requirement. The entire editor is a set of static files. Three.js and Babylon.js are loaded on demand from their CDNs; a built-in software renderer keeps the editor fully usable offline.

**Runs offline · No build step · No runtime dependencies · Pluggable engines**

---

## Quick start

1. Open `webforge3d/index.html` directly in a modern browser (double-click it).
2. Wait for the default engine to load. The **start screen** lists 12 ready-made templates and any saved scenes — pick one and press **Open in editor** (or **Continue current scene**). Reopen it later with **Ctrl + M**.
3. With an internet connection the editor starts on Three.js; if the CDN is unavailable it automatically falls back to **Native Canvas** and keeps working.
4. Click objects in the viewport or Hierarchy, move them with the gizmo, press **Ctrl + P** to play.

No installation step is required. If you prefer serving the folder over HTTP instead of opening it from disk, any static file server works — nothing about the editor depends on which one you use.

### Browser support

Chrome, Edge, Firefox and Safari (current versions). WebGL is used by Three.js and Babylon.js; **Native Canvas** needs only Canvas 2D.

---

## What is included

| Area | Features |
| --- | --- |
| **Scene editing** | Hierarchy with parenting, rename, duplicate, delete, visibility, active state, tags, search |
| **Model import** | Drag in `.glb` / `.gltf` / `.obj` (+ `.mtl` + textures) / `.blend` files; meshes, materials, embedded images and the node tree become editable scene objects |
| **Auto-rig** | One-click 19-bone humanoid skeleton for imported characters: nearest-bone mesh binding, 13 procedural clips (idle / walk / run / wave / dance / jump / crouch / punch / kick / swim / fly / sit / custom), per-bone posing |
| **Start screen** | Launcher with 12 built-in templates, saved scenes, "play immediately" and "skip on startup" preferences; reopen any time with `Ctrl + M` |
| **Unity UI** | Ten canvas element types drawn as a DOM overlay: Canvas, Panel, Text, Button, Image, Slider, Toggle, Input, Dropdown, Progress — engine independent, with FSM events and click actions |
| **Input settings** | Rebinding for 12 actions across keyboard and gamepad (Gamepad API), deadzone, look/mouse sensitivity, invert Y and vibration; saved in `localStorage` |
| **Second camera** | Picture-in-picture preview projected from a real scene camera, rendered by a private Native Canvas adapter, with corner/size controls and a toolbar toggle |
| **Scene changer** | In-game scene menu component that switches between templates and saved scenes during Play mode |
| **Audio source** | Generated tones (sine / square / sawtooth / triangle) or audio files with volume, loop and play-on-start; inspector preview and FSM controls |
| **Multiplayer** | Network Object component with stable net IDs, ownership, transform / active / colour sync and interpolation; local tabs, postMessage bridge, manual WebRTC or an optional WebSocket relay — no server required |
| **Inspector** | Transform, mesh material, texture, light, camera (including second camera / PiP), rigidbody, behaviors, JavaScript script, FSM, Unity UI, Audio Source, Scene Changer, Auto-Rig and Network Object |
| **Viewport** | Orbit / pan / zoom, ray-pick selection, focus, grid, Scene & Game views |
| **Gizmos** | Move, rotate and scale handles; World/Local space; drag snapping with Shift |
| **Lights** | Directional / Sun, Point and Spot lights with range, cone angle and penumbra |
| **Environment** | Ambient intensity and color, grid toggle, distance fog (color, near, far) |
| **Textures** | 10 procedural presets, image upload, full texture editor (brush, eraser, fill, shapes, mirroring, undo/redo, PNG export), tiling/offset, enable/remove |
| **Visual FSM** | PlayMaker-style state graph: states, six trigger types, variables, **207 ordered actions in 21 categories**, plus a searchable Action Library |
| **Play mode** | Play / pause / step / stop, runtime scripts, behaviors, FSM, AABB rigidbody physics with force, drag, freeze and raycasts, rig animation and network sync |
| **External calls** | HTTP (GET/POST/PUT/PATCH/DELETE), JSON reading, PHP / form endpoints, scene download, browser links |
| **Engines** | Three.js, Babylon.js, Native Canvas, plus runtime engine plugins with a capability matrix |
| **Persistence** | Named scenes in `localStorage`, JSON download/import, drag-and-drop `.json` |
| **Editing comfort** | Undo/redo history, keyboard shortcuts, console with script errors, FPS/triangle stats |
| **Extras** | Viewport screenshot, help/API dialogs, engine panel with per-engine docs |

The sample scene is a small physics playground: ground, cube, spinning sphere, falling cylinder, torus, light and camera.

---

## Editor tour

- **Menu bar** — File, Edit, GameObject, Component, Window, Engine, Help.
- **Toolbar** — transform tools (`Q W E R`), World/Local space, play controls, engine picker, Scene/Game toggle.
- **Hierarchy (left)** — scene tree, search, create button, focus button. Double-click focuses an object; drag a row onto another to re-parent it.
- **Engines panel (left)** — click a card (or the toolbar select) to switch renderers. Switching never modifies the scene. The last used engine is remembered.
- **Viewport (center)** — the 3D scene, selection outline, gizmo overlay and a drop zone for scene files and 3D models (`.json`, `.glb`, `.gltf`, `.obj`, `.blend`).
- **Project panel (bottom)** — primitives, actors, saved scenes and the Console.
- **Inspector (right)** — live properties of the selection. The header carries the object name, **Active** / **Visible** toggles and its **Tag**; numeric transforms update the viewport immediately and create undo entries.
- **Status bar** — engine name, object/triangle counts, multiplayer status, FPS, play time.

---

## Start screen & templates

The **start screen** opens when the editor launches and can be reopened with `Ctrl + M` or **File → Start Screen / Templates…**.

- **Templates** — Sample Scene, Blank 3D, 3D Platformer, First-Person Arena, Third-Person, Multiplayer Arena, UI Toolkit Demo, Physics Playground, Arcade Racing, Scene Hub, Space Explorer and Everything Showcase. Each is a complete scene: lights, camera, ground, playable scripts and, where relevant, Unity UI, audio, a scene changer and network objects.
- **Saved scenes** are listed alongside templates, so you can jump straight back into work.
- **Open in editor** loads the chosen scene; tick **Start playing immediately** to enter Play mode at once.
- **Skip this screen on startup** stores the preference, and the chosen template / play setting is remembered in `localStorage` under `webforge3d.launcher.v1`.
- **Continue current scene** and `Esc` close the launcher without changing anything.

Template scenes live in `js/core/scenes.js`; the in-game **Scene Changer** and the **Go to scene** FSM action use the same registry.

---

## Controls

| Action | Input |
| --- | --- |
| Select tool | `Q` |
| Move / Rotate / Scale | `W` / `E` / `R` |
| Orbit viewport | Left-drag empty space |
| Pan viewport | Middle-drag or `Shift` + left-drag |
| Zoom viewport | Mouse wheel |
| Select object | Left-click in viewport or Hierarchy |
| Focus selection | `F` or double-click |
| Play / stop | `Ctrl + P` (or toolbar) |
| Pause | `Ctrl + Shift + P` |
| Step one frame | Toolbar step button (while paused) |
| Undo / redo | `Ctrl + Z` / `Ctrl + Y` or `Ctrl + Shift + Z` |
| Duplicate | `Ctrl + D` |
| Delete | `Delete` / `Backspace` |
| Save scene | `Ctrl + S` |
| New scene | `Ctrl + N` |
| Open saved scene | `Ctrl + O` |
| Start screen / templates | `Ctrl + M` |
| Toggle picture-in-picture | Toolbar PiP button (`#btn-pip`) |
| Rebind keyboard / gamepad | **Window → Keyboard & Gamepad Settings…** |
| Snap while dragging | Hold `Shift` |
| Escape | Stop play mode, or clear selection |
| Help | `F1` |

Inside a text field, typing shortcuts are ignored so names and scripts can be edited normally.

---

## Keyboard & gamepad input

Open **Window → Keyboard & Gamepad Settings…** (also available from the start screen) to remap controls and tune how the editor and games read input.

| Group | Setting |
| --- | --- |
| **Actions** | Move forward, move back, move left, move right, jump, fire, interact, sprint, crouch, pause, camera toggle and reload |
| **Keyboard** | Click **Key**, then press any key. `Esc` cancels. |
| **Gamepad** | Click **Pad**, then press a controller button. The standard mapping covers A/B/X/Y, LB/RB, LT/RT, Back/Start, sticks and the D-pad. |
| **Analogue** | Stick deadzone, look sensitivity, mouse sensitivity, invert Y |
| **Feedback** | Vibration toggle and **Test gamepad vibration** |

- Bindings persist in `localStorage` under `webforge3d.input.v1`; **Reset defaults** restores the shipped map.
- Gamepads use the browser **Gamepad API**. Connect the controller and press a button before testing.
- The runtime polls the map every frame: scripts get `ctx.input`, `ctx.action(name)`, `ctx.axis('moveX')`, `ctx.jump`, `ctx.vibrate()`; PlayMaker has matching **Input** actions.
- Gamepad support depends on the browser; Safari exposes a reduced button set.

---

## Engines

### Built-in engines

| Engine | Source | Notes |
| --- | --- | --- |
| **Three.js r157** | jsDelivr CDN | PBR materials, soft shadows, WebGL |
| **Babylon.js 8.x** | babylonjs.com CDN | PBR materials, shadows, right-handed scene |
| **Native Canvas** | included | Software painter's-algorithm renderer; no CDN, no WebGL |

The editor is engine-agnostic: hierarchy, inspector, gizmos, play mode, scripts and saving all operate on a shared scene model. Adapters only draw that model.

### Switching and fallback

- Pick an engine from the toolbar select, the **Engine** menu, or the **Engines** panel.
- CDN engines are fetched the first time they are selected, then reused.
- Script loads time out after 20 seconds.
- If a CDN engine cannot start (offline, blocked, WebGL missing), the editor logs the error and falls back to **Native Canvas** instead of leaving a blank viewport.
- The choice is stored in `localStorage` under `webforge3d.engine`.

### Plugin / connect flow

`Engine → Connect engine plugin…` (or the `+ Connect engine…` card) asks for a plain JavaScript URL. The script is loaded at runtime and may register one or more engines with `UnityWeb.engines.register({...})`. Relative paths such as `plugins/blueprint-canvas.js` work when the editor is served over HTTP; from `file://`, use a path relative to `index.html` or a CDN URL.

A working example ships in [`plugins/blueprint-canvas.js`](plugins/blueprint-canvas.js). It subclasses the built-in Canvas renderer and restyles it as a drafting blueprint. See [`plugins/README.md`](plugins/README.md) for the full adapter contract.

Each engine definition may declare a `capabilities` object. The editor uses it to build the compatibility matrix and the capability rows in the Engines panel; undeclared features appear as **Unknown** rather than being guessed.

### Compatibility

Open **Window → Engine Compatibility…**, **Engine → Engine compatibility…** or **Help → Engine compatibility matrix** for a live table. The active engine is highlighted, and every chip can carry a tooltip explaining its limitation.

Everything except rendering is shared and therefore identical across engines:

| Shared (always available) | Renderer-dependent |
| --- | --- |
| Scene model, hierarchy, transforms, undo/redo | Shadows and shadow quality |
| Gizmos, picking, camera controls | PBR / metalness / roughness |
| Saving, JSON import/export | Point and spot light shading |
| Play mode, scripts, behaviors, AABB physics | Fog quality |
| **All FSM actions and transition triggers** | Texture filtering and anti-aliasing |
| Audio and toasts | Wireframe and transparency details |

| Feature | Three.js | Babylon.js | Native Canvas |
| --- | --- | --- | --- |
| Shadows | Full | Full | None |
| Directional / point / spot lights | Full | Full | Full |
| Fog | Full | Full | Full |
| Textures and tiling | Full | Full | Full |
| Transparency / wireframe | Full | Full | Full |
| PBR shading | Full | Full | Partial (approximate) |
| Anti-aliasing | Full | Full | Partial |
| Works offline | No (CDN) | No (CDN) | Yes |

A renderer that cannot draw shadows still runs every shadow-related FSM action: the action writes scene data, and the next engine that supports shadows will show the result. Switching engines never rewrites the scene.

---

## Lights and environment

Create lights from **GameObject → Light** or the Project panel:

| Light | Behaviour |
| --- | --- |
| **Directional / Sun** | Parallel light; direction comes from the object rotation (+Z axis) |
| **Point** | Omnidirectional light with a range falloff |
| **Spot** | Cone light along the object +Z axis with range, cone angle and penumbra |

Select a light to edit its color, intensity, range and — for spot lights — cone angle and penumbra in the Inspector. The same values drive all three renderers, so switching engines does not change the lighting setup.

**Window → Environment / Lighting…** edits scene-wide settings:

- **Ambient** intensity and color.
- **Grid** visibility in the Scene view.
- **Fog** — enable it, then set color, near and far distances. Fog is applied by Three.js, Babylon.js and the Native Canvas renderer.

---

## Second camera (picture-in-picture)

A second camera renders a live picture-in-picture view in the Game view — useful for minimaps, security cameras, racing mirrors or split-screen previews.

- Create one from **GameObject → Second Camera** or tick **Second camera → Picture-in-picture** on any Camera in the Inspector.
- The overlay is drawn by a private **Native Canvas** adapter and projected from the camera's real scene transform, so it works with every render engine without replacing the main camera.
- Inspector settings: **Show PiP**, **Corner** (four positions), **Width** and **Height**.
- The toolbar PiP button (`#btn-pip`) toggles the preview; the preference is stored under `webforge3d.pip`.
- The PiP overlay appears only in the Game view or Play mode.
- **FSM** — `Second camera: set` configures it and `Second camera: toggle` shows / hides it at runtime.

---

## Tags and active state

Every object in the Inspector header has three Unity-style controls:

- **Tag** — a free-text label with Unity-style suggestions (Player, Enemy, NPC, Pickup, GameController, …). Tags are used by the FSM actions **Set tag**, **Get tag**, **Find object by tag** and **Compare tag**, by the script API (`ctx.findByTag`), and they show as a tooltip in the Hierarchy. Tags are case-insensitive when matched.
- **Active** — the object's on/off state, following Unity `GameObject` semantics: unchecking it (or running the **Activate / deactivate** / **Toggle active** actions) stops the object *and its whole subtree* from rendering, colliding, raycasting and running scripts, behaviors and FSMs. Nothing is destroyed — script and FSM state is preserved, inactive-at-play-start objects simply defer their `onStart` / FSM start until they are activated again.
- **Visible** — a renderer-only toggle for that one object; children keep their own setting (same as the eye icon in the Hierarchy).

Inactive objects are drawn dimmed with a strike-through in the Hierarchy and excluded from the scene stats.

---

## Unity UI (canvas overlay)

UI is scene data (`node.type === "ui"` with a `node.ui` block) and is rendered as a DOM overlay above the Game view, so it is independent of the active renderer and stays crisp at any resolution.

Add elements from **GameObject → UI**, **Component → UI Canvas / Element**, the Inspector **Add Component** menu, or **Window → Unity UI Library…**.

| Element | What it does |
| --- | --- |
| **Canvas** | Full-screen root that owns child UI elements |
| **Panel** | Coloured / translucent background with rounded corners |
| **Text** | Caption with font size, weight, alignment and colour |
| **Button** | Clickable label that broadcasts an FSM event; optional scene load, URL, play or stop action |
| **Image** | Procedural or uploaded texture, tint and alpha |
| **Slider** | 0–1 track with knob; current value is readable by FSMs |
| **Toggle** | Checkbox with label and checked state |
| **Input** | Single-line text field |
| **Dropdown** | Option list with a selected index |
| **Progress** | 0–100 % fill bar |

- **Inspector** — anchor (nine positions), position, size, text, colours, background alpha, opacity, font size / weight / alignment, interactable, FSM event and image texture.
- **Play mode** — the overlay receives pointer and keyboard input; FSM events fire on click, change and submit, and values are stored in `runtime.uiValues` under both the element name and id.
- **Editor mode** — UI is display-only in the Scene view and interactive in the Game view.
- **Scripts** — `ctx.ui(name)`, `ctx.uiGet`, `ctx.uiSet`, `ctx.uiClick` and `ctx.uiVisible`.
- **FSM** — the `UI:` actions set text, value, toggle, progress, colour, opacity, visibility and interactable state, and click elements programmatically.

Scenes can mix the DOM overlay with HTML HUD elements outside the canvas using the **UI & Browser** actions.

---

## Audio sources

An **Audio Source** is a scene object that plays a generated tone or an audio file. Add one from **GameObject → Audio Source** or **Component → Audio Source**.

- **Generated tone** — frequency, waveform (sine / square / sawtooth / triangle) and duration.
- **Audio file / URL** — pick a local file (stored as a data URL) or paste a path / URL.
- **Playback** — volume, loop and **Play on Start** are saved in the scene. Sources stop cleanly when Play mode stops.
- **Inspector** — **Play** and **Stop** preview the sound while editing.
- **FSM** — `Audio: play source`, `stop source`, `set volume` and `is playing?`; scripts can call `ctx.playClip` and `ctx.playTone`.

---

## Importing 3D models

Use **File → Import 3D Model…** or simply drop model files onto the viewport. Supported formats:

| Format | What is imported |
| --- | --- |
| **`.glb` / `.gltf`** | Meshes (multiple primitives per mesh), PBR base color / roughness / metalness / opacity / double-sided flags, embedded textures (embedded buffers and data-URI images, including `KHR_texture_transform` tiling/offset), the node hierarchy with transforms (TRS or matrices) |
| **`.obj`** (+ `.mtl` + image files) | Groups become meshes; `usemtl` materials map to colors, opacity and textures. Drop the `.obj`, its `.mtl` and any referenced images (`png`, `jpg`, `jpeg`, `webp`, `gif`, `bmp`) together — the editor pairs them automatically. Negative indices, quads and polygons (fan triangulation) are handled. |
| **`.blend`** | Native Blender files, parsed by reading the file's own DNA structure catalogue: works across Blender 2.5x–4.x in both endiannesses, 32/64-bit builds and gzip-compressed saves. Mesh objects, vertex positions / normals / UVs, materials (base color, alpha) and the object hierarchy with local transforms are imported. |

How an import lands in the editor:

- A **container** node named after the file holds the imported hierarchy, so moving/rotating/scaling it transforms the whole model. You can also edit, re-parent or delete the individual parts like any GameObject.
- Each mesh part becomes a mesh node with an **Imported model** renderer entry. Triangles are counted in the status bar and the Inspector; materials, colors and textures stay editable per node.
- Models are parsed once, cached, and **warmed on scene load** — reopening a saved scene restores geometry, textures and materials instantly.
- Every engine renders imported models — Three.js, Babylon.js, Native Canvas and third-party plugins — because imports flow through the shared geometry pipeline; there is no engine-specific loader.
- Imports are undoable (**Import model** appears in the history) and can be saved: model files are stored as data URLs inside the scene.

### Coordinate systems and units

Blender is Z-up, this editor is Y-up (like glTF/Unity/Three.js):

- `.blend` imports get a **−90° X rotation on the container** so the model appears upright; each object's local transform is kept exactly as Blender stored it.
- `.obj` and glTF files are already Y-up and import without any correction.
- 1 unit in the file is 1 unit in the scene for every format.

### OBJ and Blender tips

- **OBJ with materials** — drop the `.obj`, `.mtl` and image files in one go (or pick them in one multi-select). Only the `.obj` is required; without the `.mtl`, groups still import with default colors. Files are matched by name, ignoring folders.
- **Blender** — apply modifiers in Blender before saving for the geometry you expect; curves, lattices, lights and cameras are skipped (mesh objects only). Deleting unused datablocks first shrinks the file.

### Model storage in scene JSON

Imported models live once per scene in a top-level `models` array, and mesh nodes reference them:

```json
{
  "models": [
    {
      "id": "mdl_ab12cd_0",
      "name": "robot",
      "format": "glb",
      "data": "data:model/gltf-binary;base64,..."
    },
    {
      "id": "mdl_ef34gh_1",
      "name": "plate",
      "format": "obj",
      "data": "data:text/plain;base64,...",
      "mtl": "data:text/plain;base64,...",
      "images": { "tex.png": "data:image/png;base64,..." }
    }
  ],
  "nodes": [
    {
      "id": "n_robot",
      "type": "mesh",
      "mesh": {
        "shape": "model",
        "modelId": "mdl_ab12cd_0",
        "meshIndex": 0,
        "primitiveIndex": 0,
        "color": "#ff8c26",
        "roughness": 0.3,
        "metalness": 0.8
      }
    }
  ]
}
```

`data` (and the OBJ companions `mtl` / `images`) are data URLs of the original files. Large models make scenes heavy — the editor warns above 4 MB and suggests downloading the scene as `.json`, which has no storage quota. The FSM action **Clone object** duplicates nodes without duplicating the stored model; two imports of the same file share nothing.

### Import limitations

Skipped features are reported as Console warnings rather than failing the import:

- **glTF** — skins (bind-pose geometry is used), animation clips, morph targets, cameras and lights are ignored. External `.bin` buffers and external image references are not fetched (embedded data only).
- **OBJ** — geometry is fan-triangulated (quads/polygons become triangles); from `.mtl` only `Kd`, `Ka` (when `Kd` is absent), `d`/`Tr`/`trans` and `map_Kd` / `map_d` / `map` are read.
- **Blender** — mesh objects only; unapplied modifiers, curves, surfaces, lattices, metaballs, lights, cameras, armatures, shape keys and packed/linking structures are skipped. Material slots map to color/alpha (textures embedded in `.blend` files are not extracted).
- All formats — one material per mesh part; no multi-material primitive splitting beyond what the file defines as separate meshes/groups.

---

## Auto-rigging characters

Select an imported model (or any empty root) and use **Component → Auto-Rig (Humanoid)**, **Window → Auto-Rig (Humanoid)…** or the **Auto-Rig** button in the Inspector. The editor builds a 19-bone humanoid skeleton from the model's world bounding box:

`Hips → Spine → Chest → Neck → Head`, plus `Shoulder / Upper Arm / Lower Arm / Hand` and `Upper Leg / Lower Leg / Foot` for both sides.

- **Height** — blank measures the model; a value in metres overrides it and scales the skeleton.
- **Mesh binding** — *Nearest bone* re-parents each separate mesh part to the closest joint while preserving its world transform. A single full-body mesh is left on the model root so it is not stretched; skipped parts are listed in the Console. *None* builds bones only.
- **Clips** — `idle`, `walk`, `run`, `wave`, `dance` and `custom` are procedural and run in Play mode. Choose a clip and speed in the Inspector; **Play clip** starts or pauses it.
- **Bones are ordinary scene objects** — click a bone chip to select it, pose it in the Transform inspector, or reset it. Nothing is engine-specific, so bones animate on Three.js, Babylon.js, Native Canvas and plugins.
- **Rebuild** recreates the skeleton from the current bounds; **Remove rig** deletes the bones and returns every bound mesh to the model root.
- **Persistence** — rigs, bones, bindings and clip settings save, load, duplicate and undo like any other scene data.
- **FSM** — the **Rig & Animation** actions play / stop / pause clips, set bone rotations, query bones and reset poses at runtime.

Rigging does not create skinned deformation: binding is rigid per mesh part. Characters modelled as separate body parts (common for OBJ and low-poly glTF assets) animate best.

---

## Multiplayer

Add **Component → Network Object** to an object, then open **Window → Multiplayer…**. Every network object gets a stable **net ID**, an owner and a set of sync flags.

1. Choose a **transport** and **room name**.
2. Optionally pick a **player object** (auto-claimed on connect) and a player name.
3. Press **Apply & Connect**, then **Play** in every participating tab.
4. Use the Inspector buttons or the **Multiplayer** FSM actions to claim / release, spawn / despawn and send events.

### Transports

| Transport | Needs a server? | Use it for |
| --- | --- | --- |
| **Local browser tabs** | No | Two or more tabs of the same browser, same origin. Uses `BroadcastChannel` with a `localStorage` fallback. |
| **postMessage bridge** | No | Embedding the editor in an iframe or opening it in a second window; peers are discovered and synced through the browser `postMessage` API. |
| **WebRTC (manual)** | No signalling server | Two different browsers. Host creates an **offer**, the guest pastes it and returns an **answer**, then the host applies it. Copy/paste the codes from the Multiplayer dialog. |
| **WebSocket relay** | Your own relay | Any number of peers across machines. Enter a `ws://` or `wss://` URL; messages are forwarded as JSON. |

### Sync model

- Only the **owner** streams snapshots; remote peers interpolate position, rotation, scale, active / visible and colour at the configured factor.
- **Claim** transfers authority; **Release** clears it. A peer that disconnects releases everything it owned.
- **Spawn** sends a serialized subtree (including FSM data and any referenced imported-model records) to every peer; **Despawn** removes it everywhere. Both rebuild physics and FSM runners.
- **Network events** are queued on the runtime and can drive FSM transitions or be read with **Get last network event**.
- The status bar shows **Net: N peers** and the current connection state.
- Offline network objects behave exactly like normal scene objects, so a scene always works without a second player.

Networking is data-only: it never calls a renderer, so it is identical on every engine. The editor itself still runs from `file://` and static hosting; whether same-browser tabs share a room there depends on the browser's `file://` origin rules. WebRTC needs a secure context (`https://` or `localhost`), and a remote WebSocket relay must accept your origin.

---

## Textures and painting

Every mesh can carry one texture. Add it from **Component → Texture / Material**, the Inspector **Add Component** menu, or **Window → Texture Editor…**. Textures are stored as plain scene data, so they survive engine switches, undo/redo, saving, JSON export and Play mode.

- **Presets** — checker, grid, bricks, tiles, noise, gradient, stripes, dots, wood and marble.
- **Upload** — pick any image up to 8 MB; it is embedded in the scene as a data URL.
- **Texture editor** — a 512×512 painting surface with:
  - brush and eraser with adjustable size, colour picker and a 16-colour palette
  - flood fill (with tolerance) and a colour picker tool
  - line, rectangle and ellipse tools with a live preview
  - horizontal and vertical mirroring for symmetrical textures
  - optional 16×16 grid overlay and a live 2 × 2 tiling preview
  - undo / redo (also `Ctrl + Z` / `Ctrl + Y`), fill all, clear to white
  - image import, PNG export and preset loading
  - **Apply to object** stores the painting inside the scene, so no asset folder is needed; **Cancel** leaves the original texture untouched
- **Tiling / Offset** — repeat the image across UVs and shift it; the Inspector shows a live preview.
- **Visible** — temporarily disable a texture without removing it. The remove button deletes the component.

The Native Canvas renderer maps textures per triangle with Canvas 2D affine transforms using cached tiled patterns, so painting and texturing work completely offline. Three.js uses a `CanvasTexture` with repeat/offset; Babylon.js uses a `DynamicTexture`.

---

## Visual finite state machine (PlayMaker style)

Add **Component → PlayMaker FSM** to any object, then open **Open Graph Editor** in the Inspector or **Window → FSM Graph Editor…**.

The graph editor is a modal canvas of draggable state cards connected by arrows:

- **Add State** — create a state; drag cards to arrange the graph.
- **→ Link States** — click a source state, then a target state to add a transition.
- **Click a state** — edit its name, mark it as the start state, and build its **actions on entry**.
- **Click an arrow** — edit the transition trigger.
- **Variables** — add FSM-local variables used by conditions and actions.

Transitions support six triggers:

| Trigger | Fires when |
| --- | --- |
| **After delay** | The source state has been active for at least `delay` seconds |
| **On event** | A matching event is emitted (`ctx.emitEvent("done")` or an FSM *Send event* action) |
| **While key held** | The key is down, checked every frame (`KeyboardEvent.key` names such as `Space` or `ArrowUp`) |
| **On key down** | The frame the key is first pressed |
| **On key up** | The frame the key is released |
| **On variable** | A variable satisfies `==`, `!=`, `>`, `<`, `>=` or `<=` against a value |

The first matching transition from the current state is taken each frame.

### Actions

States run an **ordered action queue** when they are entered. Add actions from the grouped picker in the state panel; each card shows its category, a one-line description and its parameters. Actions with a **Target** field accept `self`, `parent`, a node name or a node id, so one state can drive other objects.

The library contains **207 actions in 21 categories**. Open **Window → PlayMaker Action Library…** to search all of them, read each action's help and parameters, and add one to the selected object's FSM.

| Category | Actions |
| --- | --- |
| **Flow** | Log message · Wait · Send event · Start FSM · Stop FSM · Restart FSM · Enable / disable FSM |
| **Scene & Flow** | Go to scene · Go to scene URL · Restart scene · Save scene as · Exit to editor · Scene changer: show / hide · Scene changer: add scene |
| **Transform** | Move (relative) · Rotate (relative) · Set position / rotation / scale · Move to (tween) · Move by (tween) · Rotate to (tween) · Scale to (tween) · Look at point · Look at object · Reset transform · Stop tweens |
| **Variables & Math** | Set / add / multiply / clamp variable · Random float · Random integer · Toggle variable · Copy variable · Math operation · Get transform value · Get distance · Format string |
| **String & Text** | Replace text · Split string · Change text case · Convert variable (integer, decimal, fixed, text) |
| **Logic & Scene** | Branch on variable · Set ambient light · Set fog |
| **GameObject** | Set visible · Toggle visible · Set parent · Set object name · Destroy object · Clone object · Activate / deactivate · Toggle active · Set tag · Get tag · Find object by tag · Compare tag |
| **Material & Texture** | Set color · Set opacity · Set wireframe · Set texture preset · Set texture tiling · Set texture offset · Remove texture |
| **Lighting** | Set light color / intensity / range / spot angle / spot penumbra · Toggle light |
| **Camera** | Set camera FOV · Set camera clipping · Set camera background · Second camera: set · Second camera: toggle |
| **Physics** | Add impulse · Set velocity · Set body gravity · Set world gravity · Add force · Set mass · Set bounciness · Set drag · Freeze rigidbody · Raycast |
| **Network & PHP** | HTTP request · Call PHP endpoint · Read JSON value · Open URL in browser |
| **Audio** | Play tone (synthesised with `AudioContext`) · Stop all audio · Audio: play source · stop source · set volume · is playing? |
| **Debug & UI** | Show toast |
| **Rig & Animation** | Play / stop / pause / resume rig animation · Set rig speed · Set / rotate bone · Set bone scale · Reset pose · Get bone position / rotation · Get rig height / bone count / current clip · Has rig? |
| **Multiplayer** | Connect / disconnect · Is connected? · Send network event · Request sync · Push state · Claim / release ownership · Is owner? · Spawn / despawn network object · Get peer count / peer id / owner / room / transport / status · Set player name · Claim player object · Get last network event |
| **PlayerPrefs & Storage** | Save / load float, integer, text and flag · Has key? · Delete key / all keys · List keys · LocalStorage set / get / delete · Session set / get / delete |
| **Input** | Is key held · Key pressed / released this frame · Get key axis · Mouse position / wheel / button · Mouse to world point · Touch count / position · Is any key held? · Show / hide cursor · Is action pressed · Action pressed this frame · Get action value · Get input axis · Is gamepad connected · Get gamepad button / trigger · Vibrate gamepad · Rebind action |
| **Time** | Get time · Get delta time · Get unscaled delta time · Get frame count · Get real time · Set / get time scale · Get FPS |
| **Vector & Math** | Set / add / subtract / multiply vectors · Scale vector · Dot / cross product · Vector length · Normalize · Distance · Lerp · Vector to angles |
| **UI & Browser** | Set page text / HTML / title · Set element colour / style · Show / hide element · UI: set text / value / toggle / progress / colour / opacity / interactable · UI: show / hide · UI: click element · UI: get value |

Tween actions (`Move to`, `Move by`, `Rotate to`, `Scale to`) take a duration, an easing curve and **Wait for finish**. When *Wait for finish* is on, the rest of the action list waits until that tween completes; turn it off to start the next action immediately. *Wait* pauses the queue for a number of seconds. *Stop tweens* cancels the object's running tweens.

FSMs only run in Play mode. Stopping restores the pre-play snapshot like every other runtime feature — except when you switch scenes during play (**Go to scene** / **Go to scene URL** / **Restart scene**), in which case exiting play keeps the switched scene as the editable scene. Actions never call a renderer directly — they read and write the shared scene model and runtime — so the same FSM behaves identically on Three.js, Babylon.js, Native Canvas and third-party plugins.

### External calls, PHP and scene transitions

Network and scene actions run through the shared runtime, not the renderer:

- **HTTP request** — `GET`, `POST`, `PUT`, `PATCH` or `DELETE` with JSON, form or plain-text body, optional headers (`Name: value`, one per line), timeout, and variables for the response body/status. `wait` blocks the action queue until the request settles, then emits a success or failure event.
- **Call PHP endpoint** — convenience `POST` of `application/x-www-form-urlencoded` fields (`key=value&key2=value2`).
- **Read JSON value** — extracts a dotted/indexed path such as `data.player.name` or `items[0].id` from a JSON string stored in an FSM variable.
- **Go to scene URL** — downloads scene JSON and opens it; useful for loading levels produced by a PHP script.
- **Open URL in browser** — opens a link in a new or same tab (popup blockers may require a user gesture).
- **Scene storage actions** — `Go to scene` loads a scene saved in browser storage, `Save scene as` saves a checkpoint, `Restart scene` reloads the scene that was active when Play started, and `Exit to editor` stops play and restores the pre-play snapshot.

Example PHP endpoint:

```php
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$payload = json_decode(file_get_contents('php://input'), true);
echo json_encode([
  'ok' => true,
  'action' => $payload['action'] ?? $_POST['action'] ?? 'none',
  'time' => time(),
]);
```

Notes and limitations:

- When the editor is served over HTTP, the target must allow cross-origin requests (CORS). A `fetch` call blocked by CORS is reported as a network error and triggers the failure event.
- When opened from `file://`, browsers block cross-origin requests and PHP cannot receive a POST body from a `null` origin. Serve the editor and the PHP endpoint from the same origin (or configure CORS) for reliable results.
- Responses and request bodies are treated as data; store them in FSM variables and inspect with **Read JSON value** or **Format string** rather than executing them.
- External requests are aborted when play mode stops.

---

## Play mode

Play mode runs a small engine-independent simulation:

- **Rigidbody** — meshes with the component fall under gravity and collide with the ground, static meshes and other rigidbodies using AABB resolution. Physics runs on root objects only; a warning is logged for parented rigidbodies.
- **Physics controls** — the **Add force**, **Set velocity**, **Add impulse**, **Set mass**, **Set bounciness**, **Set drag**, **Set body gravity**, **Set world gravity** and **Freeze rigidbody** actions (and the runtime API) drive the same bodies; colliders are rebuilt when objects are cloned, destroyed or re-parented during play.
- **Raycast** — the **Raycast** action and `runtime.raycast()` test a ray against every scene collider and return the hit object, distance and point.
- **Behaviors** — preset component logic added from the Inspector or Component menu:
  - `spin` — constant rotation in degrees/second
  - `bob` — vertical sine motion
  - `pulse` — scale oscillation
  - `orbit` — circular motion around the origin
- **JavaScript Script** — user code with `onStart`, `onUpdate` and `onStop` hooks.
- **Visual FSM** — PlayMaker-style state machines with delay, event, held-key, key-down, key-up and variable transitions, plus 207 built-in actions (see above).
- **Unity UI** — interactive DOM overlay driven by the scene's UI elements, with FSM events and runtime `ctx.ui*` helpers.
- **Audio sources** — generated tones and audio files play during Play mode and stop with it.
- **Input map** — keyboard and gamepad actions update every frame; scripts and FSMs read the same bindings.
- **Inactive objects** — objects with **Active** unchecked (directly or through an inactive parent) skip rendering, physics, raycasts, scripts, behaviors and FSMs. Activating an object mid-play starts its `onStart` / FSM at that moment; stopping play always restores the saved state.
- **External calls** — HTTP / PHP requests run during play with timeout, response variables and success/failure events; see *External calls, PHP and scene transitions*.
- **Step** — advances exactly one frame while paused.
- **Stop** — restores the exact pre-play scene snapshot and calls `onStop`. If you switched scenes during play, the switched scene stays loaded as the editable scene instead.

### Script API

Add **Add Component → JavaScript Script** to an object, then edit it in the Inspector (or the Scripts dialog). Scripts compile with `new Function` and run only in Play mode.

```js
let t = 0;

function onStart(ctx) {
  ctx.log("ready: " + ctx.node.name);
}

function onUpdate(ctx, dt) {
  t += dt;
  ctx.node.transform.rotation.y += 40 * dt;
  ctx.node.transform.position.y = 0.5 + Math.sin(t * 2) * 0.3;
}

function onStop(ctx) {
  ctx.log("stopped");
}
```

The context object provides:

| Field | Meaning |
| --- | --- |
| `ctx.node` | The live scene node (transform, mesh, light, camera, rigidbody, …) |
| `ctx.scene` | The whole scene object (`{ version, name, env, nodes }`) |
| `ctx.find(name)` | Find another node by name |
| `ctx.findByTag(tag)` | Find the first **active** node with a tag (case-insensitive) |
| `ctx.setActive(nodeOrId, active)` | Activate or deactivate an object (node or name/id); children follow |
| `ctx.openUrl(url, target)` | Open a link in the browser (`"_blank"` by default, `"_self"` for the same tab) |
| `ctx.log(...)` | Print to the editor Console |
| `ctx.setColor(hex)` | Shortcut for `ctx.node.mesh.color` |
| `ctx.emitEvent(name)` | Send an event to FSMs waiting on it |
| `ctx.time` | Seconds since play started |
| `ctx.dt` | Current frame delta |
| `ctx.editor` | Editor instance (advanced) |
| `ctx.engine` | Active engine display name |
| `ctx.vec`, `ctx.math` | Shared vector and matrix helpers |

Compile and runtime errors appear in the Console; each failing script is reported once to avoid console spam.

---

## In-game scene changer

Add a **Scene Changer** object from **GameObject → Scene Changer** (or the component menu). It shows a compact scene menu over the Game view and loads the chosen scene instantly — including during Play mode.

- **Inspector / Window → Scene Changer…** — enable / disable, show / hide, preview while editing, title and scene list.
- Scene entries may be built-in templates or scenes saved in this browser.
- **FSM** — `Scene changer: show / hide`, `Scene changer: add scene`; `Go to scene` switches directly, and `Go to scene URL` loads one from a server.
- If you switch scenes while playing, stopping Play keeps the switched scene as the editable scene.

---

## Saving and loading

- **Save Scene** (`Ctrl + S`) stores a named entry in `localStorage` key `webforge3d.scenes.v1`. Up to 30 scenes are kept; saving the same name overwrites it.
- **Open Scene** (`Ctrl + O`) lists saved scenes and can delete entries.
- **File → Download scene as .json** exports the plain-JSON scene.
- **File → Import scene .json…** or dropping a `.json` file on the viewport imports one.
- Imported data is normalized: missing transforms, mesh fields and parent links are repaired; invalid files are rejected with a toast.
- Scene names also appear in the Project panel for one-click loading.

`localStorage` is scoped to the origin. A scene saved while opening `index.html` from disk is not visible when the same folder is later served over HTTP (and vice versa). Use JSON export to move scenes between them.

Uploaded and painted textures are embedded in the scene as data URLs (uploads are capped at 8 MB each), so scenes with many large textures can exceed the browser's storage quota. If saving reports that storage is full, download the scene as JSON instead — JSON export has no quota.

### Scene JSON format

```json
{
  "version": 1,
  "name": "Sample Scene",
  "env": {
    "ambient": 0.42,
    "ambientColor": "#ffffff",
    "showGrid": true,
    "fogEnabled": false,
    "fogColor": "#1d2025",
    "fogNear": 14,
    "fogFar": 70
  },
  "nodes": [
    {
      "id": "n_cube",
      "name": "Cube",
      "parent": null,
      "type": "mesh",
      "visible": true,
      "tag": "Enemy",
      "active": true,
      "transform": {
        "position": [0, 0.5, 0],
        "rotation": [0, 0, 0],
        "scale": [1, 1, 1]
      },
      "mesh": {
        "shape": "cube",
        "color": "#c7cdd6",
        "roughness": 0.6,
        "metalness": 0.08,
        "wireframe": false,
        "opacity": 1,
        "texture": {
          "enabled": true,
          "preset": "bricks",
          "data": null,
          "tiling": [2, 1],
          "offset": [0, 0]
        }
      },
      "rigidbody": { "mass": 1, "useGravity": true, "restitution": 0.25, "drag": 0.05, "frozen": false },
      "behaviors": [
        { "id": "b1", "kind": "spin", "params": { "x": 0, "y": 55, "z": 0 } }
      ],
      "script": { "name": "NewBehavior", "code": "function onUpdate(ctx, dt) { ... }" },
      "fsm": {
        "enabled": true,
        "start": "s_idle",
        "states": [
          {
            "id": "s_idle",
            "name": "Idle",
            "x": 46,
            "y": 62,
            "actions": [
              { "type": "setColor", "params": { "color": "#5b9bd5" } }
            ]
          }
        ],
        "transitions": [
          { "id": "t1", "from": "s_idle", "to": "s_idle", "trigger": "auto", "delay": 1, "event": "done", "key": "Space", "variable": "", "op": "==", "value": "" }
        ],
        "variables": [{ "name": "score", "value": "0" }]
      }
    }
  ]
}
```

Details:

- `parent` is a node `id` or `null`; transforms are local to the parent.
- `type` is one of `empty`, `mesh`, `light`, `camera`.
- `tag` is an optional free-text label (empty / absent means *Untagged*); `active` defaults to `true` and `false` disables the object and its children. Older scenes gain both fields automatically on load.
- `mesh.shape` is one of `cube`, `sphere`, `cylinder`, `cone`, `torus`, `capsule`, `plane` — or `model` for an imported mesh, in which case `mesh.modelId` / `mesh.meshIndex` / `mesh.primitiveIndex` point into the top-level `models` array (see *Importing 3D models*).
- `mesh.texture` is optional; `preset` names a procedural preset (`checker`, `bricks`, …) or `painted` / `uploaded` when `data` holds a data URL.
- `rotation` is stored in degrees (Euler XYZ); engines receive the converted values.
- `light` uses `{ kind: "directional" | "point" | "spot", color, intensity, range, angle, penumbra }`; `angle` and `penumbra` apply to spots.
- `camera` uses `{ fov, near, far, bg }`; the Game view renders through the first visible camera node.
- `fsm.states[].actions[].type` is any of the 207 action ids from the Actions table (`log`, `moveTo`, `setVariable`, `httpRequest`, `playTone`, `setBoneRotation`, `netSendEvent`, `prefSetFloat`, …); the action's settings live in `params`.
- `fsm.transitions[].trigger` is `auto`, `event`, `key`, `keyDown`, `keyUp` or `variable`.
- Optional components are simply absent when not attached (`mesh`, `light`, `camera`, `rigidbody`, `script`, `behaviors`, `fsm`).

The same objects are used at runtime, so plugins and scripts can read and mutate them directly.

---

## Project layout

```
webforge3d/
├─ index.html                 editor shell + script includes
├─ css/editor.css             dark theme and layout
├─ js/
│  ├─ core/
│  │  ├─ math.js              vectors, mat4, ray/AABB helpers
│  │  ├─ geometry.js          shared CPU meshes (7 primitive shapes) + UVs
│  │  ├─ textures.js          procedural, painted and uploaded texture library
│  │  ├─ modeldoc.js          glTF-shaped document builder shared by all importers
│  │  ├─ obj.js               Wavefront OBJ/MTL parser (groups, materials, textures)
│  │  ├─ blend.js             Blender .blend parser (own DNA reader, gzip inflater)
│  │  ├─ models.js            model registry, glTF/GLB parsing, geometry cache
│  │  ├─ rig.js               humanoid auto-rig, procedural clips, bone posing
│  │  ├─ network.js           multiplayer manager: local tabs, postMessage, WebRTC, WebSocket
│  │  ├─ fsm.js               FSM schema, 207 actions and runtime runner
│  │  ├─ scene.js             scene schema, transforms, serialization
│  │  ├─ scenes.js            built-in templates, scene changer, shared scripts
│  │  ├─ unityui.js           Unity-style UI elements and DOM overlay
│  │  ├─ inputmap.js          keyboard / gamepad bindings and polling
│  │  ├─ editor.js            selection, history, play state, storage
│  │  ├─ camera.js            editor rig and Game-view camera projection
│  │  ├─ gizmo.js             move/rotate/scale handles on a 2D overlay
│  │  ├─ secondcamera.js      picture-in-picture renderer
│  │  └─ runtime.js           play-mode behaviors, scripts, FSM, AABB physics
│  ├─ engines/
│  │  ├─ registry.js          engine registry + lazy script loader
│  │  ├─ native.js            offline Canvas 2D renderer (plugin base class)
│  │  ├─ three.js             Three.js adapter
│  │  └─ babylon.js           Babylon.js adapter
│  ├─ ui/
│  │  ├─ ui.js                menus, hierarchy, inspector, dialogs, console
│  │  ├─ docs.js              built-in documentation manual (F1)
│  │  └─ graph.js             PlayMaker-style FSM graph editor
│  └─ app.js                  boot, frame loop, engine switching, input
└─ plugins/
   ├─ blueprint-canvas.js     example engine plugin
   └─ README.md               plugin authoring guide
```

All scripts are classic `<script>` tags in dependency order. Nothing is bundled or transpiled, and no ES modules are required, so `file://` works.

---

## Extending

### Add an engine

1. Create a plain script, e.g. `plugins/my-engine.js`.
2. Call `UnityWeb.engines.register({ id, name, load, create })`.
3. In `load()`, inject the engine runtime (script tag, dynamic `import()` of a CDN module, WASM, etc.).
4. In `create(def)`, return an adapter implementing `init`, `resize`, `update`, `render`, `getStats`, `dispose`.
5. Load it with **Engine → Connect engine plugin…** or add a `<script>` tag to `index.html`.

Full contract and a commented skeleton are in [`plugins/README.md`](plugins/README.md).

### Add a primitive

Add a builder to `js/core/geometry.js` and a `{ id, label, icon }` entry to its `SHAPES` list. The GameObject menu, Project panel and scene serializer pick it up automatically.

### React to editor state

```js
UnityWeb.app.editor.on('selection', (id) => console.log('selected', id));
```

Events: `structure`, `values`, `transform`, `selection`, `restore`, `play`, `tool`, `space`, `view`, `log`, `saved`, `history`, `engine`, `engine-loading`, `fps`, `tick`, `camera`.

---

## Limitations

This is a compact editor, not a full game engine:

- Mesh collision is AABB-based; no compound colliders, constraints or continuous collision detection. Frozen bodies are skipped by collision resolution but still act as colliders.
- Physics, behaviors, scripts and FSMs are Play-mode only, and physics ignores parented rigidbodies.
- Geometry is procedural or imported from `.glb` / `.gltf` / `.obj` / `.blend` files; there is no animation system, terrain tool or mesh editing (imported geometry is read-only). See *Import limitations* above.
- Materials are one color/roughness/metalness set plus one optional texture per mesh; there are no multi-map PBR materials.
- FSMs are intentionally compact: one active state per object, no sub-machines, no transition animations or blend trees. Entry actions run in an ordered queue; tweens, HTTP requests and *Wait* can block that queue until they settle.
- HTTP is limited to `fetch` requests with a timeout. Cross-origin targets must allow CORS, and requests from `file://` pages (origin `null`) are generally blocked by browsers — serve the editor over HTTP next to your PHP scripts. Real-time multiplayer uses BroadcastChannel / localStorage, a postMessage bridge, manual WebRTC or a user-supplied WebSocket relay; there is no bundled game server or matchmaking, and WebRTC requires HTTPS or localhost.
- The Native Canvas renderer is a painter's-algorithm rasterizer without shadows, reflections or post-processing; it does support textures, spot lights and fog.
- Scenes live in browser storage unless exported as JSON. There is no cloud sync.
- Opening from `file://` works, but CDN engines need internet access and some browsers restrict storage for local files. Prefer a static server for long-term work.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| Viewport is blank on first load | Wait for the engine badge to stop saying “loading…”. Offline, the editor falls back to Native Canvas automatically. |
| Three.js / Babylon.js never load | Check the internet connection or a blocking extension; switch to **Native Canvas**. |
| Saved scenes are missing | Make sure you open the editor from the same origin/path as before, or import the exported JSON. |
| Plugin does not appear | Confirm the script URL is reachable and that it calls `UnityWeb.engines.register(...)` without errors; see the Console. |
| Script does nothing | Scripts run only after **Play**; compile/runtime errors are shown in the Console. |
| HTTP / PHP action fails | Check the URL, the PHP error log and CORS headers (`Access-Control-Allow-Origin`). Requests from `file://` are blocked; serve the editor over HTTP. Increase the action timeout for slow endpoints. |
| Go to scene does nothing | The scene name must exist in browser storage (save it first with **Save scene as**); check the Console for details. |
| Open URL action does nothing | Popup blockers swallow `window.open` without a user gesture; trigger it from a key-down / click-driven state, or use the same tab (`_self`). |
| Inactive object is not affected | Active state cascades from parents — an object stays off until its inactive ancestor is reactivated. Check the Hierarchy for struck-through rows. |
| Model import fails | Check the Console panel — the exact reason (bad header, empty mesh, oversized file) is logged there. The file stays untouched; nothing is added to the scene on failure. |
| OBJ shows no colors / textures | The `.mtl` (and the image files it references) must be dropped together with the `.obj`; a warning names the missing file. Files are paired by name only, so rename `tex (1).png` back to `tex.png`. |
| Blender model looks wrong / empty | Apply modifiers in Blender and re-save; only mesh objects import (curves, lattices, lights are skipped — see Console). Check that the object is not on a hidden collection layer. |
| Imported model is dark | Materials are single-color PBR; check the light setup (add a light via **GameObject → Light**) or select a part and raise its color in the Inspector. |
| Low FPS in Native Canvas | It is a software renderer; reduce object/mesh counts or switch to a WebGL engine. |

---

## License

Editor code: use freely for learning and prototyping. Three.js is MIT licensed; Babylon.js is Apache 2.0. The engine adapters load those projects from their official CDNs without modifying them.
