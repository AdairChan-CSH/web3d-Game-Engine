/* ============================================================
   docs.js — searchable documentation manual
   A built-in manual with live search over:
     • hand-written topics (interface, objects, materials, lights,
       models, physics, scripting, FSMs, scenes, networking,
       engines, troubleshooting)
     • every FSM action, generated from UW.FSM.actionTypes so it
       always matches the shipped feature set
     • the script ctx API from the runtime

   Open it with F1 or Help → Documentation manual.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});

  /* ------------------------------------------------------------
     corpus
     ------------------------------------------------------------ */
  const STATIC_TOPICS = [
    {
      id: 'interface',
      category: 'Basics',
      title: 'Interface & layout',
      keywords: 'layout panels hierarchy inspector project console window ui',
      body:
        '<p class="help-p">The layout mirrors Unity: <b>Hierarchy</b> on the left, the <b>Scene / Game viewport</b> in the middle, the <b>Inspector</b> on the right, the <b>Project / Assets panel</b> and <b>Console</b> at the bottom.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Hierarchy</b> — every object in the scene as a tree. Drag to re-parent, double-click to focus, right-click for context actions.</li>' +
        '<li><b>Viewport</b> — orbit with <kbd>LMB</kbd> drag, pan with <kbd>MMB</kbd> or <kbd>Shift+LMB</kbd>, zoom with the wheel. Double-click an object to select and frame it.</li>' +
        '<li><b>Inspector</b> — properties of the selected object: transform, components, tags, materials, physics, scripts, FSMs.</li>' +
        '<li><b>Project panel</b> — saved scenes and quick actions.</li>' +
        '<li><b>Console</b> — logs from scripts, FSMs, the runtime and imports (max 300 lines).</li>' +
        '</ul>' +
        '<p class="help-p">The toolbar switches tool (select / move / rotate / scale), play / pause / step / stop, and the rendering engine.</p>',
    },
    {
      id: 'navigation',
      category: 'Basics',
      title: 'Viewport navigation & camera',
      keywords: 'camera orbit pan zoom focus view game scene viewmodes',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Orbit</b> — drag with the left mouse button.</li>' +
        '<li><b>Pan</b> — middle mouse button or <kbd>Shift</kbd> + left drag.</li>' +
        '<li><b>Zoom</b> — mouse wheel.</li>' +
        '<li><b>Focus</b> — select an object and press <kbd>F</kbd> (or double-click it in the viewport / hierarchy).</li>' +
        '<li><b>Game view</b> — the view mode dropdown in the toolbar switches between <b>Scene</b> (editor camera) and <b>Game</b> (a Camera object\'s view). Add a Camera from GameObject → Camera.</li>' +
        '</ul>' +
        '<p class="help-p">Holding <kbd>Shift</kbd> while dragging a gizmo snaps movement to a grid and rotation to 15° steps.</p>',
    },
    {
      id: 'shortcuts',
      category: 'Basics',
      title: 'Keyboard shortcuts',
      keywords: 'keys shortcuts hotkeys f1 keyboard bindings',
      body:
        '<table class="docs-table"><tbody>' +
        '<tr><td>Q / W / E / R</td><td>Select / Move / Rotate / Scale tool</td></tr>' +
        '<tr><td>F</td><td>Focus selected object</td></tr>' +
        '<tr><td>Ctrl + P</td><td>Play / stop</td></tr>' +
        '<tr><td>Ctrl + Shift + P</td><td>Pause</td></tr>' +
        '<tr><td>Ctrl + Z / Y</td><td>Undo / redo</td></tr>' +
        '<tr><td>Ctrl + D</td><td>Duplicate object</td></tr>' +
        '<tr><td>Del</td><td>Delete object</td></tr>' +
        '<tr><td>Ctrl + N / O / S</td><td>New / open / save scene</td></tr>' +
        '<tr><td>Ctrl + M</td><td>Open the start screen / template launcher</td></tr>' +
        '<tr><td>Shift while dragging</td><td>Snap translate / rotate</td></tr>' +
        '<tr><td>F1</td><td>Open this documentation manual</td></tr>' +
        '</tbody></table>',
    },
    {
      id: 'creating-objects',
      category: 'Objects & components',
      title: 'Creating objects',
      keywords: 'create add gameobject primitive cube sphere cylinder cone torus capsule plane empty light camera',
      body:
        '<p class="help-p">Use the <b>GameObject</b> menu:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>3D Object</b> — Cube, Sphere, Cylinder, Cone, Torus, Capsule, Plane.</li>' +
        '<li><b>Create Empty</b> — a plain transform node, useful as a group or container.</li>' +
        '<li><b>Light</b> — Directional (sun), Point, or Spot.</li>' +
        '<li><b>Camera</b> — for the Game view.</li>' +
        '</ul>' +
        '<p class="help-p">New objects spawn at the camera target. When a mesh or empty is selected, new objects become its children (use Ctrl+D or drag in the hierarchy to reorganise). Imported models come from <b>File → Import 3D model (.glb / .obj / .blend)…</b> — see the Models section.</p>',
    },
    {
      id: 'transform',
      category: 'Objects & components',
      title: 'Transforms & gizmos',
      keywords: 'transform position rotation scale gizmo local world space move rotate snap',
      body:
        '<p class="help-p">Every object has <b>Position</b>, <b>Rotation</b> (Euler degrees) and <b>Scale</b>, editable in the Inspector or with gizmos (W / E / R).</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Local / World</b> toggle in the toolbar — whether gizmo axes follow the object\'s rotation.</li>' +
        '<li><b>Snap</b> — hold <kbd>Shift</kbd> while dragging for grid / 15° snapping.</li>' +
        '<li><b>Reset</b> — the ⌂ button next to the Transform header restores 0/0/1.</li>' +
        '<li>Children inherit their parent\'s transform, exactly like Unity.</li>' +
        '</ul>',
    },
    {
      id: 'inspector',
      category: 'Objects & components',
      title: 'Inspector & components',
      keywords: 'inspector components add rigidbody script fsm texture behaviors mesh renderer',
      body:
        '<p class="help-p">The Inspector shows the selected object\'s header (name, tag, active, visible) followed by its components:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Transform</b> — always present.</li>' +
        '<li><b>Mesh Renderer</b> — shape or imported model, color, roughness, metalness, opacity, wireframe.</li>' +
        '<li><b>Texture / Material</b> — preset or uploaded texture with tiling &amp; offset (Add Component → Texture).</li>' +
        '<li><b>Rigidbody</b> — physics (see Physics).</li>' +
        '<li><b>Behaviors</b> — Spin, Bob, Pulse, Orbit presets.</li>' +
        '<li><b>JavaScript Script</b> — custom code (see Scripting).</li>' +
        '<li><b>PlayMaker FSM</b> — visual state machine (see FSM).</li>' +
        '<li><b>Unity UI</b> — Canvas / Panel / Text / Button / Image / Slider / Toggle / Input / Dropdown / Progress (see Unity UI).</li>' +
        '<li><b>Audio Source</b> — generated tone or audio file, with 3D sound, volume, loop and play-on-start (see Audio Sources).</li>' +
        '<li><b>Video Player</b> — MP4 / WebM / OGG clip on a screen rect or attached to the GameObject (see Video Player).</li>' +
        '<li><b>Scene Changer</b> — in-game scene menu (see Scene changer).</li>' +
        '<li><b>Camera → Second camera</b> — picture-in-picture preview in the Game view.</li>' +
        '</ul>' +
        '<p class="help-p">Add components from the <b>Component</b> menu or <b>Add Component</b>; remove them with the ✕ on each section.</p>',
    },
    {
      id: 'tags-active',
      category: 'Objects & components',
      title: 'Tags, active & visible',
      keywords: 'tag tags active deactivate visible find compare player enemy setactive gameobject',
      body:
        '<p class="help-p">Every object has a free-text <b>Tag</b> (Inspector header) with Unity-style suggestions — Player, Enemy, Pickup…</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Active</b> — Unity GameObject semantics: an inactive object stops rendering, colliding and running scripts / behaviors / FSMs, and <b>its whole subtree is disabled too</b>. Toggle in the Inspector or the hierarchy.</li>' +
        '<li><b>Visible</b> — only toggles that object\'s renderer (children keep rendering).</li>' +
        '</ul>' +
        '<p class="help-p">Related FSM actions: <b>Set tag</b>, <b>Get tag</b>, <b>Find object by tag</b>, <b>Compare tag</b>, <b>Activate / deactivate</b>, <b>Toggle active</b>. Script equivalents: <code>ctx.findByTag(tag)</code> and <code>ctx.setActive(node, bool)</code>.</p>',
    },
    {
      id: 'hierarchy',
      category: 'Objects & components',
      title: 'Hierarchy & parenting',
      keywords: 'hierarchy parent child children drag drop duplicate delete empty group organize',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Drag</b> one object onto another to re-parent it; drop on empty space to move it to the scene root.</li>' +
        '<li><b>Double-click</b> a name to focus the object in the viewport.</li>' +
        '<li><b>Ctrl + D</b> duplicates the selected object <i>with its whole subtree</i>.</li>' +
        '<li>Struck-through names are inactive objects (their children are disabled too).</li>' +
        '<li>Imported models arrive as a container node with the model\'s node hierarchy below it.</li>' +
        '</ul>',
    },
    {
      id: 'materials',
      category: 'Materials & textures',
      title: 'Materials (color, roughness, metalness)',
      keywords: 'material color colour roughness metalness opacity wireframe pbr shading',
      body:
        '<p class="help-p">Mesh Renderer properties drive a physically-based look on every engine:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Color</b> — base albedo color (hex).</li>' +
        '<li><b>Roughness</b> — 0 = mirror-like, 1 = diffuse/matte.</li>' +
        '<li><b>Metalness</b> — 0 = dielectric, 1 = metal.</li>' +
        '<li><b>Opacity</b> — below 1 makes the mesh transparent.</li>' +
        '<li><b>Wireframe</b> — render edges only.</li>' +
        '</ul>' +
        '<p class="help-p">Imported models pick up their glTF material\'s base color, metallic / roughness factors, alpha and double-sidedness; you can override them per object afterwards.</p>',
    },
    {
      id: 'textures',
      category: 'Materials & textures',
      title: 'Textures & presets',
      keywords: 'texture preset checker bricks tiles noise gradient upload image tiling offset material',
      body:
        '<p class="help-p">Add a <b>Texture / Material</b> component (Component menu or Add Component), then pick one of the procedural presets — checker, grid, bricks, tiles, noise, gradient, stripes, dots, wood, marble — or upload an image. <b>Tiling</b> repeats the texture across the UVs; <b>Offset</b> shifts it.</p>' +
        '<p class="help-p">Uploaded and painted textures are stored as data URLs inside the scene JSON (8 MB per texture cap). glTF base-color textures from imported models become uploaded textures automatically.</p>',
    },
    {
      id: 'texture-editor',
      category: 'Materials & textures',
      title: 'Texture editor',
      keywords: 'paint painter brush eraser flood fill line rectangle mirror undo export png import image',
      body:
        '<p class="help-p">Select a mesh and open <b>Window → Texture Editor…</b>. Tools: brush, eraser, flood fill, line, rectangle, ellipse, picker. Options include size, hardness, mirroring (X/Y), and a live tiling preview. There is per-stroke undo / redo, PNG export and image import. Painting works on the shared texture object, so every engine shows it identically.</p>',
    },
    {
      id: 'lights',
      category: 'Lights & environment',
      title: 'Lights',
      keywords: 'light directional point spot intensity range angle penumbra color shadow',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Directional</b> — sun-like parallel rays, casts shadows.</li>' +
        '<li><b>Point</b> — omnidirectional with <b>Range</b> falloff.</li>' +
        '<li><b>Spot</b> — cone with <b>Range</b>, <b>Angle</b> and <b>Penumbra</b>.</li>' +
        '</ul>' +
        '<p class="help-p">Change <b>Color</b> and <b>Intensity</b> in the Inspector. When all lights are inactive the renderer falls back to a soft built-in light so the scene never goes fully black. The Native Canvas engine renders shadows approximately; Three.js and Babylon.js use real shadow maps.</p>',
    },
    {
      id: 'environment',
      category: 'Lights & environment',
      title: 'Environment & fog',
      keywords: 'environment ambient grid fog background color showgrid',
      body:
        '<p class="help-p"><b>Window → Environment / Lighting…</b> controls scene-wide settings: <b>ambient intensity</b> and color, the ground grid, and <b>distance fog</b> (color, near, far). Fog fades objects into the background with distance — useful for depth cues. All of these can also be changed at runtime through the FSM actions <b>Set ambient light</b> and <b>Set fog</b>, or via scripts with <code>ctx.scene.env</code>.</p>',
    },
    {
      id: 'model-import',
      category: 'Models',
      title: 'Importing models (.glb / .gltf / .obj / .blend)',
      keywords: 'import model glb gltf obj blend blender mesh wavefront mtl texture import upload drag drop file 3d asset',
      body:
        '<p class="help-p"><b>File → Import 3D model…</b> or simply drag model files onto the viewport. Supported formats: <b>.glb</b>, <b>.gltf</b>, <b>.obj</b> (with <b>.mtl</b> and texture images) and <b>.blend</b> (Blender).</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Every parser is built in — no CDN, no build step, works offline and on every engine.</li>' +
        '<li>The file\'s <b>node hierarchy</b> is recreated under a container object named after the file, with positions, rotations and scales.</li>' +
        '<li><b>Materials</b>: base color, metallic / roughness factors, transparency and double-sidedness are applied; embedded <b>textures</b> become texture components.</li>' +
        '<li>Missing normals get flat per-triangle normals; missing UVs get planar UVs so textures still map.</li>' +
        '<li>The model file is stored <b>once</b> in the scene (<code>scene.models</code>); every mesh node references it by <code>modelId</code> + mesh / primitive index, so duplicating a model\'s nodes is cheap.</li>' +
        '<li>Models survive save / load / undo like any scene data. The HUD shows a model count.</li>' +
        '</ul>' +
        '<p class="help-p">glTF support: glTF 2.0, GLB binary containers, data-URI buffers, indexed or plain triangles, all component types (byte / short / int / float). OBJ support: v/vt/vn data, polygon faces (fan-triangulated), <code>o</code> / <code>g</code> groups as child meshes, <code>usemtl</code> materials from a companion <code>.mtl</code> and embedded texture images (drop the <code>.obj</code>, <code>.mtl</code> and <code>.png</code> files together). Blender support: mesh + object hierarchy, transforms, materials and UVs from modern and classic saves (2.63 → 4.x), including gzip-compressed saves; Blender files are Z-up so the root gets a −90° X rotation.</p>' +
        '<p class="help-p">Not supported (skipped with a Console warning): glTF animations, skins, morph targets, cameras, lights and external .bin / image files; Blender curves, lattices, lights, modifiers that were not applied and animation data. Non-triangle primitive modes are skipped.</p>',
    },
    {
      id: 'model-import-tips',
      category: 'Models',
      title: 'Import tips for OBJ and Blender files',
      keywords: 'obj blend blender mtl texture image png jpeg tips units scale axis z-up compressed gzip',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>OBJ + textures:</b> drop / pick the <code>.obj</code>, its <code>.mtl</code> and the image files together — they are embedded into the scene so everything works offline. Only PNG / JPEG / WebP / GIF / BMP images can be embedded.</li>' +
        '<li><b>Blender units:</b> 1 Blender unit imports as 1 world unit (metres). Apply transforms (Ctrl+A) in Blender if an object looks wrong.</li>' +
        '<li><b>Z-up → Y-up:</b> the imported root is rotated −90° on X, exactly like Unity\'s Blender importer; every child keeps its local Blender transform.</li>' +
        '<li><b>Compressed saves:</b> gzip-compressed .blend files are supported by a built-in decompressor, but uncompressed saves load faster.</li>' +
        '<li><b>N-gons</b> are fan-triangulated (quad-safe); Blender\'s own triangulator may split differently.</li>' +
        '<li><b>Modifiers:</b> apply them in Blender before saving — the importer reads the stored mesh, not the modifier stack.</li>' +
        '<li>One model file = one container object with children per mesh / group, so re-parenting pieces is easy. Select the container to move the whole model.</li>' +
        '</ul>',
    },
    {
      id: 'physics',
      category: 'Physics',
      title: 'Rigidbody physics',
      keywords: 'physics rigidbody gravity mass drag freeze restitution collision ground fall bounce force impulse velocity',
      body:
        '<p class="help-p">Add a <b>Rigidbody</b> component (only meshes) and press Play:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Mass</b>, <b>Drag</b> (air resistance), <b>Restitution</b> (bounciness) and per-axis <b>freeze</b>.</li>' +
        '<li>Bodies fall with scene gravity, collide against the ground plane (y = 0) and other meshes\' world AABBs, and roll to rest.</li>' +
        '<li>Scripts can push bodies with <code>ctx.node.rigidbody.velocity</code>, and the FSM <b>Apply force / impulse</b> actions exist too.</li>' +
        '<li>Imported model nodes participate like any mesh — their world AABB is computed from the model geometry.</li>' +
        '</ul>' +
        '<p class="help-p">Physics runs in the shared runtime, so it behaves identically on every engine. Only root objects collide with each other.</p>',
    },
    {
      id: 'raycast',
      category: 'Physics',
      title: 'Raycast',
      keywords: 'raycast ray hit physics mouse direction distance origin',
      body:
        '<p class="help-p">The FSM <b>Raycast</b> action casts a ray from an object toward a direction and stores what it hits (name / point / distance / normal in variables). Scripts can use the runtime through actions; the editor\'s own picking (double-click) also uses AABB raycasts. Inactive objects are skipped.</p>',
    },
    {
      id: 'scripting',
      category: 'Scripting',
      title: 'JavaScript scripts',
      keywords: 'script javascript code onstart onupdate onstop behavior custom function',
      body:
        '<p class="help-p">Add a <b>JavaScript Script</b> component and edit it in the built-in editor. Scripts run only in Play mode; stopping restores the scene.</p>' +
        '<pre class="docs-code">function onStart(ctx) {\n  ctx.log("ready: " + ctx.node.name);\n}\n\nfunction onUpdate(ctx, dt) {\n  ctx.node.transform.rotation.y += 55 * dt;\n}</pre>' +
        '<p class="help-p">Hooks: <code>onStart(ctx)</code>, <code>onUpdate(ctx, dt)</code>, <code>onStop(ctx)</code>. Compile and runtime errors are reported in the Console. See the <b>Script ctx API</b> entries for everything on <code>ctx</code>.</p>',
    },
    {
      id: 'fsm',
      category: 'PlayMaker FSM',
      title: 'PlayMaker FSM overview',
      keywords: 'fsm playmaker state machine states graph transitions events variables',
      body:
        '<p class="help-p">A <b>PlayMaker FSM</b> component gives an object a visual state machine: <b>states</b> connected by <b>transitions</b>, with <b>actions</b> that run when a state is entered and <b>variables</b> shared between them.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Build it in <b>Window → FSM Graph Editor…</b> — add states, wire transitions, pick actions.</li>' +
        '<li>One state is the <b>start</b> state; it runs the moment Play begins.</li>' +
        '<li>Transitions fire on delay, event, key held / down / up, or a variable comparison — first match wins, checked every frame.</li>' +
        '<li>FSMs run in the shared runtime: identical behavior on every engine.</li>' +
        '</ul>' +
        '<p class="help-p">Search this manual for <b>action</b> to browse all ' + (UW.FSM ? UW.FSM.actionTypes.length : '216') + ' built-in actions.</p>',
    },
    {
      id: 'fsm-transitions',
      category: 'PlayMaker FSM',
      title: 'Transitions & triggers',
      keywords: 'transition trigger delay event key keydown keyup variable condition compare branch',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>After delay</b> — fires once N seconds passed in the state.</li>' +
        '<li><b>On event</b> — fires when that FSM event is broadcast (Send event action, scripts, other FSMs).</li>' +
        '<li><b>Key held / down / up</b> — keyboard edges via the input state.</li>' +
        '<li><b>Variable compare</b> — fires while / when a variable meets a comparison.</li>' +
        '</ul>' +
        '<p class="help-p">Transitions are evaluated every frame in declaration order from the current state; the first that matches fires.</p>',
    },
    {
      id: 'fsm-graph',
      category: 'PlayMaker FSM',
      title: 'FSM graph editor',
      keywords: 'graph editor fsm add state action transition wire drag canvas zoom',
      body:
        '<p class="help-p"><b>Window → FSM Graph Editor…</b> (or Component → PlayMaker FSM) opens the node graph: create states, drag them around, connect ports to make transitions, and configure the selected state\'s action list. Actions can be reordered; tween actions can <i>block</i> the rest of the list until they finish. Variables live at the bottom of the panel.</p>',
    },
    {
      id: 'action-library',
      category: 'PlayMaker FSM',
      title: 'PlayMaker action library (all ' + (UW.FSM ? UW.FSM.actionTypes.length : 216) + ' actions)',
      keywords: 'action library list browse search categories add fsm playmaker all actions reference',
      body:
        '<p class="help-p"><b>Window → PlayMaker Action Library…</b> opens a searchable catalogue of every built-in action. Type in the search box, filter by category, click an action to read its help and parameter list, then press <b>Add to selected FSM</b> to append it to the start state of the selected object.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>' + (UW.FSM ? UW.FSM.actionTypes.length : 216) + ' actions</b> in ' + (UW.FSM ? UW.FSM.categories.length : 21) + ' categories: Flow, Scene &amp; Flow, Transform, Variables &amp; Math, String &amp; Text, Logic &amp; Scene, GameObject, Material &amp; Texture, Lighting, Camera, Physics, Network &amp; PHP, Audio &amp; Video, Debug &amp; UI, Rig &amp; Animation, Multiplayer, PlayerPrefs &amp; Storage, Input, Time, Vector &amp; Math and UI &amp; Browser.</li>' +
        '<li>Every action is executed by the shared runtime, so the same graph behaves identically on Three.js, Babylon.js, Native Canvas and third-party engine plugins.</li>' +
        '<li>Use the graph editor to place an action in a specific state; the library is for browsing and quick insertion.</li>' +
        '<li>This manual also contains one page per action — search for an action name or id such as <code>setBoneRotation</code>.</li>' +
        '</ul>',
    },
    {
      id: 'auto-rig',
      category: 'Rigging & animation',
      title: 'Auto-rig (humanoid)',
      keywords: 'rig auto rig skeleton bones humanoid animation clip idle walk run wave dance jump crouch punch kick swim fly sit bind mesh import character',
      body:
        '<p class="help-p">Select an imported model or an empty root, then choose <b>Component → Auto-Rig (Humanoid)</b>, <b>Window → Auto-Rig (Humanoid)…</b> or the Inspector button. The editor measures the model and builds a 19-bone humanoid skeleton as ordinary empty objects: Hips, Spine, Chest, Neck, Head, Shoulder / Upper Arm / Lower Arm / Hand L+R and Upper Leg / Lower Leg / Foot L+R.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Height</b> — leave empty to measure the model bounding box, or type a value in metres to scale the skeleton.</li>' +
        '<li><b>Mesh binding → Nearest bone</b> — re-parents each separate mesh part to the closest joint while preserving its world position and scale. A single full-body mesh is left on the model root so one bone cannot stretch it; the Console lists skipped parts.</li>' +
        '<li><b>Clips</b> — <code>idle</code>, <code>walk</code>, <code>run</code>, <code>wave</code>, <code>dance</code>, <code>jump</code>, <code>crouch</code>, <code>punch</code>, <code>kick</code>, <code>swim</code>, <code>fly</code>, <code>sit</code> or a custom clip. Procedural clips rotate the bones every frame in Play mode.</li>' +
        '<li><b>Inspector</b> — the rig section shows bone chips, clip / speed controls, Play / Pause, Reset pose, Rebuild and Remove. Selecting a bone opens a Bone section with Rest position and a per-bone reset.</li>' +
        '<li>Bones are plain scene nodes, so they save, undo, reload and render on every engine. Remove Rig deletes the bones and returns every bound mesh part to the model root.</li>' +
        '<li>FSM actions in the <b>Rig &amp; Animation</b> category (play clip, stop, set bone rotation, pose, bind) drive the rig at runtime.</li>' +
        '</ul>',
    },
    {
      id: 'multiplayer',
      category: 'Networking',
      title: 'Multiplayer & network objects',
      keywords: 'multiplayer network object net id owner authority sync broadcastchannel postmessage iframe webrtc websocket room peers play together lan serverless p2p',
      body:
        '<p class="help-p">Add <b>Component → Network Object</b> to any scene object. Each object gets a stable <b>net ID</b>, an owner (authority) and per-property sync flags. Open <b>Window → Multiplayer…</b> to pick the room, transport and player object, then press Play in every tab.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Local tabs</b> — BroadcastChannel + localStorage; two or more tabs of the same browser join the room with no server or configuration.</li>' +
        '<li><b>postMessage bridge</b> — peers in an iframe or second window sync through the browser <code>postMessage</code> API; no server needed.</li>' +
        '<li><b>WebRTC</b> — manual copy/paste offer / answer codes connect two browsers directly, without a signalling server. Both tabs must be playing.</li>' +
        '<li><b>WebSocket relay</b> — optional; supply your own <code>ws://</code> or <code>wss://</code> relay and the object messages are forwarded through it.</li>' +
        '<li><b>Ownership</b> — only the owner streams snapshots. Claim / Release in the Inspector transfers authority; auto-own claims on connect. The status bar shows <b>Net: N peers</b>.</li>' +
        '<li><b>Sync flags</b> — position, rotation, scale, active / visible and colour; remote values are interpolated with a configurable factor.</li>' +
        '<li><b>Spawn / Despawn</b> — send a whole subtree to every peer or remove it everywhere, including FSM runners and physics.</li>' +
        '<li><b>FSM actions</b> — the Multiplayer category includes connect, disconnect, send event, claim, release, spawn, despawn, request sync, push state and get peer / owner information.</li>' +
        '</ul>' +
        '<p class="help-p">Networking is data-only and engine-independent: the same objects, transforms and events work on every renderer. Offline objects behave like normal scene objects.</p>',
    },
    {
      id: 'scenes',
      category: 'Scenes & files',
      title: 'Saving & loading scenes',
      keywords: 'save load scene localstorage download json import new open storage',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Ctrl + S / File → Save Scene</b> — stores the scene in browser localStorage under a name.</li>' +
        '<li><b>Ctrl + O / Open Scene…</b> — lists saved scenes; load or delete them.</li>' +
        '<li><b>Download scene as .json</b> — full backup file including imported models (base64 data URLs).</li>' +
        '<li><b>Import scene .json…</b> or drop a .json on the viewport — restores everything.</li>' +
        '<li>The FSM action <b>Go to scene</b> switches scenes at runtime; <b>Go to scene URL</b> fetches one from a server.</li>' +
        '</ul>' +
        '<p class="help-p">Very large models can exceed the browser storage quota (a few MB) — prefer downloading the .json in that case.</p>',
    },
    {
      id: 'json-format',
      category: 'Scenes & files',
      title: 'Scene JSON format',
      keywords: 'json format schema version nodes models export import file structure',
      body:
        '<pre class="docs-code">{\n  "version": 1,\n  "name": "My Scene",\n  "env": { "ambient": 0.42, "showGrid": true, ... },\n  "models": [                        // imported glTF assets\n    { "id": "mdl_x9", "name": "robot",\n      "format": "glb",\n      "data": "data:model/gltf-binary;base64,..." }\n  ],\n  "nodes": [\n    { "id": "n_cube", "name": "Cube", "parent": null,\n      "type": "mesh", "tag": "", "active": true, "visible": true,\n      "transform": { "position": [0,0.5,0], "rotation": [0,0,0], "scale": [1,1,1] },\n      "mesh": { "shape": "cube", "color": "#c7cdd6", ... },\n      "rigidbody": { "mass": 1, ... },          // optional\n      "behaviors": [], "script": {...}, "fsm": {...} }\n  ]\n}</pre>' +
        '<p class="help-p">A mesh that renders an imported model uses <code>mesh: { shape: "model", modelId: "mdl_x9", meshIndex: 0, primitiveIndex: 0, ... }</code> pointing into <code>models[]</code>. Multiple nodes can share one model record.</p>',
    },
    {
      id: 'start-screen',
      category: 'Scenes & files',
      title: 'Start screen, templates & launcher',
      keywords: 'start screen launcher template default scene boot play now skip startup ctrl m',
      body:
        '<p class="help-p">The <b>start screen</b> opens at launch and lists every built-in template plus the scenes saved in this browser. Open it again at any time with <b>Ctrl + M</b> or <b>File → Start Screen / Templates…</b>.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Pick a scene card, then <b>Open in editor</b> or tick <b>Start playing immediately</b> to enter Play mode right away.</li>' +
        '<li>Templates include Sample Scene, Blank 3D, 3D Platformer, First-Person Arena, Third-Person, Multiplayer Arena, UI Toolkit Demo, Physics Playground, Arcade Racing, Scene Hub, Space Explorer and Everything Showcase.</li>' +
        '<li><b>Continue current scene</b> (or <kbd>Esc</kbd>) closes the launcher without changing anything.</li>' +
        '<li><b>Skip this screen on startup</b> stores the preference; the chosen template and play mode are remembered in this browser.</li>' +
        '</ul>',
    },
    {
      id: 'unity-ui',
      category: 'Unity UI',
      title: 'Unity UI elements (Canvas overlay)',
      keywords: 'unity ui canvas panel text button image slider toggle input dropdown progress fsm event anchor',
      body:
        '<p class="help-p">UI lives in the scene as objects (<code>node.type === "ui"</code>) and is drawn as a DOM overlay above the Game view. It is engine independent, scales with the viewport and stays readable by screen readers.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Add elements from <b>GameObject → UI</b>, <b>Component → UI Canvas / Element</b>, or <b>Window → Unity UI Library…</b>.</li>' +
        '<li>Ten kinds: <b>Canvas, Panel, Text, Button, Image, Slider, Toggle, Input, Dropdown, Progress</b>.</li>' +
        '<li>Inspector controls: anchor (9 positions), position, size, text, colours, background alpha, opacity, font size / weight / alignment, texture (Image) and interactable.</li>' +
        '<li><b>FSM event</b> — buttons, toggles, sliders, inputs and dropdowns broadcast this event to PlayMaker FSMs during Play mode. The current value is also stored in <code>runtime.uiValues</code> by name and id.</li>' +
        '<li><b>On click</b> can load a scene, open a URL, start Play mode or stop Play mode.</li>' +
        '<li>Image elements can use any procedural texture, the Texture Editor or an uploaded picture.</li>' +
        '</ul>' +
        '<p class="help-p">In Play mode the overlay receives pointer input; in the editor it is display-only unless you switch to the Game view. Scripts get <code>ctx.ui(name)</code>, <code>ctx.uiGet</code>, <code>ctx.uiSet</code>, <code>ctx.uiClick</code> and <code>ctx.uiVisible</code>.</p>',
    },
    {
      id: 'input-settings',
      category: 'Input',
      title: 'Keyboard & gamepad settings',
      keywords: 'input keyboard gamepad joypad controller rebind bindings deadzone sensitivity invert vibration settings',
      body:
        '<p class="help-p">Open <b>Window → Keyboard &amp; Gamepad Settings…</b> (also reachable from the start screen). Twelve actions can be rebound: moveForward, moveBack, moveLeft, moveRight, jump, fire, interact, sprint, crouch, pause, cameraToggle and reload.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Key</b> — press a keyboard key to replace the binding.</li>' +
        '<li><b>Pad</b> — press a gamepad button (standard mapping: A/B/X/Y, LB/RB, LT/RT, Back/Start, sticks, D-pad).</li>' +
        '<li><b>Stick deadzone</b>, <b>look sensitivity</b>, <b>mouse sensitivity</b>, <b>invert Y</b> and <b>vibration</b> are shared by all controllers and scripts.</li>' +
        '<li>Bindings are saved in <code>localStorage</code> under <code>webforge3d.input.v1</code>; <b>Reset defaults</b> restores the shipped map.</li>' +
        '<li>Gamepads use the browser Gamepad API — connect one and press a button, then click <b>Test gamepad vibration</b>.</li>' +
        '</ul>' +
        '<p class="help-p">FSM actions in the <b>Input</b> category cover held / pressed actions, analog axes, triggers, raw pad buttons, vibration and rebinding. Scripts use <code>ctx.action()</code>, <code>ctx.axis()</code>, <code>ctx.input</code> and <code>ctx.vibrate()</code>.</p>',
    },
    {
      id: 'second-camera',
      category: 'Camera',
      title: 'Second camera (picture-in-picture)',
      keywords: 'second camera picture in picture pip overlay split view minimap camera preview',
      body:
        '<p class="help-p">Add a camera from <b>GameObject → Second Camera</b> or enable <b>Second camera → Picture-in-picture</b> on any Camera. The PiP view is drawn by a private Native Canvas adapter, so it works with every engine and never replaces the main Game view camera.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Inspector: <b>Show PiP</b>, <b>Corner</b> (four corners), <b>Width</b> and <b>Height</b>.</li>' +
        '<li>Toolbar: the picture-in-picture button toggles the preview; the preference is stored under <code>webforge3d.pip</code>.</li>' +
        '<li>The overlay is only drawn in the Game view or Play mode.</li>' +
        '<li>FSM: <b>Second camera: set</b> and <b>Second camera: toggle</b>.</li>' +
        '</ul>',
    },
    {
      id: 'scene-changer',
      category: 'Scenes & files',
      title: 'In-game scene changer',
      keywords: 'scene changer menu switch level goto scene in game runtime load scene hub',
      body:
        '<p class="help-p">A <b>Scene Changer</b> object shows a compact scene menu on top of the Game view. Clicking a scene loads it instantly, even during Play mode.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Create one from <b>GameObject → Scene Changer</b>, or add the component to any object.</li>' +
        '<li>Configure it in the Inspector or with <b>Window → Scene Changer…</b>: enabled, visible, preview while editing, title and scene list.</li>' +
        '<li>Scene names can be built-in templates or scenes saved in this browser.</li>' +
        '<li>FSM: <b>Scene changer: show / hide</b> and <b>Scene changer: add scene</b>; <b>Go to scene</b> switches directly.</li>' +
        '</ul>',
    },
    {
      id: 'audio-sources',
      category: 'Audio',
      title: 'Audio Sources',
      keywords: 'audio source sound tone waveform frequency volume loop play awake mute music sfx wav mp3 ogg 3d panner spatial',
      body:
        '<p class="help-p">An <b>Audio Source</b> object plays either a generated tone or an audio file. Add one from <b>GameObject → Audio Source</b> or <b>Component → Audio Source</b>.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Generated tone</b> — frequency, waveform (sine / square / sawtooth / triangle) and duration.</li>' +
        '<li><b>Audio file / URL</b> — choose a WAV, MP3, OGG or any browser-supported file (stored as a data URL), or paste a path / URL.</li>' +
        '<li><b>3D sound</b> — a real Web Audio <code>PannerNode</code>. The listener follows the active Game camera and the emitter follows the GameObject. Set distance model, min / max distance, rolloff and cone angles.</li>' +
        '<li>Volume, loop and <b>Play on Start</b> are stored in the scene; sources stop cleanly when Play mode stops.</li>' +
        '<li>Inspector <b>Play / Stop</b> previews the sound while editing.</li>' +
        '<li>FSM: <b>Audio: play / stop / set volume / is playing?</b> and <b>3D sound / distance / cone</b>; scripts can call <code>ctx.audioPlay</code>, <code>ctx.audioStop</code> and <code>ctx.audio3d</code>.</li>' +
        '</ul>',
    },
    {
      id: 'video-player',
      category: 'Video',
      title: 'Video Player',
      keywords: 'video player movie film mp4 webm ogg ogv clip screen world billboard play pause stop seek volume mute',
      body:
        '<p class="help-p">A <b>Video Player</b> plays a video clip in the Game view. Add one from <b>GameObject → Video Player</b> or <b>Component → Video Player</b>. It works on every rendering engine because playback is drawn as a DOM overlay.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Clip</b> — choose a local MP4, WebM or OGG file (embedded as a data URL) or paste a URL. Files over 16 MB are rejected to protect browser storage.</li>' +
        '<li><b>Screen space</b> — anchor the player to the viewport (like Unity UI), with position, size, fit and optional browser controls.</li>' +
        '<li><b>World space</b> — the player billboards at the GameObject position and scales with the Game camera.</li>' +
        '<li>Volume, speed, loop, mute, visibility and <b>Play on Start</b> are stored in the scene. An optional <b>End event</b> fires into the FSM when the clip finishes.</li>' +
        '<li>FSM: <b>Video: play / pause / stop / seek / volume / get state</b>; scripts can call <code>ctx.videoPlay</code>, <code>ctx.videoPause</code>, <code>ctx.videoStop</code>, <code>ctx.videoSeek</code>, <code>ctx.videoTime</code> and <code>ctx.videoDuration</code>.</li>' +
        '<li>Browsers may require one user click before video or audio can autoplay.</li>' +
        '</ul>',
    },
    {
      id: 'networking',
      category: 'Networking',
      title: 'HTTP requests & PHP',
      keywords: 'network http fetch php request get post json api server load scene url',
      body:
        '<p class="help-p">The FSM <b>HTTP request</b> action performs GET / POST calls with JSON bodies and headers; responses become FSM variables (status, body, parsed fields). Pair it with <b>Go to scene URL</b> to stream level files from a PHP endpoint, or <b>Format string</b> to compose payloads. This is the supported way to talk to a server — scripts run in a sandboxed context without fetch, so use actions for networking.</p>',
    },
    {
      id: 'engines',
      category: 'Engines & plugins',
      title: 'Rendering engines',
      keywords: 'engine three babylon native canvas renderer switch offline cdn fallback',
      body:
        '<p class="help-p">Pick a renderer from the toolbar dropdown or the Engine menu:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Three.js</b> — WebGL, loaded on demand from its CDN.</li>' +
        '<li><b>Babylon.js</b> — WebGL, loaded on demand from its CDN.</li>' +
        '<li><b>Native Canvas</b> — the built-in software renderer; works fully offline.</li>' +
        '</ul>' +
        '<p class="help-p">Switching is instant and never touches the scene — every engine reads the same scene model, including imported models. Check <b>Window → Engine Compatibility…</b> for the feature matrix. Heavy imported models render fastest on the WebGL engines.</p>',
    },
    {
      id: 'plugins',
      category: 'Engines & plugins',
      title: 'Engine plugins',
      keywords: 'plugin adapter register custom engine sdk api unityweb engines connect',
      body:
        '<p class="help-p">Register your own renderer at runtime with <code>UnityWeb.engines.register({...})</code> — it appears in the Engine menu instantly. An adapter implements <code>load()</code>, <code>create(def)</code> → <code>{ init, resize, update, render, getStats, dispose }</code>. Read geometry through <code>UnityWeb.geom.forNode(node)</code> (works for primitives and imported models), lights through <code>UnityWeb.scene.collectLights</code> and textures through <code>UnityWeb.textures.getTiled</code>. See <b>Help → Scripting &amp; plugin API</b> and <code>plugins/README.md</code> for the full surface.</p>',
    },
    {
      id: 'play-mode',
      category: 'Basics',
      title: 'Play mode',
      keywords: 'play pause stop step runtime simulate run test gamectrl',
      body:
        '<p class="help-p"><b>Ctrl + P</b> starts Play mode: rigidbodies simulate, behaviors / scripts / FSMs run, and the toolbar shows pause / single-step. <b>Stop</b> restores the scene exactly as it was — any runtime change (moves, activations, spawned clones) is reverted.</p>' +
        '<p class="help-p">The FSM <b>Exit to editor</b> action stops play from inside the game; <b>Restart scene</b> reloads the pre-play state while staying in play mode.</p>',
    },
    {
      id: 'troubleshooting',
      category: 'Troubleshooting',
      title: 'Troubleshooting',
      keywords: 'troubleshoot problem error blank black scene slow storage quota import fails not visible',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Scene is black</b> — all lights may be inactive; the renderer keeps a faint fallback light, but check Environment ambient.</li>' +
        '<li><b>Object not visible</b> — check <b>Visible</b>, <b>Active</b> (parents too — inactive disables the subtree) and opacity.</li>' +
        '<li><b>Model import fails</b> — the Console shows the exact reason: .gltf must embed buffers as data URIs (export .glb instead); OBJ needs faces; .blend must be saved by Blender 2.63+ with mesh data (apply modifiers); non-triangle modes are skipped.</li>' +
        '<li><b>Save fails</b> — browser storage is full, usually from big model data URLs; download the scene as .json instead.</li>' +
        '<li><b>Slow viewport</b> — heavy models render faster on Three.js / Babylon.js than Native Canvas; reduce triangle counts.</li>' +
        '<li><b>Script does nothing</b> — scripts run only in Play mode; compile errors appear in the Console.</li>' +
        '<li><b>Undo missing a step</b> — some edits are grouped; check the Edit menu\'s undo label.</li>' +
        '</ul>',
    },
  ];

  /* script ctx API entries, derived from the runtime context */
  function scriptApiTopics() {
    const api = [
      ['ctx.node', 'The object this script runs on. Its full data: transform, mesh, light, tag, active…', 'node object self this me'],
      ['ctx.scene', 'The whole scene model: nodes, models, env — read/modify it live.', 'scene nodes models env world'],
      ['ctx.find(name)', 'Find a node by exact name. Returns the node object or null.', 'find search name lookup object'],
      ['ctx.findByTag(tag)', 'Find the first <b>active</b> object with a tag (case-insensitive).', 'tag find bytag lookup'],
      ['ctx.setActive(nodeOrId, active)', 'Activate or deactivate an object (Unity semantics — children follow).', 'setactive activate deactivate enable disable'],
      ['ctx.setColor(hex)', 'Set this mesh\'s material color, e.g. ctx.setColor("#ff8800").', 'color colour material setcolor'],
      ['ctx.openUrl(url, target)', 'Open a URL in a new tab (or "_self"). Call it from key / click flows so popup blockers allow it.', 'openurl url open link web page'],
      ['ctx.log(...)', 'Write to the editor Console (objects are JSON-stringified).', 'log console print debug message'],
      ['ctx.emitEvent(name)', 'Broadcast an FSM event that transitions can listen for.', 'event emit send fsm trigger'],
      ['ctx.time / ctx.dt', 'Seconds since play started / seconds since last frame.', 'time delta dt seconds elapsed'],
      ['ctx.editor / ctx.engine', 'The editor instance (undo, selection, logging) and the active engine\'s name.', 'editor engine name access'],
      ['ctx.vec / ctx.math', 'The shared math helpers: vector ops, matrices, clamp, lerp…', 'math vec vector helpers lerp clamp'],
      ['ctx.audioPlay / ctx.audioStop / ctx.audio3d', 'Control Audio Source objects. <code>audio3d(ref, true)</code> enables positional sound.', 'audio sound wav mp3 ogg 3d spatial play stop'],
      ['ctx.videoPlay / ctx.videoPause / ctx.videoStop', 'Control Video Player objects by name or id. Also: <code>videoSeek</code>, <code>videoTime</code>, <code>videoDuration</code>, <code>videoVolume</code> and <code>videoPlaying</code>.', 'video movie clip play pause stop seek time duration'],
    ];
    return api.map(([title, body, keywords]) => ({
      id: 'api-' + title.replace(/[^a-z]/gi, ''),
      category: 'Scripting API',
      title: title,
      keywords: 'script api ' + keywords,
      body: '<p class="help-p"><code>' + title + '</code> — ' + body + '</p>' +
        '<p class="help-p"><i>See also:</i> JavaScript scripts, PlayMaker FSM.</p>',
    }));
  }

  /* FSM action entries, derived from UW.FSM so they never go stale */
  function fsmActionTopics() {
    const F = UW.FSM;
    if (!F || !F.actionTypes) return [];
    const catLabel = {};
    (F.categories || []).forEach((c) => { catLabel[c.id] = c.label; });
    return F.actionTypes.map((a) => {
      const params = (a.params || []).map((p) => {
        const type = p.type || 'value';
        const def = p.def != null ? String(p.def) : '';
        return '<tr><td>' + p.label + '</td><td>' + type + '</td><td>' + (def || '—') + '</td></tr>';
      }).join('');
      const paramKeywords = (a.params || []).map((p) => (p.key || '') + ' ' + (p.label || '')).join(' ');
      return {
        id: 'action-' + a.id,
        category: 'FSM actions · ' + (catLabel[a.category] || a.category),
        title: a.label,
        keywords: 'fsm action ' + a.id + ' ' + (a.category || '') + ' ' + paramKeywords,
        body:
          '<p class="help-p">' + (a.help || '') + '</p>' +
          (params
            ? '<table class="docs-table"><thead><tr><th>Parameter</th><th>Type</th><th>Default</th></tr></thead><tbody>' + params + '</tbody></table>'
            : '<p class="help-p"><i>No parameters.</i></p>') +
          '<p class="help-p"><i>Category:</i> ' + (catLabel[a.category] || a.category) + ' · <i>Action id:</i> <code>' + a.id + '</code></p>',
      };
    });
  }

  let cachedEntries = null;
  function entries() {
    if (cachedEntries) return cachedEntries;
    cachedEntries = []
      .concat(STATIC_TOPICS)
      .concat(scriptApiTopics())
      .concat(fsmActionTopics())
      .map((e) => {
        const div = document.createElement('div');
        div.innerHTML = e.body;
        return Object.assign({}, e, {
          titleLower: e.title.toLowerCase(),
          keywordsLower: (e.keywords || '').toLowerCase(),
          categoryLower: (e.category || '').toLowerCase(),
          plainText: (div.textContent || '').toLowerCase(),
        });
      });
    return cachedEntries;
  }

  /* ------------------------------------------------------------
     search
     ------------------------------------------------------------ */
  function scoreEntry(entry, terms) {
    let total = 0;
    for (const t of terms) {
      let s = 0;
      if (entry.titleLower.indexOf(t) >= 0) s += 6 + (entry.titleLower.indexOf(t) === 0 ? 3 : 0);
      if (entry.keywordsLower.indexOf(t) >= 0) s += 4;
      if (entry.categoryLower.indexOf(t) >= 0) s += 3;
      if (entry.plainText.indexOf(t) >= 0) s += 1;
      if (!s) return 0; // every term must match somewhere
      total += s;
    }
    return total;
  }

  function search(query) {
    const terms = String(query || '').toLowerCase().split(/\s+/).filter(Boolean);
    const list = entries();
    if (!terms.length) {
      // relevance-ish default order: static topics, api, then actions
      return list.map((e) => ({ e, s: 1 }));
    }
    const out = [];
    for (const e of list) {
      const s = scoreEntry(e, terms);
      if (s > 0) out.push({ e, s });
    }
    out.sort((a, b) => b.s - a.s || a.e.title.localeCompare(b.e.title));
    return out;
  }

  /* ------------------------------------------------------------
     dialog
     ------------------------------------------------------------ */
  function open(query) {
    if (!UW.UI || !UW.UI.openModal) return;
    const UI = UW.UI;
    const body = UI.div('docs-wrap');

    const bar = UI.div('docs-bar');
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'docs-input';
    input.placeholder = 'Search the manual — try "tag", "tween", "import model", "fog"…';
    bar.appendChild(input);
    const count = UI.el('span', 'docs-count', '');
    bar.appendChild(count);
    body.appendChild(bar);

    const panes = UI.div('docs-panes');
    const listEl = UI.div('docs-list');
    const detail = UI.div('docs-detail');
    const detailInner = UI.div('docs-detail-inner');
    detail.appendChild(detailInner);
    panes.appendChild(listEl);
    panes.appendChild(detail);
    body.appendChild(panes);

    let flat = []; // currently visible entries in display order
    let cursor = -1;

    const renderDetail = (entry) => {
      detailInner.innerHTML = '';
      if (!entry) {
        detailInner.appendChild(UI.el('p', 'help-p', 'Select a topic to read it here.'));
        return;
      }
      detailInner.appendChild(UI.el('div', 'docs-detail-cat', entry.category));
      detailInner.appendChild(UI.el('h3', 'docs-detail-title', entry.title));
      const content = UI.div('docs-detail-body');
      content.innerHTML = entry.body;
      detailInner.appendChild(content);
    };

    const highlight = (row) => {
      const prev = listEl.querySelector('.docs-item.active');
      if (prev) prev.classList.remove('active');
      row.classList.add('active');
      row.scrollIntoView({ block: 'nearest' });
    };

    const selectIndex = (i) => {
      if (!flat.length) return;
      cursor = Math.max(0, Math.min(flat.length - 1, i));
      const item = flat[cursor];
      const rows = listEl.querySelectorAll('.docs-item');
      const row = rows[cursor];
      if (row) highlight(row);
      renderDetail(item.e || item);
    };

    const renderList = () => {
      const q = input.value;
      const results = search(q);
      flat = results.map((r) => r.e);
      listEl.innerHTML = '';
      const shown = flat.slice(0, 60);
      count.textContent = flat.length
        ? flat.length + (flat.length > 60 ? ' matches (showing 60)' : ' matches')
        : 'no matches';

      let lastCat = null;
      let idx = 0;
      for (const entry of shown) {
        if (entry.category !== lastCat) {
          lastCat = entry.category;
          listEl.appendChild(UI.el('div', 'docs-group', lastCat));
        }
        const row = UI.el('div', 'docs-item');
        const t = UI.el('div', 'docs-item-title', entry.title);
        row.appendChild(t);
        const snippet = entry.plainText.slice(0, 90).trim();
        row.appendChild(UI.el('div', 'docs-item-snippet', snippet + (entry.plainText.length > 90 ? '…' : '')));
        const myIndex = idx++;
        row.addEventListener('click', () => selectIndex(myIndex));
        listEl.appendChild(row);
      }
      if (!shown.length) {
        listEl.appendChild(UI.el('div', 'docs-empty', 'Nothing found for "' + q + '". Try a shorter word.'));
      }
      cursor = -1;
      selectIndex(0);
    };

    input.addEventListener('input', renderList);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); selectIndex(cursor + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); selectIndex(cursor - 1); }
      else if (e.key === 'Enter') { e.preventDefault(); selectIndex(cursor < 0 ? 0 : cursor); }
    });

    const modal = UI.openModal({
      title: 'Documentation Manual',
      icon: 'i-help',
      wide: true,
      cls: 'docs-modal',
      body,
      actions: [{ label: 'Close', kind: 'primary' }],
    });

    if (query) input.value = query;
    renderList();
    setTimeout(() => { try { input.focus(); input.select(); } catch (e) { /* ignore */ } }, 30);
    return modal;
  }

  UW.Docs = { open, search, entries };
})();
