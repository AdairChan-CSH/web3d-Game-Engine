/* ============================================================
   unityui.js — Unity-style Canvas / UI elements
   UI is part of the scene model (node.type === 'ui') and is drawn as
   a DOM overlay on top of the Game view. Because it is plain DOM it
   works with every rendering engine, scales with the viewport and is
   readable by screen readers. Buttons, toggles, sliders, inputs and
   dropdowns fire FSM events in Play mode.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const U = (UW.unityui = {});

  const KINDS = [
    { id: 'canvas', label: 'Canvas', icon: 'i-ui', group: 'UI' },
    { id: 'panel', label: 'Panel', icon: 'i-ui', group: 'UI' },
    { id: 'text', label: 'Text', icon: 'i-ui', group: 'UI' },
    { id: 'button', label: 'Button', icon: 'i-ui', group: 'UI' },
    { id: 'image', label: 'Image', icon: 'i-ui', group: 'UI' },
    { id: 'slider', label: 'Slider', icon: 'i-ui', group: 'UI' },
    { id: 'toggle', label: 'Toggle', icon: 'i-ui', group: 'UI' },
    { id: 'input', label: 'Input Field', icon: 'i-ui', group: 'UI' },
    { id: 'dropdown', label: 'Dropdown', icon: 'i-ui', group: 'UI' },
    { id: 'progress', label: 'Progress Bar', icon: 'i-ui', group: 'UI' },
  ];
  U.kinds = KINDS;
  U.kindIds = KINDS.map((k) => k.id);

  const ANCHORS = [
    { id: 'topLeft', label: 'Top left' },
    { id: 'topCenter', label: 'Top center' },
    { id: 'topRight', label: 'Top right' },
    { id: 'middleLeft', label: 'Middle left' },
    { id: 'center', label: 'Center' },
    { id: 'middleRight', label: 'Middle right' },
    { id: 'bottomLeft', label: 'Bottom left' },
    { id: 'bottomCenter', label: 'Bottom center' },
    { id: 'bottomRight', label: 'Bottom right' },
  ];
  U.anchors = ANCHORS;

  const PAD = 8;

  function kindDefault(kind) {
    const base = {
      kind,
      visible: true,
      interactable: true,
      anchor: 'topLeft',
      x: 24,
      y: 24,
      w: 220,
      h: 48,
      text: 'Text',
      fontSize: 20,
      font: 'sans',
      bold: false,
      color: '#f2f5f9',
      bg: '#252b33',
      bgAlpha: 0.92,
      radius: 8,
      border: 1,
      align: 'left',
      padding: 10,
      value: 0.5,
      min: 0,
      max: 1,
      step: 0.01,
      checked: false,
      options: 'Option A, Option B, Option C',
      placeholder: 'Type here…',
      event: '',
      action: '',
      scene: '',
      url: '',
      texture: null,
      opacity: 1,
    };
    if (kind === 'canvas') {
      return Object.assign(base, {
        anchor: 'topLeft', x: 0, y: 0, w: 1280, h: 720, bg: '#10141a', bgAlpha: 0, border: 0, radius: 0, text: 'Canvas',
      });
    }
    if (kind === 'panel') {
      return Object.assign(base, { w: 320, h: 180, bg: '#20262e', bgAlpha: 0.92, radius: 10, text: 'Panel' });
    }
    if (kind === 'text') {
      return Object.assign(base, { w: 340, h: 40, text: 'New Text', bg: '#000000', bgAlpha: 0, border: 0, align: 'left' });
    }
    if (kind === 'button') {
      return Object.assign(base, { w: 200, h: 52, text: 'Button', bg: '#3d8bfd', align: 'center', event: 'uiClick' });
    }
    if (kind === 'image') {
      return Object.assign(base, { w: 200, h: 200, text: 'Image', bg: '#2c323a', align: 'center', bgAlpha: 1 });
    }
    if (kind === 'slider') {
      return Object.assign(base, { w: 240, h: 36, text: 'Slider', bg: '#1b2027', event: 'uiChange' });
    }
    if (kind === 'toggle') {
      return Object.assign(base, { w: 190, h: 40, text: 'Toggle', bg: '#1b2027', event: 'uiToggle' });
    }
    if (kind === 'input') {
      return Object.assign(base, { w: 280, h: 46, text: '', bg: '#141920', event: 'uiSubmit' });
    }
    if (kind === 'dropdown') {
      return Object.assign(base, { w: 260, h: 44, bg: '#141920', event: 'uiChange' });
    }
    if (kind === 'progress') {
      return Object.assign(base, { w: 260, h: 24, text: 'Progress', bg: '#141920', border: 0 });
    }
    return base;
  }

  U.createComponent = function (kind, props) {
    const id = U.kindIds.indexOf(kind) >= 0 ? kind : 'panel';
    return Object.assign(kindDefault(id), props || {});
  };

  U.label = function (kind) {
    const k = KINDS.find((x) => x.id === kind);
    return k ? k.label : 'UI Element';
  };

  const num = (v, d) => (Number.isFinite(+v) ? +v : d);
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hex = (v, d) => (typeof v === 'string' && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim()) ? v.trim() : d);

  U.normalize = function (ui) {
    if (!ui || typeof ui !== 'object') return null;
    const kind = U.kindIds.indexOf(ui.kind) >= 0 ? ui.kind : 'panel';
    const d = kindDefault(kind);
    const out = Object.assign(d, ui);
    out.kind = kind;
    out.visible = ui.visible !== false;
    out.interactable = ui.interactable !== false;
    out.anchor = ANCHORS.some((a) => a.id === ui.anchor) ? ui.anchor : d.anchor;
    out.x = num(ui.x, d.x);
    out.y = num(ui.y, d.y);
    out.w = Math.max(8, num(ui.w, d.w));
    out.h = Math.max(8, num(ui.h, d.h));
    out.text = ui.text != null ? String(ui.text) : d.text;
    out.fontSize = clamp(num(ui.fontSize, d.fontSize), 6, 200);
    out.font = ui.font === 'mono' ? 'mono' : 'sans';
    out.bold = ui.bold === true;
    out.color = hex(ui.color, d.color);
    out.bg = hex(ui.bg, d.bg);
    out.bgAlpha = clamp(num(ui.bgAlpha, d.bgAlpha), 0, 1);
    out.radius = clamp(num(ui.radius, d.radius), 0, 200);
    out.border = clamp(num(ui.border, d.border), 0, 20);
    out.align = ['left', 'center', 'right'].indexOf(ui.align) >= 0 ? ui.align : d.align;
    out.padding = clamp(num(ui.padding, d.padding), 0, 80);
    out.opacity = clamp(num(ui.opacity, 1), 0, 1);
    out.value = num(ui.value, d.value);
    out.min = num(ui.min, d.min);
    out.max = num(ui.max, d.max);
    if (out.max <= out.min) out.max = out.min + 1;
    out.step = Math.max(0.0001, num(ui.step, d.step));
    out.checked = ui.checked === true;
    out.options = typeof ui.options === 'string' ? ui.options : (Array.isArray(ui.options) ? ui.options.join(', ') : d.options);
    out.placeholder = ui.placeholder != null ? String(ui.placeholder) : d.placeholder;
    out.event = typeof ui.event === 'string' ? ui.event.trim().slice(0, 64) : d.event;
    out.action = ['', 'scene', 'url', 'play', 'stop'].indexOf(ui.action) >= 0 ? ui.action : '';
    out.scene = typeof ui.scene === 'string' ? ui.scene : '';
    out.url = typeof ui.url === 'string' ? ui.url : '';
    out.texture = UW.textures ? UW.textures.normalize(ui.texture) : (ui.texture || null);
    return out;
  };

  /* ---------------- DOM layer ---------------- */
  let layer = null;
  let sig = '';
  let dirty = true;
  const texCache = new Map();

  U.invalidate = function () { dirty = true; };

  function ensureLayer() {
    if (layer && document.body.contains(layer)) return layer;
    const viewport = document.getElementById('viewport');
    if (!viewport) return null;
    layer = document.getElementById('unityui-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.id = 'unityui-layer';
      layer.className = 'unityui-layer';
      layer.setAttribute('aria-hidden', 'true');
      const gizmo = document.getElementById('gizmo');
      if (gizmo && gizmo.parentNode === viewport) viewport.insertBefore(layer, gizmo);
      else viewport.appendChild(layer);
    }
    return layer;
  }

  function textureURL(tex) {
    if (!tex || tex.enabled === false || !UW.textures) return null;
    let key = 'sig';
    try { key = UW.textures.signature(tex) || JSON.stringify(tex.preset || ''); } catch (e) { /* ignore */ }
    if (texCache.has(key)) return texCache.get(key);
    let url = null;
    try { url = UW.textures.previewDataURL(tex, 256); } catch (e) { url = null; }
    texCache.set(key, url);
    if (texCache.size > 80) texCache.delete(texCache.keys().next().value);
    return url;
  }

  function pageSize() {
    const viewport = document.getElementById('viewport');
    const r = viewport ? viewport.getBoundingClientRect() : { width: 1280, height: 720 };
    return { w: Math.max(1, r.width), h: Math.max(1, r.height) };
  }

  function place(node, el, page, scale) {
    const ui = node.ui;
    const w = ui.w * scale;
    const h = ui.h * scale;
    const a = ui.anchor;
    let x = ui.x * scale;
    let y = ui.y * scale;
    if (a.indexOf('Right') >= 0) x = page.w - w - x;
    else if (a.indexOf('Center') >= 0 || a === 'center') x = (page.w - w) / 2 + x;
    if (a.indexOf('bottom') === 0) y = page.h - h - y;
    else if (a.indexOf('middle') === 0 || a === 'center') y = (page.h - h) / 2 + y;
    el.style.left = Math.round(x) + 'px';
    el.style.top = Math.round(y) + 'px';
    el.style.width = Math.round(w) + 'px';
    el.style.height = Math.round(h) + 'px';
  }

  function emit(editor, node, eventName) {
    const rt = editor.runtime;
    if (!rt) return;
    const name = eventName || node.ui.event || '';
    if (name) rt.emitEvent(name);
    rt.uiValues = rt.uiValues || {};
    rt.uiValues[node.name] = uiValue(node);
    rt.uiValues[node.id] = uiValue(node);
    if (node.ui.action === 'scene' && node.ui.scene) {
      editor.gotoScene(node.ui.scene, { play: true });
    } else if (node.ui.action === 'url' && node.ui.url) {
      try { window.open(node.ui.url, '_blank', 'noopener'); } catch (e) { /* ignore */ }
    } else if (node.ui.action === 'play') {
      editor.play();
    } else if (node.ui.action === 'stop') {
      editor.stop();
    }
  }

  U.emit = emit;

  function uiValue(node) {
    const ui = node.ui;
    if (ui.kind === 'toggle') return ui.checked ? 'true' : 'false';
    if (ui.kind === 'button') return 'clicked';
    return String(ui.value != null ? ui.value : ui.text || '');
  }

  function widgetContent(editor, node, box, scale) {
    const ui = node.ui;
    const playing = !!editor.runtime && editor.playing;
    const interactive = playing && ui.interactable;
    const fontFamily = ui.font === 'mono' ? 'var(--mono, monospace)' : 'inherit';
    const base = {
      color: ui.color,
      fontSize: (ui.fontSize * scale) + 'px',
      fontFamily,
      fontWeight: ui.bold ? '700' : '400',
      padding: (ui.padding * scale) + 'px',
      textAlign: ui.align,
      borderRadius: (ui.radius * scale) + 'px',
      border: ui.border ? Math.max(1, Math.round(ui.border * scale)) + 'px solid rgba(255,255,255,.18)' : 'none',
      background: 'transparent',
      opacity: String(ui.opacity),
      pointerEvents: interactive ? 'auto' : 'none',
    };

    if (ui.kind === 'panel' || ui.kind === 'canvas' || ui.kind === 'image') {
      const a = Math.round(ui.bgAlpha * 255).toString(16).padStart(2, '0');
      box.style.background = ui.bg + a;
      const url = textureURL(ui.texture);
      if (url && ui.kind === 'image') {
        box.style.backgroundImage = 'url("' + url + '")';
        box.style.backgroundSize = 'cover';
        box.style.backgroundPosition = 'center';
      }
      if (ui.kind === 'image' && !url && ui.text) {
        box.textContent = ui.text;
        box.style.display = 'flex';
        box.style.alignItems = 'center';
        box.style.justifyContent = 'center';
      }
      if (ui.kind === 'canvas') {
        box.style.pointerEvents = 'none';
        if (ui.bgAlpha === 0) box.style.background = 'transparent';
      }
      return;
    }

    if (ui.kind === 'text') {
      box.textContent = ui.text;
      box.style.display = 'flex';
      box.style.alignItems = 'center';
      box.style.justifyContent = ui.align === 'center' ? 'center' : ui.align === 'right' ? 'flex-end' : 'flex-start';
      box.style.textShadow = '0 1px 2px rgba(0,0,0,.65)';
      box.style.whiteSpace = 'pre-wrap';
      return;
    }

    if (ui.kind === 'button') {
      const a = Math.round(ui.bgAlpha * 255).toString(16).padStart(2, '0');
      box.textContent = ui.text;
      box.style.display = 'flex';
      box.style.alignItems = 'center';
      box.style.justifyContent = 'center';
      box.style.background = ui.bg + a;
      box.classList.add('unityui-button');
      if (interactive) {
        box.style.cursor = 'pointer';
        box.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          emit(editor, node);
          U.invalidate();
        });
      } else {
        box.style.opacity = String(ui.opacity * (ui.interactable ? 1 : 0.55));
      }
      return;
    }

    if (ui.kind === 'toggle') {
      box.style.display = 'flex';
      box.style.alignItems = 'center';
      box.style.gap = (8 * scale) + 'px';
      const mark = document.createElement('span');
      mark.className = 'unityui-check' + (ui.checked ? ' on' : '');
      mark.style.width = Math.round(ui.h * 0.6) + 'px';
      mark.style.height = Math.round(ui.h * 0.6) + 'px';
      mark.style.borderRadius = Math.round(ui.h * 0.16) + 'px';
      mark.style.border = '2px solid rgba(255,255,255,.5)';
      mark.style.flex = '0 0 auto';
      mark.style.display = 'inline-flex';
      mark.style.alignItems = 'center';
      mark.style.justifyContent = 'center';
      mark.style.fontSize = Math.round(ui.h * 0.38) + 'px';
      mark.textContent = ui.checked ? '✓' : '';
      mark.style.background = ui.checked ? ui.bg : 'transparent';
      box.appendChild(mark);
      const label = document.createElement('span');
      label.textContent = ui.text;
      box.appendChild(label);
      if (interactive) {
        box.style.cursor = 'pointer';
        box.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          ui.checked = !ui.checked;
          emit(editor, node);
          U.invalidate();
        });
      }
      return;
    }

    if (ui.kind === 'slider') {
      const wrap = document.createElement('div');
      wrap.className = 'unityui-slider';
      wrap.style.display = 'flex';
      wrap.style.alignItems = 'center';
      wrap.style.gap = (8 * scale) + 'px';
      wrap.style.height = '100%';
      if (ui.text) {
        const label = document.createElement('span');
        label.textContent = ui.text;
        label.style.whiteSpace = 'nowrap';
        label.style.fontSize = (ui.fontSize * scale * 0.8) + 'px';
        wrap.appendChild(label);
      }
      const input = document.createElement('input');
      input.type = 'range';
      input.min = String(ui.min);
      input.max = String(ui.max);
      input.step = String(ui.step);
      input.value = String(ui.value);
      input.style.flex = '1';
      input.disabled = !interactive;
      input.addEventListener('input', () => {
        ui.value = parseFloat(input.value);
        emit(editor, node);
      });
      wrap.appendChild(input);
      const val = document.createElement('span');
      val.textContent = String(Math.round(ui.value * 100) / 100);
      val.style.fontSize = (ui.fontSize * scale * 0.75) + 'px';
      val.style.minWidth = (38 * scale) + 'px';
      wrap.appendChild(val);
      box.appendChild(wrap);
      return;
    }

    if (ui.kind === 'progress') {
      const a = Math.round(ui.bgAlpha * 255).toString(16).padStart(2, '0');
      box.style.background = ui.bg + a;
      const fill = document.createElement('div');
      const pct = clamp((ui.value - ui.min) / (ui.max - ui.min), 0, 1) * 100;
      fill.className = 'unityui-progress-fill';
      fill.style.width = pct + '%';
      fill.style.height = '100%';
      fill.style.background = '#3d8bfd';
      fill.style.borderRadius = 'inherit';
      box.appendChild(fill);
      if (ui.text) {
        const label = document.createElement('span');
        label.textContent = ui.text;
        label.style.position = 'absolute';
        label.style.inset = '0';
        label.style.display = 'flex';
        label.style.alignItems = 'center';
        label.style.justifyContent = 'center';
        label.style.fontSize = (ui.fontSize * scale * 0.7) + 'px';
        label.style.pointerEvents = 'none';
        box.appendChild(label);
      }
      box.style.overflow = 'hidden';
      box.style.position = 'absolute';
      return;
    }

    if (ui.kind === 'input') {
      const input = document.createElement('input');
      input.type = 'text';
      input.value = ui.text || '';
      input.placeholder = ui.placeholder;
      input.disabled = !interactive;
      input.style.width = '100%';
      input.style.height = '100%';
      input.style.boxSizing = 'border-box';
      input.style.background = 'transparent';
      input.style.border = 'none';
      input.style.outline = 'none';
      input.style.color = ui.color;
      input.style.fontSize = (ui.fontSize * scale) + 'px';
      input.style.fontFamily = fontFamily;
      input.style.textAlign = ui.align;
      input.addEventListener('input', () => { ui.text = input.value; });
      input.addEventListener('change', () => emit(editor, node));
      box.appendChild(input);
      return;
    }

    if (ui.kind === 'dropdown') {
      const select = document.createElement('select');
      select.style.width = '100%';
      select.style.height = '100%';
      select.style.background = 'transparent';
      select.style.color = ui.color;
      select.style.border = 'none';
      select.style.outline = 'none';
      select.style.fontSize = (ui.fontSize * scale) + 'px';
      select.disabled = !interactive;
      const options = String(ui.options || '').split(',').map((s) => s.trim()).filter(Boolean);
      if (!options.length) options.push('Option');
      options.forEach((opt, i) => {
        const o = document.createElement('option');
        o.value = opt;
        o.textContent = opt;
        if (i === Math.round(clamp(ui.value, 0, options.length - 1))) o.selected = true;
        select.appendChild(o);
      });
      select.addEventListener('change', () => {
        ui.value = Math.max(0, options.indexOf(select.value));
        ui.text = select.value;
        emit(editor, node);
        U.invalidate();
      });
      box.appendChild(select);
      return;
    }

    for (const key of Object.keys(base)) box.style[key] = base[key];
    box.textContent = ui.text;
  }

  function build(editor, nodes) {
    const host = ensureLayer();
    if (!host) return;
    clearHost(host);
    const page = pageSize();
    const scale = Math.max(0.7, Math.min(1.8, Math.min(page.w / 1280, page.h / 720)));
    for (const node of nodes) {
      if (!node.ui || !node.ui.visible) continue;
      const box = document.createElement('div');
      box.className = 'unityui-node unityui-' + node.ui.kind;
      box.dataset.uiId = node.id;
      box.dataset.uiName = node.name;
      box.style.position = 'absolute';
      box.style.boxSizing = 'border-box';
      box.style.overflow = node.ui.kind === 'dropdown' ? 'hidden' : 'visible';
      const interactive = editor.playing && node.ui.interactable;
      box.style.pointerEvents = interactive ? 'auto' : 'none';
      if (node.ui.kind === 'canvas' || node.ui.kind === 'panel' || node.ui.kind === 'image') {
        const a = Math.round(node.ui.bgAlpha * 255).toString(16).padStart(2, '0');
        box.style.background = node.ui.bg + a;
        if (node.ui.border) {
          box.style.border = Math.max(1, Math.round(node.ui.border * scale)) + 'px solid rgba(255,255,255,.14)';
        }
        box.style.borderRadius = (node.ui.radius * scale) + 'px';
        box.style.color = node.ui.color;
        box.style.fontSize = (node.ui.fontSize * scale) + 'px';
        box.style.textAlign = node.ui.align;
        box.style.padding = (node.ui.padding * scale) + 'px';
        box.style.opacity = String(node.ui.opacity);
        if (node.ui.kind === 'image') {
          const url = textureURL(node.ui.texture);
          if (url) {
            box.style.backgroundImage = 'url("' + url + '")';
            box.style.backgroundSize = 'cover';
            box.style.backgroundPosition = 'center';
          }
        }
        if (node.ui.kind === 'canvas' && node.ui.bgAlpha === 0) box.style.background = 'transparent';
      }
      place(node, box, page, scale);
      if (node.ui.kind === 'text' || node.ui.kind === 'panel' || node.ui.kind === 'canvas' || node.ui.kind === 'image') {
        if (node.ui.kind === 'text') {
          box.style.color = node.ui.color;
          box.style.fontSize = (node.ui.fontSize * scale) + 'px';
          box.style.fontWeight = node.ui.bold ? '700' : '400';
          box.style.fontFamily = node.ui.font === 'mono' ? 'var(--mono, monospace)' : 'inherit';
          box.style.display = 'flex';
          box.style.alignItems = 'center';
          box.style.justifyContent = node.ui.align === 'center' ? 'center' : node.ui.align === 'right' ? 'flex-end' : 'flex-start';
          box.style.textAlign = node.ui.align;
          box.style.padding = (node.ui.padding * scale) + 'px';
          box.style.textShadow = '0 1px 2px rgba(0,0,0,.65)';
          box.style.whiteSpace = 'pre-wrap';
          box.textContent = node.ui.text;
          box.style.opacity = String(node.ui.opacity);
          if (!editor.playing) box.style.pointerEvents = 'none';
        } else if (node.ui.kind === 'image' && !textureURL(node.ui.texture) && node.ui.text) {
          box.style.display = 'flex';
          box.style.alignItems = 'center';
          box.style.justifyContent = 'center';
          box.textContent = node.ui.text;
        }
      } else {
        if (node.ui.kind !== 'toggle') {
          box.style.background = hexA(node.ui.bg, node.ui.bgAlpha);
          box.style.borderRadius = (node.ui.radius * scale) + 'px';
          if (node.ui.border) box.style.border = Math.max(1, Math.round(node.ui.border * scale)) + 'px solid rgba(255,255,255,.18)';
        } else {
          box.style.background = 'transparent';
        }
        box.style.color = node.ui.color;
        box.style.fontSize = (node.ui.fontSize * scale) + 'px';
        box.style.fontFamily = node.ui.font === 'mono' ? 'var(--mono, monospace)' : 'inherit';
        box.style.fontWeight = node.ui.bold ? '700' : '400';
        box.style.textAlign = node.ui.align;
        box.style.padding = (node.ui.padding * scale) + 'px';
        box.style.opacity = String(node.ui.opacity);
        widgetContent(editor, node, box, scale);
      }
      host.appendChild(box);
    }
  }

  function hexA(hex, alpha) {
    const a = Math.round(clamp(alpha, 0, 1) * 255).toString(16).padStart(2, '0');
    return hex + a;
  }

  function clearHost(host) {
    while (host.firstChild) host.removeChild(host.firstChild);
  }

  /* Called from the app loop. Rebuilds only when the UI data or the
     viewport size changes, so typing in a field is never interrupted. */
  U.update = function (editor) {
    const host = ensureLayer();
    if (!host) return;
    const active = editor.viewMode === 'game' || editor.playing;
    if (!active) {
      host.style.display = 'none';
      return;
    }
    host.style.display = 'block';
    const nodes = editor.scene.nodes.filter((n) => n.type === 'ui' && n.ui && n.visible && UW.scene.isActive(editor.scene, n));
    const page = pageSize();
    const key = nodes.map((n) => n.id + ':' + JSON.stringify(n.ui)).join('|') + '|' + page.w + 'x' + page.h + '|' + editor.playing;
    if (key === sig && !dirty) return;
    sig = key;
    dirty = false;
    build(editor, nodes);
  };

  U.clear = function () {
    if (layer) clearHost(layer);
    sig = '';
    dirty = true;
  };

  /* Programmatic helpers used by FSM actions and scripts. */
  U.find = function (editor, ref) {
    const key = String(ref == null ? '' : ref).trim();
    if (!key) return null;
    const node = editor.scene.nodes.find((n) => n.type === 'ui' && (n.id === key || n.name === key));
    return node || null;
  };

  U.getValue = function (editor, ref) {
    const node = U.find(editor, ref);
    if (!node) return '';
    if (node.ui.kind === 'toggle') return node.ui.checked ? 'true' : 'false';
    if (node.ui.kind === 'input') return node.ui.text || '';
    if (node.ui.kind === 'dropdown') return node.ui.text || '';
    if (node.ui.kind === 'button') return 'clicked';
    return String(node.ui.value);
  };

  U.setValue = function (editor, ref, value) {
    const node = U.find(editor, ref);
    if (!node) return false;
    const kind = node.ui.kind;
    if (kind === 'toggle') node.ui.checked = value === true || value === 'true' || value === 1 || value === '1';
    else if (kind === 'input' || kind === 'dropdown') node.ui.text = String(value);
    else if (kind === 'text' || kind === 'panel' || kind === 'button') node.ui.text = String(value);
    else node.ui.value = Number(value);
    if (editor.runtime) {
      editor.runtime.uiValues = editor.runtime.uiValues || {};
      editor.runtime.uiValues[node.name] = U.getValue(editor, ref);
      editor.runtime.uiValues[node.id] = U.getValue(editor, ref);
    }
    dirty = true;
    return true;
  };

  U.click = function (editor, ref) {
    const node = U.find(editor, ref);
    if (!node) return false;
    emit(editor, node);
    dirty = true;
    return true;
  };

  U.setVisible = function (editor, ref, visible) {
    const node = U.find(editor, ref);
    if (!node) return false;
    node.ui.visible = visible !== false;
    dirty = true;
    return true;
  };

  U.open = function (editor, ref) {
    const node = U.find(editor, ref);
    if (!node) return false;
    emit(editor, node);
    return true;
  };

  U.textureURL = textureURL;
})();
