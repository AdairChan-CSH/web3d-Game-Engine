/* ============================================================
   inputmap.js — keyboard + gamepad action mapping
   One shared, rebindable action map used by the runtime, the FSM
   and the settings dialog. Keyboard state comes from the runtime's
   e.code sets; gamepads are polled through the Gamepad API.
   Everything is stored in the browser, so it works on file://.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const I = (UW.input = {});
  const STORE_KEY = 'webforge3d.input.v1';

  /* Standard-mapping gamepad buttons:
     0 A, 1 B, 2 X, 3 Y, 4 LB, 5 RB, 6 LT, 7 RT, 8 Back, 9 Start,
     10 L3, 11 R3, 12 D-pad up, 13 down, 14 left, 15 right, 16 Home */
  const PAD_BUTTONS = [
    { index: 0, label: 'A / Cross' },
    { index: 1, label: 'B / Circle' },
    { index: 2, label: 'X / Square' },
    { index: 3, label: 'Y / Triangle' },
    { index: 4, label: 'LB / L1' },
    { index: 5, label: 'RB / R1' },
    { index: 6, label: 'LT / L2' },
    { index: 7, label: 'RT / R2' },
    { index: 8, label: 'Back / Share' },
    { index: 9, label: 'Start / Options' },
    { index: 10, label: 'L3 (stick)' },
    { index: 11, label: 'R3 (stick)' },
    { index: 12, label: 'D-pad Up' },
    { index: 13, label: 'D-pad Down' },
    { index: 14, label: 'D-pad Left' },
    { index: 15, label: 'D-pad Right' },
  ];
  I.padButtons = PAD_BUTTONS;

  const PAD_AXES = [
    { index: 0, label: 'Left stick X' },
    { index: 1, label: 'Left stick Y' },
    { index: 2, label: 'Right stick X' },
    { index: 3, label: 'Right stick Y' },
  ];
  I.padAxes = PAD_AXES;

  const ACTION_DEFS = [
    { id: 'moveForward', label: 'Move forward', keys: ['KeyW', 'ArrowUp'], pad: [12], axis: { index: 1, sign: -1 } },
    { id: 'moveBack', label: 'Move backward', keys: ['KeyS', 'ArrowDown'], pad: [13], axis: { index: 1, sign: 1 } },
    { id: 'moveLeft', label: 'Move left', keys: ['KeyA', 'ArrowLeft'], pad: [14], axis: { index: 0, sign: -1 } },
    { id: 'moveRight', label: 'Move right', keys: ['KeyD', 'ArrowRight'], pad: [15], axis: { index: 0, sign: 1 } },
    { id: 'jump', label: 'Jump', keys: ['Space'], pad: [0] },
    { id: 'fire', label: 'Fire / primary', keys: ['KeyF'], pad: [2] },
    { id: 'interact', label: 'Interact', keys: ['KeyE'], pad: [3] },
    { id: 'sprint', label: 'Sprint', keys: ['ShiftLeft', 'ShiftRight'], pad: [5, 7] },
    { id: 'crouch', label: 'Crouch', keys: ['ControlLeft', 'KeyC'], pad: [1] },
    { id: 'pause', label: 'Pause', keys: ['Escape', 'KeyP'], pad: [9] },
    { id: 'cameraToggle', label: 'Switch camera', keys: ['KeyV'], pad: [8] },
    { id: 'reload', label: 'Reload / restart', keys: ['KeyR'], pad: [4] },
  ];
  I.actionDefs = ACTION_DEFS;

  const DEFAULT_SETTINGS = { deadzone: 0.18, lookSensitivity: 1, invertY: false, vibration: true, mouseSensitivity: 1 };

  const KEY_LABELS = {
    Space: 'Space', Escape: 'Esc', Enter: 'Enter', Tab: 'Tab', ShiftLeft: 'L Shift', ShiftRight: 'R Shift',
    ControlLeft: 'L Ctrl', ControlRight: 'R Ctrl', AltLeft: 'L Alt', AltRight: 'R Alt',
    ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Backspace: 'Backspace',
    Delete: 'Delete', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']',
    Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\',
  };
  I.keyLabel = function (code) {
    if (!code) return '—';
    if (KEY_LABELS[code]) return KEY_LABELS[code];
    const m = /^Key([A-Z])$/.exec(code);
    if (m) return m[1];
    const d = /^Digit([0-9])$/.exec(code);
    if (d) return d[1];
    const f = /^F([0-9]{1,2})$/.exec(code);
    if (f) return 'F' + f[1];
    return code.replace(/^Numpad/, 'Num ');
  };
  I.padButtonLabel = function (index) {
    const b = PAD_BUTTONS.find((x) => x.index === Number(index));
    return b ? b.label : (index == null ? '—' : 'Btn ' + index);
  };

  function clone(v) { return JSON.parse(JSON.stringify(v)); }

  function defaults() {
    const actions = {};
    for (const a of ACTION_DEFS) {
      actions[a.id] = { keys: a.keys.slice(), pad: a.pad.slice(), axis: a.axis ? Object.assign({}, a.axis) : null };
    }
    return { version: 1, actions, settings: Object.assign({}, DEFAULT_SETTINGS) };
  }

  function sanitize(cfg) {
    const out = defaults();
    if (!cfg || typeof cfg !== 'object') return out;
    if (cfg.actions && typeof cfg.actions === 'object') {
      for (const a of ACTION_DEFS) {
        const src = cfg.actions[a.id];
        if (!src || typeof src !== 'object') continue;
        if (Array.isArray(src.keys)) out.actions[a.id].keys = src.keys.filter((k) => typeof k === 'string').slice(0, 4);
        if (Array.isArray(src.pad)) out.actions[a.id].pad = src.pad.map((n) => Number(n)).filter((n) => n >= 0 && n < 32);
        if (src.axis && Number.isFinite(+src.axis.index)) {
          out.actions[a.id].axis = { index: Math.max(0, Math.min(3, +src.axis.index)), sign: +src.axis.sign < 0 ? -1 : 1 };
        } else out.actions[a.id].axis = null;
      }
    }
    if (cfg.settings && typeof cfg.settings === 'object') {
      const s = cfg.settings;
      out.settings.deadzone = Number.isFinite(+s.deadzone) ? Math.max(0, Math.min(0.9, +s.deadzone)) : 0.18;
      out.settings.lookSensitivity = Number.isFinite(+s.lookSensitivity) ? Math.max(0.1, Math.min(5, +s.lookSensitivity)) : 1;
      out.settings.mouseSensitivity = Number.isFinite(+s.mouseSensitivity) ? Math.max(0.1, Math.min(5, +s.mouseSensitivity)) : 1;
      out.settings.invertY = s.invertY === true;
      out.settings.vibration = s.vibration !== false;
    }
    return out;
  }

  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      return sanitize(raw ? JSON.parse(raw) : null);
    } catch (e) {
      return defaults();
    }
  }

  I.config = load();

  I.get = function () {
    return JSON.parse(JSON.stringify(I.config));
  };
  I.save = function (next) {
    I.config = sanitize(next || I.config);
    try { localStorage.setItem(STORE_KEY, JSON.stringify(I.config)); } catch (e) { /* ignore */ }
    return I.config;
  };
  I.reset = function () {
    I.config = defaults();
    try { localStorage.removeItem(STORE_KEY); } catch (e) { /* ignore */ }
    I._prev.clear();
    return I.get();
  };
  I.actionConfig = (id) => (I.config.actions[id] || null);
  I.settings = () => I.config.settings;
  I.setSettings = function (patch) {
    I.config.settings = Object.assign({}, I.config.settings, patch || {});
    I.save(I.config);
  };

  /* ---------------- gamepad state ---------------- */
  I.padState = function () {
    let pads = [];
    try {
      pads = navigator.getGamepads ? Array.from(navigator.getGamepads()) : [];
    } catch (e) {
      pads = [];
    }
    const pad = pads.find((p) => p && p.connected) || null;
    if (!pad) return { connected: false, name: '', buttons: [], axes: [0, 0, 0, 0] };
    const buttons = [];
    for (let i = 0; i < pad.buttons.length; i++) {
      const b = pad.buttons[i];
      buttons.push(b ? { pressed: !!b.pressed, value: Number(b.value) || 0 } : { pressed: false, value: 0 });
    }
    const axes = [];
    for (let i = 0; i < 4; i++) axes.push(Number(pad.axes[i]) || 0);
    return { connected: true, name: pad.id || 'Gamepad', buttons, axes, raw: pad };
  };

  I.padConnected = function () {
    const s = I.padState();
    return s.connected;
  };

  I._prev = new Map();

  /* Attach an action snapshot to a runtime. Called once per frame before
     the FSM runs, so actions can read the same input as scripts. */
  I.poll = function (runtime) {
    const cfg = I.config;
    const settings = cfg.settings;
    const pad = I.padState();
    const codes = runtime.codesDown || new Set();
    const pressed = runtime.codesPressed || new Set();
    const released = runtime.codesReleased || new Set();
    const mouse = runtime.mouse || { buttons: new Set() };
    const mouseNames = { 'Mouse0': 0, 'Mouse1': 1, 'Mouse2': 2 };

    const prev = I._prev;
    const actions = {};
    for (const def of ACTION_DEFS) {
      const a = cfg.actions[def.id] || def;
      let down = false;
      let edgeDown = false;
      let edgeUp = false;
      let value = 0;

      for (const key of a.keys || []) {
        if (mouseNames[key] != null) {
          if (mouse.buttons && mouse.buttons.has(mouseNames[key])) { down = true; value = 1; }
          continue;
        }
        if (codes.has(key)) { down = true; value = 1; }
        if (pressed.has(key)) edgeDown = true;
        if (released.has(key)) edgeUp = true;
      }
      for (const idx of a.pad || []) {
        const b = pad.buttons[idx];
        if (!b) continue;
        const threshold = Math.max(0.05, settings.deadzone * 0.65);
        if (b.pressed || b.value > threshold) {
          down = true;
          value = Math.max(value, b.pressed ? 1 : Math.min(1, b.value));
        }
      }
      if (a.axis && pad.connected) {
        const raw = pad.axes[a.axis.index] || 0;
        const signed = raw * (a.axis.sign < 0 ? -1 : 1);
        if (signed > settings.deadzone) {
          down = true;
          value = Math.max(value, Math.min(1, (signed - settings.deadzone) / (1 - settings.deadzone)));
        }
      }

      const prevDown = prev.get(def.id) === true;
      const padDown = down && !prevDown;
      const padUp = !down && prevDown;
      prev.set(def.id, down);
      actions[def.id] = {
        down,
        pressed: edgeDown || padDown,
        released: edgeUp || padUp,
        value,
      };
    }

    /* Analog sticks and the mouse position are exposed separately so
       movement code does not have to know about the mapping table. */
    const dead = settings.deadzone;
    const stick = (v) => {
      const a = Math.abs(v);
      if (a <= dead) return 0;
      return (v - Math.sign(v) * dead) / (1 - dead);
    };
    const moveX = clamp1(stick(pad.axes[0] || 0) + (actions.moveRight.value - actions.moveLeft.value));
    let moveY = clamp1(stick(pad.axes[1] || 0) + (actions.moveBack.value - actions.moveForward.value));
    let lookX = clamp1(stick(pad.axes[2] || 0)) * settings.lookSensitivity;
    let lookY = clamp1(stick(pad.axes[3] || 0)) * settings.lookSensitivity;
    if (settings.invertY) { lookY = -lookY; moveY = -moveY; }

    const state = {
      connected: pad.connected,
      name: pad.name,
      actions,
      axes: {
        moveX,
        moveY: -moveY,
        lookX,
        lookY,
        rawLeftX: pad.axes[0] || 0,
        rawLeftY: pad.axes[1] || 0,
        rawRightX: pad.axes[2] || 0,
        rawRightY: pad.axes[3] || 0,
      },
      triggers: {
        left: pad.buttons[6] ? pad.buttons[6].value : 0,
        right: pad.buttons[7] ? pad.buttons[7].value : 0,
      },
      settings,
    };
    return state;
  };

  function clamp1(v) { return v < -1 ? -1 : v > 1 ? 1 : v; }

  I.resetEdges = function () {
    I._prev.clear();
  };

  I.action = function (runtime, name) {
    const state = runtime && runtime.inputState;
    if (!state || !state.actions[name]) return { down: false, pressed: false, released: false, value: 0 };
    return state.actions[name];
  };

  I.vibrate = function (strength, duration) {
    if (!I.config.settings.vibration) return false;
    const pad = I.padState();
    if (!pad.connected || !pad.raw || !pad.raw.vibrationActuator) return false;
    const s = Math.max(0, Math.min(1, Number(strength)));
    const ms = Math.max(10, Math.min(5000, Number(duration) || 180));
    try {
      const res = pad.raw.vibrationActuator.playEffect('dual-rumble', {
        startDelay: 0, duration: ms, weakMagnitude: s, strongMagnitude: Math.min(1, s * 0.8),
      });
      if (res && res.catch) res.catch(() => {});
      return true;
    } catch (e) {
      return false;
    }
  };

  /* ---------------- rebinding helpers ---------------- */
  I.listenKey = function (onKey, onCancel) {
    let done = false;
    const handler = (e) => {
      if (e.key === 'Escape' && !e.code) { cleanup(); if (onCancel) onCancel(); return; }
      if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta') {
        // modifier keys are valid bindings, do not swallow the event
      }
      e.preventDefault();
      e.stopPropagation();
      cleanup();
      onKey(e.code || e.key);
    };
    const cleanup = () => {
      if (done) return;
      done = true;
      window.removeEventListener('keydown', handler, true);
    };
    window.addEventListener('keydown', handler, true);
    return cleanup;
  };

  I.listenPadButton = function (onButton, onCancel) {
    let frame = 0;
    let raf = 0;
    const tick = () => {
      const pad = I.padState();
      if (pad.connected) {
        for (let i = 0; i < pad.buttons.length; i++) {
          if (pad.buttons[i].pressed) {
            cancel();
            onButton(i);
            return;
          }
        }
      }
      if (++frame > 60 * 12) { cancel(); if (onCancel) onCancel(); return; }
      raf = requestAnimationFrame(tick);
    };
    const cancel = () => { if (raf) cancelAnimationFrame(raf); raf = 0; };
    raf = requestAnimationFrame(tick);
    return cancel;
  };

  I.describe = function (name) {
    const a = I.config.actions[name] || (ACTION_DEFS.find((d) => d.id === name));
    if (!a) return '—';
    const keys = (a.keys || []).map(I.keyLabel).join(' / ') || '—';
    const pads = (a.pad || []).map((i) => 'P' + i).join(' / ');
    return pads ? keys + '  ·  ' + pads : keys;
  };

  I.defaults = defaults;
  I.storageKey = STORE_KEY;
})();
