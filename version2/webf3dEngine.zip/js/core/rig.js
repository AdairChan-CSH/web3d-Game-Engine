/* ============================================================
   rig.js — humanoid auto-rigging and procedural animation
   Builds an ordinary empty-node skeleton under a model root, can
   rigid-bind the model's mesh parts to the nearest bone (world
   preserving), and animates the bones with procedural clips.

   Everything here is plain scene data, so a rig is saved with the
   scene and behaves the same on every rendering engine. No skinning
   shader is required: mesh parts are parented to bones, which keeps
   the feature engine independent and works on file://.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const R = (UW.rig = {});

  const CLIP_IDS = ['none', 'idle', 'walk', 'run', 'wave', 'dance', 'jump', 'crouch', 'punch', 'kick', 'swim', 'fly', 'sit', 'custom'];
  R.clipIds = CLIP_IDS;
  R.clips = [
    { id: 'none', label: 'None (manual bones)' },
    { id: 'idle', label: 'Idle breathing' },
    { id: 'walk', label: 'Walk cycle' },
    { id: 'run', label: 'Run cycle' },
    { id: 'wave', label: 'Wave' },
    { id: 'dance', label: 'Dance' },
    { id: 'jump', label: 'Jump / leap' },
    { id: 'crouch', label: 'Crouch / sneak' },
    { id: 'punch', label: 'Punch combo' },
    { id: 'kick', label: 'Kick' },
    { id: 'swim', label: 'Swim' },
    { id: 'fly', label: 'Fly / hover' },
    { id: 'sit', label: 'Sit down' },
    { id: 'custom', label: 'Custom (rigAnim.custom)' },
  ];

  const LABELS = {
    hips: 'Hips',
    spine: 'Spine',
    chest: 'Chest',
    neck: 'Neck',
    head: 'Head',
    shoulderL: 'Shoulder.L',
    shoulderR: 'Shoulder.R',
    upperArmL: 'Upper Arm.L',
    upperArmR: 'Upper Arm.R',
    lowerArmL: 'Lower Arm.L',
    lowerArmR: 'Lower Arm.R',
    handL: 'Hand.L',
    handR: 'Hand.R',
    upperLegL: 'Upper Leg.L',
    upperLegR: 'Upper Leg.R',
    lowerLegL: 'Lower Leg.L',
    lowerLegR: 'Lower Leg.R',
    footL: 'Foot.L',
    footR: 'Foot.R',
  };

  /* Absolute joint positions as fractions of model height; x is the
     fraction of height to the side of the model centre. */
  const TEMPLATE = [
    { role: 'hips', parent: null, x: 0, y: 0.52, z: 0 },
    { role: 'spine', parent: 'hips', x: 0, y: 0.60, z: 0 },
    { role: 'chest', parent: 'spine', x: 0, y: 0.70, z: 0 },
    { role: 'neck', parent: 'chest', x: 0, y: 0.82, z: 0 },
    { role: 'head', parent: 'neck', x: 0, y: 0.89, z: 0 },
    { role: 'shoulderL', parent: 'chest', x: -0.11, y: 0.79, z: 0 },
    { role: 'upperArmL', parent: 'shoulderL', x: -0.19, y: 0.78, z: 0 },
    { role: 'lowerArmL', parent: 'upperArmL', x: -0.22, y: 0.64, z: 0 },
    { role: 'handL', parent: 'lowerArmL', x: -0.24, y: 0.51, z: 0 },
    { role: 'shoulderR', parent: 'chest', x: 0.11, y: 0.79, z: 0 },
    { role: 'upperArmR', parent: 'shoulderR', x: 0.19, y: 0.78, z: 0 },
    { role: 'lowerArmR', parent: 'upperArmR', x: 0.22, y: 0.64, z: 0 },
    { role: 'handR', parent: 'lowerArmR', x: 0.24, y: 0.51, z: 0 },
    { role: 'upperLegL', parent: 'hips', x: -0.09, y: 0.50, z: 0 },
    { role: 'lowerLegL', parent: 'upperLegL', x: -0.10, y: 0.27, z: 0 },
    { role: 'footL', parent: 'lowerLegL', x: -0.10, y: 0.045, z: 0 },
    { role: 'upperLegR', parent: 'hips', x: 0.09, y: 0.50, z: 0 },
    { role: 'lowerLegR', parent: 'upperLegR', x: 0.10, y: 0.27, z: 0 },
    { role: 'footR', parent: 'lowerLegR', x: 0.10, y: 0.045, z: 0 },
  ];

  const ROLE_INDEX = {};
  TEMPLATE.forEach((b, i) => { ROLE_INDEX[b.role] = i; });
  const SIDE_OF = (role) => (role.slice(-1) === 'L' ? 'L' : role.slice(-1) === 'R' ? 'R' : '');

  R.roles = TEMPLATE.map((b) => ({ role: b.role, label: LABELS[b.role], side: SIDE_OF(b.role) }));
  R.roleLabel = (role) => LABELS[role] || role;

  function meshParts(scene, root) {
    const out = [];
    const all = [root, ...UW.scene.descendants(scene, root.id)];
    for (const n of all) {
      if (n.type !== 'mesh' || !n.mesh) continue;
      if (n.bone) continue;
      out.push(n);
    }
    return out;
  }

  function modelBounds(scene, root, world) {
    const parts = meshParts(scene, root);
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (const n of parts) {
      const wm = world.get(n.id);
      if (!wm) continue;
      const b = UW.scene.worldBounds(n, wm);
      for (let a = 0; a < 3; a++) {
        if (b.min[a] < min[a]) min[a] = b.min[a];
        if (b.max[a] > max[a]) max[a] = b.max[a];
      }
    }
    if (!Number.isFinite(min[0])) {
      const wm = world.get(root.id) || M.mat4.identity();
      const b = UW.scene.worldBounds(root, wm);
      return { min: b.min, max: b.max, parts };
    }
    return { min, max, parts };
  }

  /* Remove an existing rig (if any) before building a new one. */
  function clearRig(editor, root) {
    if (root.rig) removeRig(editor, root.id, { silent: true });
  }

  R.build = function (editor, rootId, opts) {
    opts = opts || {};
    const scene = editor.scene;
    const root = UW.scene.find(scene, rootId);
    if (!root) throw new Error('Select an object to rig.');
    if (editor.playing) throw new Error('Exit Play mode before auto-rigging.');
    const parts = meshParts(scene, root);
    if (!parts.length) throw new Error('The selected object has no meshes to rig.');

    clearRig(editor, root);

    const world = UW.scene.worldMatrices(scene);
    const box = modelBounds(scene, root, world);
    let height = opts.height > 0 ? +opts.height : (box.max[1] - box.min[1]);
    if (!Number.isFinite(height) || height <= 0.01) {
      height = Math.max(0.5, M.vec.dist(box.max, box.min));
    }
    const cx = (box.min[0] + box.max[0]) / 2;
    const cz = (box.min[2] + box.max[2]) / 2;
    const invRoot = M.mat4.invert(world.get(root.id) || M.mat4.identity());

    const abs = {};
    const local = {};
    for (const t of TEMPLATE) {
      const wp = [cx + t.x * height, box.min[1] + t.y * height, cz + t.z * height];
      abs[t.role] = wp;
      local[t.role] = M.mat4.point(invRoot, wp);
    }

    const bones = {};
    const created = [];
    for (const t of TEMPLATE) {
      const parentAbs = t.parent ? local[t.parent] : [0, 0, 0];
      const position = [
        M.round(local[t.role][0] - parentAbs[0], 4),
        M.round(local[t.role][1] - parentAbs[1], 4),
        M.round(local[t.role][2] - parentAbs[2], 4),
      ];
      const bone = UW.scene.makeNode({
        name: UW.scene.uniqueName(scene, LABELS[t.role] || t.role),
        type: 'empty',
        parent: t.parent ? bones[t.parent] : root.id,
        transform: { position, rotation: [0, 0, 0], scale: [1, 1, 1] },
      });
      bone.bone = {
        role: t.role,
        rig: root.id,
        side: SIDE_OF(t.role),
        rest: { position: position.slice(), rotation: [0, 0, 0], scale: [1, 1, 1] },
      };
      bones[t.role] = bone.id;
      created.push(bone);
      scene.nodes.push(bone);
    }

    const rig = {
      kind: 'humanoid',
      height: M.round(height, 4),
      bones,
      order: TEMPLATE.map((t) => t.role),
      bindings: [],
      autoBound: false,
      builtAt: Date.now(),
    };
    root.rig = rig;

    const bindMode = opts.bind === 'none' ? 'none' : 'nearest';
    const skipped = [];
    if (bindMode === 'nearest') {
      // Conservative: a single full-body mesh cannot be rigidly bound to one
      // joint without turning the whole character into a puppet on a stick.
      for (const part of parts) {
        const wm = world.get(part.id);
        const wb = wm ? UW.scene.worldBounds(part, wm) : null;
        if (!wb) continue;
        const span = wb.max[1] - wb.min[1];
        if (parts.length === 1 && span > height * 0.55) {
          skipped.push(part.name);
          continue;
        }
        if (span > height * 0.72) {
          skipped.push(part.name);
          continue;
        }
        let best = null;
        let bestDist = Infinity;
        for (const t of TEMPLATE) {
          const d = M.vec.dist(wb.center, abs[t.role]);
          if (d < bestDist) {
            bestDist = d;
            best = t.role;
          }
        }
        if (!best) continue;
        rig.bindings.push({ nodeId: part.id, parent: part.parent || null });
        UW.scene.reparentPreserve(scene, part.id, bones[best]);
      }
      rig.autoBound = rig.bindings.length > 0;
    }

    if (opts.animate !== false) {
      root.rigAnim = {
        enabled: true,
        playing: true,
        clip: 'idle',
        speed: 1,
        custom: {},
      };
    }

    return { root, rig, bones: created, bindings: rig.bindings.length, height: rig.height, skipped };
  };

  R.remove = function (editor, rootId) {
    return removeRig(editor, rootId, {});
  };

  function removeRig(editor, rootId, opts) {
    const scene = editor.scene;
    const root = UW.scene.find(scene, rootId);
    if (!root || !root.rig) return 0;
    const rig = root.rig;
    const boneIds = Object.keys(rig.bones).map((k) => rig.bones[k]);
    const boneSet = new Set(boneIds);

    // Put bound meshes back where they came from (world preserving).
    for (const b of rig.bindings.slice()) {
      const node = UW.scene.find(scene, b.nodeId);
      if (!node) continue;
      const parent = b.parent && UW.scene.find(scene, b.parent) ? b.parent : root.id;
      UW.scene.reparentPreserve(scene, node.id, parent);
    }

    // Anything else still parented to a bone belongs to the root again.
    for (const n of scene.nodes.slice()) {
      if (n.parent && boneSet.has(n.parent)) {
        UW.scene.reparentPreserve(scene, n.id, root.id);
      }
    }

    // Remove bone nodes (and any descendants that are themselves bones).
    const doomed = new Set();
    for (const id of boneIds) {
      const n = UW.scene.find(scene, id);
      if (!n) continue;
      doomed.add(id);
      for (const d of UW.scene.descendants(scene, id)) {
        if (d.bone) doomed.add(d.id);
      }
    }
    scene.nodes = scene.nodes.filter((n) => !doomed.has(n.id));
    for (const n of scene.nodes) if (n.parent && doomed.has(n.parent)) n.parent = null;
    delete root.rig;
    delete root.rigAnim;
    if (!opts.silent) editor.log('info', 'Removed rig from "' + root.name + '" (' + doomed.size + ' bones).');
    return doomed.size;
  }

  /* Reset every bone to its rest pose (used when stopping a clip). */
  R.resetPose = function (scene, root) {
    if (!root || !root.rig) return;
    for (const role of Object.keys(root.rig.bones)) {
      const bone = UW.scene.find(scene, root.rig.bones[role]);
      if (!bone || !bone.bone) continue;
      const rest = bone.bone.rest;
      bone.transform.position = rest.position.slice();
      bone.transform.rotation = rest.rotation.slice();
      bone.transform.scale = rest.scale.slice();
    }
  };

  /* Small helpers used by the clip functions. */
  function makePose(scene, root) {
    const nodes = {};
    for (const role of Object.keys(root.rig.bones)) {
      const bone = UW.scene.find(scene, root.rig.bones[role]);
      if (!bone || !bone.bone) continue;
      nodes[role] = bone;
      const rest = bone.bone.rest;
      bone.transform.position = rest.position.slice();
      bone.transform.rotation = rest.rotation.slice();
      bone.transform.scale = rest.scale.slice();
    }
    return {
      nodes,
      rot(role, x, y, z) {
        const bone = nodes[role];
        if (!bone) return;
        const r = bone.transform.rotation;
        r[0] += x || 0;
        r[1] += y || 0;
        r[2] += z || 0;
      },
      bob(dy) {
        const bone = nodes.hips;
        if (bone) bone.transform.position[1] += dy || 0;
      },
      shift(dx, dz) {
        const bone = nodes.hips;
        if (!bone) return;
        bone.transform.position[0] += dx || 0;
        bone.transform.position[2] += dz || 0;
      },
    };
  }

  const CLIP_FUNCS = {
    idle(t, h, p) {
      const s = Math.sin(t * 1.5);
      p.rot('spine', s * 1.4, 0, 0);
      p.rot('chest', Math.sin(t * 1.5 + 0.5) * 1.8, 0, 0);
      p.rot('head', -Math.sin(t * 1.4 + 0.9) * 2.2, Math.sin(t * 0.55) * 4, 0);
      p.rot('upperArmL', 0, s * 2.5, 2);
      p.rot('upperArmR', 0, s * 2.5, -2);
      p.rot('lowerArmL', 0, s * 1.5, 0);
      p.rot('lowerArmR', 0, s * 1.5, 0);
      p.bob(Math.sin(t * 1.8) * h * 0.004);
    },
    walk(t, h, p) {
      const s = Math.sin(t * 5.2);
      const c = Math.cos(t * 5.2);
      p.rot('upperLegL', -s * 26, 0, 0);
      p.rot('upperLegR', s * 26, 0, 0);
      p.rot('lowerLegL', Math.max(0, -s) * 22, 0, 0);
      p.rot('lowerLegR', Math.max(0, s) * 22, 0, 0);
      p.rot('upperArmL', 0, -s * 17, 3);
      p.rot('upperArmR', 0, -s * 17, -3);
      p.rot('lowerArmL', 0, Math.max(0, s) * 12, 0);
      p.rot('lowerArmR', 0, Math.max(0, -s) * 12, 0);
      p.rot('chest', 4, -s * 4, 0);
      p.rot('head', 0, s * 2, 0);
      p.bob(Math.abs(c) * h * 0.018 - h * 0.009);
      p.shift(0, 0);
    },
    run(t, h, p) {
      const s = Math.sin(t * 8.2);
      const c = Math.cos(t * 8.2);
      p.rot('upperLegL', -s * 40, 0, 0);
      p.rot('upperLegR', s * 40, 0, 0);
      p.rot('lowerLegL', Math.max(0, -s) * 48, 0, 0);
      p.rot('lowerLegR', Math.max(0, s) * 48, 0, 0);
      p.rot('upperArmL', 0, -s * 30, 5);
      p.rot('upperArmR', 0, -s * 30, -5);
      p.rot('lowerArmL', 0, 25 + Math.max(0, s) * 20, 0);
      p.rot('lowerArmR', 0, 25 + Math.max(0, -s) * 20, 0);
      p.rot('spine', 9, 0, 0);
      p.rot('chest', 5, -s * 6, 0);
      p.rot('head', -6, s * 2, 0);
      p.bob(Math.abs(c) * h * 0.032 - h * 0.016);
    },
    wave(t, h, p) {
      const s = Math.sin(t * 6);
      p.rot('upperArmR', 0, -10, 78);
      p.rot('lowerArmR', 0, 0, 30 + s * 24);
      p.rot('handR', 0, 0, s * 10);
      p.rot('head', 0, 9, 4);
      p.rot('chest', 0, -5, 0);
      p.rot('upperArmL', 0, 3, 4);
      p.bob(Math.sin(t * 1.5) * h * 0.003);
    },
    dance(t, h, p) {
      const s = Math.sin(t * 4.4);
      const c = Math.cos(t * 4.4);
      p.rot('hips', 0, s * 14, c * 5);
      p.rot('spine', 0, -s * 8, 0);
      p.rot('chest', 2, s * 10, 0);
      p.rot('head', 0, s * 12, -c * 6);
      p.rot('upperArmL', 0, s * 28, 28 + c * 20);
      p.rot('upperArmR', 0, -s * 28, -28 - c * 20);
      p.rot('lowerArmL', 0, 20, 35);
      p.rot('lowerArmR', 0, -20, -35);
      p.rot('upperLegL', -Math.max(0, s) * 16, 0, 0);
      p.rot('upperLegR', Math.max(0, s) * 16, 0, 0);
      p.bob(Math.abs(c) * h * 0.012);
    },
    jump(t, h, p) {
      // One shot loop: crouch, launch, tuck, land.
      const cycle = (t * 1.1) % 1;
      let crouch = 0;
      let lift = 0;
      let tuck = 0;
      if (cycle < 0.22) {
        crouch = Math.sin((cycle / 0.22) * Math.PI) * 0.55;
      } else if (cycle < 0.62) {
        const k = (cycle - 0.22) / 0.4;
        lift = Math.sin(k * Math.PI) * h * 0.22;
        tuck = Math.sin(k * Math.PI);
      } else if (cycle < 0.82) {
        crouch = Math.sin(((cycle - 0.62) / 0.2) * Math.PI) * 0.4;
      }
      const knee = 34 * crouch + 46 * tuck;
      p.rot('upperLegL', -knee * 0.9, 0, 2);
      p.rot('upperLegR', -knee * 0.9, 0, -2);
      p.rot('lowerLegL', knee, 0, 0);
      p.rot('lowerLegR', knee, 0, 0);
      p.rot('spine', 12 * crouch - 6 * tuck, 0, 0);
      p.rot('chest', 8 * crouch, 0, 0);
      p.rot('head', -10 * crouch + 4 * tuck, 0, 0);
      p.rot('upperArmL', 0, -46 * tuck, 24 + 20 * crouch);
      p.rot('upperArmR', 0, 46 * tuck, -24 - 20 * crouch);
      p.rot('lowerArmL', 0, 18 + 34 * tuck, 0);
      p.rot('lowerArmR', 0, -18 - 34 * tuck, 0);
      p.bob(lift - crouch * h * 0.05);
    },
    crouch(t, h, p) {
      const s = Math.sin(t * 3.4);
      const k = 38;
      p.rot('upperLegL', -k, 0, 3);
      p.rot('upperLegR', -k, 0, -3);
      p.rot('lowerLegL', k + 8, 0, 0);
      p.rot('lowerLegR', k + 8, 0, 0);
      p.rot('footL', -10, 0, 0);
      p.rot('footR', -10, 0, 0);
      p.rot('hips', 6, 0, 0);
      p.rot('spine', 18, s * 3, 0);
      p.rot('chest', 8, -s * 2, 0);
      p.rot('head', -20, s * 8, 0);
      p.rot('upperArmL', 0, -22, 16);
      p.rot('upperArmR', 0, 22, -16);
      p.rot('lowerArmL', 0, 30, 0);
      p.rot('lowerArmR', 0, -30, 0);
      p.bob(-h * 0.19 + Math.sin(t * 3.4) * h * 0.003);
    },
    punch(t, h, p) {
      // Alternating two-punch combo.
      const beat = Math.sin(t * 7.4);
      const right = Math.max(0, beat);
      const left = Math.max(0, -beat);
      p.rot('hips', 0, right * 10 - left * 10, 0);
      p.rot('spine', 3, right * 16 - left * 16, 0);
      p.rot('chest', 4, right * 12 - left * 12, 0);
      p.rot('head', 0, -right * 8 + left * 8, 0);
      p.rot('upperArmR', 0, 28 + right * 58, -18 + right * 14);
      p.rot('lowerArmR', 0, -30 - right * 52, 0);
      p.rot('upperArmL', 0, -28 - left * 58, 18 - left * 14);
      p.rot('lowerArmL', 0, 30 + left * 52, 0);
      p.rot('upperLegL', -6, 0, 4);
      p.rot('upperLegR', 6, 0, -4);
      p.rot('lowerLegL', 8, 0, 0);
      p.rot('lowerLegR', 8, 0, 0);
      p.bob(Math.max(right, left) * h * 0.008);
    },
    kick(t, h, p) {
      const s = Math.sin(t * 5.6);
      const k = Math.max(0, s);
      p.rot('upperLegR', -k * 74, 0, -4);
      p.rot('lowerLegR', k * 18, 0, 0);
      p.rot('footR', -k * 22, 0, 0);
      p.rot('upperLegL', k * 8, 0, 4);
      p.rot('lowerLegL', 6, 0, 0);
      p.rot('hips', -k * 8, k * 8, 0);
      p.rot('spine', -k * 10, -k * 6, 0);
      p.rot('chest', 4, -k * 10, 0);
      p.rot('head', 0, k * 6, 0);
      p.rot('upperArmL', 0, -k * 36, 18);
      p.rot('upperArmR', 0, k * 36, -18);
      p.rot('lowerArmL', 0, 34, 0);
      p.rot('lowerArmR', 0, -34, 0);
      p.bob(Math.sin(t * 5.6) * h * 0.006);
    },
    swim(t, h, p) {
      const s = Math.sin(t * 2.1);
      const c = Math.cos(t * 2.1);
      // Body flat and floating forward.
      p.rot('hips', 74, 0, 0);
      p.rot('spine', 6, s * 8, 0);
      p.rot('chest', 4, -s * 6, 0);
      p.rot('head', -48, s * 14, 0);
      p.rot('upperArmL', 0, -s * 62, 40);
      p.rot('upperArmR', 0, s * 62, -40);
      p.rot('lowerArmL', 0, 20 + Math.max(0, s) * 30, 0);
      p.rot('lowerArmR', 0, -20 - Math.max(0, -s) * 30, 0);
      p.rot('upperLegL', s * 18, 0, 3);
      p.rot('upperLegR', -s * 18, 0, -3);
      p.rot('lowerLegL', Math.max(0, s) * 20, 0, 0);
      p.rot('lowerLegR', Math.max(0, -s) * 20, 0, 0);
      p.bob(Math.sin(t * 2.1) * h * 0.012);
    },
    fly(t, h, p) {
      const s = Math.sin(t * 3.2);
      const c = Math.cos(t * 3.2);
      p.rot('hips', 24, 0, 0);
      p.rot('spine', 8 + s * 2, 0, 0);
      p.rot('chest', 6, s * 4, 0);
      p.rot('head', -26, s * 6, 0);
      p.rot('upperArmL', 0, -14, 62 + c * 10);
      p.rot('upperArmR', 0, 14, -62 - c * 10);
      p.rot('lowerArmL', 0, 12, 22);
      p.rot('lowerArmR', 0, -12, -22);
      p.rot('upperLegL', s * 12, 0, 4);
      p.rot('upperLegR', -s * 12, 0, -4);
      p.rot('lowerLegL', 16 + Math.max(0, s) * 10, 0, 0);
      p.rot('lowerLegR', 16 + Math.max(0, -s) * 10, 0, 0);
      p.bob(Math.sin(t * 1.6) * h * 0.03 + h * 0.04);
    },
    sit(t, h, p) {
      const s = Math.sin(t * 1.2);
      const k = 84;
      p.rot('upperLegL', -k, 0, 5);
      p.rot('upperLegR', -k, 0, -5);
      p.rot('lowerLegL', k, 0, 0);
      p.rot('lowerLegR', k, 0, 0);
      p.rot('footL', 8, 0, 0);
      p.rot('footR', 8, 0, 0);
      p.rot('hips', -6, 0, 0);
      p.rot('spine', -4 + s * 1.4, 0, 0);
      p.rot('chest', s * 2, 0, 0);
      p.rot('head', -s * 2, s * 5, 0);
      p.rot('upperArmL', 0, 10, 32 + s * 4);
      p.rot('upperArmR', 0, -10, -32 - s * 4);
      p.rot('lowerArmL', 0, 26, 0);
      p.rot('lowerArmR', 0, -26, 0);
      p.bob(-h * 0.34);
    },
  };

  /* Apply the node's rigAnim clip to its bones. Called every frame by
     runtime.js, so it never touches renderer state. */
  R.animate = function (scene, root, time) {
    if (!root || !root.rig || !root.rigAnim) return;
    const anim = root.rigAnim;
    if (anim.enabled === false || anim.playing === false) return;
    if (anim.clip === 'none' && !anim.customTouched) return;
    const p = makePose(scene, root);
    const speed = Number.isFinite(+anim.speed) ? +anim.speed : 1;
    if (anim.clip !== 'none') {
      const t = time * speed;
      const fn = CLIP_FUNCS[anim.clip];
      if (fn) fn(t, root.rig.height || 1, p);
      if (anim.clip === 'custom' && anim.custom && typeof anim.custom === 'object') {
        for (const role of Object.keys(anim.custom)) {
          const v = anim.custom[role];
          if (!p.nodes[role] || !v) continue;
          if (Array.isArray(v)) p.rot(role, +v[0] || 0, +v[1] || 0, +v[2] || 0);
          else p.rot(role, +v.x || 0, +v.y || 0, +v.z || 0);
        }
      }
    }
  };

  /* Set one bone rotation immediately (degrees, optional relative). */
  R.setBoneRotation = function (scene, root, role, x, y, z, relative) {
    if (!root || !root.rig || !root.rig.bones[role]) return false;
    const bone = UW.scene.find(scene, root.rig.bones[role]);
    if (!bone) return false;
    if (relative) {
      bone.transform.rotation[0] += x || 0;
      bone.transform.rotation[1] += y || 0;
      bone.transform.rotation[2] += z || 0;
    } else {
      bone.transform.rotation = [x || 0, y || 0, z || 0];
    }
    return true;
  };

  R.worldBone = function (scene, root, role) {
    if (!root || !root.rig || !root.rig.bones[role]) return null;
    const bone = UW.scene.find(scene, root.rig.bones[role]);
    if (!bone) return null;
    const wm = UW.scene.worldMatrices(scene).get(bone.id);
    return wm ? [wm[12], wm[13], wm[14]] : null;
  };

  R.heightOf = function (editor, root) {
    if (!root) return 0;
    const world = UW.scene.worldMatrices(editor.scene);
    const box = modelBounds(editor.scene, root, world);
    return M.round(box.max[1] - box.min[1], 3);
  };
})();
