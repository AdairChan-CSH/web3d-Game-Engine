/* ============================================================
   video.js — Video Player GameObject

   A Video Player is an ordinary scene object (node.type === "video")
   drawn as a DOM <video> overlay in the Game view. It is engine
   independent: Three.js, Babylon.js, Native Canvas and plugins all
   share the same component, FSM actions and script API. Clips can be
   screen-space (anchored to the viewport) or world-space (projected
   from the GameObject transform, like a billboard).
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const V = (UW.Video = {});
  const M = UW.math;
  const VEC = M && M.vec;

  let layer = null;
  const entries = new Map(); // node id -> { box, video, badge, src, appliedTime }

  function ensureLayer() {
    if (layer && document.body.contains(layer)) return layer;
    const viewport = document.getElementById('viewport');
    if (!viewport) return null;
    layer = document.getElementById('video-layer');
    if (!layer) {
      layer = document.createElement('div');
      layer.id = 'video-layer';
      layer.className = 'video-layer';
      layer.setAttribute('aria-hidden', 'true');
      const gizmo = document.getElementById('gizmo');
      if (gizmo && gizmo.parentNode === viewport) viewport.insertBefore(layer, gizmo);
      else viewport.appendChild(layer);
    }
    return layer;
  }

  function pageSize() {
    const viewport = document.getElementById('viewport');
    const r = viewport ? viewport.getBoundingClientRect() : { width: 1280, height: 720 };
    return { w: Math.max(1, r.width), h: Math.max(1, r.height) };
  }

  function num(value, fallback, min, max) {
    const x = Number(value);
    return Number.isFinite(x) ? Math.max(min, Math.min(max, x)) : fallback;
  }

  function placeScreen(cfg, box, page) {
    const scale = Math.max(0.7, Math.min(1.8, Math.min(page.w / 1280, page.h / 720)));
    const w = num(cfg.w, 480, 32, 4000) * scale;
    const h = num(cfg.h, 270, 32, 4000) * scale;
    const anchor = cfg.anchor || 'center';
    let x = num(cfg.x, 0, -4000, 4000) * scale;
    let y = num(cfg.y, 0, -4000, 4000) * scale;
    if (anchor.indexOf('Right') >= 0) x = page.w - w - x;
    else if (anchor.indexOf('Center') >= 0 || anchor === 'center') x = (page.w - w) / 2 + x;
    if (anchor.indexOf('bottom') === 0) y = page.h - h - y;
    else if (anchor.indexOf('middle') === 0 || anchor === 'center') y = (page.h - h) / 2 + y;
    box.style.left = Math.round(x) + 'px';
    box.style.top = Math.round(y) + 'px';
    box.style.width = Math.round(w) + 'px';
    box.style.height = Math.round(h) + 'px';
  }

  function project(vp, p, w, h) {
    const x = vp[0] * p[0] + vp[4] * p[1] + vp[8] * p[2] + vp[12];
    const y = vp[1] * p[0] + vp[5] * p[1] + vp[9] * p[2] + vp[13];
    const cw = vp[3] * p[0] + vp[7] * p[1] + vp[11] * p[2] + vp[15];
    if (!(cw > 0.0001)) return null;
    return { x: (x / cw * 0.5 + 0.5) * w, y: (1 - (y / cw * 0.5 + 0.5)) * h };
  }

  function placeWorld(editor, node, cfg, box, page) {
    const rig = UW.app && UW.app.cameraRig;
    const vp = rig && rig.vp;
    if (!vp || !VEC || !M.mat4) return placeScreen(cfg, box, page);
    const wm = editor.world().get(node.id) || M.mat4.identity();
    const p = [wm[12], wm[13], wm[14]];
    const center = project(vp, p, page.w, page.h);
    if (!center) { box.style.display = 'none'; return; }
    const fwd = rig.forward || VEC.norm(VEC.sub(rig.target || [0, 0, 0], rig.eye || [0, 0, 0]));
    const right = VEC.norm(VEC.cross(fwd, rig.up || [0, 1, 0]));
    const up = VEC.norm(VEC.cross(right, fwd));
    const px = project(vp, VEC.add(p, VEC.scale(right, num(cfg.worldWidth, 2, 0.05, 1000) / 2)), page.w, page.h);
    const py = project(vp, VEC.add(p, VEC.scale(up, num(cfg.worldHeight, 1.125, 0.05, 1000) / 2)), page.w, page.h);
    const w = px ? Math.abs(px.x - center.x) * 2 : 320;
    const h = py ? Math.abs(py.y - center.y) * 2 : 180;
    box.style.left = Math.round(center.x - w / 2) + 'px';
    box.style.top = Math.round(center.y - h / 2) + 'px';
    box.style.width = Math.round(Math.max(8, w)) + 'px';
    box.style.height = Math.round(Math.max(8, h)) + 'px';
  }

  function createEntry(node) {
    const box = document.createElement('div');
    box.className = 'video-player';
    box.dataset.videoId = node.id;
    const video = document.createElement('video');
    video.className = 'video-element';
    video.setAttribute('playsinline', '');
    video.preload = 'auto';
    box.appendChild(video);
    const badge = document.createElement('span');
    badge.className = 'video-badge';
    box.appendChild(badge);
    const ent = { box, video, badge, src: null, appliedTime: -1 };
    video.addEventListener('timeupdate', () => {
      const ed = UW.app && UW.app.editor;
      const current = ed && ed.scene.nodes.find((n) => n.id === node.id);
      if (current && current.video) {
        current.video.time = video.currentTime;
        ent.appliedTime = video.currentTime;
      }
    });
    video.addEventListener('ended', () => {
      const ed = UW.app && UW.app.editor;
      const current = ed && ed.scene.nodes.find((n) => n.id === node.id);
      if (!current || !current.video) return;
      current.video.playing = false;
      if (current.video.event && ed.runtime) ed.runtime.emitEvent(current.video.event);
      if (ed.emit) ed.emit('values');
    });
    return ent;
  }

  V.update = function (editor) {
    const host = ensureLayer();
    if (!host) return;
    const active = editor.viewMode === 'game' || !!editor.playing;
    if (!active) {
      host.style.display = 'none';
      for (const ent of entries.values()) {
        try { if (!ent.video.paused) ent.video.pause(); } catch (e) { /* ignore */ }
      }
      return;
    }
    host.style.display = 'block';

    const nodes = editor.scene.nodes.filter((n) =>
      n.type === 'video' && n.video && n.visible !== false &&
      (!UW.scene || UW.scene.isActive(editor.scene, n))
    );
    const live = new Set(nodes.map((n) => n.id));
    for (const [id, ent] of entries) {
      if (!live.has(id)) {
        try { ent.video.pause(); } catch (e) { /* ignore */ }
        if (ent.box.parentNode) ent.box.parentNode.removeChild(ent.box);
        entries.delete(id);
      }
    }

    const page = pageSize();
    for (const node of nodes) {
      const cfg = node.video;
      let ent = entries.get(node.id);
      if (!ent) {
        ent = createEntry(node);
        entries.set(node.id, ent);
        host.appendChild(ent.box);
      }
      ent.badge.textContent = node.name || 'Video Player';
      ent.box.style.display = cfg.visible === false ? 'none' : 'block';
      ent.box.style.pointerEvents = cfg.controls ? 'auto' : 'none';

      if (ent.src !== cfg.src) {
        ent.src = cfg.src;
        ent.appliedTime = -1;
        if (cfg.src) {
          ent.video.src = cfg.src;
          try { ent.video.load(); } catch (e) { /* ignore */ }
        } else {
          ent.video.removeAttribute('src');
          try { ent.video.load(); } catch (e) { /* ignore */ }
        }
      }
      ent.video.loop = !!cfg.loop;
      ent.video.muted = !!cfg.muted;
      const vol = num(cfg.volume, 1, 0, 1);
      if (Math.abs(ent.video.volume - vol) > 0.001) ent.video.volume = vol;
      const speed = num(cfg.speed, 1, 0.25, 4);
      if (Math.abs(ent.video.playbackRate - speed) > 0.001) {
        try { ent.video.playbackRate = speed; } catch (e) { /* ignore */ }
      }
      const fit = ['contain', 'cover', 'fill', 'none'].indexOf(cfg.fit) >= 0 ? cfg.fit : 'contain';
      if (ent.video.style.objectFit !== fit) ent.video.style.objectFit = fit;
      if (!!ent.video.controls !== !!cfg.controls) ent.video.controls = !!cfg.controls;

      if (Math.abs(num(cfg.time, 0, 0, 100000) - ent.appliedTime) > 0.05 && ent.video.readyState > 0) {
        try {
          ent.video.currentTime = num(cfg.time, 0, 0, 100000);
          ent.appliedTime = cfg.time;
        } catch (e) { /* seek may fail until metadata loads */ }
      }

      if (cfg.mode === 'world') placeWorld(editor, node, cfg, ent.box, page);
      else placeScreen(cfg, ent.box, page);

      const shouldPlay = !!cfg.playing && !!cfg.src;
      if (shouldPlay && ent.video.paused) {
        const res = ent.video.play();
        if (res && res.catch) res.catch(() => {});
      } else if (!shouldPlay && !ent.video.paused) {
        ent.video.pause();
      }
    }
  };

  V.clear = function () {
    if (layer) while (layer.firstChild) layer.removeChild(layer.firstChild);
    entries.clear();
  };

  function record(editor, ref) {
    const key = String(ref == null ? '' : ref).trim();
    if (!key || !editor || !editor.scene) return null;
    return editor.scene.nodes.find((n) => n.type === 'video' && n.video && (n.id === key || n.name === key)) || null;
  }
  V.find = record;

  V.play = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return false;
    node.video.playing = true;
    return true;
  };
  V.pause = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return false;
    node.video.playing = false;
    return true;
  };
  V.stop = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return false;
    node.video.playing = false;
    node.video.time = 0;
    const ent = entries.get(node.id);
    if (ent) {
      try { ent.video.pause(); ent.video.currentTime = 0; } catch (e) { /* ignore */ }
      ent.appliedTime = 0;
    }
    return true;
  };
  V.seek = function (editor, ref, seconds) {
    const node = record(editor, ref);
    if (!node) return false;
    node.video.time = num(seconds, 0, 0, 100000);
    const ent = entries.get(node.id);
    if (ent) ent.appliedTime = -1;
    return true;
  };
  V.volume = function (editor, ref, value, mute) {
    const node = record(editor, ref);
    if (!node) return false;
    node.video.volume = num(value, 1, 0, 1);
    if (mute !== undefined) node.video.muted = !!mute;
    return true;
  };
  V.isPlaying = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return false;
    const ent = entries.get(node.id);
    return !!node.video.playing && !!node.video.src && (!ent || !ent.video.paused);
  };
  V.time = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return 0;
    const ent = entries.get(node.id);
    return ent ? ent.video.currentTime || 0 : num(node.video.time, 0, 0, 100000);
  };
  V.duration = function (editor, ref) {
    const node = record(editor, ref);
    if (!node) return 0;
    const ent = entries.get(node.id);
    return ent && Number.isFinite(ent.video.duration) ? ent.video.duration : 0;
  };
})();
