/* ============================================================
   network.js — server-free multiplayer for WebForge 3D
   Three transports, all optional:
     • local   — BroadcastChannel + localStorage events between tabs
                 of the same browser (works best from http(s)://)
     • webrtc  — manual copy/paste offer/answer, no signalling server
     • ws      — any user-supplied WebSocket relay (optional)

   A "Network Object" is a normal scene node with `node.network`.
   Its owner streams transform / active / colour snapshots; remote
   peers interpolate into the shared scene model, so every renderer
   shows the same result. Spawn and despawn replicate whole subtrees.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const N = (UW.Net = {});

  let counter = 0;
  const rand = () => Math.random().toString(36).slice(2, 10);
  N.newPeerId = () => 'peer_' + rand() + (counter++).toString(36);
  N.newNetId = () => 'net_' + Date.now().toString(36) + '_' + (counter++).toString(36) + rand().slice(0, 4);

  function encodeSignal(obj) {
    try {
      return btoa(unescape(encodeURIComponent(JSON.stringify(obj))));
    } catch (e) {
      return JSON.stringify(obj);
    }
  }
  function decodeSignal(text) {
    const raw = String(text || '').trim();
    if (!raw) throw new Error('Paste the connection code first.');
    try {
      return JSON.parse(raw.charAt(0) === '{' ? raw : decodeURIComponent(escape(atob(raw))));
    } catch (e) {
      throw new Error('That connection code is not valid.');
    }
  }

  function angleLerp(a, b, t) {
    let d = ((b - a + 540) % 360) - 180;
    return a + d * t;
  }

  class NetManager {
    constructor(runtime) {
      this.runtime = runtime;
      this.editor = runtime.editor;
      this.connected = false;
      this.transport = 'local';
      this.room = 'My Game';
      this.url = '';
      this.peerId = N.newPeerId();
      this.name = 'Player';
      this.peers = new Map();
      this.targets = new Map();
      this.map = new Map();
      this.statusText = 'offline';
      this.connectedAt = 0;
      this._bc = null;
      this._ws = null;
      this._pc = null;
      this._dc = null;
      this._pm = false;
      this._onMessage = null;
      this._ls = false;
      this._lsPrefix = '';
      this._onStorage = null;
      this._seen = new Map();
      this._sendAcc = 0;
      this._pingAcc = 0;
      this._indexAcc = 0;
      this._sendRate = 0.1;
      this._msgSeq = 0;
      this.lastEvent = null;
      this._closed = false;
    }

    /* ---------------- status ---------------- */
    status() {
      return {
        connected: this.connected,
        transport: this.transport,
        room: this.room,
        peerId: this.peerId,
        name: this.name,
        peers: Array.from(this.peers.values()).map((p) => ({ id: p.id, name: p.name })),
        text: this.statusText,
      };
    }

    _emitStatus() {
      try { this.editor.emit('network', this.status()); } catch (e) { /* ignore */ }
    }

    _setConnected(on, text) {
      const was = this.connected;
      this.connected = !!on;
      this.statusText = text || (on ? 'online' : 'offline');
      if (on && !was) this.connectedAt = Date.now();
      if (!on) this.connectedAt = 0;
      this._emitStatus();
    }

    /* ---------------- public lifecycle ---------------- */
    start() {
      this.index();
      const cfg = this.editor.scene.network || {};
      this.transport = cfg.transport || 'local';
      this.room = cfg.room || 'My Game';
      this.url = cfg.url || '';
      this.name = cfg.playerName || 'Player';
      if (cfg.autoConnect === true) {
        this.connect(cfg);
      } else if (this.networkedNodes().length && cfg.transport !== 'webrtc') {
        this.editor.log('info', '[Net] ' + this.networkedNodes().length + ' network object(s) ready. Open Window → Multiplayer to connect.');
      }
    }

    stop() {
      this.disconnect(true);
      this.targets.clear();
      this._closed = true;
    }

    connect(config) {
      config = config || {};
      this.disconnect(true);
      this._closed = false;
      this.index();
      this.transport = config.transport || this.transport || 'local';
      this.room = String(config.room || this.room || 'My Game').trim().slice(0, 64) || 'My Game';
      this.url = String(config.url || this.url || '').trim();
      this.name = String(config.playerName || this.name || 'Player').slice(0, 32);
      if (config.peerId) this.peerId = config.peerId;
      this.peers.clear();
      this.targets.clear();
      this._seen.clear();
      this.statusText = 'connecting';

      if (this.transport === 'local') this._connectLocal();
      else if (this.transport === 'ws') this._connectWebSocket();
      else if (this.transport === 'postmessage') this._connectPostMessage();
      else if (this.transport === 'webrtc') {
        this.connected = false;
        this.statusText = 'waiting for WebRTC offer / answer';
        this._emitStatus();
        this.editor.log('info', '[Net] WebRTC uses manual copy/paste offers. Use Window → Multiplayer.');
      } else {
        this._connectLocal();
      }
      return this;
    }

    disconnect(quiet) {
      if (this._pm) {
        try { this._send({ t: 'bye' }, true); } catch (e) { /* ignore */ }
      }
      if (this._bc) {
        try { this._send({ t: 'bye' }, true); } catch (e) { /* ignore */ }
        try { this._bc.close(); } catch (e) { /* ignore */ }
        this._bc = null;
      }
      if (this._ws) {
        try { this._ws.close(); } catch (e) { /* ignore */ }
        this._ws = null;
      }
      if (this._dc) {
        try { this._dc.close(); } catch (e) { /* ignore */ }
        this._dc = null;
      }
      if (this._pc) {
        try { this._pc.close(); } catch (e) { /* ignore */ }
        this._pc = null;
      }
      if (this._onStorage) {
        window.removeEventListener('storage', this._onStorage);
        this._onStorage = null;
      }
      if (this._onMessage) {
        window.removeEventListener('message', this._onMessage);
        this._onMessage = null;
      }
      this._pm = false;
      this._ls = false;
      this._bc = null;
      this.peers.clear();
      this.targets.clear();
      const was = this.connected;
      this.connected = false;
      this.statusText = 'offline';
      if (!quiet) {
        this._emitStatus();
        if (was) this.editor.log('info', '[Net] Disconnected from "' + this.room + '".');
      }
    }

    /* ---------------- local tabs ---------------- */
    _connectLocal() {
      this.transport = 'local';
      this._lsPrefix = 'wf3d.net.' + this.room + '.';
      try {
        if (typeof BroadcastChannel !== 'undefined') {
          this._bc = new BroadcastChannel('wf3d.net.' + this.room);
          this._bc.onmessage = (ev) => this._receive(ev.data);
        }
      } catch (e) {
        this._bc = null;
      }
      try {
        if (!this._bc && typeof localStorage !== 'undefined') {
          this._ls = true;
          this._onStorage = (ev) => {
            if (!ev || !ev.key || ev.key.indexOf(this._lsPrefix) !== 0) return;
            try { this._receive(JSON.parse(ev.newValue)); } catch (e) { /* ignore */ }
          };
          window.addEventListener('storage', this._onStorage);
        }
      } catch (e) {
        this._ls = false;
      }
      if (!this._bc && !this._ls) {
        this._setConnected(false, 'no local transport available');
        this.editor.log('warn', '[Net] BroadcastChannel and localStorage are unavailable.');
        return;
      }
      this._setConnected(true, 'local tab transport');
      this.editor.log('info', '[Net] Connected to room "' + this.room + '" (same-browser tabs).');
      this._announce();
      setTimeout(() => this._claimDefaults(), 40);
    }

    _lsWrite(msg) {
      if (!this._ls) return;
      try {
        const key = this._lsPrefix + this.peerId + '.' + Date.now() + '.' + (++this._msgSeq);
        localStorage.setItem(key, JSON.stringify(msg));
        setTimeout(() => { try { localStorage.removeItem(key); } catch (e) { /* ignore */ } }, 15000);
      } catch (e) {
        this._ls = false;
      }
    }

    /* ---------------- window / iframe bridge ---------------- */
    _connectPostMessage() {
      this.transport = 'postmessage';
      this._pm = true;
      this._onMessage = (ev) => {
        const data = ev && ev.data;
        if (!data || data.__wf3d !== 1 || !data.msg || typeof data.msg !== 'object') return;
        if (data.room && data.room !== this.room) return;
        this._receive(data.msg);
        if (ev.source && ev.source !== window) this._pmRelay(data.msg, ev.source);
      };
      window.addEventListener('message', this._onMessage);
      this._setConnected(true, 'window / iframe bridge');
      this.editor.log('info', '[Net] Connected to room "' + this.room + '" over postMessage (parent window + iframes).');
      this._announce();
      setTimeout(() => this._claimDefaults(), 40);
    }

    _pmPost(msg, skipSource) {
      if (!this._pm) return;
      const payload = { __wf3d: 1, room: this.room, msg };
      const send = (win) => {
        if (!win || win === window) return;
        try { win.postMessage(payload, '*'); } catch (e) { /* ignore */ }
      };
      send(window.parent);
      let frames = [];
      try { frames = Array.prototype.slice.call(window.frames || []); } catch (e) { frames = []; }
      for (const frame of frames) {
        let win = null;
        try { win = frame; } catch (e) { win = null; }
        if (!win || win === skipSource) continue;
        send(win);
      }
    }

    _pmRelay(msg, source) {
      this._pmPost(msg, source);
    }

    /* ---------------- WebSocket relay ---------------- */
    _connectWebSocket() {
      this.transport = 'ws';
      const url = this.url;
      if (!url) {
        this._setConnected(false, 'missing WebSocket URL');
        this.editor.log('warn', '[Net] Enter a ws:// or wss:// relay URL first.');
        return;
      }
      if (typeof WebSocket === 'undefined') {
        this._setConnected(false, 'WebSocket unavailable');
        return;
      }
      let ws;
      try { ws = new WebSocket(url); } catch (e) {
        this._setConnected(false, 'WebSocket failed');
        this.editor.log('error', '[Net] ' + (e && e.message ? e.message : e));
        return;
      }
      this._ws = ws;
      ws.onopen = () => {
        this._setConnected(true, 'WebSocket relay');
        this.editor.log('info', '[Net] Connected to relay ' + url);
        this._announce();
        this._claimDefaults();
      };
      ws.onmessage = (ev) => {
        try { this._receive(JSON.parse(ev.data)); } catch (e) { /* ignore */ }
      };
      ws.onerror = () => {
        this.editor.log('warn', '[Net] WebSocket error — the relay may be unavailable or the URL may be wrong.');
      };
      ws.onclose = () => {
        if (this._ws === ws) {
          this._ws = null;
          this._setConnected(false, 'relay closed');
        }
      };
    }

    /* ---------------- WebRTC manual signalling ---------------- */
    async createOffer(extra) {
      extra = extra || {};
      this.disconnect(true);
      this._closed = false;
      this.transport = 'webrtc';
      if (extra.room) this.room = String(extra.room).trim().slice(0, 64) || this.room;
      if (extra.name) this.name = String(extra.name).slice(0, 32);
      this.statusText = 'creating offer';
      this._emitStatus();
      await this._newPeerConnection();
      this._dc = this._pc.createDataChannel('webforge3d', { ordered: true });
      this._bindChannel(this._dc);
      const offer = await this._pc.createOffer();
      await this._pc.setLocalDescription(offer);
      await this._waitForIce();
      return encodeSignal({ type: 'offer', sdp: this._pc.localDescription, room: this.room, name: this.name });
    }

    async acceptAnswer(code) {
      if (!this._pc) throw new Error('Create an offer first.');
      const data = decodeSignal(code);
      if (data.type && data.type !== 'answer') throw new Error('That is not an answer code.');
      await this._pc.setRemoteDescription(data.sdp);
      this.statusText = 'answer applied — connecting';
      this._emitStatus();
      return true;
    }

    async joinWithOffer(code) {
      this.disconnect(true);
      this._closed = false;
      this.transport = 'webrtc';
      const data = decodeSignal(code);
      if (data.room) this.room = data.room;
      if (data.name) this.peers.set(data.from || 'host', { id: data.from || 'host', name: data.name, last: Date.now() });
      this.statusText = 'creating answer';
      this._emitStatus();
      await this._newPeerConnection();
      this._pc.ondatachannel = (ev) => this._bindChannel(ev.channel);
      await this._pc.setRemoteDescription(data.sdp);
      const answer = await this._pc.createAnswer();
      await this._pc.setLocalDescription(answer);
      await this._waitForIce();
      return encodeSignal({ type: 'answer', sdp: this._pc.localDescription, room: this.room, name: this.name });
    }

    async _newPeerConnection() {
      if (typeof RTCPeerConnection === 'undefined') {
        throw new Error('This browser does not support WebRTC.');
      }
      this._pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
      });
      this._pc.onconnectionstatechange = () => {
        const st = this._pc ? this._pc.connectionState : 'closed';
        if (st === 'failed' || st === 'disconnected' || st === 'closed') {
          this._setConnected(false, 'WebRTC ' + st);
        }
      };
      this._pc.oniceconnectionstatechange = () => {
        if (!this._pc) return;
        if (this._pc.iceConnectionState === 'connected' || this._pc.iceConnectionState === 'completed') {
          if (!this.connected) this._setConnected(true, 'WebRTC peer connection');
        }
      };
    }

    _waitForIce() {
      const pc = this._pc;
      if (!pc) return Promise.resolve();
      if (pc.iceGatheringState === 'complete') return Promise.resolve();
      return new Promise((resolve) => {
        const done = () => {
          pc.removeEventListener('icegatheringstatechange', check);
          pc.removeEventListener('icecandidate', cand);
          resolve();
        };
        const check = () => {
          if (pc.iceGatheringState === 'complete') done();
        };
        const cand = (ev) => {
          if (!ev.candidate) done();
        };
        pc.addEventListener('icegatheringstatechange', check);
        pc.addEventListener('icecandidate', cand);
        setTimeout(done, 9000);
      });
    }

    _bindChannel(dc) {
      this._dc = dc;
      dc.onopen = () => {
        this._setConnected(true, 'WebRTC data channel');
        this.editor.log('info', '[Net] WebRTC data channel open.');
        this._announce();
        this._claimDefaults();
      };
      dc.onmessage = (ev) => {
        try { this._receive(JSON.parse(ev.data)); } catch (e) { /* ignore */ }
      };
      dc.onclose = () => {
        if (this._dc === dc) {
          this._dc = null;
          this._setConnected(false, 'data channel closed');
        }
      };
    }

    /* ---------------- send / receive ---------------- */
    _send(msg, force) {
      if (!this.connected && !force) return;
      if (!msg || msg.t === 'bye' && !this.connected) { /* still allow bye */ }
      msg.id = this.peerId + ':' + Date.now().toString(36) + ':' + (++this._msgSeq);
      msg.room = this.room;
      msg.from = this.peerId;
      msg.name = this.name;
      if (this._bc) {
        try { this._bc.postMessage(msg); } catch (e) { /* ignore */ }
      }
      if (this._ls) this._lsWrite(msg);
      if (this._dc && this._dc.readyState === 'open') {
        try { this._dc.send(JSON.stringify(msg)); } catch (e) { /* ignore */ }
      }
      if (this._ws && this._ws.readyState === 1) {
        try { this._ws.send(JSON.stringify(msg)); } catch (e) { /* ignore */ }
      }
      if (this._pm) this._pmPost(msg);
    }

    _receive(msg) {
      if (!msg || typeof msg !== 'object') return;
      if (msg.room && msg.room !== this.room) return;
      if (msg.from && msg.from === this.peerId) return;
      if (msg.id) {
        if (this._seen.has(msg.id)) return;
        this._seen.set(msg.id, 1);
        if (this._seen.size > 600) {
          const first = this._seen.keys().next().value;
          this._seen.delete(first);
        }
      }
      const peerKey = msg.from || 'unknown';
      const existing = this.peers.get(peerKey);
      this.peers.set(peerKey, { id: peerKey, name: msg.name || (existing && existing.name) || 'Peer', last: Date.now() });
      if (!existing) this._emitStatus();

      switch (msg.t) {
        case 'hello':
          this._send({ t: 'peer' });
          break;
        case 'ping':
          this._send({ t: 'peer' });
          break;
        case 'peer':
          break;
        case 'bye':
          this.peers.delete(peerKey);
          this._releaseOwnedBy(peerKey);
          this._emitStatus();
          break;
        case 'claim':
          this._applyClaim(msg.netId, msg.owner, peerKey);
          break;
        case 'state':
          this._applyState(msg.objects || []);
          break;
        case 'spawn':
          this._applySpawn(msg);
          break;
        case 'despawn':
          this._destroyLocal(msg.netId);
          break;
        case 'event':
          this._applyEvent(msg);
          break;
        case 'syncRequest':
          this._sendSnapshot(true);
          break;
        default:
          break;
      }
    }

    _announce() {
      this._send({ t: 'hello' });
    }

    _applyClaim(netId, owner, from) {
      const node = this.map.get(netId);
      if (!node || !node.network) return;
      const prev = node.network.owner;
      if (prev && prev !== owner && prev === this.peerId && owner !== this.peerId) {
        this.editor.log('info', '[Net] "' + node.name + '" was claimed by another peer.');
      }
      node.network.owner = owner || '';
      if (owner !== this.peerId) this.targets.delete(netId);
      if (from && owner === this.peerId) this.targets.delete(netId);
      this.editor.emit('values');
    }

    _applyState(objects) {
      for (const o of objects) {
        if (!o || !o.id) continue;
        const node = this.map.get(o.id);
        if (!node || !node.network) continue;
        if (node.network.owner === this.peerId) continue;
        this.targets.set(o.id, {
          position: Array.isArray(o.p) ? o.p.slice(0, 3) : null,
          rotation: Array.isArray(o.r) ? o.r.slice(0, 3) : null,
          scale: Array.isArray(o.s) ? o.s.slice(0, 3) : null,
          active: typeof o.a === 'boolean' ? o.a : null,
          color: typeof o.c === 'string' ? o.c : null,
          visible: typeof o.v === 'boolean' ? o.v : null,
          t: Date.now(),
        });
        if (o.a != null && node.network.syncActive) {
          node.active = o.a;
          this.runtime.refreshActive();
        }
        if (o.v != null && node.network.syncActive) node.visible = o.v;
        if (o.c && node.mesh && node.network.syncColor) node.mesh.color = o.c;
      }
    }

    _applySpawn(msg) {
      if (!msg.nodes || !msg.nodes.length) return;
      if (msg.netId && this.map.has(msg.netId)) {
        // already here — just accept a state update
        return;
      }
      const scene = this.editor.scene;
      if (Array.isArray(msg.models) && msg.models.length) {
        if (!Array.isArray(scene.models)) scene.models = [];
        let added = false;
        for (const rec of msg.models) {
          if (!rec || !rec.id || scene.models.some((m) => m && m.id === rec.id)) continue;
          scene.models.push(JSON.parse(JSON.stringify(rec)));
          added = true;
        }
        if (added && UW.models && typeof UW.models.warm === 'function') {
          try { UW.models.warm(scene); } catch (e) { /* ignore */ }
        }
      }
      const existing = new Set(scene.nodes.map((n) => n.id));
      const remap = new Map();
      const nodes = [];
      for (const raw of msg.nodes) {
        const n = JSON.parse(JSON.stringify(raw));
        if (existing.has(n.id)) {
          const next = UW.scene.uid();
          remap.set(n.id, next);
          n.id = next;
        }
        nodes.push(n);
      }
      for (const n of nodes) {
        if (n.parent && remap.has(n.parent)) n.parent = remap.get(n.parent);
        if (n.parent && !scene.nodes.some((x) => x.id === n.parent) && !nodes.some((x) => x.id === n.parent)) n.parent = null;
      }
      scene.nodes.push(...nodes);
      this.index();
      const root = nodes.find((n) => n.network && n.network.netId === msg.netId) || nodes[0];
      if (root && root.network) root.network.owner = msg.owner || '';
      if (root && this.runtime) {
        for (const n of nodes) {
          if (n.fsm && typeof this.runtime.spawnRunner === 'function') {
            const runner = this.runtime.spawnRunner(n);
            if (runner && this.runtime.isActive(n)) {
              try { runner.start(); } catch (e) { /* ignore */ }
            }
          }
        }
      }
      if (this.runtime && typeof this.runtime.rebuildPhysics === 'function') this.runtime.rebuildPhysics();
      this.editor.touch(true);
      this.editor.log('info', '[Net] Spawned "' + (root ? root.name : 'object') + '" from a peer.');
    }

    _applyEvent(msg) {
      const name = String(msg.event || '').trim();
      if (!name) return;
      this.lastEvent = { name, data: msg.data, from: msg.from, time: Date.now() };
      if (!Array.isArray(this.runtime.netEvents)) this.runtime.netEvents = [];
      this.runtime.netEvents.push(this.lastEvent);
      if (this.runtime.netEvents.length > 40) this.runtime.netEvents.shift();
      this.runtime.emitEvent(name);
      this.editor.log('info', '[Net] Event "' + name + '" from ' + (msg.name || 'peer') + '.');
    }

    _releaseOwnedBy(peerId) {
      for (const node of this.editor.scene.nodes) {
        if (node.network && node.network.owner === peerId) {
          node.network.owner = '';
          this.targets.delete(node.network.netId);
        }
      }
    }

    /* ---------------- scene index & claiming ---------------- */
    index() {
      this.map.clear();
      for (const node of this.editor.scene.nodes) {
        if (node.network && node.network.netId) this.map.set(node.network.netId, node);
      }
    }

    networkedNodes() {
      return this.editor.scene.nodes.filter((n) => n.network && n.network.netId);
    }

    nodeByNetId(id) {
      return this.map.get(id) || null;
    }

    _claimDefaults() {
      const cfg = this.editor.scene.network || {};
      const wanted = String(cfg.playerObject || '').trim();
      let claimed = 0;
      if (wanted) {
        const node = this.editor.scene.nodes.find((n) => n.network && (n.id === wanted || n.name === wanted));
        if (node && this.claim(node)) claimed++;
      }
      for (const node of this.editor.scene.nodes) {
        if (!node.network || !node.network.autoOwn) continue;
        if (node.network.owner && node.network.owner !== this.peerId) continue;
        if (this.claim(node)) claimed++;
      }
      if (claimed) this.editor.log('info', '[Net] Claimed ' + claimed + ' object(s) for ' + this.name + '.');
      return claimed;
    }

    claim(node) {
      if (!node || !node.network) return false;
      node.network.owner = this.peerId;
      this.targets.delete(node.network.netId);
      this._send({ t: 'claim', netId: node.network.netId, owner: this.peerId });
      this.editor.emit('values');
      return true;
    }

    release(node) {
      if (!node || !node.network) return false;
      node.network.owner = '';
      this.targets.delete(node.network.netId);
      this._send({ t: 'claim', netId: node.network.netId, owner: '' });
      this.editor.emit('values');
      return true;
    }

    isOwner(node) {
      if (!node || !node.network) return true;
      if (!this.connected) return true;
      return node.network.owner === this.peerId;
    }

    /* ---------------- spawn / despawn / events ---------------- */
    spawn(node) {
      if (!node || !node.network) return false;
      const subtree = [node, ...UW.scene.descendants(this.editor.scene, node.id)];
      const nodes = subtree.map((n) => JSON.parse(JSON.stringify(n)));
      const modelIds = new Set();
      for (const n of subtree) {
        if (n.mesh && n.mesh.shape === 'model' && n.mesh.modelId) modelIds.add(n.mesh.modelId);
      }
      const models = modelIds.size
        ? (this.editor.scene.models || [])
          .filter((m) => m && modelIds.has(m.id))
          .map((m) => JSON.parse(JSON.stringify(m)))
        : [];
      if (!node.network.owner) node.network.owner = this.peerId;
      this._send({
        t: 'spawn',
        netId: node.network.netId,
        owner: node.network.owner,
        nodes,
        models,
      });
      this.index();
      return true;
    }

    despawn(node) {
      if (!node || !node.network) return false;
      const netId = node.network.netId;
      this._send({ t: 'despawn', netId });
      this._destroyLocal(netId);
      return true;
    }

    _destroyLocal(netId) {
      const node = this.map.get(netId);
      if (!node) return;
      const doomed = new Set([node.id, ...UW.scene.descendants(this.editor.scene, node.id).map((n) => n.id)]);
      this.editor.scene.nodes = this.editor.scene.nodes.filter((n) => !doomed.has(n.id));
      if (doomed.has(this.editor.selected)) this.editor.select(null, true);
      if (this.runtime && this.runtime.removeNodes) this.runtime.removeNodes(doomed);
      if (this.runtime && this.runtime.rebuildPhysics) this.runtime.rebuildPhysics();
      this.targets.delete(netId);
      this.index();
      this.editor.touch(true);
    }

    sendEvent(name, data) {
      const n = String(name || '').trim();
      if (!n) return false;
      this._send({ t: 'event', event: n, data: data == null ? null : data });
      return true;
    }

    requestSync() {
      this._send({ t: 'syncRequest' });
    }

    /* Public convenience used by the FSM action "Push state now". */
    pushState() {
      this._sendSnapshot(true);
      return this.connected;
    }

    /* ---------------- snapshots ---------------- */
    _stateOf(node) {
      const t = node.transform;
      return {
        id: node.network.netId,
        p: node.network.syncPosition ? [M.round(t.position[0], 4), M.round(t.position[1], 4), M.round(t.position[2], 4)] : null,
        r: node.network.syncRotation ? [M.round(t.rotation[0], 3), M.round(t.rotation[1], 3), M.round(t.rotation[2], 3)] : null,
        s: node.network.syncScale ? [M.round(t.scale[0], 3), M.round(t.scale[1], 3), M.round(t.scale[2], 3)] : null,
        a: node.network.syncActive ? node.active !== false : null,
        v: node.network.syncActive ? node.visible !== false : null,
        c: node.network.syncColor && node.mesh ? node.mesh.color : null,
      };
    }

    _sendSnapshot(force) {
      if (!this.connected) return;
      const objects = [];
      for (const node of this.editor.scene.nodes) {
        if (!node.network || node.network.owner !== this.peerId) continue;
        objects.push(this._stateOf(node));
      }
      if (!objects.length && !force) return;
      this._send({ t: 'state', objects });
    }

    /* ---------------- per-frame ---------------- */
    update(dt) {
      if (!this.connected) return;
      this._indexAcc += dt;
      if (this._indexAcc > 0.5) {
        this._indexAcc = 0;
        this.index();
      }

      this._pingAcc += dt;
      if (this._pingAcc > 2) {
        this._pingAcc = 0;
        this._send({ t: 'ping' });
        if (this.transport === 'local') {
          const now = Date.now();
          let changed = false;
          for (const [id, p] of this.peers) {
            if (now - p.last > 12000) {
              this.peers.delete(id);
              changed = true;
            }
          }
          if (changed) this._emitStatus();
        }
      }

      // interpolate snapshots received from other owners
      if (this.targets.size) {
        for (const [netId, target] of Array.from(this.targets)) {
          const node = this.map.get(netId);
          if (!node) {
            this.targets.delete(netId);
            continue;
          }
          const interp = Math.max(0.015, node.network.interpolation || 0.12);
          const k = 1 - Math.exp(-dt / interp);
          const t = node.transform;
          if (target.position && node.network.syncPosition) {
            t.position[0] += (target.position[0] - t.position[0]) * k;
            t.position[1] += (target.position[1] - t.position[1]) * k;
            t.position[2] += (target.position[2] - t.position[2]) * k;
          }
          if (target.rotation && node.network.syncRotation) {
            for (let i = 0; i < 3; i++) t.rotation[i] = angleLerp(t.rotation[i], target.rotation[i], k);
          }
          if (target.scale && node.network.syncScale) {
            for (let i = 0; i < 3; i++) t.scale[i] += (target.scale[i] - t.scale[i]) * k;
          }
        }
      }

      this._sendAcc += dt;
      if (this._sendAcc >= this._sendRate) {
        this._sendAcc = 0;
        this._sendSnapshot(false);
      }
    }
  }

  N.createRuntime = function (runtime) {
    return new NetManager(runtime);
  };
  N.Manager = NetManager;

  /* Small helpers used by the inspector / dialogs. */
  N.createComponent = function () {
    return {
      netId: N.newNetId(),
      owner: '',
      syncPosition: true,
      syncRotation: true,
      syncScale: false,
      syncActive: true,
      syncColor: true,
      interpolation: 0.12,
      autoOwn: false,
    };
  };
})();
