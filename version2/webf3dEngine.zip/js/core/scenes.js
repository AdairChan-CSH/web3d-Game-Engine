/* ============================================================
   scenes.js — built-in scene templates + in-game scene changer
   Templates are ordinary scene JSON generated at runtime, so they
   load on file:// without any assets. The launcher and the Scene
   Changer both use this one list, and saved browser scenes are
   merged in by name.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const S = UW.scene;
  const SC = (UW.scenes = {});

  let seq = 0;
  const nid = (prefix) => (prefix || 't') + '_' + (++seq).toString(36) + Date.now().toString(36).slice(-3);

  function node(kind, name, pos, opts) {
    const o = Object.assign({ name, position: pos || [0, 0, 0] }, opts || {});
    const n = S.createNode(kind, o);
    if (o.rotation) n.transform.rotation = o.rotation.slice();
    if (o.scale) n.transform.scale = o.scale.slice();
    if (o.color && n.mesh) n.mesh.color = o.color;
    if (o.mesh) Object.assign(n.mesh, o.mesh);
    if (o.rigidbody) n.rigidbody = Object.assign({ mass: 1, useGravity: true, restitution: 0.25 }, o.rigidbody);
    if (o.behaviors) n.behaviors = o.behaviors.map((b) => ({ id: S.uid(), kind: b.kind, params: b.params || {} }));
    if (o.ui && UW.unityui) n.ui = UW.unityui.createComponent(o.ui.kind || 'panel', o.ui);
    if (o.script) n.script = o.script;
    if (o.fsm) n.fsm = o.fsm;
    if (o.network) n.network = Object.assign(UW.Net ? UW.Net.createComponent() : {}, o.network);
    if (o.sceneChanger) n.sceneChanger = Object.assign(SC.changerDefaults(), o.sceneChanger);
    if (o.audio) n.audio = Object.assign({ kind: 'tone', src: '', frequency: 330, volume: 0.25, loop: false, playOnAwake: true, playing: true }, o.audio);
    if (o.tag) n.tag = o.tag;
    if (o.active === false) n.active = false;
    if (o.children) {
      for (const child of o.children) {
        const c = node(child.kind, child.name, child.pos, child.opts);
        c.parent = n.id;
        n.__children = n.__children || [];
        n.__children.push(c);
      }
    }
    return n;
  }

  function uiNode(kind, name, props) {
    const n = S.createNode('ui', { name });
    n.ui = UW.unityui.createComponent(kind, props || {});
    return n;
  }

  function fsm(states) {
    const base = UW.FSM ? UW.FSM.defaults() : null;
    if (!base) return null;
    const first = base.states[0];
    first.name = (states && states[0] && states[0].name) || 'Idle';
    if (states && states[0] && states[0].actions) {
      first.actions = states[0].actions.map((a) => (UW.FSM.defaultAction(a)));
    }
    return base;
  }

  function scene(name, description, nodes, extra) {
    const data = {
      version: 1,
      name,
      description: description || '',
      env: S.defaultEnv(),
      network: S.defaultNetwork(),
      models: [],
      nodes,
    };
    return Object.assign(data, extra || {});
  }

  /* Small reusable player controller script. ctx.input/ctx.axis/ctx.jump
     are provided by runtime.js. */
  const PLAYER_SCRIPT = {
    name: 'PlayerController',
    code: `// Built-in third-person / platformer controller (Play mode only)
let vy = 0;
function onStart(ctx) {
  ctx.log('Player ready — WASD / left stick to move, Space / A to jump.');
}
function onUpdate(ctx, dt) {
  const speed = ctx.action('sprint').down ? 10 : 5.5;
  const x = ctx.axis('moveX');
  const z = -ctx.axis('moveY');
  const p = ctx.node.transform;
  p.position[0] += x * speed * dt;
  p.position[2] += z * speed * dt;
  if (Math.abs(x) + Math.abs(z) > 0.05) {
    ctx.node.transform.rotation[1] = Math.atan2(x, z) * 180 / Math.PI;
    ctx.playClip('walk');
  } else {
    ctx.playClip('idle');
  }
  if (ctx.action('jump').pressed) ctx.jump(6.2);
}
`,
  };

  const CAR_SCRIPT = {
    name: 'VehicleController',
    code: `let speed = 0;
function onUpdate(ctx, dt) {
  const throttle = ctx.axis('moveY');
  const steer = ctx.axis('moveX');
  speed += throttle * 14 * dt;
  speed *= Math.pow(0.4, dt);
  speed = Math.max(-9, Math.min(18, speed));
  const p = ctx.node.transform;
  p.rotation[1] += steer * (speed >= 0 ? 1 : -1) * 62 * dt;
  const yaw = p.rotation[1] * Math.PI / 180;
  p.position[0] += Math.sin(yaw) * speed * dt;
  p.position[2] += Math.cos(yaw) * speed * dt;
  if (ctx.action('fire').pressed) ctx.playTone(220, 0.06, 0.08, 'square');
}
`,
  };

  /* ---------------- templates ---------------- */
  const TEMPLATES = [];

  function add(def) { TEMPLATES.push(def); }

  add({
    id: 'sample',
    name: 'Sample Scene',
    description: 'The default WebForge sandbox with primitives, physics and a camera.',
    icon: 'i-cube',
    tags: ['Default', '3D'],
    build() {
      return S.defaultScene();
    },
  });

  add({
    id: 'blank',
    name: 'Blank 3D',
    description: 'An empty scene with just a camera and a directional light.',
    icon: 'i-plus',
    tags: ['Empty'],
    build() {
      const d = S.emptyScene();
      d.name = 'Blank 3D';
      return d;
    },
  });

  add({
    id: 'platformer',
    name: '3D Platformer',
    description: 'Jump between platforms, collect coins and score with a Canvas HUD.',
    icon: 'i-sphere',
    tags: ['Game', 'Physics', 'UI'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [30, 1, 30], color: '#38404a', mesh: { roughness: 0.95 } });
      const p1 = node('cube', 'Platform 1', [0, 1.2, -4], { scale: [3.4, 0.4, 3.4], color: '#4b5563' });
      const p2 = node('cube', 'Platform 2', [-3.4, 2.3, -7.5], { scale: [2.6, 0.4, 2.6], color: '#5b6472' });
      const p3 = node('cube', 'Platform 3', [3.2, 3.5, -11], { scale: [2.4, 0.4, 2.4], color: '#6b7480' });
      const player = node('capsule', 'Player', [0, 1, 2], {
        color: '#46b3ff', rigidbody: { mass: 1, restitution: 0.05, drag: 0.6 }, script: PLAYER_SCRIPT,
      });
      const coins = [];
      [[0, 1.1, 2.2], [-1.2, 1.1, 1.2], [1.4, 1.1, 0.6], [0, 2.4, -4], [-3.4, 3.3, -7.5]].forEach((p, i) => {
        coins.push(node('sphere', 'Coin ' + (i + 1), p, {
          scale: [0.28, 0.28, 0.28], color: '#ffd35c',
          behaviors: [{ kind: 'spin', params: { y: 120 } }, { kind: 'bob', params: { amplitude: 0.18, speed: 2.4 } }],
        }));
      });
      const light = node('light.directional', 'Sun', [4, 8, 5], { rotation: [52, -34, 0] });
      const fill = node('light.point', 'Fill Light', [0, 3, 3], { color: '#ffcf9e' });
      const camera = node('camera', 'Main Camera', [0, 4.2, 10], { rotation: [-12, 0, 0] });
      const hud = uiNode('canvas', 'Canvas', { w: 1280, h: 720, bgAlpha: 0 });
      hud.parent = null;
      const score = uiNode('text', 'Score Text', {
        anchor: 'topLeft', x: 28, y: 24, w: 320, h: 44, text: 'SCORE 0', fontSize: 30, bold: true, color: '#ffe08a',
      });
      const hint = uiNode('text', 'Hint Text', {
        anchor: 'bottomCenter', x: 0, y: 26, w: 560, h: 34, text: 'WASD / left stick to move · Space / A to jump', fontSize: 18, align: 'center', color: '#cfe4ff',
      });
      const env = S.defaultEnv();
      env.ambient = 0.55;
      return scene('3D Platformer', 'Platformer starter', [light, fill, camera, ground, p1, p2, p3, player, ...coins, hud, score, hint], { env });
    },
  });

  add({
    id: 'fps',
    name: 'First-Person Arena',
    description: 'Enclosed arena, cover, enemies and a crosshair / ammo HUD.',
    icon: 'i-camera',
    tags: ['Game', 'FPS', 'UI'],
    build() {
      const ground = node('plane', 'Arena Floor', [0, 0, 0], { scale: [34, 1, 34], color: '#2f353d' });
      const walls = [];
      const wallAt = (x, z, sx, sz) => walls.push(node('cube', 'Wall', [x, 1.6, z], { scale: [sx, 3.2, sz], color: '#4b545f' }));
      wallAt(0, -17, 34, 0.6); wallAt(0, 17, 34, 0.6); wallAt(-17, 0, 0.6, 34); wallAt(17, 0, 0.6, 34);
      const covers = [
        [3, 0.7, 2, 2.2, 1.4, 2.2], [-4, 0.7, -3, 2.6, 1.4, 1.2], [0, 0.7, -7, 4, 1.4, 1],
        [-8, 0.7, 5, 1.4, 1.4, 3.4], [8, 0.7, -5, 2.4, 1.4, 2.4],
      ].map((c, i) => node('cube', 'Cover ' + (i + 1), [c[0], c[1], c[2]], { scale: [c[3], c[4], c[5]], color: '#59626d' }));
      const enemies = [[-6, 0.5, -9], [6, 0.5, -11], [0, 0.5, 8]].map((p, i) => node('cube', 'Enemy ' + (i + 1), p, {
        color: i === 2 ? '#c0564f' : '#b07a3a',
        behaviors: [{ kind: 'spin', params: { y: 25 + i * 10 } }],
        fsm: fsm([{ name: 'Patrol', actions: ['log'] }]),
      }));
      enemies.forEach((e) => {
        if (!e.fsm) return;
        e.fsm.states[0].actions = [UW.FSM.defaultAction('log')];
        e.fsm.states[0].actions[0].params.message = 'Enemy alerted';
        e.fsm.states[0].actions[0].params.level = 'warn';
      });
      const camera = node('camera', 'Player Camera', [0, 1.75, 9], { rotation: [-4, 0, 0] });
      const light = node('light.directional', 'Sun', [3, 9, 4], { rotation: [50, -40, 0] });
      const lamp = node('light.point', 'Arena Lamp', [0, 5, 0], { color: '#d7e6ff', mesh: null });
      const cross = uiNode('image', 'Crosshair', {
        anchor: 'center', x: 0, y: 0, w: 18, h: 18, bg: '#7ef0ff', bgAlpha: 0.9, radius: 9, border: 2, text: '',
      });
      const hud = uiNode('panel', 'HUD Panel', {
        anchor: 'bottomLeft', x: 24, y: 24, w: 280, h: 104, bgAlpha: 0.72, bg: '#0d1117',
      });
      const health = uiNode('progress', 'Health Bar', {
        anchor: 'bottomLeft', x: 40, y: 38, w: 240, h: 22, value: 100, min: 0, max: 100, text: 'HEALTH 100', fontSize: 15,
      });
      const ammo = uiNode('text', 'Ammo Text', {
        anchor: 'bottomRight', x: 30, y: 30, w: 240, h: 46, text: 'AMMO 30 / 90', fontSize: 24, bold: true, align: 'right', color: '#9fe4ff',
      });
      const env = S.defaultEnv();
      env.ambient = 0.4;
      env.fogEnabled = true;
      env.fogColor = '#1a1f26';
      env.fogNear = 16;
      env.fogFar = 48;
      return scene('First-Person Arena', 'FPS starter', [light, lamp, camera, ground, ...walls, ...covers, ...enemies, cross, hud, health, ammo], { env });
    },
  });

  add({
    id: 'thirdperson',
    name: 'Third-Person',
    description: 'Character controller with a chase camera, walk/jump motion and UI.',
    icon: 'i-rig',
    tags: ['Game', 'Character'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [42, 1, 42], color: '#39423b' });
      const player = node('capsule', 'Player', [0, 1, 0], {
        color: '#62c08a', rigidbody: { mass: 1, restitution: 0.05, drag: 0.7 }, script: PLAYER_SCRIPT,
      });
      const dummy = node('empty', 'Target Dummy', [4, 0.9, -4], {
        children: [
          { kind: 'capsule', name: 'Body', pos: [0, 0, 0], opts: { color: '#a77b55', scale: [0.5, 0.9, 0.5] } },
          { kind: 'sphere', name: 'Head', pos: [0, 0.95, 0], opts: { color: '#c79a70', scale: [0.32, 0.32, 0.32] } },
          { kind: 'cube', name: 'Arms', pos: [0, 0.25, 0], opts: { color: '#926a48', scale: [1.4, 0.18, 0.18] } },
        ],
      });
      const rocks = [[-5, 0.4, 3], [6, 0.6, 1], [-8, 0.5, -6], [9, 0.45, -8]].map((p, i) =>
        node('sphere', 'Rock ' + (i + 1), p, { scale: [1.1, 0.8, 1], color: '#6b7078', behaviors: [{ kind: 'spin', params: { y: 6 } }] }));
      const camera = node('camera', 'Chase Camera', [0, 3.4, 8.5], { rotation: [-12, 0, 0] });
      const light = node('light.directional', 'Sun', [5, 8, 6], { rotation: [46, -42, 0] });
      const title = uiNode('text', 'Title', { anchor: 'topCenter', x: 0, y: 22, w: 520, h: 48, align: 'center', text: 'THIRD-PERSON DEMO', fontSize: 30, bold: true });
      const hint = uiNode('text', 'Controls', { anchor: 'bottomCenter', x: 0, y: 24, w: 560, h: 34, align: 'center', text: 'Move with WASD / left stick · Space / A jumps', fontSize: 18, color: '#bfe9cf' });
      return scene('Third-Person', 'Character starter', [light, camera, ground, player, dummy, ...rocks, title, hint], { env: Object.assign(S.defaultEnv(), { ambient: 0.55 }) });
    },
  });

  add({
    id: 'multiplayer',
    name: 'Multiplayer Arena',
    description: 'Network Objects, an auto-claimed player avatar and a scoreboard HUD.',
    icon: 'i-net',
    tags: ['Multiplayer', '4 kinds', 'UI'],
    build() {
      const ground = node('plane', 'Arena Floor', [0, 0, 0], { scale: [30, 1, 30], color: '#333a41' });
      const pillars = [[-7, 1.4, -7], [7, 1.4, -7], [-7, 1.4, 7], [7, 1.4, 7], [0, 1.4, 0]].map((p, i) =>
        node('cylinder', 'Pillar ' + (i + 1), p, { scale: [0.8, 2.8, 0.8], color: '#5b6470' }));
      const player = node('cube', 'Player Avatar', [0, 0.6, 3], {
        color: '#4aa8ff', rigidbody: { mass: 1, restitution: 0.2 },
        network: { autoOwn: true }, tag: 'Player',
      });
      const crates = [[3, 0.5, -2], [-3, 0.5, -4], [5, 0.5, 4], [-5, 0.5, 2]].map((p, i) =>
        node('cube', 'Network Crate ' + (i + 1), p, { color: i % 2 ? '#d7a24a' : '#8a68d6', network: { syncColor: true } }));
      const ball = node('sphere', 'Sync Ball', [0, 1.2, -5], { scale: [0.6, 0.6, 0.6], color: '#62d6a4', network: { syncScale: true } });
      const camera = node('camera', 'Main Camera', [0, 5, 11], { rotation: [-14, 0, 0] });
      const light = node('light.directional', 'Sun', [4, 8, 4], { rotation: [50, -36, 0] });
      const title = uiNode('text', 'Lobby Title', { anchor: 'topCenter', x: 0, y: 22, w: 600, h: 44, align: 'center', text: 'MULTIPLAYER ARENA', fontSize: 28, bold: true, color: '#8fc3ff' });
      const board = uiNode('panel', 'Scoreboard', { anchor: 'topRight', x: 24, y: 24, w: 260, h: 140, bgAlpha: 0.78 });
      const boardText = uiNode('text', 'Scoreboard Text', { anchor: 'topRight', x: 40, y: 40, w: 230, h: 110, text: 'PEERS\\n1. You', fontSize: 17, color: '#d8e8ff' });
      const room = uiNode('text', 'Room Label', { anchor: 'bottomLeft', x: 26, y: 26, w: 420, h: 34, text: 'Room: My Game · local tabs', fontSize: 16, color: '#9fb4c9' });
      const net = S.defaultNetwork();
      net.transport = 'local';
      net.room = 'My Game';
      net.playerObject = player.id;
      net.autoConnect = true;
      return scene('Multiplayer Arena', 'Four-transport multiplayer starter', [light, camera, ground, ...pillars, player, ...crates, ball, title, board, boardText, room], { network: net });
    },
  });

  add({
    id: 'uikit',
    name: 'UI Toolkit Demo',
    description: 'Canvas, Panel, Text, Button, Toggle, Slider, Input, Dropdown and Progress.',
    icon: 'i-ui',
    tags: ['UI', 'Canvas', 'FSM'],
    build() {
      const camera = node('camera', 'Main Camera', [0, 2.2, 8], { rotation: [-6, 0, 0] });
      const light = node('light.directional', 'Sun', [3, 7, 4], { rotation: [50, -30, 0] });
      const backdrop = node('plane', 'Backdrop', [0, 0, -1], { scale: [18, 1, 10], rotation: [-90, 0, 0], color: '#2c3440' });
      const canvas = uiNode('canvas', 'Canvas', { w: 1280, h: 720, bg: '#111827', bgAlpha: 0.55 });
      const panel = uiNode('panel', 'Main Panel', { anchor: 'center', x: 0, y: 0, w: 560, h: 480, bg: '#161c24', bgAlpha: 0.96, radius: 14 });
      const title = uiNode('text', 'Title', { anchor: 'center', x: 0, y: -170, w: 500, h: 54, align: 'center', text: 'WEBFORGE UI KIT', fontSize: 34, bold: true, color: '#8fc3ff' });
      const subtitle = uiNode('text', 'Subtitle', { anchor: 'center', x: 0, y: -126, w: 500, h: 30, align: 'center', text: 'Every Unity UI element, rendered in the Game view', fontSize: 16, color: '#9fb4c9' });
      const button = uiNode('button', 'Play Button', { anchor: 'center', x: 0, y: -60, w: 300, h: 52, text: 'START GAME', bg: '#3d8bfd', radius: 10, event: 'startGame' });
      const toggle = uiNode('toggle', 'Sound Toggle', { anchor: 'center', x: -110, y: 10, w: 220, h: 40, text: 'Sound effects', checked: true, event: 'toggleSound' });
      const slider = uiNode('slider', 'Volume Slider', { anchor: 'center', x: 0, y: 62, w: 340, h: 36, text: 'Volume', value: 0.7, min: 0, max: 1, step: 0.01, event: 'volumeChange' });
      const input = uiNode('input', 'Name Input', { anchor: 'center', x: 0, y: 114, w: 340, h: 44, text: '', placeholder: 'Player name…', align: 'center', event: 'nameSubmit' });
      const dropdown = uiNode('dropdown', 'Mode Dropdown', { anchor: 'center', x: 0, y: 166, w: 340, h: 44, options: 'Deathmatch, Team Battle, Co-op, Sandbox', value: 0, event: 'modeChange' });
      const progress = uiNode('progress', 'Loading Bar', { anchor: 'center', x: 0, y: 218, w: 340, h: 24, value: 0.35, min: 0, max: 1, text: 'Loading 35%', fontSize: 15 });
      const controller = node('empty', 'UI Controller', [0, 0, 0], {
        fsm: fsm([{ name: 'Idle', actions: ['log'] }]),
      });
      if (controller.fsm) {
        controller.fsm.states[0].actions = [UW.FSM.defaultAction('log')];
        controller.fsm.states[0].actions[0].params.message = 'UI demo ready — press the button!';
      }
      return scene('UI Toolkit Demo', 'Unity UI element demo', [light, camera, backdrop, canvas, panel, title, subtitle, button, toggle, slider, input, dropdown, progress, controller], { env: S.defaultEnv() });
    },
  });

  add({
    id: 'physics',
    name: 'Physics Playground',
    description: 'Stacks, ramps and bouncing bodies powered by the tiny AABB solver.',
    icon: 'i-sphere',
    tags: ['Physics', 'Sandbox'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [34, 1, 34], color: '#3a3f46' });
      const ramp = node('cube', 'Ramp', [-4, 1.4, 0], { rotation: [0, 0, -22], scale: [8, 0.4, 4], color: '#5d6773' });
      const bodies = [];
      const colors = ['#d96b5f', '#d9a441', '#5b9bd5', '#9d86e0', '#6fb59a', '#d97fb0'];
      for (let i = 0; i < 14; i++) {
        const kind = ['cube', 'sphere', 'cylinder', 'capsule'][i % 4];
        bodies.push(node(kind, 'Body ' + (i + 1), [
          -2 + (i % 4) * 1.2, 2.5 + Math.floor(i / 4) * 1.4, 3 + (i % 3) * 0.9,
        ], {
          color: colors[i % colors.length],
          scale: kind === 'sphere' ? [0.45, 0.45, 0.45] : [0.7, 0.7, 0.7],
          rigidbody: { mass: 1 + (i % 4) * 0.4, restitution: 0.15 + (i % 5) * 0.1, drag: 0.1 },
        }));
      }
      const pedestal = node('cylinder', 'Pedestal', [5, 1, -3], { scale: [1.6, 2, 1.6], color: '#4b5563' });
      const light = node('light.directional', 'Sun', [4, 9, 4], { rotation: [48, -38, 0] });
      const camera = node('camera', 'Main Camera', [0, 5.5, 12], { rotation: [-16, 0, 0] });
      const title = uiNode('text', 'Title', { anchor: 'topLeft', x: 24, y: 22, w: 420, h: 40, text: 'PHYSICS PLAYGROUND', fontSize: 25, bold: true });
      const reset = uiNode('button', 'Reset Button', { anchor: 'topRight', x: 24, y: 22, w: 150, h: 44, text: 'RESET', bg: '#b9564e', event: 'resetPhysics' });
      return scene('Physics Playground', 'Physics sandbox', [light, camera, ground, ramp, pedestal, ...bodies, title, reset], { env: Object.assign(S.defaultEnv(), { ambient: 0.5 }) });
    },
  });

  add({
    id: 'racing',
    name: 'Arcade Racing',
    description: 'Drive a vehicle with the keyboard or a gamepad around a simple track.',
    icon: 'i-move',
    tags: ['Game', 'Vehicle'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [70, 1, 70], color: '#3c5a3f' });
      const track = node('plane', 'Track', [0, 0.02, 0], { scale: [34, 1, 18], color: '#3a3f45' });
      const rails = [];
      for (let i = -3; i <= 3; i++) {
        rails.push(node('cube', 'Rail L ' + i, [-18, 0.4, i * 5], { scale: [0.3, 0.8, 3], color: '#d9d9d9' }));
        rails.push(node('cube', 'Rail R ' + i, [18, 0.4, i * 5], { scale: [0.3, 0.8, 3], color: '#d9d9d9' }));
      }
      const cones = [];
      for (let i = 0; i < 8; i++) {
        cones.push(node('cylinder', 'Cone ' + (i + 1), [-12 + i * 3.4, 0.3, -7 + (i % 3) * 2], { scale: [0.3, 0.6, 0.3], color: '#ff8a3d' }));
      }
      const car = node('cube', 'Car', [0, 0.55, 4], {
        color: '#d94b4b', scale: [1.1, 0.55, 2.1], script: CAR_SCRIPT, tag: 'Player',
      });
      const wheel1 = node('cylinder', 'Wheel FL', [-0.62, 0.32, 0.7], { scale: [0.3, 0.3, 0.22], rotation: [0, 0, 90], color: '#1d1f22' });
      const wheel2 = node('cylinder', 'Wheel FR', [0.62, 0.32, 0.7], { scale: [0.3, 0.3, 0.22], rotation: [0, 0, 90], color: '#1d1f22' });
      wheel1.parent = car.id; wheel2.parent = car.id;
      const camera = node('camera', 'Chase Camera', [0, 5, 12], { rotation: [-15, 0, 0] });
      const light = node('light.directional', 'Sun', [6, 10, 5], { rotation: [45, -40, 0] });
      const speed = uiNode('text', 'Speed', { anchor: 'bottomRight', x: 30, y: 30, w: 300, h: 56, align: 'right', text: '0 km/h', fontSize: 32, bold: true, color: '#ffe08a' });
      const hint = uiNode('text', 'Hint', { anchor: 'bottomLeft', x: 26, y: 30, w: 480, h: 34, text: 'W/S throttle · A/D steer (left stick works too)', fontSize: 17, color: '#cfe4ff' });
      return scene('Arcade Racing', 'Racing starter', [light, camera, ground, track, ...rails, ...cones, car, wheel1, wheel2, speed, hint], { env: Object.assign(S.defaultEnv(), { ambient: 0.6 }) });
    },
  });

  add({
    id: 'scenemanager',
    name: 'Scene Hub',
    description: 'An in-game Scene Changer menu that jumps between built-in and saved scenes.',
    icon: 'i-scene',
    tags: ['Scene changer', 'UI'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [26, 1, 26], color: '#333b44' });
      const ring = node('torus', 'Portal Ring', [0, 2.4, -3], { scale: [2.2, 2.2, 2.2], color: '#6f8cff', behaviors: [{ kind: 'spin', params: { y: 25 } }] });
      const orb = node('sphere', 'Portal Core', [0, 2.4, -3], { scale: [0.9, 0.9, 0.9], color: '#a9c4ff', behaviors: [{ kind: 'pulse', params: { amount: 0.12, speed: 2 } }] });
      const camera = node('camera', 'Main Camera', [0, 3.6, 8], { rotation: [-9, 0, 0] });
      const light = node('light.directional', 'Sun', [4, 8, 4], { rotation: [48, -35, 0] });
      const point = node('light.point', 'Portal Light', [0, 2.6, -2], { color: '#8fb0ff', intensity: 2.2, range: 12 });
      const changer = node('empty', 'Scene Changer', [0, 0, 0], {
        sceneChanger: { title: 'SCENE HUB', scenes: ['Sample Scene', '3D Platformer', 'First-Person Arena', 'UI Toolkit Demo', 'Physics Playground', 'Arcade Racing', 'Space Explorer'] },
      });
      const title = uiNode('text', 'Title', { anchor: 'topCenter', x: 0, y: 22, w: 620, h: 52, align: 'center', text: 'WEBFORGE SCENE HUB', fontSize: 33, bold: true, color: '#a9c4ff' });
      const note = uiNode('text', 'Note', { anchor: 'bottomCenter', x: 0, y: 24, w: 700, h: 32, align: 'center', text: 'Use the scene menu or press Play to travel between scenes', fontSize: 17, color: '#cfe4ff' });
      return scene('Scene Hub', 'Scene changer demo', [light, point, camera, ground, ring, orb, changer, title, note], { env: Object.assign(S.defaultEnv(), { ambient: 0.4 }) });
    },
  });

  add({
    id: 'space',
    name: 'Space Explorer',
    description: 'Orbiting planets, stars and a point-lit flying camera.',
    icon: 'i-sphere',
    tags: ['Showcase', '3D'],
    build() {
      const sun = node('sphere', 'Sun', [0, 3, -10], { scale: [2.4, 2.4, 2.4], color: '#ffcf5c', mesh: { metalness: 0.2, roughness: 0.4 } });
      const sunLight = node('light.point', 'Sun Light', [0, 3, -10], { color: '#ffd98a', intensity: 3.2, range: 40 });
      const planets = [];
      const colors = ['#5b9bd5', '#d97f6a', '#6fb59a', '#9d86e0', '#d9a441'];
      for (let i = 0; i < 5; i++) {
        const r = 3.2 + i * 1.5;
        planets.push(node('sphere', 'Planet ' + (i + 1), [Math.cos(i * 1.2) * r, 2.5 + (i % 2), -10 + Math.sin(i * 1.2) * r * 0.5], {
          scale: [0.5 + (i % 3) * 0.18, 0.5 + (i % 3) * 0.18, 0.5 + (i % 3) * 0.18], color: colors[i],
          behaviors: [{ kind: 'orbit', params: { radius: r, speed: 8 + i * 4, height: (i % 2) * 0.6 } }],
        }));
      }
      const stars = [];
      for (let i = 0; i < 90; i++) {
        const a = i * 2.399;
        const r = 10 + (i % 20) * 1.6;
        stars.push(node('sphere', 'Star ' + (i + 1), [Math.cos(a) * r, 2 + Math.sin(a * 1.7) * 9, -10 + Math.sin(a) * r], {
          scale: [0.06, 0.06, 0.06], color: '#dfe9ff',
        }));
      }
      const ship = node('cone', 'Ship', [0, 2, 8], { rotation: [-70, 0, 0], scale: [0.5, 0.9, 0.5], color: '#c9d3e0' });
      const camera = node('camera', 'Ship Camera', [0, 2.4, 10], { rotation: [-4, 0, 0] });
      const rig = node('light.directional', 'Rim Light', [6, 6, 4], { rotation: [40, -30, 0], color: '#9fc4ff', intensity: 0.6 });
      const title = uiNode('text', 'Title', { anchor: 'topCenter', x: 0, y: 22, w: 620, h: 52, align: 'center', text: 'SPACE EXPLORER', fontSize: 32, bold: true, color: '#d8e8ff' });
      const env = S.defaultEnv();
      env.ambient = 0.18;
      env.fogEnabled = true;
      env.fogColor = '#070b14';
      env.fogNear = 30;
      env.fogFar = 110;
      const cam = camera.camera;
      cam.bg = '#070b14';
      return scene('Space Explorer', 'Space showcase', [rig, sunLight, camera, sun, ...planets, ...stars, ship, title], { env });
    },
  });

  add({
    id: 'showcase',
    name: 'Everything Showcase',
    description: 'Every primitive, all three light types, camera, audio source and UI.',
    icon: 'i-grid',
    tags: ['Showcase', 'Objects'],
    build() {
      const ground = node('plane', 'Ground', [0, 0, 0], { scale: [40, 1, 40], color: '#30363d' });
      const shapes = ['cube', 'sphere', 'cylinder', 'cone', 'torus', 'capsule', 'quad'];
      const objs = shapes.map((s, i) => node(s, S.UNITY_LABELS ? S.UNITY_LABELS[s] || s : s, [-7.5 + i * 2.5, 0.8, -4], {
        color: ['#c7cdd6', '#5b9bd5', '#d9a441', '#cf7f6a', '#9d86e0', '#6fb59a', '#7f8c99'][i],
        behaviors: i % 2 ? [{ kind: 'spin', params: { y: 30 } }] : [],
      }));
      const dir = node('light.directional', 'Directional Light', [4, 8, 4], { rotation: [50, -35, 0] });
      const point = node('light.point', 'Point Light', [-4, 2.5, 2], { color: '#ffb877' });
      const spot = node('light.spot', 'Spot Light', [4, 4, 2], { color: '#b9d8ff' });
      const camera = node('camera', 'Main Camera', [0, 4, 12], { rotation: [-12, 0, 0] });
      const second = node('camera', 'Second Camera', [8, 3, 8], { rotation: [-8, -40, 0] });
      second.camera.secondary = true;
      second.camera.pip = { enabled: true, corner: 'bottomRight', width: 300, height: 190 };
      const audio = node('audio', 'Audio Source', [0, 0, 0], {
        audio: { kind: 'tone', frequency: 440, volume: 0.12, loop: true, playOnAwake: false },
      });
      const title = uiNode('text', 'Title', { anchor: 'topCenter', x: 0, y: 22, w: 680, h: 50, align: 'center', text: 'EVERY OBJECT & COMPONENT', fontSize: 30, bold: true, color: '#9fe4ff' });
      const pip = uiNode('text', 'Pip Hint', { anchor: 'bottomRight', x: 26, y: 214, w: 300, h: 28, align: 'right', text: 'Second camera → picture-in-picture', fontSize: 14, color: '#9fb4c9' });
      return scene('Everything Showcase', 'All object types', [dir, point, spot, camera, second, audio, ground, ...objs, title, pip], { env: Object.assign(S.defaultEnv(), { ambient: 0.45 }) });
    },
  });

  /* ---------------- public API ---------------- */
  SC.templates = TEMPLATES;

  SC.list = function () {
    return TEMPLATES.map((t) => ({ id: t.id, name: t.name, description: t.description, icon: t.icon, tags: t.tags || [] }));
  };

  SC.build = function (id) {
    const t = TEMPLATES.find((x) => x.id === id);
    if (!t) return null;
    try {
      const data = t.build();
      data.name = data.name || t.name;
      return S.normalize(JSON.parse(JSON.stringify(data)));
    } catch (e) {
      console.error('[WebForge] Template failed: ' + id, e);
      return null;
    }
  };

  /* Built-in templates plus saved browser scenes. */
  SC.all = function (editor) {
    const out = TEMPLATES.map((t) => ({ id: 'builtin:' + t.id, name: t.name, description: t.description, icon: t.icon, tags: t.tags || [], builtin: true }));
    let saved = [];
    try { saved = editor ? editor.storage() : []; } catch (e) { saved = []; }
    for (const s of saved) {
      out.push({
        id: 'saved:' + s.name,
        name: s.name,
        description: (s.data && s.data.nodes ? s.data.nodes.length : 0) + ' objects · saved ' + new Date(s.savedAt).toLocaleDateString(),
        icon: 'i-folder',
        tags: ['Saved'],
        saved: true,
      });
    }
    return out;
  };

  SC.find = function (editor, name) {
    const key = String(name || '').trim();
    if (!key) return null;
    const builtin = TEMPLATES.find((t) => t.name === key || t.id === key);
    if (builtin) return SC.build(builtin.id);
    if (editor) {
      const entry = editor.storage().find((s) => s.name === key);
      if (entry && entry.data) return S.normalize(JSON.parse(JSON.stringify(entry.data)));
    }
    return null;
  };

  SC.apply = function (editor, name) {
    const data = SC.find(editor, name);
    if (!data) return false;
    if (editor.playing) editor.stop();
    editor.undoStack.length = 0;
    editor.redoStack.length = 0;
    editor.restore(data, { dirty: false });
    editor.sceneName = data.name || 'Untitled Scene';
    editor.scene.name = editor.sceneName;
    editor.dirty = false;
    const cam = editor.scene.nodes.find((n) => n.type === 'camera');
    if (cam) editor.selected = cam.id;
    editor.emit('selection', editor.selected);
    editor.emit('structure');
    return true;
  };

  SC.changerDefaults = function () {
    return {
      enabled: true,
      title: 'SCENE CHANGER',
      scenes: ['Sample Scene', '3D Platformer', 'First-Person Arena', 'UI Toolkit Demo'],
      visible: true,
      showInEditor: true,
    };
  };

  /* Look up the scene changer component in a scene. */
  SC.changer = function (scene) {
    return scene.nodes.find((n) => n.sceneChanger && n.sceneChanger.enabled !== false && n.active !== false) || null;
  };

  /* Renders the in-game scene menu. Called once per frame from app.js. */
  let menu = null;
  let menuSig = '';
  SC.updateChanger = function (editor) {
    const viewport = document.getElementById('viewport');
    if (!viewport) return;
    const found = SC.changer(editor.scene);
    const comp = found ? found.sceneChanger : null;
    const shouldShow = (editor.viewMode === 'game' || editor.playing) &&
      !!comp && comp.enabled !== false && comp.visible !== false &&
      (editor.playing || comp.showInEditor !== false);
    if (!menu) {
      menu = document.createElement('div');
      menu.id = 'scene-changer';
      menu.className = 'scene-changer hidden';
      viewport.appendChild(menu);
    }
    if (!shouldShow) {
      menu.classList.add('hidden');
      menuSig = '';
      return;
    }
    const scenes = (comp.scenes || []).filter(Boolean);
    const sig = JSON.stringify([comp.title, scenes, editor.sceneName]);
    menu.classList.remove('hidden');
    if (sig === menuSig) return;
    menuSig = sig;
    while (menu.firstChild) menu.removeChild(menu.firstChild);
    const head = document.createElement('div');
    head.className = 'scene-changer-head';
    head.textContent = comp.title || 'SCENE CHANGER';
    menu.appendChild(head);
    for (const name of scenes) {
      const b = document.createElement('button');
      b.className = 'scene-changer-item' + (name === editor.sceneName ? ' active' : '');
      b.textContent = name;
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        if (name === editor.sceneName) return;
        if (!editor.gotoScene(name, { play: editor.playing })) {
          editor.log('warn', 'Scene "' + name + '" was not found.');
          if (UW.UI && UW.UI.toast) UW.UI.toast('Scene not found: ' + name, 'warn');
        }
      });
      menu.appendChild(b);
    }
    const hint = document.createElement('div');
    hint.className = 'scene-changer-hint';
    hint.textContent = editor.playing ? 'Click to switch · Esc stops Play' : 'Press Play to use the menu';
    menu.appendChild(hint);
  };

  SC.clearChanger = function () {
    if (menu) menu.classList.add('hidden');
    menuSig = '';
  };
})();
