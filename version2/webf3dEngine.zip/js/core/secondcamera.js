/* ============================================================
   secondcamera.js — in-game picture-in-picture camera
   Renders a second scene camera into a small DOM overlay using a
   private Native Canvas adapter. It never touches the active engine
   adapter, so it works on Three.js, Babylon.js, Native and plugins.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;
  const SC = (UW.SecondCamera = {});
  const STORE_KEY = 'webforge3d.pip';

  SC.enabled = true;
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw === '0') SC.enabled = false;
  } catch (e) { /* ignore */ }

  SC.setEnabled = function (on) {
    SC.enabled = on !== false;
    try { localStorage.setItem(STORE_KEY, SC.enabled ? '1' : '0'); } catch (e) { /* ignore */ }
    return SC.enabled;
  };

  SC.toggle = function () {
    return SC.setEnabled(!SC.enabled);
  };

  SC.find = function (editor) {
    if (!editor || !editor.scene) return null;
    const actives = UW.scene.activeMap(editor.scene);
    return editor.scene.nodes.find((n) =>
      n.type === 'camera' && n.camera && n.visible !== false &&
      actives.get(n.id) !== false && n.camera.secondary === true
    ) || null;
  };

  let host = null;
  let adapter = null;
  let lastSig = '';

  function ensureHost() {
    const viewport = document.getElementById('viewport');
    if (!viewport) return null;
    if (host && host.parentNode === viewport) return host;
    host = document.getElementById('pip');
    if (!host) {
      host = document.createElement('div');
      host.id = 'pip';
      host.className = 'pip hidden';
      host.setAttribute('aria-label', 'Second camera preview');
      const tools = document.getElementById('viewport-tools');
      if (tools && tools.parentNode === viewport) viewport.insertBefore(host, tools);
      else viewport.appendChild(host);
    } else {
      const tools = document.getElementById('viewport-tools');
      if (tools && tools.parentNode === viewport && host.nextSibling !== tools) viewport.insertBefore(host, tools);
    }
    return host;
  }

  function ensureAdapter() {
    if (adapter) return adapter;
    if (!UW.adapters || !UW.adapters.Native) return null;
    try {
      adapter = new UW.adapters.Native({ id: 'pip', name: 'Second Camera' });
      adapter.init(host).catch(() => {});
      adapter.canvas.style.width = '100%';
      adapter.canvas.style.height = '100%';
      adapter.canvas.style.display = 'block';
      adapter.canvas.style.pointerEvents = 'none';
    } catch (e) {
      adapter = null;
    }
    return adapter;
  }

  function hide() {
    if (host) host.classList.add('hidden');
    lastSig = '';
  }

  SC.render = function (editor) {
    const isGame = editor && (editor.viewMode === 'game' || editor.playing);
    const node = isGame && SC.enabled ? SC.find(editor) : null;
    if (!node || node.camera.pip && node.camera.pip.enabled === false) {
      hide();
      return;
    }
    const h = ensureHost();
    if (!h) return;
    const a = ensureAdapter();
    if (!a) { hide(); return; }

    const pip = node.camera.pip || {};
    const corner = ['topLeft', 'topRight', 'bottomLeft', 'bottomRight'].indexOf(pip.corner) >= 0
      ? pip.corner : 'bottomRight';
    const width = Math.max(120, Math.min(960, Number(pip.width) || 320));
    const height = Math.max(80, Math.min(640, Number(pip.height) || 200));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const sig = [node.id, corner, width, height, dpr].join('|');

    h.classList.remove('hidden');
    h.className = 'pip pip-' + corner;
    if (sig !== lastSig) {
      lastSig = sig;
      h.style.width = width + 'px';
      h.style.height = height + 'px';
      a.resize(width, height, dpr);
    }

    const wm = editor.world().get(node.id) || M.mat4.identity();
    const eye = [wm[12], wm[13], wm[14]];
    const forward = V.norm([-wm[8], -wm[9], -wm[10]]);
    let up = V.norm([wm[4], wm[5], wm[6]]);
    if (Math.abs(V.dot(forward, up)) > 0.999) up = [0, 0, 1];
    const target = V.add(eye, forward);
    const fov = Number(node.camera.fov) || 55;
    const near = Math.max(0.01, Number(node.camera.near) || 0.1);
    const far = Math.max(near + 0.1, Number(node.camera.far) || 600);
    const aspect = width / Math.max(1, height);

    const cam = {
      eye,
      target,
      up,
      fov,
      near,
      far,
      aspect,
      width,
      height,
      view: M.mat4.lookAt(eye, target, up),
      proj: M.mat4.perspective(fov, aspect, near, far),
      backgroundColor: node.camera.bg || editor.scene.env.fogColor || '#1d2025',
    };

    a.update({
      scene: editor.scene,
      cam,
      viewMode: 'game',
      selected: null,
      env: editor.scene.env || {},
      time: editor.time,
    });
    try { a.render(); } catch (e) { /* the PiP preview must never break the editor */ }
  };

  SC.dispose = function () {
    if (adapter) {
      try { adapter.dispose(); } catch (e) { /* ignore */ }
      adapter = null;
    }
    if (host && host.parentNode) host.parentNode.removeChild(host);
    host = null;
    lastSig = '';
  };
})();
