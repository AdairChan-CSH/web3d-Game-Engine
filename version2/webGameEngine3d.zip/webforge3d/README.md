# WebForge 3D

A Unity-inspired 3D scene editor that runs in the browser using **only HTML, CSS and vanilla JavaScript**.

There is no build step, no Node.js, no Python, no database and no web server requirement. The entire editor is a set of static files. Three.js and Babylon.js are loaded on demand from their CDNs; a built-in software renderer keeps the editor fully usable offline.

**Runs offline · No build step · No runtime dependencies · Pluggable engines**

---

## Quick start

1. Open `webforge3d/index.html` directly in a modern browser (double-click it).
2. Wait for the default engine to load. With an internet connection the editor starts on Three.js; if the CDN is unavailable it automatically falls back to **Native Canvas** and keeps working.
3. Click objects in the viewport or Hierarchy, move them with the gizmo, press **Ctrl + P** to play.

Or, if you prefer serving the folder:

```sh
# any static server works
python -m http.server 8000
# then visit http://localhost:8000/
```

No installation step is required either way.

### Browser support

Chrome, Edge, Firefox and Safari (current versions). WebGL is used by Three.js and Babylon.js; **Native Canvas** needs only Canvas 2D.

---

## What is included

| Area | Features |
| --- | --- |
| **Scene editing** | Hierarchy with parenting, rename, duplicate, delete, visibility, search |
| **Inspector** | Transform, mesh material, texture, light, camera, rigidbody, behaviors, JavaScript script, FSM |
| **Viewport** | Orbit / pan / zoom, ray-pick selection, focus, grid, Scene & Game views |
| **Gizmos** | Move, rotate and scale handles; World/Local space; drag snapping with Shift |
| **Lights** | Directional / Sun, Point and Spot lights with range, cone angle and penumbra |
| **Environment** | Ambient intensity and color, grid toggle, distance fog (color, near, far) |
| **Textures** | 10 procedural presets, image upload, built-in painter, tiling/offset, enable/remove |
| **Visual FSM** | PlayMaker-style state graph: states, six trigger types, variables, 58 ordered actions in 11 categories |
| **Play mode** | Play / pause / step / stop, runtime scripts, behaviors, FSM, AABB rigidbody physics |
| **Engines** | Three.js, Babylon.js, Native Canvas, plus runtime engine plugins with a capability matrix |
| **Persistence** | Named scenes in `localStorage`, JSON download/import, drag-and-drop `.json` |
| **Editing comfort** | Undo/redo history, keyboard shortcuts, console with script errors, FPS/triangle stats |
| **Extras** | Viewport screenshot, help/API dialogs, engine panel with per-engine docs |

The sample scene is a small physics playground: ground, cube, spinning sphere, falling cylinder, torus, light and camera.

---

## Editor tour

- **Menu bar** — File, Edit, GameObject, Component, Window, Engine, Help.
- **Toolbar** — transform tools (`Q W E R`), World/Local space, play controls, engine picker, Scene/Game toggle.
- **Hierarchy (left)** — scene tree, search, create button, focus button. Double-click focuses an object; drag a row onto another to re-parent it.
- **Engines panel (left)** — click a card (or the toolbar select) to switch renderers. Switching never modifies the scene. The last used engine is remembered.
- **Viewport (center)** — the 3D scene, selection outline, gizmo overlay and a drop zone for scene files.
- **Project panel (bottom)** — primitives, actors, saved scenes and the Console.
- **Inspector (right)** — live properties of the selection. Numeric transforms update the viewport immediately and create undo entries.
- **Status bar** — engine name, object/triangle counts, FPS, play time.

---

## Controls

| Action | Input |
| --- | --- |
| Select tool | `Q` |
| Move / Rotate / Scale | `W` / `E` / `R` |
| Orbit viewport | Left-drag empty space |
| Pan viewport | Middle-drag or `Shift` + left-drag |
| Zoom viewport | Mouse wheel |
| Select object | Left-click in viewport or Hierarchy |
| Focus selection | `F` or double-click |
| Play / stop | `Ctrl + P` (or toolbar) |
| Pause | `Ctrl + Shift + P` |
| Step one frame | Toolbar step button (while paused) |
| Undo / redo | `Ctrl + Z` / `Ctrl + Y` or `Ctrl + Shift + Z` |
| Duplicate | `Ctrl + D` |
| Delete | `Delete` / `Backspace` |
| Save scene | `Ctrl + S` |
| New scene | `Ctrl + N` |
| Open saved scene | `Ctrl + O` |
| Snap while dragging | Hold `Shift` |
| Escape | Stop play mode, or clear selection |
| Help | `F1` |

Inside a text field, typing shortcuts are ignored so names and scripts can be edited normally.

---

## Engines

### Built-in engines

| Engine | Source | Notes |
| --- | --- | --- |
| **Three.js r157** | jsDelivr CDN | PBR materials, soft shadows, WebGL |
| **Babylon.js 8.x** | babylonjs.com CDN | PBR materials, shadows, right-handed scene |
| **Native Canvas** | included | Software painter's-algorithm renderer; no CDN, no WebGL |

The editor is engine-agnostic: hierarchy, inspector, gizmos, play mode, scripts and saving all operate on a shared scene model. Adapters only draw that model.

### Switching and fallback

- Pick an engine from the toolbar select, the **Engine** menu, or the **Engines** panel.
- CDN engines are fetched the first time they are selected, then reused.
- Script loads time out after 20 seconds.
- If a CDN engine cannot start (offline, blocked, WebGL missing), the editor logs the error and falls back to **Native Canvas** instead of leaving a blank viewport.
- The choice is stored in `localStorage` under `webforge3d.engine`.

### Plugin / connect flow

`Engine → Connect engine plugin…` (or the `+ Connect engine…` card) asks for a plain JavaScript URL. The script is loaded at runtime and may register one or more engines with `UnityWeb.engines.register({...})`. Relative paths such as `plugins/blueprint-canvas.js` work when the editor is served over HTTP; from `file://`, use a path relative to `index.html` or a CDN URL.

A working example ships in [`plugins/blueprint-canvas.js`](plugins/blueprint-canvas.js). It subclasses the built-in Canvas renderer and restyles it as a drafting blueprint. See [`plugins/README.md`](plugins/README.md) for the full adapter contract.

Each engine definition may declare a `capabilities` object. The editor uses it to build the compatibility matrix and the capability rows in the Engines panel; undeclared features appear as **Unknown** rather than being guessed.

### Compatibility

Open **Window → Engine Compatibility…**, **Engine → Engine compatibility…** or **Help → Engine compatibility matrix** for a live table. The active engine is highlighted, and every chip can carry a tooltip explaining its limitation.

Everything except rendering is shared and therefore identical across engines:

| Shared (always available) | Renderer-dependent |
| --- | --- |
| Scene model, hierarchy, transforms, undo/redo | Shadows and shadow quality |
| Gizmos, picking, camera controls | PBR / metalness / roughness |
| Saving, JSON import/export | Point and spot light shading |
| Play mode, scripts, behaviors, AABB physics | Fog quality |
| **All FSM actions and transition triggers** | Texture filtering and anti-aliasing |
| Audio and toasts | Wireframe and transparency details |

| Feature | Three.js | Babylon.js | Native Canvas |
| --- | --- | --- | --- |
| Shadows | Full | Full | None |
| Directional / point / spot lights | Full | Full | Full |
| Fog | Full | Full | Full |
| Textures and tiling | Full | Full | Full |
| Transparency / wireframe | Full | Full | Full |
| PBR shading | Full | Full | Partial (approximate) |
| Anti-aliasing | Full | Full | Partial |
| Works offline | No (CDN) | No (CDN) | Yes |

A renderer that cannot draw shadows still runs every shadow-related FSM action: the action writes scene data, and the next engine that supports shadows will show the result. Switching engines never rewrites the scene.

---

## Lights and environment

Create lights from **GameObject → Light** or the Project panel:

| Light | Behaviour |
| --- | --- |
| **Directional / Sun** | Parallel light; direction comes from the object rotation (+Z axis) |
| **Point** | Omnidirectional light with a range falloff |
| **Spot** | Cone light along the object +Z axis with range, cone angle and penumbra |

Select a light to edit its color, intensity, range and — for spot lights — cone angle and penumbra in the Inspector. The same values drive all three renderers, so switching engines does not change the lighting setup.

**Window → Environment / Lighting…** edits scene-wide settings:

- **Ambient** intensity and color.
- **Grid** visibility in the Scene view.
- **Fog** — enable it, then set color, near and far distances. Fog is applied by Three.js, Babylon.js and the Native Canvas renderer.

---

## Textures and painting

Every mesh can carry one texture. Add it from **Component → Texture / Material**, the Inspector **Add Component** menu, or **Window → Texture Painter…**. Textures are stored as plain scene data, so they survive engine switches, undo/redo, saving, JSON export and Play mode.

- **Presets** — checker, grid, bricks, tiles, noise, gradient, stripes, dots, wood and marble.
- **Upload** — pick any image up to 4 MB; it is embedded in the scene as a data URL.
- **Paint** — the built-in painter works on a 512×512 canvas with brush/eraser, size, color, fill and clear. *Save texture* stores the painting in the scene, so no asset folder is needed.
- **Tiling / Offset** — repeat the image across UVs and shift it; the Inspector shows a live preview.
- **Visible** — temporarily disable a texture without removing it. The remove button deletes the component.

The Native Canvas renderer maps textures per triangle with Canvas 2D affine transforms using cached tiled patterns, so painting and texturing work completely offline. Three.js uses a `CanvasTexture` with repeat/offset; Babylon.js uses a `DynamicTexture`.

---

## Visual finite state machine (PlayMaker style)

Add **Component → PlayMaker FSM** to any object, then open **Open Graph Editor** in the Inspector or **Window → FSM Graph Editor…**.

The graph editor is a modal canvas of draggable state cards connected by arrows:

- **Add State** — create a state; drag cards to arrange the graph.
- **→ Link States** — click a source state, then a target state to add a transition.
- **Click a state** — edit its name, mark it as the start state, and build its **actions on entry**.
- **Click an arrow** — edit the transition trigger.
- **Variables** — add FSM-local variables used by conditions and actions.

Transitions support six triggers:

| Trigger | Fires when |
| --- | --- |
| **After delay** | The source state has been active for at least `delay` seconds |
| **On event** | A matching event is emitted (`ctx.emitEvent("done")` or an FSM *Send event* action) |
| **While key held** | The key is down, checked every frame (`KeyboardEvent.key` names such as `Space` or `ArrowUp`) |
| **On key down** | The frame the key is first pressed |
| **On key up** | The frame the key is released |
| **On variable** | A variable satisfies `==`, `!=`, `>`, `<`, `>=` or `<=` against a value |

The first matching transition from the current state is taken each frame.

### Actions

States run an **ordered action queue** when they are entered. Add actions from the grouped picker in the state panel; each card shows its category, a one-line description and its parameters. Actions with a **Target** field accept `self`, `parent`, a node name or a node id, so one state can drive other objects.

| Category | Actions |
| --- | --- |
| **Flow** | Log message · Wait · Send event · Start FSM · Stop FSM · Restart FSM · Enable / disable FSM |
| **Transform** | Move (relative) · Rotate (relative) · Set position / rotation / scale · Move to (tween) · Move by (tween) · Rotate to (tween) · Scale to (tween) · Look at point · Look at object · Reset transform · Stop tweens |
| **Variables & Math** | Set / add / multiply / clamp variable · Random float · Random integer · Toggle variable · Copy variable · Get transform value |
| **Logic & Scene** | Branch on variable · Set ambient light · Set fog |
| **GameObject** | Set visible · Toggle visible · Set parent |
| **Material & Texture** | Set color · Set opacity · Set wireframe · Set texture preset · Set texture tiling · Set texture offset · Remove texture |
| **Lighting** | Set light color / intensity / range / spot angle / spot penumbra · Toggle light |
| **Camera** | Set camera FOV · Set camera clipping · Set camera background |
| **Physics** | Add impulse · Set velocity · Set body gravity · Set world gravity |
| **Audio** | Play tone (synthesised with `AudioContext`) · Stop all audio |
| **Debug & UI** | Show toast |

Tween actions (`Move to`, `Move by`, `Rotate to`, `Scale to`) take a duration, an easing curve and **Wait for finish**. When *Wait for finish* is on, the rest of the action list waits until that tween completes; turn it off to start the next action immediately. *Wait* pauses the queue for a number of seconds. *Stop tweens* cancels the object's running tweens.

FSMs only run in Play mode. Stopping restores the pre-play snapshot like every other runtime feature. Actions never call a renderer directly — they read and write the shared scene model and runtime — so the same FSM behaves identically on Three.js, Babylon.js, Native Canvas and third-party plugins.

---

## Play mode

Play mode runs a small engine-independent simulation:

- **Rigidbody** — meshes with the component fall under gravity and collide with the ground, static meshes and other rigidbodies using AABB resolution. Physics runs on root objects only; a warning is logged for parented rigidbodies.
- **Behaviors** — preset component logic added from the Inspector or Component menu:
  - `spin` — constant rotation in degrees/second
  - `bob` — vertical sine motion
  - `pulse` — scale oscillation
  - `orbit` — circular motion around the origin
- **JavaScript Script** — user code with `onStart`, `onUpdate` and `onStop` hooks.
- **Visual FSM** — PlayMaker-style state machines with delay, event, held-key, key-down, key-up and variable transitions, plus 58 built-in actions (see above).
- **Step** — advances exactly one frame while paused.
- **Stop** — restores the exact pre-play scene snapshot and calls `onStop`.

### Script API

Add **Add Component → JavaScript Script** to an object, then edit it in the Inspector (or the Scripts dialog). Scripts compile with `new Function` and run only in Play mode.

```js
let t = 0;

function onStart(ctx) {
  ctx.log("ready: " + ctx.node.name);
}

function onUpdate(ctx, dt) {
  t += dt;
  ctx.node.transform.rotation.y += 40 * dt;
  ctx.node.transform.position.y = 0.5 + Math.sin(t * 2) * 0.3;
}

function onStop(ctx) {
  ctx.log("stopped");
}
```

The context object provides:

| Field | Meaning |
| --- | --- |
| `ctx.node` | The live scene node (transform, mesh, light, camera, rigidbody, …) |
| `ctx.scene` | The whole scene object (`{ version, name, env, nodes }`) |
| `ctx.find(name)` | Find another node by name |
| `ctx.log(...)` | Print to the editor Console |
| `ctx.setColor(hex)` | Shortcut for `ctx.node.mesh.color` |
| `ctx.emitEvent(name)` | Send an event to FSMs waiting on it |
| `ctx.time` | Seconds since play started |
| `ctx.dt` | Current frame delta |
| `ctx.editor` | Editor instance (advanced) |
| `ctx.engine` | Active engine display name |
| `ctx.vec`, `ctx.math` | Shared vector and matrix helpers |

Compile and runtime errors appear in the Console; each failing script is reported once to avoid console spam.

---

## Saving and loading

- **Save Scene** (`Ctrl + S`) stores a named entry in `localStorage` key `webforge3d.scenes.v1`. Up to 30 scenes are kept; saving the same name overwrites it.
- **Open Scene** (`Ctrl + O`) lists saved scenes and can delete entries.
- **File → Download scene as .json** exports the plain-JSON scene.
- **File → Import scene .json…** or dropping a `.json` file on the viewport imports one.
- Imported data is normalized: missing transforms, mesh fields and parent links are repaired; invalid files are rejected with a toast.
- Scene names also appear in the Project panel for one-click loading.

`localStorage` is scoped to the origin. A scene saved while opening `index.html` from disk is not visible when the same folder is later served over HTTP (and vice versa). Use JSON export to move scenes between them.

Uploaded and painted textures are embedded in the scene as data URLs (uploads are capped at 4 MB each), so scenes with many large textures can exceed the browser's storage quota. If saving reports that storage is full, download the scene as JSON instead — JSON export has no quota.

### Scene JSON format

```json
{
  "version": 1,
  "name": "Sample Scene",
  "env": {
    "ambient": 0.42,
    "ambientColor": "#ffffff",
    "showGrid": true,
    "fogEnabled": false,
    "fogColor": "#1d2025",
    "fogNear": 14,
    "fogFar": 70
  },
  "nodes": [
    {
      "id": "n_cube",
      "name": "Cube",
      "parent": null,
      "type": "mesh",
      "visible": true,
      "transform": {
        "position": [0, 0.5, 0],
        "rotation": [0, 0, 0],
        "scale": [1, 1, 1]
      },
      "mesh": {
        "shape": "cube",
        "color": "#c7cdd6",
        "roughness": 0.6,
        "metalness": 0.08,
        "wireframe": false,
        "opacity": 1,
        "texture": {
          "enabled": true,
          "preset": "bricks",
          "data": null,
          "tiling": [2, 1],
          "offset": [0, 0]
        }
      },
      "rigidbody": { "mass": 1, "useGravity": true, "restitution": 0.25 },
      "behaviors": [
        { "id": "b1", "kind": "spin", "params": { "x": 0, "y": 55, "z": 0 } }
      ],
      "script": { "name": "NewBehavior", "code": "function onUpdate(ctx, dt) { ... }" },
      "fsm": {
        "enabled": true,
        "start": "s_idle",
        "states": [
          {
            "id": "s_idle",
            "name": "Idle",
            "x": 46,
            "y": 62,
            "actions": [
              { "type": "setColor", "params": { "color": "#5b9bd5" } }
            ]
          }
        ],
        "transitions": [
          { "id": "t1", "from": "s_idle", "to": "s_idle", "trigger": "auto", "delay": 1, "event": "done", "key": "Space", "variable": "", "op": "==", "value": "" }
        ],
        "variables": [{ "name": "score", "value": "0" }]
      }
    }
  ]
}
```

Details:

- `parent` is a node `id` or `null`; transforms are local to the parent.
- `type` is one of `empty`, `mesh`, `light`, `camera`.
- `mesh.shape` is one of `cube`, `sphere`, `cylinder`, `cone`, `torus`, `capsule`, `plane`.
- `mesh.texture` is optional; `preset` names a procedural preset (`checker`, `bricks`, …) or `painted` / `uploaded` when `data` holds a data URL.
- `rotation` is stored in degrees (Euler XYZ); engines receive the converted values.
- `light` uses `{ kind: "directional" | "point" | "spot", color, intensity, range, angle, penumbra }`; `angle` and `penumbra` apply to spots.
- `camera` uses `{ fov, near, far, bg }`; the Game view renders through the first visible camera node.
- `fsm.states[].actions[].type` is any of the 58 action ids from the Actions table (`log`, `moveTo`, `setVariable`, `playTone`, …); the action's settings live in `params`.
- `fsm.transitions[].trigger` is `auto`, `event`, `key`, `keyDown`, `keyUp` or `variable`.
- Optional components are simply absent when not attached (`mesh`, `light`, `camera`, `rigidbody`, `script`, `behaviors`, `fsm`).

The same objects are used at runtime, so plugins and scripts can read and mutate them directly.

---

## Project layout

```
webforge3d/
├─ index.html                 editor shell + script includes
├─ css/editor.css             dark theme and layout
├─ js/
│  ├─ core/
│  │  ├─ math.js              vectors, mat4, ray/AABB helpers
│  │  ├─ geometry.js          shared CPU meshes (7 primitive shapes) + UVs
│  │  ├─ textures.js          procedural, painted and uploaded texture library
│  │  ├─ fsm.js               FSM schema, actions and runtime runner
│  │  ├─ scene.js             scene schema, transforms, serialization
│  │  ├─ editor.js            selection, history, play state, storage
│  │  ├─ camera.js            editor rig and Game-view camera projection
│  │  ├─ gizmo.js             move/rotate/scale handles on a 2D overlay
│  │  └─ runtime.js           play-mode behaviors, scripts, FSM, AABB physics
│  ├─ engines/
│  │  ├─ registry.js          engine registry + lazy script loader
│  │  ├─ native.js            offline Canvas 2D renderer (plugin base class)
│  │  ├─ three.js             Three.js adapter
│  │  └─ babylon.js           Babylon.js adapter
│  ├─ ui/
│  │  ├─ ui.js                menus, hierarchy, inspector, dialogs, console
│  │  └─ graph.js             PlayMaker-style FSM graph editor
│  └─ app.js                  boot, frame loop, engine switching, input
└─ plugins/
   ├─ blueprint-canvas.js     example engine plugin
   └─ README.md               plugin authoring guide
```

All scripts are classic `<script>` tags in dependency order. Nothing is bundled or transpiled, and no ES modules are required, so `file://` works.

---

## Extending

### Add an engine

1. Create a plain script, e.g. `plugins/my-engine.js`.
2. Call `UnityWeb.engines.register({ id, name, load, create })`.
3. In `load()`, inject the engine runtime (script tag, dynamic `import()` of a CDN module, WASM, etc.).
4. In `create(def)`, return an adapter implementing `init`, `resize`, `update`, `render`, `getStats`, `dispose`.
5. Load it with **Engine → Connect engine plugin…** or add a `<script>` tag to `index.html`.

Full contract and a commented skeleton are in [`plugins/README.md`](plugins/README.md).

### Add a primitive

Add a builder to `js/core/geometry.js` and a `{ id, label, icon }` entry to its `SHAPES` list. The GameObject menu, Project panel and scene serializer pick it up automatically.

### React to editor state

```js
UnityWeb.app.editor.on('selection', (id) => console.log('selected', id));
```

Events: `structure`, `values`, `transform`, `selection`, `restore`, `play`, `tool`, `space`, `view`, `log`, `saved`, `history`, `engine`, `engine-loading`, `fps`, `tick`, `camera`.

---

## Limitations

This is a compact editor, not a full game engine:

- Mesh collision is AABB-based; no compound colliders, constraints or continuous collision detection.
- Physics, behaviors and scripts are Play-mode only, and physics ignores parented rigidbodies.
- Geometry is procedural; there is no model importer (OBJ/GLB), animation system or terrain tool.
- Materials are one color/roughness/metalness set plus one optional texture per mesh; there are no multi-map PBR materials.
- FSMs are intentionally compact: one active state per object, no sub-machines, no transition animations or blend trees. Entry actions run in an ordered queue, and tween actions can block the rest of that queue until they finish.
- The Native Canvas renderer is a painter's-algorithm rasterizer without shadows, reflections or post-processing; it does support textures, spot lights and fog.
- Scenes live in browser storage unless exported as JSON. There is no cloud sync.
- Opening from `file://` works, but CDN engines need internet access and some browsers restrict storage for local files. Prefer a static server for long-term work.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| Viewport is blank on first load | Wait for the engine badge to stop saying “loading…”. Offline, the editor falls back to Native Canvas automatically. |
| Three.js / Babylon.js never load | Check the internet connection or a blocking extension; switch to **Native Canvas**. |
| Saved scenes are missing | Make sure you open the editor from the same origin/path as before, or import the exported JSON. |
| Plugin does not appear | Confirm the script URL is reachable and that it calls `UnityWeb.engines.register(...)` without errors; see the Console. |
| Script does nothing | Scripts run only after **Play**; compile/runtime errors are shown in the Console. |
| Low FPS in Native Canvas | It is a software renderer; reduce object/mesh counts or switch to a WebGL engine. |

---

## License

Editor code: use freely for learning and prototyping. Three.js is MIT licensed; Babylon.js is Apache 2.0. The engine adapters load those projects from their official CDNs without modifying them.
