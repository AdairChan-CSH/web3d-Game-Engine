/* ============================================================
   editor.js — editor state: selection, undo, play mode, storage
   UI-agnostic. The UI subscribes to the events emitted here.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const STORE_KEY = 'webforge3d.scenes.v1';

  UW.Editor = class Editor {
    constructor() {
      this.scene = UW.scene.defaultScene();
      this.sceneName = this.scene.name;
      this.selected = 'n_cube';
      this.tool = 'translate';
      this.space = 'world';
      this.viewMode = 'scene';
      this.camera = { yaw: 0.68, pitch: 0.33, distance: 12.5, target: [0, 1.05, 0] };
      this.playing = false;
      this.paused = false;
      this.time = 0;
      this.runtime = null;
      this.engineId = null;
      this.engineName = '—';
      this.showGrid = true;
      this.undoStack = [];
      this.redoStack = [];
      this.limit = 60;
      this.logs = [];
      this._logSeq = 0;
      this._edit = null;
      this._listeners = new Map();
      this.dirty = false;
      this.everPlayed = false;
      this.log('info', 'WebForge 3D ready — ' + this.scene.nodes.length + ' objects in scene.');
    }

    /* ---------------- events ---------------- */
    on(evt, fn) {
      if (!this._listeners.has(evt)) this._listeners.set(evt, []);
      this._listeners.get(evt).push(fn);
      return () => this.off(evt, fn);
    }
    off(evt, fn) {
      const list = this._listeners.get(evt);
      if (!list) return;
      this._listeners.set(evt, list.filter((f) => f !== fn));
    }
    emit(evt, data) {
      const list = this._listeners.get(evt);
      if (list) for (const fn of list.slice()) fn(data);
    }

    /* ---------------- queries ---------------- */
    get nodes() {
      return this.scene.nodes;
    }
    node(id) {
      return UW.scene.find(this.scene, id);
    }
    get selectedNode() {
      return this.selected ? this.node(this.selected) : null;
    }
    world() {
      return UW.scene.worldMatrices(this.scene);
    }

    /* ---------------- selection ---------------- */
    select(id, silent) {
      const next = id && this.node(id) ? id : null;
      if (next === this.selected) {
        if (!silent) this.emit('selection', next);
        return;
      }
      this.selected = next;
      if (!silent) this.emit('selection', next);
    }

    /* ---------------- mode ---------------- */
    setTool(tool) {
      if (this.tool === tool) return;
      this.tool = tool;
      this.emit('tool', tool);
    }
    setSpace(space) {
      if (this.space === space) return;
      this.space = space;
      this.emit('space', space);
    }
    setViewMode(mode) {
      if (this.viewMode === mode) return;
      this.viewMode = mode;
      this.emit('view', mode);
    }
    setEngine(id, name) {
      this.engineId = id;
      this.engineName = name;
      this.emit('engine', { id, name });
    }

    /* ---------------- object creation ---------------- */
    parentForNew() {
      const sel = this.selectedNode;
      if (!sel) return null;
      return sel.type === 'mesh' || sel.type === 'empty' ? sel.id : null;
    }

    addNode(kind, opts = {}) {
      const label = kind === 'empty' ? 'Create Empty' : kind === 'camera' ? 'Create Camera' : kind.indexOf('light') === 0 ? 'Create Light' : 'Create ' + UW.geom.shapeLabel(kind);
      return this.transact(label, () => {
        const parent = opts.parent !== undefined ? opts.parent : this.parentForNew();
        const node = UW.scene.createNode(kind, {
          parent,
          position: opts.position || this.spawnPosition(parent),
          scale: opts.scale,
          name: opts.name,
        });
        node.name = UW.scene.uniqueName(this.scene, node.name);
        this.scene.nodes.push(node);
        this.selected = node.id;
        return node;
      }, { select: true });
    }

    spawnPosition(parentId) {
      const p = this.camera.target.slice();
      p[0] = M.round(p[0], 2);
      p[2] = M.round(p[2], 2);
      if (parentId) {
        const parent = this.node(parentId);
        const world = this.world();
        const pw = world.get(parentId);
        if (parent && pw) {
          const lp = M.mat4.point(M.mat4.invert(pw), p);
          return [M.round(lp[0], 2), 0.5, M.round(lp[2], 2)];
        }
      }
      p[1] = 0.5;
      return p;
    }

    addPrimitive(shape) {
      const colorMap = {
        cube: '#c7cdd6', sphere: '#5b9bd5', cylinder: '#d9a441',
        cone: '#cf7f6a', torus: '#9d86e0', capsule: '#6fb59a', plane: '#5a6470',
      };
      const parent = this.parentForNew();
      const spawn = this.spawnPosition(parent);
      const position = spawn.slice();
      let scale;
      if (shape === 'plane') {
        position[1] = 0;
        scale = [8, 1, 8];
      }
      if (shape === 'capsule') position[1] = 0.5;
      const node = this.addNode(shape, { parent, position, scale, color: colorMap[shape] });
      this.emit('structure');
      return node;
    }

    deleteNode(id) {
      const node = this.node(id);
      if (!node) return;
      const doomed = new Set([id, ...UW.scene.descendants(this.scene, id).map((n) => n.id)]);
      this.transact('Delete ' + node.name, () => {
        this.scene.nodes = this.scene.nodes.filter((n) => !doomed.has(n.id));
        if (doomed.has(this.selected)) this.selected = null;
      }, { select: true });
    }

    duplicateNode(id) {
      const clone = UW.scene.cloneSubtree(this.scene, id);
      if (!clone) return;
      this.transact('Duplicate ' + clone.root.name, () => {
        clone.root.name = UW.scene.uniqueName(this.scene, clone.root.name);
        this.scene.nodes.push(...clone.nodes);
        this.selected = clone.root.id;
      }, { select: true });
    }

    reparent(id, newParentId) {
      const node = this.node(id);
      if (!node) return;
      if (newParentId === id) return;
      const desc = UW.scene.descendants(this.scene, id).map((n) => n.id);
      if (desc.includes(newParentId)) return;
      this.transact('Reparent ' + node.name, () => {
        node.parent = newParentId || null;
      });
    }

    renameNode(id, name) {
      const node = this.node(id);
      if (!node || !name || node.name === name) return;
      this.transact('Rename', () => { node.name = name; });
    }

    toggleVisible(id) {
      const node = this.node(id);
      if (!node) return;
      this.transact('Toggle visibility', () => { node.visible = !node.visible; });
    }

    addBehavior(id, kind) {
      const node = this.node(id);
      if (!node) return;
      const presets = {
        spin: { x: 0, y: 60, z: 0 },
        bob: { amplitude: 0.3, speed: 1.6 },
        pulse: { amount: 0.18, speed: 2.4 },
        orbit: { radius: 2.2, speed: 40, height: 0 },
      };
      this.transact('Add behavior', () => {
        node.behaviors = node.behaviors || [];
        node.behaviors.push({ id: UW.scene.uid(), kind, params: Object.assign({}, presets[kind] || {}) });
      });
    }

    removeBehavior(id, behaviorId) {
      const node = this.node(id);
      if (!node) return;
      this.transact('Remove behavior', () => {
        node.behaviors = node.behaviors.filter((b) => b.id !== behaviorId);
      });
    }

    addComponent(id, type) {
      const node = this.node(id);
      if (!node) return;
      this.transact('Add ' + type, () => {
        if (type === 'rigidbody') node.rigidbody = { mass: 1, useGravity: true, restitution: 0.3 };
        if (type === 'script') node.script = { name: 'NewBehavior', code: DEFAULT_SCRIPT };
        if (type === 'texture' && node.mesh) node.mesh.texture = UW.textures.defaultTexture('checker');
        if (type === 'fsm') node.fsm = UW.FSM.defaults();
        if (type === 'camera') {
          node.type = 'camera';
          node.camera = node.camera || { fov: 55, near: 0.1, far: 600, bg: '#1d2025' };
          delete node.mesh;
        }
      });
    }

    removeComponent(id, type) {
      const node = this.node(id);
      if (!node) return;
      this.transact('Remove ' + type, () => {
        if (type === 'rigidbody') delete node.rigidbody;
        if (type === 'script') delete node.script;
        if (type === 'texture' && node.mesh) delete node.mesh.texture;
        if (type === 'fsm') delete node.fsm;
        if (type === 'behaviors') node.behaviors = [];
      });
    }

    setEnv(key, value) {
      this.scene.env = this.scene.env || UW.scene.defaultEnv();
      this.scene.env[key] = value;
      this.touch();
    }

    /* ---------------- history ---------------- */
    serializeScene() {
      return JSON.stringify({
        version: 1,
        name: this.sceneName,
        env: this.scene.env,
        nodes: this.scene.nodes,
      });
    }

    snapshot() {
      return this.serializeScene();
    }

    restore(json, opts = {}) {
      const data = typeof json === 'string' ? JSON.parse(json) : JSON.parse(JSON.stringify(json));
      this.scene = UW.scene.normalize(data);
      this.sceneName = this.scene.name || 'Untitled Scene';
      if (this.selected && !this.node(this.selected)) this.selected = null;
      if (!opts.keepSelection) this.selected = this.node(this.selected) ? this.selected : null;
      this.dirty = !!opts.dirty;
      this.emit('restore', this.scene);
      this.emit('structure');
      this.emit('selection', this.selected);
      this.emit('values');
    }

    pushUndo(before, label) {
      if (!before) return;
      const current = this.serializeScene();
      if (current === before) return;
      this.undoStack.push({ label: label || 'Edit', snapshot: before });
      if (this.undoStack.length > this.limit) this.undoStack.shift();
      this.redoStack.length = 0;
      this.dirty = true;
      this.emit('history');
    }

    transact(label, fn, opts = {}) {
      const before = this.serializeScene();
      const result = fn();
      this.pushUndo(before, label);
      this.dirty = true;
      if (opts.select) this.emit('selection', this.selected);
      this.emit('structure');
      this.emit('values');
      return result;
    }

    beginEdit() {
      if (!this._edit) this._edit = this.serializeScene();
    }
    commitEdit(label) {
      if (this._edit) {
        this.pushUndo(this._edit, label || 'Edit');
        this._edit = null;
      }
    }

    touch(structure) {
      this.dirty = true;
      if (structure) this.emit('structure');
      else this.emit('values');
    }

    undo() {
      const entry = this.undoStack.pop();
      if (!entry) return;
      this.redoStack.push({ label: entry.label, snapshot: this.serializeScene() });
      this.restore(entry.snapshot, { dirty: true });
      this.log('info', 'Undo: ' + entry.label);
    }

    redo() {
      const entry = this.redoStack.pop();
      if (!entry) return;
      this.undoStack.push({ label: entry.label, snapshot: this.serializeScene() });
      this.restore(entry.snapshot, { dirty: true });
      this.log('info', 'Redo: ' + entry.label);
    }

    canUndo() { return this.undoStack.length > 0; }
    canRedo() { return this.redoStack.length > 0; }

    /* ---------------- play mode ---------------- */
    play() {
      if (this.playing) return;
      this.playSnapshot = this.serializeScene();
      this.playing = true;
      this.paused = false;
      this.time = 0;
      this.everPlayed = true;
      this.runtime = new UW.Runtime(this);
      this.runtime.start();
      this.log('info', 'Play mode started.');
      this.emit('play', { playing: true, paused: false });
    }

    pause() {
      if (!this.playing) return;
      this.paused = !this.paused;
      this.emit('play', { playing: true, paused: this.paused });
    }

    step() {
      if (!this.playing) {
        this.play();
      }
      this.paused = true;
      if (this.runtime) {
        this.runtime.update(1 / 60);
        this.time += 1 / 60;
      }
      this.emit('play', { playing: true, paused: true });
      this.emit('values');
    }

    stop() {
      if (!this.playing) return;
      this.playing = false;
      this.paused = false;
      if (this.runtime && typeof this.runtime.stop === 'function') this.runtime.stop();
      this.runtime = null;
      if (this.playSnapshot) this.restore(this.playSnapshot, { dirty: true });
      this.time = 0;
      this.log('info', 'Play mode stopped — scene restored.');
      this.emit('play', { playing: false, paused: false });
    }

    update(dt) {
      if (this.playing && !this.paused && this.runtime) {
        this.runtime.update(dt);
        this.time += dt;
        this.emit('tick', dt);
      }
    }

    /* ---------------- camera ---------------- */
    focus(id) {
      const node = this.node(id || this.selected);
      if (!node) return;
      const wm = this.world().get(node.id) || M.mat4.identity();
      const wb = UW.scene.worldBounds(node, wm);
      const radius = Math.max(0.5, M.vec.dist(wb.max, wb.min) * 0.5);
      this.camera.target = wb.center.slice();
      this.camera.distance = Math.max(2.4, radius * 3.1);
      this.emit('camera');
    }

    resetCamera() {
      this.camera = { yaw: 0.68, pitch: 0.33, distance: 12.5, target: [0, 1.05, 0] };
      this.emit('camera');
    }

    /* ---------------- logging ---------------- */
    log(level, message) {
      const entry = {
        id: ++this._logSeq,
        level: level || 'info',
        message: String(message),
        time: new Date(),
      };
      this.logs.push(entry);
      if (this.logs.length > 300) this.logs.shift();
      this.emit('log', entry);
    }

    clearLogs() {
      this.logs.length = 0;
      this.emit('log', null);
    }

    /* ---------------- storage ---------------- */
    storage() {
      try {
        const raw = localStorage.getItem(STORE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    saveScene(name) {
      const entry = {
        name: name || this.sceneName || 'Untitled Scene',
        savedAt: Date.now(),
        data: JSON.parse(this.serializeScene()),
      };
      entry.data.name = entry.name;
      const list = this.storage().filter((s) => s.name !== entry.name);
      list.unshift(entry);
      try {
        localStorage.setItem(STORE_KEY, JSON.stringify(list.slice(0, 30)));
      } catch (e) {
        this.log('error', 'Could not save "' + entry.name + '" — browser storage is full. Use File → Download scene as .json instead.');
        return null;
      }
      this.sceneName = entry.name;
      this.scene.name = entry.name;
      this.dirty = false;
      this.log('info', 'Scene saved to browser storage: "' + entry.name + '".');
      this.emit('saved', entry);
      this.emit('structure');
      return entry;
    }

    loadScene(name) {
      const entry = this.storage().find((s) => s.name === name);
      if (!entry) return false;
      if (this.playing) this.stop();
      this.undoStack.length = 0;
      this.redoStack.length = 0;
      this.restore(entry.data);
      this.dirty = false;
      this.sceneName = entry.name;
      this.log('info', 'Loaded scene "' + entry.name + '".');
      return true;
    }

    deleteScene(name) {
      const list = this.storage().filter((s) => s.name !== name);
      localStorage.setItem(STORE_KEY, JSON.stringify(list));
      this.emit('saved', null);
    }
  };

  const DEFAULT_SCRIPT = `// Runs only in Play mode. Available: onStart(ctx), onUpdate(ctx, dt), onStop(ctx)
// ctx.node      -> live scene object (transform, mesh, ...)
// ctx.find(name) -> another object
// ctx.log(...)  -> editor console

let t = 0;

function onStart(ctx) {
  ctx.log("Hello from " + ctx.node.name);
}

function onUpdate(ctx, dt) {
  t += dt;
  ctx.node.transform.position.y += Math.sin(t * 3) * 0.004;
  ctx.node.transform.rotation.y += 40 * dt;
}
`;

  UW.DEFAULT_SCRIPT = DEFAULT_SCRIPT;

  UW.storageKey = STORE_KEY;
})();
