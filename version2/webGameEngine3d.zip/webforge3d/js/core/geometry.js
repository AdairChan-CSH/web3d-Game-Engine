/* ============================================================
   geometry.js — shared procedural primitives (non-indexed tris)
   Every engine (Three, Babylon, native canvas) renders these same
   buffers, so the scene looks identical no matter the engine.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const TAU = Math.PI * 2;

  function makeBuilder() {
    const pos = [];
    const nrm = [];
    return {
      pos, nrm,
      tri(a, b, c, na, nb, nc) {
        pos.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
        const an = na || [0, 1, 0];
        const bn = nb || an;
        const cn = nc || an;
        nrm.push(an[0], an[1], an[2], bn[0], bn[1], bn[2], cn[0], cn[1], cn[2]);
      },
      quad(a, b, c, d, n) {
        this.tri(a, b, c, n, n, n);
        this.tri(a, c, d, n, n, n);
      },
    };
  }

  function spherePoint(r, phi, theta) {
    const sp = Math.sin(phi);
    return [r * sp * Math.cos(theta), r * Math.cos(phi), r * sp * Math.sin(theta)];
  }

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* UVs are generated from local positions/normals so every primitive and
     every engine shares one texture layout. Wrapping shapes get seam-safe
     u values (the seam triangle is pushed one period forward). */
  function vertexUV(shape, x, y, z, nx, ny, nz) {
    if (shape === 'sphere') {
      const r = Math.hypot(x, y, z) || 1;
      return [Math.atan2(z, x) / TAU + 0.5, Math.acos(clamp(y / r, -1, 1)) / Math.PI];
    }
    if (shape === 'cylinder' || shape === 'cone' || shape === 'capsule') {
      return [Math.atan2(z, x) / TAU + 0.5, y + 0.5];
    }
    if (shape === 'torus') {
      const R = 0.35;
      return [Math.atan2(z, x) / TAU + 0.5, Math.atan2(y, Math.hypot(x, z) - R) / TAU + 0.5];
    }
    const ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
    if (ay >= ax && ay >= az) return [x + 0.5, z + 0.5];
    if (ax >= az) return [z + 0.5, y + 0.5];
    return [x + 0.5, y + 0.5];
  }

  function computeUVs(shape, pos, nrm) {
    const out = new Float32Array((pos.length / 3) * 2);
    const wraps = shape === 'sphere' || shape === 'cylinder' || shape === 'cone' ||
      shape === 'capsule' || shape === 'torus';
    for (let t = 0; t < pos.length; t += 9) {
      const us = [0, 0, 0];
      const vs = [0, 0, 0];
      for (let k = 0; k < 3; k++) {
        const i = t + k * 3;
        const uv = vertexUV(shape, pos[i], pos[i + 1], pos[i + 2], nrm[i], nrm[i + 1], nrm[i + 2]);
        us[k] = uv[0];
        vs[k] = uv[1];
      }
      if (wraps) {
        const lo = Math.min(us[0], us[1], us[2]);
        const hi = Math.max(us[0], us[1], us[2]);
        if (hi - lo > 0.5) {
          for (let k = 0; k < 3; k++) if (us[k] < 0.5) us[k] += 1;
        }
      }
      for (let k = 0; k < 3; k++) {
        const o = (t / 3 + k) * 2;
        out[o] = us[k];
        out[o + 1] = vs[k];
      }
    }
    return out;
  }

  const builders = {
    cube() {
      const b = makeBuilder();
      const h = 0.5;
      const n = {
        pz: [0, 0, 1], nz: [0, 0, -1], px: [1, 0, 0],
        nx: [-1, 0, 0], py: [0, 1, 0], ny: [0, -1, 0],
      };
      b.quad([-h, -h, h], [h, -h, h], [h, h, h], [-h, h, h], n.pz);
      b.quad([h, -h, -h], [-h, -h, -h], [-h, h, -h], [h, h, -h], n.nz);
      b.quad([h, -h, h], [h, -h, -h], [h, h, -h], [h, h, h], n.px);
      b.quad([-h, -h, -h], [-h, -h, h], [-h, h, h], [-h, h, -h], n.nx);
      b.quad([-h, h, h], [h, h, h], [h, h, -h], [-h, h, -h], n.py);
      b.quad([-h, -h, -h], [h, -h, -h], [h, -h, h], [-h, -h, h], n.ny);
      return { b, min: [-0.5, -0.5, -0.5], max: [0.5, 0.5, 0.5] };
    },

    sphere() {
      const b = makeBuilder();
      const LAT = 18, LON = 28, r = 0.5;
      for (let i = 0; i < LAT; i++) {
        const p1 = (i / LAT) * Math.PI;
        const p2 = ((i + 1) / LAT) * Math.PI;
        for (let j = 0; j < LON; j++) {
          const t1 = (j / LON) * TAU;
          const t2 = ((j + 1) / LON) * TAU;
          const a = spherePoint(r, p1, t1);
          const bb = spherePoint(r, p1, t2);
          const c = spherePoint(r, p2, t2);
          const d = spherePoint(r, p2, t1);
          const na = UW.math.vec.norm(a);
          const nb = UW.math.vec.norm(bb);
          const nc = UW.math.vec.norm(c);
          const nd = UW.math.vec.norm(d);
          if (i === 0) {
            b.tri(a, c, d, na, nc, nd);
          } else if (i === LAT - 1) {
            b.tri(a, bb, c, na, nb, nc);
          } else {
            b.tri(a, bb, c, na, nb, nc);
            b.tri(a, c, d, na, nc, nd);
          }
        }
      }
      return { b, min: [-0.5, -0.5, -0.5], max: [0.5, 0.5, 0.5] };
    },

    plane() {
      const b = makeBuilder();
      const n = [0, 1, 0];
      b.quad([-0.5, 0, -0.5], [-0.5, 0, 0.5], [0.5, 0, 0.5], [0.5, 0, -0.5], n);
      return { b, min: [-0.5, -0.002, -0.5], max: [0.5, 0.002, 0.5], twoSided: true };
    },

    cylinder() {
      const b = makeBuilder();
      const SEG = 28, r = 0.5, h = 0.5;
      for (let i = 0; i < SEG; i++) {
        const a1 = (i / SEG) * TAU;
        const a2 = ((i + 1) / SEG) * TAU;
        const c1 = Math.cos(a1), s1 = Math.sin(a1);
        const c2 = Math.cos(a2), s2 = Math.sin(a2);
        const p1 = [r * c1, -h, r * s1], p2 = [r * c2, -h, r * s2];
        const p3 = [r * c2, h, r * s2], p4 = [r * c1, h, r * s1];
        const n1 = [c1, 0, s1], n2 = [c2, 0, s2];
        b.tri(p1, p2, p3, n1, n2, n2);
        b.tri(p1, p3, p4, n1, n2, n1);
        b.tri([0, h, 0], p4, p3, [0, 1, 0], [0, 1, 0], [0, 1, 0]);
        b.tri([0, -h, 0], p2, p1, [0, -1, 0], [0, -1, 0], [0, -1, 0]);
      }
      return { b, min: [-0.5, -0.5, -0.5], max: [0.5, 0.5, 0.5] };
    },

    cone() {
      const b = makeBuilder();
      const SEG = 28, r = 0.5, h = 0.5;
      const apex = [0, h, 0];
      for (let i = 0; i < SEG; i++) {
        const a1 = (i / SEG) * TAU;
        const a2 = ((i + 1) / SEG) * TAU;
        const c1 = Math.cos(a1), s1 = Math.sin(a1);
        const c2 = Math.cos(a2), s2 = Math.sin(a2);
        const p1 = [r * c1, -h, r * s1];
        const p2 = [r * c2, -h, r * s2];
        const n1 = UW.math.vec.norm([c1, r / (2 * h) * 2, s1]);
        const n2 = UW.math.vec.norm([c2, r / (2 * h) * 2, s2]);
        const na = UW.math.vec.norm([(n1[0] + n2[0]) / 2, n1[1], (n1[2] + n2[2]) / 2]);
        b.tri(p1, p2, apex, n1, n2, na);
        b.tri([0, -h, 0], p2, p1, [0, -1, 0], [0, -1, 0], [0, -1, 0]);
      }
      return { b, min: [-0.5, -0.5, -0.5], max: [0.5, 0.5, 0.5] };
    },

    torus() {
      const b = makeBuilder();
      const R = 0.35, r = 0.15, SEG = 28, TUBE = 14;
      for (let i = 0; i < SEG; i++) {
        const u1 = (i / SEG) * TAU, u2 = ((i + 1) / SEG) * TAU;
        for (let j = 0; j < TUBE; j++) {
          const v1 = (j / TUBE) * TAU, v2 = ((j + 1) / TUBE) * TAU;
          const pt = (u, v) => {
            const cu = Math.cos(u), su = Math.sin(u);
            const cv = Math.cos(v), sv = Math.sin(v);
            const cx = R * cu, cz = R * su;
            return {
              p: [(R + r * cv) * cu, r * sv, (R + r * cv) * su],
              n: UW.math.vec.norm([cv * cu, sv, cv * su]),
            };
          };
          const A = pt(u1, v1), B = pt(u2, v1), C = pt(u2, v2), D = pt(u1, v2);
          b.tri(A.p, B.p, C.p, A.n, B.n, C.n);
          b.tri(A.p, C.p, D.p, A.n, C.n, D.n);
        }
      }
      return { b, min: [-0.5, -0.15, -0.5], max: [0.5, 0.15, 0.5] };
    },

    capsule() {
      const b = makeBuilder();
      const r = 0.35, half = 0.15, SEG = 26, RINGS = 7;
      function cap(centerY, sign) {
        for (let i = 0; i < RINGS; i++) {
          const f1 = (i / RINGS) * (Math.PI / 2);
          const f2 = ((i + 1) / RINGS) * (Math.PI / 2);
          for (let j = 0; j < SEG; j++) {
            const t1 = (j / SEG) * TAU, t2 = ((j + 1) / SEG) * TAU;
            const p = (f, t) => {
              const sf = Math.sin(f), cf = Math.cos(f);
              return [r * sf * Math.cos(t), centerY + sign * r * cf, r * sf * Math.sin(t)];
            };
            const A = p(f1, t1), B = p(f1, t2), C = p(f2, t2), D = p(f2, t1);
            const na = UW.math.vec.norm(UW.math.vec.sub(A, [0, centerY, 0]));
            const nb = UW.math.vec.norm(UW.math.vec.sub(B, [0, centerY, 0]));
            const nc = UW.math.vec.norm(UW.math.vec.sub(C, [0, centerY, 0]));
            const nd = UW.math.vec.norm(UW.math.vec.sub(D, [0, centerY, 0]));
            b.tri(A, B, C, na, nb, nc);
            b.tri(A, C, D, na, nc, nd);
          }
        }
      }
      cap(half, 1);
      cap(-half, -1);
      for (let j = 0; j < SEG; j++) {
        const t1 = (j / SEG) * TAU, t2 = ((j + 1) / SEG) * TAU;
        const c1 = Math.cos(t1), s1 = Math.sin(t1), c2 = Math.cos(t2), s2 = Math.sin(t2);
        const p1 = [r * c1, -half, r * s1], p2 = [r * c2, -half, r * s2];
        const p3 = [r * c2, half, r * s2], p4 = [r * c1, half, r * s1];
        b.tri(p1, p2, p3, [c1, 0, s1], [c2, 0, s2], [c2, 0, s2]);
        b.tri(p1, p3, p4, [c1, 0, s1], [c2, 0, s2], [c1, 0, s1]);
      }
      return { b, min: [-0.35, -0.5, -0.35], max: [0.35, 0.5, 0.35] };
    },
  };

  const cache = {};

  const SHAPES = [
    { id: 'cube', label: 'Cube', icon: 'i-cube' },
    { id: 'sphere', label: 'Sphere', icon: 'i-sphere' },
    { id: 'cylinder', label: 'Cylinder', icon: 'i-cube' },
    { id: 'cone', label: 'Cone', icon: 'i-cube' },
    { id: 'torus', label: 'Torus', icon: 'i-sphere' },
    { id: 'capsule', label: 'Capsule', icon: 'i-sphere' },
    { id: 'plane', label: 'Plane', icon: 'i-grid' },
  ];

  UW.geom = {
    shapes: SHAPES,
    shapeLabel(id) {
      const s = SHAPES.find((s) => s.id === id);
      return s ? s.label : id;
    },
    get(shape) {
      if (cache[shape]) return cache[shape];
      const fn = builders[shape] || builders.cube;
      const raw = fn();
      const data = {
        shape,
        positions: new Float32Array(raw.b.pos),
        normals: new Float32Array(raw.b.nrm),
        uvs: computeUVs(shape, raw.b.pos, raw.b.nrm),
        bounds: { min: raw.min, max: raw.max },
        twoSided: !!raw.twoSided,
        triangles: raw.b.pos.length / 9,
      };
      cache[shape] = data;
      return data;
    },
  };
})();
