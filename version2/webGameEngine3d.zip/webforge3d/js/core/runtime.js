/* ============================================================
   runtime.js — play-mode simulation
   A tiny, engine-agnostic runtime: behaviors, user JS scripts and
   a very small AABB physics solver. Works identically on every
   rendering engine because it only touches the scene model.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  UW.Runtime = class Runtime {
    constructor(editor) {
      this.editor = editor;
      this.time = 0;
      this.bodies = [];
      this.statics = [];
      this.behaviors = [];
      this.scripts = [];
      this.fsmRunners = [];
      this.fsmEvents = [];
      this.pressedKeys = new Set();
      this.keysDown = new Set();
      this.keysUp = new Set();
      this._audio = null;
      this._emitAcc = 0;
      this.groundY = 0;
      this.gravity = 9.81;
      this._onKeyDown = null;
      this._onKeyUp = null;
      this._onBlur = null;
    }

    start() {
      const ed = this.editor;
      const scene = ed.scene;
      const wm = ed.world();

      for (const node of scene.nodes) {
        const base = JSON.parse(JSON.stringify(node.transform));
        const wmat = wm.get(node.id) || M.mat4.identity();
        const wb = UW.scene.worldBounds(node, wmat);

        if (node.rigidbody && node.type === 'mesh') {
          if (node.parent) {
            ed.log('warn', 'Rigidbody on "' + node.name + '" ignored: physics only runs on root objects.');
          } else {
            const half = [
              (wb.max[0] - wb.min[0]) / 2,
              (wb.max[1] - wb.min[1]) / 2,
              (wb.max[2] - wb.min[2]) / 2,
            ];
            this.bodies.push({
              node,
              base,
              vel: [0, 0, 0],
              half,
              mass: Math.max(0.05, node.rigidbody.mass || 1),
              restitution: node.rigidbody.restitution != null ? node.rigidbody.restitution : 0.3,
              useGravity: node.rigidbody.useGravity !== false,
              sleeping: false,
            });
          }
        }

        // static AABB colliders: every visible mesh that is not a dynamic body and is not paper-thin
        const isDynamic = node.rigidbody && node.type === 'mesh' && !node.parent;
        if (node.type === 'mesh' && node.visible && !isDynamic) {
          const h = wb.max[1] - wb.min[1];
          if (h > 0.06) {
            this.statics.push({
              node,
              min: wb.min,
              max: wb.max,
            });
          }
        }

        if (node.behaviors && node.behaviors.length) {
          for (const b of node.behaviors) {
            this.behaviors.push({ node, kind: b.kind, params: b.params || {}, base });
          }
        }

        if (node.script && node.script.code) {
          const compiled = this.compile(node);
          if (compiled) {
            this.scripts.push({ node, ...compiled, api: compiled.api, started: false, errorOnce: false, name: node.script.name || 'Script' });
          }
        }

        if (node.fsm && UW.FSM) {
          const runner = UW.FSM.createRunner(node, this);
          if (runner) this.fsmRunners.push(runner);
        }
      }

      for (const s of this.scripts) {
        if (s.api && s.api.onStart) {
          try {
            s.api.onStart(this.context(s, 0));
            s.started = true;
          } catch (e) {
            this.scriptError(s, e);
          }
        } else {
          s.started = true;
        }
      }

      for (const runner of this.fsmRunners) {
        try { runner.start(); } catch (e) {
          this.editor.log('error', '[FSM] "' + runner.node.name + '" failed to start: ' + (e && e.message ? e.message : e));
        }
      }

      this._bindKeys();
    }

    _bindKeys() {
      const isField = (t) => {
        const tag = (t && t.tagName ? t.tagName : '').toLowerCase();
        return tag === 'input' || tag === 'textarea' || tag === 'select' || (t && t.isContentEditable);
      };
      this._onKeyDown = (e) => {
        if (isField(e.target)) return;
        if (!this.pressedKeys.has(e.key)) this.keysDown.add(e.key);
        this.pressedKeys.add(e.key);
      };
      this._onKeyUp = (e) => {
        if (isField(e.target)) return;
        this.pressedKeys.delete(e.key);
        this.keysUp.add(e.key);
      };
      this._onBlur = () => {
        this.pressedKeys.clear();
        this.keysDown.clear();
        this.keysUp.clear();
      };
      window.addEventListener('keydown', this._onKeyDown);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('blur', this._onBlur);
    }

    emitEvent(name) {
      if (!name) return;
      this.fsmEvents.push({ name: String(name), taken: new Set(), life: 2 });
      if (this.fsmEvents.length > 64) this.fsmEvents.shift();
    }

    /* Create (but do not start) an FSM runner on demand. Used by the
       Start/Restart/Enable FSM actions so disabled machines can be
       activated at runtime. */
    spawnRunner(node) {
      if (!node || !node.fsm || !UW.FSM) return null;
      const existing = this.fsmRunners.find((r) => r.node === node);
      if (existing) return existing;
      const runner = UW.FSM.createRunner(node, this, true);
      if (runner) this.fsmRunners.push(runner);
      return runner || null;
    }

    /* ---------------- audio ---------------- */
    audioContext() {
      if (this._audio) {
        if (this._audio.state === 'suspended') this._audio.resume().catch(() => {});
        return this._audio;
      }
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) {
        this.editor.log('warn', 'Audio is not supported by this browser.');
        return null;
      }
      try {
        this._audio = new Ctx();
      } catch (e) {
        this.editor.log('warn', 'Could not start audio: ' + (e && e.message ? e.message : e));
        return null;
      }
      return this._audio;
    }

    playTone(frequency, duration, volume, wave) {
      const ctx = this.audioContext();
      if (!ctx) return;
      const freq = Math.max(20, Number(frequency) || 440);
      const dur = Math.max(0.03, Number(duration) || 0.18);
      const vol = Math.max(0, Math.min(1, Number(volume) || 0.18));
      const types = { sine: 1, square: 1, sawtooth: 1, triangle: 1 };
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = types[wave] ? wave : 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, vol), ctx.currentTime + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + dur + 0.03);
    }

    stopAudio() {
      if (!this._audio) return;
      try { this._audio.close(); } catch (e) { /* ignore */ }
      this._audio = null;
    }

    compile(node) {
      try {
        const code = node.script.code;
        const factory = new Function(
          '"use strict";\n' + code + '\n;return {' +
            'onStart: typeof onStart === "function" ? onStart : null,' +
            'onUpdate: typeof onUpdate === "function" ? onUpdate : null,' +
            'onStop: typeof onStop === "function" ? onStop : null' +
          '};'
        );
        return { api: factory() };
      } catch (e) {
        this.editor.log('error', 'Script "' + (node.script.name || node.name) + '" failed to compile: ' + e.message);
        return null;
      }
    }

    context(s, dt) {
      const ed = this.editor;
      return {
        node: s.node,
        scene: ed.scene,
        time: this.time,
        dt,
        editor: ed,
        engine: ed.engineName,
        vec: V,
        math: M,
        find: (name) => ed.scene.nodes.find((n) => n.name === name) || null,
        log: (...args) => ed.log('info', args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')),
        emitEvent: (name) => this.emitEvent(name),
        setColor: (hex) => {
          if (s.node.mesh) s.node.mesh.color = hex;
        },
      };
    }

    scriptError(s, e) {
      if (!s.errorOnce) {
        s.errorOnce = true;
        this.editor.log('error', 'Script "' + s.name + '" error: ' + (e && e.message ? e.message : e));
      }
    }

    update(dt) {
      dt = Math.min(dt, 0.05);
      this.time += dt;
      const ed = this.editor;

      /* ---- behaviors ---- */
      for (const b of this.behaviors) {
        const t = b.node.transform;
        const base = b.base;
        if (b.kind === 'spin') {
          t.rotation[0] = base.rotation[0] + (b.params.x || 0) * this.time;
          t.rotation[1] = base.rotation[1] + (b.params.y || 0) * this.time;
          t.rotation[2] = base.rotation[2] + (b.params.z || 0) * this.time;
        } else if (b.kind === 'bob') {
          t.position[1] = base.position[1] + Math.sin(this.time * (b.params.speed || 1.6)) * (b.params.amplitude || 0.3);
        } else if (b.kind === 'pulse') {
          const k = 1 + Math.sin(this.time * (b.params.speed || 2.4)) * (b.params.amount || 0.18);
          t.scale[0] = base.scale[0] * k;
          t.scale[1] = base.scale[1] * k;
          t.scale[2] = base.scale[2] * k;
        } else if (b.kind === 'orbit') {
          const radius = b.params.radius || 2.2;
          const a0 = Math.atan2(base.position[0], base.position[2]);
          const a = a0 + (this.time * (b.params.speed || 40) * Math.PI) / 180;
          t.position[0] = Math.sin(a) * radius;
          t.position[2] = Math.cos(a) * radius;
          t.position[1] = base.position[1] + (b.params.height || 0);
        }
      }

      /* ---- user scripts ---- */
      if (this.scripts.length) {
        const subs = {};
        for (const s of this.scripts) subs[s.node.id] = s;
        for (const s of this.scripts) {
          if (!s.api || !s.api.onUpdate) continue;
          try {
            const ctx = this.context(s, dt);
            ctx.sub = subs;
            s.api.onUpdate(ctx, dt);
          } catch (e) {
            this.scriptError(s, e);
          }
        }
      }

      /* ---- state machines ---- */
      if (this.fsmRunners.length) {
        for (const runner of this.fsmRunners) {
          try {
            runner.update(dt);
          } catch (e) {
            if (!runner._errOnce) {
              runner._errOnce = true;
              ed.log('error', '[FSM] "' + runner.node.name + '": ' + (e && e.message ? e.message : e));
            }
          }
        }
        for (const ev of this.fsmEvents) ev.life -= 1;
        this.fsmEvents = this.fsmEvents.filter((ev) => ev.life > 0);
      }
      this.keysDown.clear();
      this.keysUp.clear();

      /* ---- dynamics ---- */
      for (const body of this.bodies) {
        const p = body.node.transform.position;
        if (body.useGravity) body.vel[1] -= this.gravity * dt;
        body.vel[0] *= 0.999;
        body.vel[2] *= 0.999;
        p[0] += body.vel[0] * dt;
        p[1] += body.vel[1] * dt;
        p[2] += body.vel[2] * dt;

        const hy = body.half[1];
        if (p[1] - hy < this.groundY) {
          p[1] = this.groundY + hy;
          if (body.vel[1] < 0) {
            body.vel[1] = -body.vel[1] * body.restitution;
            if (Math.abs(body.vel[1]) < 0.55) body.vel[1] = 0;
          }
          body.vel[0] *= 0.9;
          body.vel[2] *= 0.9;
        }
      }

      // dynamic vs static AABBs
      for (const body of this.bodies) {
        const p = body.node.transform.position;
        const half = body.half;
        for (const s of this.statics) {
          const bmin = [p[0] - half[0], p[1] - half[1], p[2] - half[2]];
          const bmax = [p[0] + half[0], p[1] + half[1], p[2] + half[2]];
          if (bmax[0] <= s.min[0] || bmin[0] >= s.max[0]) continue;
          if (bmax[2] <= s.min[2] || bmin[2] >= s.max[2]) continue;
          if (bmax[1] <= s.min[1] || bmin[1] >= s.max[1]) continue;
          // resolve along the axis with the smallest penetration
          const pushX = Math.min(bmax[0] - s.min[0], s.max[0] - bmin[0]);
          const pushY = Math.min(bmax[1] - s.min[1], s.max[1] - bmin[1]);
          const pushZ = Math.min(bmax[2] - s.min[2], s.max[2] - bmin[2]);
          if (pushY <= pushX && pushY <= pushZ) {
            const dir = p[1] > (s.min[1] + s.max[1]) / 2 ? 1 : -1;
            p[1] += pushY * dir;
            if (Math.sign(body.vel[1]) !== Math.sign(dir)) {
              body.vel[1] = -body.vel[1] * body.restitution;
              if (Math.abs(body.vel[1]) < 0.55) body.vel[1] = 0;
            }
            body.vel[0] *= 0.9;
            body.vel[2] *= 0.9;
          } else if (pushX <= pushZ) {
            const dir = p[0] > (s.min[0] + s.max[0]) / 2 ? 1 : -1;
            p[0] += pushX * dir;
            body.vel[0] *= -body.restitution;
          } else {
            const dir = p[2] > (s.min[2] + s.max[2]) / 2 ? 1 : -1;
            p[2] += pushZ * dir;
            body.vel[2] *= -body.restitution;
          }
        }
      }

      // dynamic vs dynamic (sphere-ish, cheap)
      for (let i = 0; i < this.bodies.length; i++) {
        for (let j = i + 1; j < this.bodies.length; j++) {
          const A = this.bodies[i];
          const B = this.bodies[j];
          const pa = A.node.transform.position;
          const pb = B.node.transform.position;
          const overlapX = Math.min(pa[0] + A.half[0], pb[0] + B.half[0]) - Math.max(pa[0] - A.half[0], pb[0] - B.half[0]);
          const overlapY = Math.min(pa[1] + A.half[1], pb[1] + B.half[1]) - Math.max(pa[1] - A.half[1], pb[1] - B.half[1]);
          const overlapZ = Math.min(pa[2] + A.half[2], pb[2] + B.half[2]) - Math.max(pa[2] - A.half[2], pb[2] - B.half[2]);
          if (overlapX <= 0 || overlapY <= 0 || overlapZ <= 0) continue;
          if (overlapY <= overlapX && overlapY <= overlapZ) {
            const dir = pa[1] >= pb[1] ? 1 : -1;
            pa[1] += (overlapY / 2) * dir;
            pb[1] -= (overlapY / 2) * dir;
            const va = A.vel[1], vb = B.vel[1];
            A.vel[1] = vb * 0.7;
            B.vel[1] = va * 0.7;
          } else if (overlapX <= overlapZ) {
            const dir = pa[0] >= pb[0] ? 1 : -1;
            pa[0] += (overlapX / 2) * dir;
            pb[0] -= (overlapX / 2) * dir;
            A.vel[0] = -A.vel[0] * 0.6;
            B.vel[0] = -B.vel[0] * 0.6;
          } else {
            const dir = pa[2] >= pb[2] ? 1 : -1;
            pa[2] += (overlapZ / 2) * dir;
            pb[2] -= (overlapZ / 2) * dir;
            A.vel[2] = -A.vel[2] * 0.6;
            B.vel[2] = -B.vel[2] * 0.6;
          }
        }
      }

      // ground clamp after pair resolution
      for (const body of this.bodies) {
        const p = body.node.transform.position;
        if (p[1] - body.half[1] < this.groundY) {
          p[1] = this.groundY + body.half[1];
          body.vel[1] = Math.max(0, body.vel[1]);
        }
      }

      this._emitAcc += dt;
      if (this._emitAcc > 0.08) {
        this._emitAcc = 0;
        ed.emit('values');
      }
    }

    stop() {
      for (const s of this.scripts) {
        if (s.api && s.api.onStop && s.started) {
          try {
            s.api.onStop(this.context(s, 0));
          } catch (e) {
            this.scriptError(s, e);
          }
        }
      }
      if (this._onKeyDown) window.removeEventListener('keydown', this._onKeyDown);
      if (this._onKeyUp) window.removeEventListener('keyup', this._onKeyUp);
      if (this._onBlur) window.removeEventListener('blur', this._onBlur);
      this._onKeyDown = this._onKeyUp = this._onBlur = null;
      for (const runner of this.fsmRunners) {
        try { if (runner.stop) runner.stop(); } catch (e) { /* ignore */ }
      }
      this.stopAudio();
      this.pressedKeys.clear();
      this.keysDown.clear();
      this.keysUp.clear();
      this.fsmEvents.length = 0;
      this.fsmRunners.length = 0;
    }
  };
})();
