/* ============================================================
   native.js — zero-dependency software 3D renderer (Canvas 2D)
   Exists so the editor still works completely offline and proves
   that the scene model is engine-agnostic. Painter's algorithm,
   near-plane clipping, diffuse + spec shading, shadows: none.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  function clipNear(poly, near) {
    const out = [];
    const n = poly.length;
    for (let i = 0; i < n; i++) {
      const A = poly[i];
      const B = poly[(i + 1) % n];
      const inA = A.p[2] <= -near;
      const inB = B.p[2] <= -near;
      if (inA) out.push(A);
      if (inA !== inB) {
        const t = (-near - A.p[2]) / (B.p[2] - A.p[2]);
        out.push({
          p: [A.p[0] + (B.p[0] - A.p[0]) * t, A.p[1] + (B.p[1] - A.p[1]) * t, -near],
          uv: [A.uv[0] + (B.uv[0] - A.uv[0]) * t, A.uv[1] + (B.uv[1] - A.uv[1]) * t],
        });
      }
    }
    return out;
  }

  UW.adapters = UW.adapters || {};

  UW.adapters.Native = class NativeAdapter {
    constructor(def) {
      this.def = def;
      this.canvas = null;
      this.ctx = null;
      this.w = 1;
      this.h = 1;
      this.dpr = 1;
      this.frame = null;
      this.stats = { triangles: 0, objects: 0, calls: 0 };
      this.bg = null;
      this._prims = [];
      this._patterns = new Map();
    }

    async init(host) {
      this.canvas = document.createElement('canvas');
      this.canvas.className = 'engine-canvas';
      host.appendChild(this.canvas);
      this.ctx = this.canvas.getContext('2d');
      this.ctx.imageSmoothingEnabled = true;
    }

    resize(w, h, dpr) {
      this.w = w;
      this.h = h;
      this.dpr = dpr;
      this.canvas.width = Math.max(1, Math.round(w * dpr));
      this.canvas.height = Math.max(1, Math.round(h * dpr));
      this.canvas.style.width = w + 'px';
      this.canvas.style.height = h + 'px';
    }

    update(frame) {
      this.frame = frame;
    }

    render() {
      const f = this.frame;
      if (!f) return;
      const ctx = this.ctx;
      const { scene, cam, viewMode, selected, env } = f;
      const w = this.w, h = this.h;
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      if (viewMode === 'game') {
        ctx.fillStyle = cam.backgroundColor || '#1d2025';
        ctx.fillRect(0, 0, w, h);
      }

      const showGrid = viewMode === 'scene' && env.showGrid !== false;
      const world = UW.scene.worldMatrices(scene);
      const near = Math.max(0.02, cam.near);
      const lights = this.collectLights(scene, world);

      const planePrims = [];
      const solidPrims = [];
      const ctxState = { w, h, proj: cam.proj, near, env: env || {}, dpr: this.dpr };
      let drawn = 0;

      for (const node of scene.nodes) {
        if (!node.visible || node.type !== 'mesh') continue;
        const wm = world.get(node.id);
        if (!wm) continue;
        const mv = M.mat4.mul(cam.view, wm);
        const geo = UW.geom.get(node.mesh.shape);
        const color = M.colorToRgb(node.mesh.color);
        const isPlane = node.mesh.shape === 'plane' || geo.twoSided;
        const bucket = isPlane ? planePrims : solidPrims;
        const tiled = node.mesh.texture && node.mesh.texture.enabled !== false && UW.textures
          ? UW.textures.getTiled(node.mesh.texture) : null;

        const pos = geo.positions;
        const nrm = geo.normals;
        for (let i = 0; i < pos.length; i += 9) {
          const tri = this.triangulate(mv, pos, nrm, wm, i, geo, cam, lights, color, node, ctxState, tiled);
          if (!tri) continue;
          tri.mesh = node;
          bucket.push(tri);
          drawn++;
        }
      }

      // background plane-like objects first (ground), then grid, then sorted solids
      for (const p of planePrims) this.paintPrim(ctx, p);

      if (showGrid) this.drawGrid(ctx, cam, w, h, near);

      solidPrims.sort((a, b) => a.z - b.z);
      for (const p of solidPrims) this.paintPrim(ctx, p);

      if (selected && viewMode === 'scene') this.drawSelection(ctx, scene, world, selected, cam, w, h, near);

      this.stats.triangles = drawn;
      this.stats.objects = scene.nodes.filter((n) => n.visible).length;
      this.stats.calls = drawn;
      this.bg = viewMode === 'game' ? cam.backgroundColor : null;
    }

    collectLights(scene, world) {
      const lights = [];
      for (const node of scene.nodes) {
        if (node.type !== 'light' || !node.visible || !node.light) continue;
        const wm = world.get(node.id);
        if (!wm) continue;
        const color = M.colorToRgb(node.light.color);
        if (node.light.kind === 'point') {
          lights.push({
            type: 'point',
            pos: [wm[12], wm[13], wm[14]],
            color,
            intensity: node.light.intensity,
            range: node.light.range || 12,
          });
        } else if (node.light.kind === 'spot') {
          const dir = V.norm([wm[8], wm[9], wm[10]]);
          lights.push({
            type: 'spot',
            pos: [wm[12], wm[13], wm[14]],
            dir,
            color,
            intensity: node.light.intensity,
            range: node.light.range || 16,
            angle: (node.light.angle || 38) * M.DEG,
            penumbra: node.light.penumbra != null ? node.light.penumbra : 0.35,
          });
        } else {
          const dir = V.norm([wm[8], wm[9], wm[10]]);
          lights.push({ type: 'dir', dir, color, intensity: node.light.intensity });
        }
      }
      if (!lights.length) lights.push({ type: 'dir', dir: V.norm([-0.5, -1, -0.4]), color: [1, 1, 1], intensity: 1 });
      return lights;
    }

    triangulate(mv, pos, nrm, wm, i, geo, cam, lights, baseColor, node, st, tiled) {
      const near = st.near;
      const uvSrc = geo.uvs;
      const vps = [
        M.mat4.point(mv, [pos[i], pos[i + 1], pos[i + 2]]),
        M.mat4.point(mv, [pos[i + 3], pos[i + 4], pos[i + 5]]),
        M.mat4.point(mv, [pos[i + 6], pos[i + 7], pos[i + 8]]),
      ];
      if (vps[0][2] > -near && vps[1][2] > -near && vps[2][2] > -near) return null;
      const vi = i / 3;
      const items = vps.map((p, k) => ({
        p,
        uv: uvSrc ? [uvSrc[(vi + k) * 2], uvSrc[(vi + k) * 2 + 1]] : [0, 0],
      }));
      const poly = clipNear(items, near);
      if (poly.length < 3) return null;

      // world normal
      let n = [
        (nrm[i] + nrm[i + 3] + nrm[i + 6]) / 3,
        (nrm[i + 1] + nrm[i + 4] + nrm[i + 7]) / 3,
        (nrm[i + 2] + nrm[i + 5] + nrm[i + 8]) / 3,
      ];
      n = V.norm(M.mat4.dir(wm, n));
      const wc = M.mat4.point(wm, [
        (pos[i] + pos[i + 3] + pos[i + 6]) / 3,
        (pos[i + 1] + pos[i + 4] + pos[i + 7]) / 3,
        (pos[i + 2] + pos[i + 5] + pos[i + 8]) / 3,
      ]);
      const toEye = V.norm(V.sub(cam.eye, wc));
      if (!geo.twoSided && V.dot(n, toEye) < 0 && node.mesh.shape !== 'plane') {
        n = V.scale(n, -1);
      }

      const env = st.env || {};
      const amb = env.ambient != null ? Math.max(0, env.ambient) : 0.42;
      const ambC = M.colorToRgb(env.ambientColor || '#ffffff');
      const metal = node.mesh.metalness || 0;
      let lr = baseColor[0] * (0.15 + amb * 0.6 * ambC[0]);
      let lg = baseColor[1] * (0.15 + amb * 0.6 * ambC[1]);
      let lb = baseColor[2] * (0.15 + amb * 0.6 * ambC[2]);
      let lightLevel = 0.15 + amb * 0.6 * ((ambC[0] + ambC[1] + ambC[2]) / 3);
      let spec = 0;

      for (const L of lights) {
        let ldir, atten = 1;
        if (L.type === 'dir') {
          ldir = V.scale(L.dir, -1);
        } else {
          const toL = V.sub(L.pos, wc);
          const dist = V.len(toL);
          ldir = V.scale(toL, 1 / (dist || 1));
          atten = Math.max(0, 1 - dist / (L.range || 16));
          if (L.type === 'spot') {
            const cosA = V.dot(V.scale(ldir, -1), L.dir);
            const angle = L.angle || 0.6;
            const cutoff = Math.cos(angle);
            const inner = Math.cos(angle * (1 - M.clamp(L.penumbra || 0, 0, 1)));
            atten *= M.clamp((cosA - cutoff) / Math.max(1e-4, inner - cutoff), 0, 1);
          }
        }
        if (atten <= 0) continue;
        const ndl = Math.max(0, V.dot(n, ldir));
        const tint = (L.color[0] + L.color[1] + L.color[2]) / 3;
        lr += baseColor[0] * ndl * L.intensity * atten * L.color[0];
        lg += baseColor[1] * ndl * L.intensity * atten * L.color[1];
        lb += baseColor[2] * ndl * L.intensity * atten * L.color[2];
        lightLevel += ndl * L.intensity * atten * tint;
        const hvec = V.norm(V.add(ldir, toEye));
        spec += Math.pow(Math.max(0, V.dot(n, hvec)), 28) * L.intensity * atten * (0.15 + metal * 0.6);
      }

      const rgb = [
        M.clamp(lr + spec, 0, 1),
        M.clamp(lg + spec, 0, 1),
        M.clamp(lb + spec, 0, 1),
      ];
      const rgbCss = (c) => 'rgb(' + c.map((v) => Math.round(M.clamp(v, 0, 1) * 255)).join(',') + ')';

      let z = 0;
      for (const item of poly) z += item.p[2];
      z /= poly.length;
      const depth = -z;
      let fog = 0;
      if (env.fogEnabled) {
        const fn = env.fogNear != null ? env.fogNear : 14;
        const ff = env.fogFar != null ? env.fogFar : 70;
        fog = M.clamp((depth - fn) / Math.max(0.001, ff - fn), 0, 1);
      }
      const fogC = M.colorToRgb(env.fogColor || '#1d2025');
      const fill = rgbCss([
        M.lerp(rgb[0], fogC[0], fog),
        M.lerp(rgb[1], fogC[1], fog),
        M.lerp(rgb[2], fogC[2], fog),
      ]);

      const proj = st.proj;
      const pts = [];
      const uvs = [];
      for (const item of poly) {
        const c = M.mat4.point4(proj, item.p);
        if (c[3] <= 1e-6) return null;
        const iw = 1 / c[3];
        pts.push([(c[0] * iw * 0.5 + 0.5) * st.w, (0.5 - c[1] * iw * 0.5) * st.h]);
        uvs.push(item.uv);
      }
      return {
        pts,
        uvs,
        fill,
        shade: rgbCss(rgb),
        lightLevel,
        z,
        fog,
        fogColor: fogC,
        wire: !!node.mesh.wireframe,
        opacity: node.mesh.opacity != null ? node.mesh.opacity : 1,
        texture: tiled && uvSrc ? { tiled } : null,
      };
    }

    paintPrim(ctx, p) {
      const pts = p.pts;
      if (!pts || pts.length < 3) return;
      if (p.texture && !p.wire) {
        this.paintTextured(ctx, p);
        return;
      }
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
      ctx.closePath();
      if (p.wire) {
        ctx.strokeStyle = p.fill;
        ctx.lineWidth = 1;
        ctx.stroke();
      } else {
        ctx.fillStyle = p.fill;
        if (p.opacity < 1) {
          ctx.globalAlpha = p.opacity;
          ctx.fill();
          ctx.globalAlpha = 1;
        } else {
          ctx.fill();
        }
        ctx.strokeStyle = p.fill;
        ctx.lineWidth = 0.7;
        ctx.stroke();
      }
    }

    /* Affine per-triangle texture mapping. The tiled canvas is used as an
       infinite pattern and the clip path keeps it inside the triangle. */
    paintTextured(ctx, p) {
      const pts = p.pts;
      const uvs = p.uvs;
      const tiled = p.texture && p.texture.tiled;
      if (!tiled || !pts || !uvs || pts.length < 3 || uvs.length < 3) return;
      const W = Math.max(1, tiled.periodW);
      const H = Math.max(1, tiled.periodH);
      const tx = tiled.repeatX, ty = tiled.repeatY;
      const ox = tiled.offsetX, oy = tiled.offsetY;
      const texPt = (uv) => [(uv[0] * tx + ox) * W, (1 - (uv[1] * ty + oy)) * H];
      const t0 = texPt(uvs[0]), t1 = texPt(uvs[1]), t2 = texPt(uvs[2]);
      const s0 = pts[0], s1 = pts[1], s2 = pts[2];
      const du1 = t1[0] - t0[0], dv1 = t1[1] - t0[1];
      const du2 = t2[0] - t0[0], dv2 = t2[1] - t0[1];
      const det = du1 * dv2 - du2 * dv1;
      if (Math.abs(det) < 1e-5) {
        ctx.fillStyle = p.shade || p.fill;
        ctx.beginPath();
        ctx.moveTo(s0[0], s0[1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
        ctx.fill();
        return;
      }
      let pattern = this._patterns.get(tiled.canvas);
      if (!pattern) {
        // Texture edits create new tiled canvases; keep the cache bounded.
        if (this._patterns.size > 64) this._patterns.clear();
        pattern = ctx.createPattern(tiled.canvas, 'repeat');
        if (!pattern) return;
        this._patterns.set(tiled.canvas, pattern);
      }

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
      ctx.closePath();
      ctx.clip();

      const a = ((s1[0] - s0[0]) * dv2 - (s2[0] - s0[0]) * dv1) / det;
      const b = ((s2[0] - s0[0]) * du1 - (s1[0] - s0[0]) * du2) / det;
      const c = ((s1[1] - s0[1]) * dv2 - (s2[1] - s0[1]) * dv1) / det;
      const d = ((s2[1] - s0[1]) * du1 - (s1[1] - s0[1]) * du2) / det;
      const e = s0[0] - a * t0[0] - b * t0[1];
      const f = s0[1] - c * t0[0] - d * t0[1];
      const dpr = this.dpr || 1;
      ctx.setTransform(a * dpr, c * dpr, b * dpr, d * dpr, e * dpr, f * dpr);
      ctx.fillStyle = pattern;
      if (p.opacity < 1) ctx.globalAlpha = p.opacity;
      const minX = Math.min(t0[0], t1[0], t2[0]) - 2;
      const minY = Math.min(t0[1], t1[1], t2[1]) - 2;
      const maxX = Math.max(t0[0], t1[0], t2[0]) + 2;
      const maxY = Math.max(t0[1], t1[1], t2[1]) + 2;
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
      ctx.globalAlpha = 1;

      // lighting (multiply) and fog (alpha) overlays, still clipped to the triangle
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (p.lightLevel < 1 || p.shade) {
        ctx.globalCompositeOperation = 'multiply';
        ctx.fillStyle = p.shade || '#ffffff';
        ctx.fillRect(0, 0, this.w, this.h);
        ctx.globalCompositeOperation = 'source-over';
      }
      if (p.fog > 0) {
        const fc = p.fogColor || [0.11, 0.13, 0.15];
        ctx.fillStyle = 'rgba(' + fc.map((v) => Math.round(M.clamp(v, 0, 1) * 255)).join(',') + ',' + p.fog + ')';
        ctx.fillRect(0, 0, this.w, this.h);
      }
      ctx.restore();

      if (p.opacity >= 1) {
        ctx.strokeStyle = p.fill;
        ctx.lineWidth = 0.7;
        ctx.beginPath();
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        ctx.closePath();
        ctx.stroke();
      }
    }

    drawGrid(ctx, cam, w, h, near) {
      const range = 22;
      const lines = [];
      for (let i = -range; i <= range; i++) {
        const major = i % 5 === 0;
        lines.push({ a: [i, 0.003, -range], b: [i, 0.003, range], major });
        lines.push({ a: [-range, 0.003, i], b: [range, 0.003, i], major });
      }
      ctx.save();
      ctx.lineWidth = 1;
      for (const line of lines) {
        const va = M.mat4.point(cam.view, line.a);
        const vb = M.mat4.point(cam.view, line.b);
        let A = va, B = vb;
        if (A[2] > -near && B[2] > -near) continue;
        if (A[2] > -near || B[2] > -near) {
          const t = (-near - A[2]) / (B[2] - A[2]);
          const P = [A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, -near];
          if (A[2] > -near) A = P; else B = P;
        }
        const pa = M.mat4.point4(cam.proj, A);
        const pb = M.mat4.point4(cam.proj, B);
        if (pa[3] <= 1e-6 || pb[3] <= 1e-6) continue;
        const ia = 1 / pa[3], ib = 1 / pb[3];
        const x1 = (pa[0] * ia * 0.5 + 0.5) * w, y1 = (0.5 - pa[1] * ia * 0.5) * h;
        const x2 = (pb[0] * ib * 0.5 + 0.5) * w, y2 = (0.5 - pb[1] * ib * 0.5) * h;
        if ((x1 < 0 && x2 < 0) || (x1 > w && x2 > w) || (y1 < 0 && y2 < 0) || (y1 > h && y2 > h)) continue;
        // fade with distance from origin
        const fade = Math.max(0.15, 1 - Math.hypot((line.a[0] + line.b[0]) / 2, (line.a[2] + line.b[2]) / 2) / 26);
        if (line.major && (line.a[0] === 0 || line.a[2] === 0)) {
          ctx.strokeStyle = line.a[0] === 0 ? 'rgba(91,147,230,' + 0.28 * fade + ')' : 'rgba(226,96,94,' + 0.24 * fade + ')';
        } else {
          ctx.strokeStyle = 'rgba(190,205,225,' + (line.major ? 0.16 : 0.08) * fade + ')';
        }
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      ctx.restore();
    }

    drawSelection(ctx, scene, world, id, cam, w, h, near) {
      const node = UW.scene.find(scene, id);
      if (!node) return;
      const wm = world.get(id);
      if (!wm) return;
      const b = UW.scene.bounds(node);
      const corners = [];
      for (let i = 0; i < 8; i++) {
        corners.push(M.mat4.point(wm, [
          i & 1 ? b.max[0] : b.min[0],
          i & 2 ? b.max[1] : b.min[1],
          i & 4 ? b.max[2] : b.min[2],
        ]));
      }
      const edges = [
        [0, 1], [1, 3], [3, 2], [2, 0],
        [4, 5], [5, 7], [7, 6], [6, 4],
        [0, 4], [1, 5], [2, 6], [3, 7],
      ];
      ctx.save();
      ctx.strokeStyle = 'rgba(86,170,255,.95)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 3]);
      for (const [a, b2] of edges) {
        const pa = M.mat4.point(cam.view, corners[a]);
        const pb = M.mat4.point(cam.view, corners[b2]);
        if (pa[2] > -near || pb[2] > -near) continue;
        const ca = M.mat4.point4(cam.proj, pa);
        const cb = M.mat4.point4(cam.proj, pb);
        if (ca[3] <= 1e-6 || cb[3] <= 1e-6) continue;
        const ia = 1 / ca[3], ib = 1 / cb[3];
        ctx.beginPath();
        ctx.moveTo((ca[0] * ia * 0.5 + 0.5) * w, (0.5 - ca[1] * ia * 0.5) * h);
        ctx.lineTo((cb[0] * ib * 0.5 + 0.5) * w, (0.5 - cb[1] * ib * 0.5) * h);
        ctx.stroke();
      }
      ctx.restore();
    }

    getStats() {
      return this.stats;
    }

    dispose() {
      if (this.canvas && this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
      this._patterns.clear();
      this.canvas = null;
      this.ctx = null;
      this.frame = null;
    }
  };

  UW.engines.register({
    id: 'native',
    name: 'Native Canvas',
    short: 'JS',
    version: '1.0',
    license: 'built-in',
    vendor: 'WebForge',
    url: '',
    description: 'Zero-dependency software renderer. Works offline, no CDN, no WebGL.',
    badge: 'offline',
    capabilities: {
      webgl: { level: 'none', note: 'Canvas 2D software rasterizer' },
      shadows: { level: 'none', note: 'No shadow maps (painter’s algorithm)' },
      directional: { level: 'full', note: 'Diffuse + specular shading' },
      point: { level: 'full', note: 'Range falloff' },
      spot: { level: 'full', note: 'Cone angle and penumbra' },
      fog: { level: 'full', note: 'Per-triangle linear fog' },
      textures: { level: 'full', note: 'Affine per-triangle texture mapping' },
      tiling: 'full',
      transparency: 'full',
      wireframe: 'full',
      pbr: { level: 'partial', note: 'Approximate metalness and specular response' },
      antialias: { level: 'partial', note: 'Canvas image smoothing and device pixel ratio' },
      offline: { level: 'full', note: 'Built into the editor' },
      runtime: 'full',
    },
    async load() {},
    create() {
      return new UW.adapters.Native(this);
    },
  });
})();
