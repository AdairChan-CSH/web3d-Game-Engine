/* ============================================================
   app.js — bootstraps the editor, runs the frame loop, owns the
   active engine adapter and all viewport input.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  class App {
    constructor() {
      this.editor = new UW.Editor();
      this.cameraRig = new UW.CameraRig(this.editor);
      this.gizmo = new UW.Gizmo(this);
      this.stage = document.getElementById('stage');
      this.viewport = document.getElementById('viewport');
      this.adapter = null;
      this.activeDef = null;
      this.switching = false;
      this.last = 0;
      this.fps = 60;
      this._frames = 0;
      this._fpsT = 0;
      this._hudT = 0;
      this.width = 0;
      this.height = 0;
      this.pointer = null;
      this.stats = { triangles: 0, objects: 0, calls: 0, fps: 60 };
      this._bindViewport();
      this._bindKeyboard();
      this._bindResize();
      this._bindDrop();
    }

    async start() {
      await UW.UI.init(this);
      const saved = (() => {
        try { return localStorage.getItem('webforge3d.engine'); } catch (e) { return null; }
      })();
      const id = saved && UW.engines.get(saved) ? saved : 'three';
      await this.setEngine(id);
      this.last = performance.now();
      this._fpsT = this.last;
      requestAnimationFrame(this._loop.bind(this));
    }

    setEngineSafe(id) {
      return this.setEngine(id);
    }

    async setEngine(id) {
      if (this.switching) return;
      const def = UW.engines.get(id);
      if (!def) {
        this.editor.log('error', 'Engine "' + id + '" is not registered.');
        return;
      }
      this.switching = true;
      this.editor.emit('engine-loading', { id: def.id, name: def.name, state: 'loading' });
      const old = this.adapter;
      let next = null;
      try {
        await def.load();
        next = def.create(def);
        await next.init(this.stage);
        this._sizeAdapter(next);
        if (old) old.dispose();
        this.adapter = next;
        this.activeDef = def;
        this.editor.setEngine(def.id, def.name + (def.version ? ' ' + def.version : ''));
        this.editor.log('info', 'Engine ready — ' + def.name + ' ' + (def.version || '') + ' (' + (def.license || 'unknown license') + ').');
        try { localStorage.setItem('webforge3d.engine', def.id); } catch (e) { /* ignore */ }
        this.editor.emit('engine-loading', { id: def.id, name: def.name, state: 'ready' });
      } catch (err) {
        if (next) {
          try { next.dispose(); } catch (e) { /* ignore */ }
        }
        this.editor.log('error', 'Could not start ' + def.name + ': ' + (err && err.message ? err.message : err));
        this.editor.emit('engine-loading', { id: def.id, name: def.name, state: 'error', message: err && err.message });
        this.switching = false;
        if (def.id !== 'native') {
          this.editor.log('warn', 'Falling back to the built-in Native Canvas renderer.');
          await this.setEngine('native');
        }
        return;
      }
      this.switching = false;
    }

    _sizeAdapter(adapter) {
      const w = Math.max(1, this.stage.clientWidth);
      const h = Math.max(1, this.stage.clientHeight);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.width = w;
      this.height = h;
      adapter.resize(w, h, dpr);
      this.cameraRig.setViewport(w, h);
      this.gizmo.resize(w, h, dpr);
    }

    resize() {
      const w = Math.max(1, this.stage.clientWidth);
      const h = Math.max(1, this.stage.clientHeight);
      if (w === this.width && h === this.height) return;
      this.width = w;
      this.height = h;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (this.adapter) this.adapter.resize(w, h, dpr);
      this.cameraRig.setViewport(w, h);
      this.gizmo.resize(w, h, dpr);
    }

    _loop(t) {
      requestAnimationFrame(this._loop.bind(this));
      const dt = Math.min(0.05, Math.max(0, (t - this.last) / 1000) || 0.016);
      this.last = t;

      this.resize();
      this.editor.update(dt);
      this.cameraRig.update();

      if (this.adapter) {
        const frame = {
          scene: this.editor.scene,
          cam: this.cameraRig,
          viewMode: this.editor.viewMode,
          selected: this.editor.selected,
          env: this.editor.scene.env || {},
          time: this.editor.time,
        };
        this.adapter.update(frame);
        this.adapter.render();
        this.stats = this.adapter.getStats() || this.stats;
      }

      this.gizmo.draw();

      this._frames++;
      if (t - this._fpsT > 500) {
        this.fps = Math.round((this._frames * 1000) / (t - this._fpsT));
        this._frames = 0;
        this._fpsT = t;
        this.editor.emit('fps', this.fps);
      }
      if (t - this._hudT > 140) {
        this._hudT = t;
        UW.UI.updateStats({
          fps: this.fps,
          triangles: (this.stats && this.stats.triangles) || 0,
          objects: this.editor.scene.nodes.length,
          calls: (this.stats && this.stats.calls) || 0,
          engine: this.activeDef ? this.activeDef.name : '—',
          time: this.editor.time,
        });
      }
    }

    /* ---------------- viewport input ---------------- */
    _local(e) {
      const r = this.viewport.getBoundingClientRect();
      return [e.clientX - r.left, e.clientY - r.top];
    }

    _bindViewport() {
      const vp = this.viewport;
      const ed = this.editor;

      vp.addEventListener('contextmenu', (e) => e.preventDefault());

      vp.addEventListener('pointerdown', (e) => {
        if (e.target.closest('button, a, input, select, #loading')) return;
        const [x, y] = this._local(e);
        const mode = { lmb: e.button === 0, mmb: e.button === 1, rmb: e.button === 2 };
        if (e.button === 0 && this.editor.viewMode === 'scene') {
          const hit = this.gizmo.hitTest(x, y);
          if (hit && this.gizmo.startDrag(hit, x, y)) {
            this.pointer = { id: e.pointerId, mode: 'gizmo', x, y, sx: x, sy: y, moved: false };
            vp.setPointerCapture(e.pointerId);
            e.preventDefault();
            return;
          }
        }
        let pMode = null;
        if (mode.mmb || e.shiftKey) pMode = 'pan';
        else if (mode.lmb) pMode = 'pending';
        else if (mode.rmb) pMode = 'orbit';
        if (!pMode) return;
        if (this.editor.viewMode === 'game' && pMode !== 'pending') return;
        this.pointer = { id: e.pointerId, mode: pMode, x, y, sx: x, sy: y, moved: false, button: e.button };
        vp.setPointerCapture(e.pointerId);
        e.preventDefault();
      });

      vp.addEventListener('pointermove', (e) => {
        const [x, y] = this._local(e);
        const p = this.pointer;
        if (!p) {
          if (this.editor.viewMode === 'scene') {
            const hover = this.gizmo.hitTest(x, y);
            this.gizmo.hover = hover;
            vp.style.cursor = hover ? 'grab' : 'default';
          } else {
            vp.style.cursor = 'default';
          }
          return;
        }
        const dx = x - p.x;
        const dy = y - p.y;
        p.x = x;
        p.y = y;
        if (Math.hypot(x - p.sx, y - p.sy) > 4) p.moved = true;

        if (p.mode === 'gizmo') {
          this.gizmo.moveDrag(x, y, e.shiftKey);
          vp.style.cursor = 'grabbing';
          return;
        }
        if (p.mode === 'pending' && p.moved) {
          p.mode = 'orbit';
          vp.style.cursor = 'grabbing';
        }
        if (p.mode === 'orbit') {
          this.cameraRig.orbit(dx, dy);
          vp.style.cursor = 'grabbing';
        } else if (p.mode === 'pan') {
          this.cameraRig.pan(dx, dy);
          vp.style.cursor = 'grabbing';
        }
      });

      const finish = (e) => {
        const p = this.pointer;
        this.pointer = null;
        vp.style.cursor = 'default';
        if (!p) return;
        if (p.mode === 'gizmo') {
          this.gizmo.endDrag();
          return;
        }
        if (p.mode === 'pending' && !p.moved && e && e.type === 'pointerup') {
          const [x, y] = this._local(e);
          const id = this.pick(x, y);
          this.editor.select(id);
          if (id) this.editor.emit('camera');
        }
      };
      vp.addEventListener('pointerup', finish);
      vp.addEventListener('pointercancel', finish);

      vp.addEventListener('wheel', (e) => {
        if (this.editor.viewMode === 'game') return;
        e.preventDefault();
        this.cameraRig.zoom(e.deltaY);
      }, { passive: false });

      vp.addEventListener('dblclick', (e) => {
        if (e.target.closest('button')) return;
        const [x, y] = this._local(e);
        const id = this.pick(x, y);
        if (id) {
          this.editor.select(id);
          this.editor.focus(id);
        }
      });

      // quick focus in hierarchy by double-click handled in UI
      ed.on('focus', () => this.editor.focus());
    }

    pick(x, y) {
      const ray = this.cameraRig.ray(x, y);
      const world = this.editor.world();
      let best = null;
      let bestDist = Infinity;
      for (const node of this.editor.scene.nodes) {
        if (!node.visible) continue;
        const wm = world.get(node.id);
        if (!wm) continue;
        const inv = M.mat4.invert(wm);
        const o = M.mat4.point(inv, ray.origin);
        const d = M.mat4.dir(inv, ray.dir);
        const b = UW.scene.bounds(node);
        const t = M.rayAABB(o, d, b.min, b.max);
        if (t == null) continue;
        const localHit = [o[0] + d[0] * t, o[1] + d[1] * t, o[2] + d[2] * t];
        const wp = M.mat4.point(wm, localHit);
        const dist = V.dist(ray.origin, wp);
        if (dist < bestDist) {
          bestDist = dist;
          best = node.id;
        }
      }
      return best;
    }

    /* ---------------- keyboard ---------------- */
    _bindKeyboard() {
      const ed = this.editor;
      window.addEventListener('keydown', (e) => {
        const tag = (e.target.tagName || '').toLowerCase();
        const editing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
        const mod = e.ctrlKey || e.metaKey;

        // Modal dialogs (FSM graph, painter, environment, help) can hold scene
        // references that a global shortcut would invalidate, so ignore them.
        if (document.getElementById('modal-layer').classList.contains('open')) return;

        if (mod && e.key.toLowerCase() === 's') {
          e.preventDefault();
          UW.UI.saveSceneDialog();
          return;
        }
        if (mod && e.key.toLowerCase() === 'n') {
          e.preventDefault();
          UW.UI.newSceneDialog();
          return;
        }
        if (mod && e.key.toLowerCase() === 'o') {
          e.preventDefault();
          UW.UI.openScenesDialog();
          return;
        }
        if (mod && e.key.toLowerCase() === 'p') {
          e.preventDefault();
          if (e.shiftKey) {
            if (ed.playing) ed.pause();
          } else {
            ed.playing ? ed.stop() : ed.play();
          }
          return;
        }
        if (e.key === 'F1') {
          e.preventDefault();
          UW.UI.openHelp();
          return;
        }
        if (editing) return;

        if (mod && e.key.toLowerCase() === 'z') {
          e.preventDefault();
          if (e.shiftKey) ed.redo(); else ed.undo();
          return;
        }
        if (mod && e.key.toLowerCase() === 'y') {
          e.preventDefault();
          ed.redo();
          return;
        }
        if (mod && e.key.toLowerCase() === 'd') {
          e.preventDefault();
          if (ed.selected) ed.duplicateNode(ed.selected);
          return;
        }
        if (e.key === 'Delete' || e.key === 'Backspace') {
          if (ed.selected && !ed.playing) {
            e.preventDefault();
            ed.deleteNode(ed.selected);
          }
          return;
        }
        if (e.key === 'F') {
          ed.focus();
          return;
        }
        const tools = { q: 'select', w: 'translate', e: 'rotate', r: 'scale' };
        if (tools[e.key.toLowerCase()]) {
          ed.setTool(tools[e.key.toLowerCase()]);
          UW.UI.syncToolbar();
          return;
        }
        if (e.key === 'Escape') {
          if (document.getElementById('modal-layer').classList.contains('open')) return;
          if (ed.playing) ed.stop();
          else ed.select(null);
        }
      });
    }

    _bindResize() {
      const ro = new ResizeObserver(() => this.resize());
      ro.observe(this.stage);
      window.addEventListener('resize', () => this.resize());
    }

    _bindDrop() {
      const vp = this.viewport;
      const overlay = document.getElementById('drop-overlay');
      let depth = 0;
      ['dragenter', 'dragover'].forEach((ev) =>
        vp.addEventListener(ev, (e) => {
          if (!e.dataTransfer) return;
          if (!Array.from(e.dataTransfer.types).includes('Files')) return;
          e.preventDefault();
          if (ev === 'dragenter') depth++;
          overlay.classList.remove('hidden');
        })
      );
      vp.addEventListener('dragleave', () => {
        depth = Math.max(0, depth - 1);
        if (!depth) overlay.classList.add('hidden');
      });
      vp.addEventListener('drop', (e) => {
        if (!e.dataTransfer || !e.dataTransfer.files.length) return;
        e.preventDefault();
        depth = 0;
        overlay.classList.add('hidden');
        const file = e.dataTransfer.files[0];
        UW.UI.importSceneFile(file);
      });
    }

    screenshot() {
      if (!this.adapter || !this.adapter.canvas) return null;
      const a = this.adapter.canvas;
      const g = document.getElementById('gizmo');
      const out = document.createElement('canvas');
      out.width = a.width;
      out.height = a.height;
      const ctx = out.getContext('2d');
      ctx.drawImage(a, 0, 0, out.width, out.height);
      if (g && g.width) {
        try { ctx.drawImage(g, 0, 0, out.width, out.height); } catch (e) { /* ignore */ }
      }
      return out.toDataURL('image/png');
    }
  }

  // boot
  window.addEventListener('DOMContentLoaded', () => {
    const app = new App();
    UW.app = app;
    app.start().catch((e) => {
      console.error(e);
      document.body.insertAdjacentHTML('beforeend',
        '<pre style="position:fixed;left:10px;bottom:10px;z-index:999;color:#f88;background:#200;padding:10px;border-radius:6px;max-width:70vw;white-space:pre-wrap">' +
        String(e && e.stack || e) + '</pre>');
    });
  });
})();
