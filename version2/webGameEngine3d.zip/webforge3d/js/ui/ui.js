/* ============================================================
   ui.js — the Unity-style editor shell
   Menus, hierarchy, inspector, project panel, console, modals.
   All DOM is generated here; the scene model lives in editor.js.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;

  let app;
  let editor;
  const els = {};
  const S = {
    filter: '',
    logFilter: 'all',
    tab: 'assets',
    collapsed: new Set(),
    transformRefs: null,
    menuPopup: null,
    menuAnchor: null,
  };

  /* ------------------------------------------------------------
     tiny helpers
     ------------------------------------------------------------ */
  const $ = (id) => document.getElementById(id);
  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }
  function div(cls) { return el('div', cls); }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function iconEl(name, cls) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', cls || 'icon');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#' + name);
    svg.appendChild(use);
    return svg;
  }
  function icon(name, cls) {
    return '<svg class="' + (cls || 'icon') + '"><use href="#' + name + '"/></svg>';
  }
  function fmt(v) {
    if (!Number.isFinite(v)) return '0';
    return String(Math.round(v * 1000) / 1000);
  }
  function fmtTime(d) {
    const p = (n) => String(n).padStart(2, '0');
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }
  function fmtDate(ts) {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  const hasSelection = () => !!editor.selectedNode;

  /* ------------------------------------------------------------
     toasts / modal
     ------------------------------------------------------------ */
  function toast(message, kind) {
    const layer = $('toast-layer');
    const t = el('div', 'toast' + (kind ? ' ' + kind : ''), message);
    layer.appendChild(t);
    setTimeout(() => {
      t.style.transition = 'opacity .25s, transform .25s';
      t.style.opacity = '0';
      t.style.transform = 'translateX(10px)';
      setTimeout(() => t.remove(), 260);
    }, kind === 'error' ? 5200 : 3000);
  }

  let modalClose = null;

  function openModal(opts) {
    const layer = $('modal-layer');
    clear(layer);
    const card = div('modal' + (opts.wide ? ' wide' : '') + (opts.cls ? ' ' + opts.cls : ''));
    const head = div('modal-head');
    if (opts.icon) head.appendChild(iconEl(opts.icon, 'icon modal-icon'));
    head.appendChild(el('div', 'modal-title', opts.title || 'Dialog'));
    const x = el('button', 'icon-btn sm');
    x.appendChild(iconEl('i-close'));
    x.title = 'Close';
    x.addEventListener('click', () => closeModal());
    head.appendChild(x);
    card.appendChild(head);

    const body = div('modal-body');
    if (typeof opts.body === 'string') body.innerHTML = opts.body;
    else if (opts.body) body.appendChild(opts.body);
    card.appendChild(body);

    if (opts.actions && opts.actions.length) {
      const foot = div('modal-foot');
      for (const action of opts.actions) {
        const b = el('button', 'btn' + (action.kind ? ' ' + action.kind : ''), action.label);
        b.addEventListener('click', () => {
          if (action.action) {
            const keep = action.action(closeModal);
            if (keep === false) return;
          }
          if (action.keepOpen !== true) closeModal();
        });
        foot.appendChild(b);
      }
      card.appendChild(foot);
    }

    layer.appendChild(card);
    layer.classList.add('open');
    modalClose = () => {
      layer.classList.remove('open');
      layer.innerHTML = '';
      modalClose = null;
      if (opts.onClose) {
        try { opts.onClose(); } catch (e) { /* ignore */ }
      }
    };
    layer.onpointerdown = (e) => { if (e.target === layer) closeModal(); };
    return { close: closeModal, card, body };
  }

  function closeModal() {
    if (modalClose) modalClose();
  }

  function confirmModal(title, message, okLabel, onOk) {
    const body = div();
    body.appendChild(el('p', 'help-p', message));
    openModal({
      title,
      icon: 'i-help',
      body,
      actions: [
        { label: 'Cancel', kind: 'ghost' },
        { label: okLabel || 'OK', kind: 'danger', action: () => onOk() },
      ],
    });
  }

  /* ------------------------------------------------------------
     popup menus
     ------------------------------------------------------------ */
  function closeMenu() {
    if (S.menuPopup && S.menuPopup.parentNode) S.menuPopup.parentNode.removeChild(S.menuPopup);
    if (S.menuAnchor) S.menuAnchor.classList.remove('open');
    S.menuPopup = null;
    S.menuAnchor = null;
    document.removeEventListener('pointerdown', outsideMenu, true);
  }
  function outsideMenu(e) {
    if (!S.menuPopup) return;
    if (S.menuPopup.contains(e.target)) return;
    if (S.menuAnchor && S.menuAnchor.contains(e.target)) return;
    closeMenu();
  }

  function showPopup(items, anchor) {
    closeMenu();
    const layer = $('menu-layer');
    const pop = div('menu-popup');
    for (const it of items) {
      if (!it) continue;
      if (it.sep) { pop.appendChild(div('menu-sep')); continue; }
      if (it.header) { pop.appendChild(el('div', 'menu-label', it.header)); continue; }
      const b = el('button', 'menu-item');
      if (it.disabled) b.classList.add('disabled');
      if (it.icon) b.appendChild(iconEl(it.icon, 'icon mi-icon'));
      else b.appendChild(el('span', 'mi-icon'));
      b.appendChild(el('span', 'mi-label', it.label));
      if (it.shortcut) b.appendChild(el('span', 'mi-shortcut', it.shortcut));
      if (it.checked) {
        b.style.color = '#cfe4ff';
        b.style.background = 'rgba(74,158,255,.14)';
      }
      b.addEventListener('click', () => {
        closeMenu();
        if (it.action) it.action();
      });
      pop.appendChild(b);
    }
    layer.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    pop.style.left = Math.min(r.left, window.innerWidth - 250) + 'px';
    pop.style.top = r.bottom + 3 + 'px';
    const pr = pop.getBoundingClientRect();
    if (pr.bottom > window.innerHeight - 8) pop.style.top = Math.max(6, r.top - pr.height - 3) + 'px';
    S.menuPopup = pop;
    S.menuAnchor = anchor;
    if (anchor.classList.contains('menu-anchor')) anchor.classList.add('open');
    setTimeout(() => document.addEventListener('pointerdown', outsideMenu, true), 0);
  }

  function openMenu(name, anchor) {
    const items = menuItems(name);
    showPopup(items, anchor);
  }

  /* ------------------------------------------------------------
     menu definitions
     ------------------------------------------------------------ */
  function menuItems(name) {
    if (name === 'file') {
      return [
        { label: 'New Scene', shortcut: 'Ctrl+N', icon: 'i-plus', action: newSceneDialog },
        { label: 'Open Scene…', shortcut: 'Ctrl+O', icon: 'i-folder', action: openScenesDialog },
        { label: 'Save Scene', shortcut: 'Ctrl+S', icon: 'i-save', action: saveSceneDialog },
        { sep: true },
        { label: 'Download scene as .json', icon: 'i-save', action: downloadScene },
        { label: 'Import scene .json…', icon: 'i-folder', action: importDialog },
        { sep: true },
        { label: 'Reload editor', action: () => location.reload() },
      ];
    }
    if (name === 'edit') {
      const undo = editor.undoStack[editor.undoStack.length - 1];
      const redo = editor.redoStack[editor.redoStack.length - 1];
      return [
        { label: 'Undo' + (undo ? ' ' + undo.label : ''), shortcut: 'Ctrl+Z', icon: 'i-rotate', disabled: !editor.canUndo(), action: () => editor.undo() },
        { label: 'Redo' + (redo ? ' ' + redo.label : ''), shortcut: 'Ctrl+Shift+Z', icon: 'i-rotate', disabled: !editor.canRedo(), action: () => editor.redo() },
        { sep: true },
        { label: 'Duplicate', shortcut: 'Ctrl+D', icon: 'i-copy', disabled: !hasSelection(), action: () => editor.duplicateNode(editor.selected) },
        { label: 'Delete', shortcut: 'Del', icon: 'i-trash', disabled: !hasSelection(), action: () => editor.deleteNode(editor.selected) },
        { sep: true },
        { label: 'Focus selected', shortcut: 'F', icon: 'i-camera', disabled: !hasSelection(), action: () => editor.focus() },
        { label: 'Deselect', shortcut: 'Esc', disabled: !hasSelection(), action: () => editor.select(null) },
      ];
    }
    if (name === 'gameobject') {
      const items = [
        { label: 'Create Empty', icon: 'i-plus', action: () => editor.addNode('empty', { name: 'Empty' }) },
        { header: '3D Object' },
      ];
      for (const s of UW.geom.shapes) {
        items.push({ label: s.label, icon: s.icon, action: () => editor.addPrimitive(s.id) });
      }
      items.push({ sep: true }, { header: 'Light' });
      items.push({ label: 'Directional Light', icon: 'i-light', action: () => editor.addNode('light.directional') });
      items.push({ label: 'Point Light', icon: 'i-light', action: () => editor.addNode('light.point') });
      items.push({ label: 'Spot Light', icon: 'i-light', action: () => editor.addNode('light.spot') });
      items.push({ sep: true }, { header: 'Camera' });
      items.push({ label: 'Camera', icon: 'i-camera', action: () => editor.addNode('camera') });
      return items;
    }
    if (name === 'component') {
      const node = editor.selectedNode;
      const mesh = node && node.type === 'mesh';
      return [
        { header: 'Rendering' },
        { label: 'Mesh Renderer', icon: 'i-cube', disabled: !mesh, action: () => { } },
        { label: 'Texture / Material', icon: 'i-grid', disabled: !mesh || !!(node && node.mesh && node.mesh.texture), action: () => { if (node) { editor.addComponent(node.id, 'texture'); renderInspector(); } } },
        { label: 'Camera', icon: 'i-camera', disabled: !node || node.type === 'camera', action: () => { if (node) editor.addComponent(node.id, 'camera'); } },
        { sep: true },
        { header: 'Physics' },
        { label: 'Rigidbody', icon: 'i-sphere', disabled: !mesh || !!node.rigidbody, action: () => editor.addComponent(node.id, 'rigidbody') },
        { sep: true },
        { header: 'Scripting' },
        { label: 'JavaScript Script', icon: 'i-code', disabled: !node || !!node.script, action: () => { if (node) { editor.addComponent(node.id, 'script'); renderInspector(); openScriptEditor(node); } } },
        { label: 'PlayMaker FSM', icon: 'i-link', disabled: !node || !!node.fsm, action: () => { if (node) { editor.addComponent(node.id, 'fsm'); renderInspector(); UW.Graph.open(node, editor); } } },
        { sep: true },
        { header: 'Behaviors' },
        { label: 'Spin', disabled: !mesh, action: () => editor.addBehavior(node.id, 'spin') },
        { label: 'Bob', disabled: !mesh, action: () => editor.addBehavior(node.id, 'bob') },
        { label: 'Pulse', disabled: !mesh, action: () => editor.addBehavior(node.id, 'pulse') },
        { label: 'Orbit', disabled: !mesh, action: () => editor.addBehavior(node.id, 'orbit') },
      ];
    }
    if (name === 'window') {
      const node = editor.selectedNode;
      return [
        { label: 'Environment / Lighting…', icon: 'i-settings', action: openEnvironmentDialog },
        { label: 'Texture Painter…', icon: 'i-grid', disabled: !node || node.type !== 'mesh', action: () => openTexturePainter(node) },
        { label: 'FSM Graph Editor…', icon: 'i-link', disabled: !node, action: openFsmGraph },
        { label: 'Engine Compatibility…', icon: 'i-engine', action: openCompatibilityDialog },
        { sep: true },
        { label: 'Toggle Grid', icon: 'i-grid', checked: editor.scene.env.showGrid !== false, action: () => { editor.setEnv('showGrid', editor.scene.env.showGrid === false); syncToolbar(); } },
      ];
    }
    if (name === 'engine') {
      const items = [{ header: 'Rendering engine' }];
      for (const def of UW.engines.list()) {
        items.push({
          label: def.name + (def.version ? ' ' + def.version : ''),
          icon: def.id === editor.engineId ? 'i-check' : 'i-engine',
          checked: def.id === editor.engineId,
          action: () => app.setEngine(def.id),
        });
      }
      items.push({ sep: true });
      items.push({ label: 'Engine compatibility…', icon: 'i-check', action: openCompatibilityDialog });
      items.push({ label: 'Connect engine plugin…', icon: 'i-link', action: connectEngineDialog });
      items.push({ label: 'Engine API reference', icon: 'i-help', action: () => openHelp('api') });
      return items;
    }
    if (name === 'help') {
      return [
        { label: 'Keyboard shortcuts', shortcut: 'F1', icon: 'i-help', action: () => openHelp() },
        { label: 'Scripting & plugin API', icon: 'i-code', action: () => openHelp('api') },
        { sep: true },
        { label: 'Open engine documentation', icon: 'i-link', action: openEngineDocs },
        { label: 'Engine compatibility matrix', icon: 'i-engine', action: openCompatibilityDialog },
        { label: 'About WebForge 3D', icon: 'i-cube', action: aboutDialog },
      ];
    }
    return [];
  }

  function openEngineDocs() {
    if (app.activeDef && app.activeDef.url) window.open(app.activeDef.url, '_blank', 'noopener');
    else toast('This engine has no external documentation link.', 'warn');
  }

  /* ------------------------------------------------------------
     engine compatibility matrix
     ------------------------------------------------------------ */
  function capLabel(level) {
    return { full: 'Full', partial: 'Partial', none: 'None', unknown: 'Unknown' }[level] || 'Unknown';
  }

  function openCompatibilityDialog() {
    const defs = UW.engines.list();
    const features = UW.engines.features;
    const body = div();

    body.appendChild(el('p', 'help-p',
      'The scene model, PlayMaker FSMs, JavaScript scripts, physics and saving are shared by every engine. ' +
      'The matrix below only describes rendering features; the active engine is highlighted.'));

    const wrap = div('compat-wrap');
    const table = el('table', 'compat-table');
    const thead = document.createElement('thead');
    const headRow = document.createElement('tr');
    const featureHead = document.createElement('th');
    featureHead.textContent = 'Feature';
    headRow.appendChild(featureHead);
    for (const def of defs) {
      const th = document.createElement('th');
      if (def.id === editor.engineId) th.classList.add('compat-active');
      th.appendChild(el('span', 'compat-engine-name', def.name));
      if (def.version) th.appendChild(el('span', 'compat-engine-ver', def.version));
      headRow.appendChild(th);
    }
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    for (const f of features) {
      const tr = document.createElement('tr');
      const th = document.createElement('th');
      th.appendChild(el('span', 'compat-feature-name', f.label));
      if (f.help) th.appendChild(el('span', 'compat-feature-help', f.help));
      tr.appendChild(th);
      for (const def of defs) {
        const cap = UW.engines.capability(def, f.id);
        const td = document.createElement('td');
        if (def.id === editor.engineId) td.classList.add('compat-active');
        const chip = el('span', 'compat-level compat-' + cap.level, capLabel(cap.level));
        if (cap.note) chip.title = cap.note;
        td.appendChild(chip);
        if (cap.note) td.appendChild(el('span', 'compat-note', cap.note));
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    wrap.appendChild(table);
    body.appendChild(wrap);

    const legend = div('compat-legend');
    for (const [level, text] of [
      ['full', 'Full — implemented natively'],
      ['partial', 'Partial — approximate or limited'],
      ['none', 'None — not rendered'],
      ['unknown', 'Unknown — plugin did not declare it'],
    ]) {
      const item = el('span', 'compat-legend-item');
      item.appendChild(el('span', 'compat-level compat-' + level, capLabel(level)));
      item.appendChild(el('span', null, text));
      legend.appendChild(item);
    }
    body.appendChild(legend);

    body.appendChild(el('p', 'help-p',
      'Plugin authors can add a <code>capabilities</code> object to <code>UnityWeb.engines.register({…})</code>. ' +
      'Undefined features are shown as Unknown instead of being guessed. FSM actions are runtime-only, so they always work, ' +
      'even when a renderer cannot show shadows or PBR shading.'));

    openModal({
      title: 'Engine Compatibility',
      icon: 'i-engine',
      wide: true,
      cls: 'compat-modal',
      body,
      actions: [{ label: 'Close', kind: 'primary' }],
    });
  }

  /* ------------------------------------------------------------
     modals: scenes, scripts, plugins, help
     ------------------------------------------------------------ */
  function saveSceneDialog() {
    const field = div('field');
    field.appendChild(el('label', null, 'Scene name'));
    const input = document.createElement('input');
    input.type = 'text';
    input.value = editor.sceneName || 'Untitled Scene';
    field.appendChild(input);
    field.appendChild(el('div', 'hint', 'Scenes are stored in this browser (localStorage). Download a .json copy from the File menu to keep a file.'));
    openModal({
      title: 'Save Scene',
      icon: 'i-save',
      body: field,
      actions: [
        { label: 'Cancel', kind: 'ghost' },
        {
          label: 'Save', kind: 'primary',
          action: (close) => {
            const name = input.value.trim();
            if (!name) { input.focus(); return false; }
            const saved = editor.saveScene(name);
            if (!saved) {
              toast('Browser storage is full — download the scene as JSON instead.', 'error');
              return false;
            }
            toast('Scene saved: ' + name, 'ok');
            renderAssets();
            renderStatus();
          },
        },
      ],
    });
    setTimeout(() => { input.focus(); input.select(); }, 40);
  }

  function doNewScene() {
    if (editor.playing) editor.stop();
    editor.undoStack.length = 0;
    editor.redoStack.length = 0;
    editor.restore(UW.scene.emptyScene(), { dirty: false });
    editor.sceneName = 'Untitled Scene';
    const camera = editor.scene.nodes.find((n) => n.type === 'camera');
    editor.selected = camera ? camera.id : null;
    editor.camera = { yaw: 0.68, pitch: 0.26, distance: 11, target: [0, 1.2, 0] };
    editor.emit('selection', editor.selected);
    editor.emit('structure');
    editor.dirty = false;
    toast('New scene created.', 'ok');
  }

  function newSceneDialog() {
    if (!editor.dirty) { doNewScene(); return; }
    confirmModal('New Scene', 'Discard unsaved changes and start a new scene?', 'Discard', doNewScene);
  }

  function openScenesDialog() {
    const list = editor.storage();
    const body = div();
    if (!list.length) {
      body.appendChild(el('p', 'help-p', 'No saved scenes yet. Use File → Save Scene (Ctrl+S).'));
    } else {
      const wrap = div();
      wrap.style.display = 'flex';
      wrap.style.flexDirection = 'column';
      wrap.style.gap = '5px';
      for (const entry of list) {
        const row = div('behavior-row');
        row.style.padding = '7px 8px';
        const ico = div('script-ico');
        ico.style.background = '#22303f';
        ico.style.color = '#8fc3ff';
        ico.appendChild(iconEl('i-folder'));
        row.appendChild(ico);
        const meta = div();
        meta.style.flex = '1';
        meta.appendChild(el('div', 'b-name', entry.name));
        meta.appendChild(el('div', 'b-params', fmtDate(entry.savedAt) + ' · ' + (entry.data.nodes ? entry.data.nodes.length : 0) + ' objects'));
        row.appendChild(meta);
        const load = el('button', 'btn', 'Open');
        load.addEventListener('click', () => {
          closeModal();
          if (editor.loadScene(entry.name)) {
            app.cameraRig.editor.camera.distance = 12;
            toast('Loaded scene: ' + entry.name, 'ok');
            renderAssets();
          }
        });
        row.appendChild(load);
        const del = el('button', 'icon-btn sm');
        del.appendChild(iconEl('i-trash'));
        del.title = 'Delete scene';
        del.addEventListener('click', () => {
          editor.deleteScene(entry.name);
          closeModal();
          renderAssets();
          toast('Deleted scene: ' + entry.name, 'warn');
        });
        row.appendChild(del);
        wrap.appendChild(row);
      }
      body.appendChild(wrap);
    }
    openModal({ title: 'Open Scene', icon: 'i-folder', body, actions: [{ label: 'Close', kind: 'ghost' }] });
  }

  function downloadScene() {
    const data = editor.serializeScene();
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (editor.sceneName || 'scene').replace(/[^\w\-]+/g, '_') + '.json';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 0);
    toast('Scene downloaded as .json', 'ok');
  }

  function importDialog() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.onchange = () => { if (input.files && input.files[0]) importSceneFile(input.files[0]); };
    input.click();
  }

  function importSceneFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        UW.scene.normalize(data);
        if (editor.playing) editor.stop();
        editor.undoStack.length = 0;
        editor.redoStack.length = 0;
        editor.restore(data);
        editor.sceneName = data.name || file.name.replace(/\.json$/i, '');
        editor.dirty = true;
        editor.select(null);
        toast('Scene imported: ' + file.name, 'ok');
        renderAssets();
        renderStatus();
      } catch (e) {
        toast('Invalid scene file: ' + e.message, 'error');
        editor.log('error', 'Import failed: ' + e.message);
      }
    };
    reader.readAsText(file);
  }

  function openScriptEditor(node) {
    if (!node) return;
    if (!node.script) node.script = { name: 'NewBehavior', code: UW.DEFAULT_SCRIPT };
    const body = div();
    const row = div('script-toolbar');
    const nameField = div('field');
    nameField.style.flex = '1';
    nameField.appendChild(el('label', null, 'Script name'));
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.value = node.script.name || 'NewBehavior';
    nameField.appendChild(nameInput);
    row.appendChild(nameField);
    const spacer = div('spacer');
    row.appendChild(spacer);
    const tpl = el('button', 'btn ghost', 'Insert example');
    tpl.addEventListener('click', () => {
      area.value = UW.DEFAULT_SCRIPT;
      toast('Example script inserted.', 'info');
    });
    row.appendChild(tpl);
    body.appendChild(row);

    const area = document.createElement('textarea');
    area.className = 'code-area';
    area.spellcheck = false;
    area.value = node.script.code || '';
    area.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const s = area.selectionStart;
        area.value = area.value.slice(0, s) + '  ' + area.value.slice(area.selectionEnd);
        area.selectionStart = area.selectionEnd = s + 2;
      }
    });
    body.appendChild(area);
    body.appendChild(el('div', 'hint', 'Hooks: onStart(ctx), onUpdate(ctx, dt), onStop(ctx). Runs only in Play mode; errors appear in the Console.'));

    openModal({
      title: 'JavaScript Script — ' + node.name,
      icon: 'i-code',
      wide: true,
      body,
      actions: [
        { label: 'Cancel', kind: 'ghost' },
        {
          label: 'Apply', kind: 'primary',
          action: () => {
            const code = area.value;
            const name = nameInput.value.trim() || 'Script';
            editor.transact('Edit script', () => {
              node.script = { name, code };
            });
            toast('Script saved: ' + name, 'ok');
            renderInspector();
          },
        },
      ],
    });
  }

  function connectEngineDialog() {
    const body = div();
    const field = div('field');
    field.appendChild(el('label', null, 'Adapter script URL'));
    const input = document.createElement('input');
    input.type = 'text';
    input.value = 'plugins/blueprint-canvas.js';
    field.appendChild(input);
    field.appendChild(el('div', 'hint', 'A plain <script> that calls UnityWeb.engines.register({...}). Relative paths work; CDN URLs must allow cross-origin script loading.'));
    body.appendChild(field);

    const example = div('field');
    example.appendChild(el('label', null, 'Minimal adapter registration'));
    const pre = document.createElement('pre');
    pre.style.cssText = 'margin:0;padding:9px;background:#171a1e;border:1px solid #343a42;border-radius:4px;font-family:var(--mono);font-size:10px;color:#b9c9dc;overflow:auto;line-height:1.55';
    pre.textContent = [
      'UnityWeb.engines.register({',
      "  id: 'my-engine',",
      "  name: 'My Engine',",
      '  version: "1.0",',
      '  license: "MIT",',
      '  async load() { /* load the runtime */ },',
      '  create(def) {',
      '    return {',
      '      async init(host) { /* create a canvas in host */ },',
      '      resize(w, h, dpr) {},',
      '      update(frame) { /* frame.scene / frame.cam */ },',
      '      render() {},',
      '      getStats() { return { triangles: 0, objects: 0 }; },',
      '      dispose() {}',
      '    };',
      '  }',
      '});',
    ].join('\n');
    example.appendChild(pre);
    body.appendChild(example);

    const note = el('div', 'help-note');
    note.innerHTML = 'Included example: <code>plugins/blueprint-canvas.js</code> — a working “Blueprint” renderer that reuses the native canvas pipeline.';
    body.appendChild(note);

    openModal({
      title: 'Connect Engine Plugin',
      icon: 'i-link',
      wide: true,
      body,
      actions: [
        { label: 'Cancel', kind: 'ghost' },
        {
          label: 'Load plugin', kind: 'primary',
          action: (close) => {
            const url = input.value.trim();
            if (!url) { input.focus(); return false; }
            const before = new Set(UW.engines.list().map((d) => d.id));
            toast('Loading engine plugin…', 'info');
            loadScriptUrl(url)
              .then(() => {
                const added = UW.engines.list().filter((d) => !before.has(d.id));
                if (!added.length) throw new Error('script loaded but no new engine was registered');
                close();
                renderEngineSelect();
                renderEngines();
                renderEngineDoc();
                toast('Engine connected: ' + added.map((d) => d.name).join(', '), 'ok');
                app.setEngine(added[added.length - 1].id);
              })
              .catch((err) => {
                toast('Plugin failed: ' + err.message, 'error');
                editor.log('error', 'Engine plugin failed: ' + err.message);
              });
            return false;
          },
        },
      ],
    });
    setTimeout(() => input.select(), 60);
  }

  function loadScriptUrl(url) {
    return new Promise((resolve, reject) => {
      const abs = new URL(url, location.href).href;
      const existing = Array.from(document.scripts).find((s) => s.src === abs);
      if (existing) {
        resolve();
        return;
      }
      const s = document.createElement('script');
      const timer = setTimeout(() => reject(new Error('timed out loading ' + url)), 20000);
      s.src = url;
      s.async = true;
      s.onload = () => { clearTimeout(timer); resolve(); };
      s.onerror = () => { clearTimeout(timer); reject(new Error('could not fetch ' + url)); };
      document.head.appendChild(s);
    });
  }

  function openHelp(section) {
    const body = div();
    if (section !== 'api') {
      body.appendChild(el('div', 'help-section-title', 'Getting started'));
      const p = el('p', 'help-p');
      p.innerHTML = 'The layout mirrors Unity: <b>Hierarchy</b> on the left, <b>Scene/Game</b> viewport in the middle, <b>Inspector</b> on the right and the <b>Project</b> panel at the bottom. Pick a rendering engine from the select in the toolbar — the same scene renders on all of them.';
      body.appendChild(p);

      body.appendChild(el('div', 'help-section-title', 'Keyboard'));
      const grid = div('shortcut-grid');
      const shortcuts = [
        ['Move / Rotate / Scale', 'W / E / R'],
        ['Select tool', 'Q'],
        ['Focus selected', 'F'],
        ['Play / stop', 'Ctrl + P'],
        ['Pause', 'Ctrl + Shift + P'],
        ['Undo / redo', 'Ctrl + Z / Y'],
        ['Duplicate', 'Ctrl + D'],
        ['Delete object', 'Del'],
        ['Save scene', 'Ctrl + S'],
        ['Orbit viewport', 'LMB drag'],
        ['Pan viewport', 'MMB / Shift+LMB'],
        ['Zoom viewport', 'Wheel'],
        ['Snap rotate / translate', 'Shift while dragging'],
        ['Help', 'F1'],
      ];
      for (const [label, key] of shortcuts) {
        const row = div('shortcut-row');
        row.appendChild(el('span', null, label));
        const kbd = document.createElement('kbd');
        kbd.textContent = key;
        row.appendChild(kbd);
        grid.appendChild(row);
      }
      body.appendChild(grid);

      body.appendChild(el('div', 'help-section-title', 'Engines & plugins'));
      const p2 = el('p', 'help-p');
      p2.innerHTML = 'Three.js and Babylon.js are loaded on demand from their CDNs; <b>Native Canvas</b> is built in and works offline. The engine menu and the left <b>Engines</b> panel switch renderers instantly without touching the scene. Connect your own adapter with <b>Engine → Connect engine plugin…</b>. Open <b>Window → Engine Compatibility…</b> for a feature matrix, or read the capability rows in the <b>Engine API</b> panel.';
      body.appendChild(p2);

      body.appendChild(el('div', 'help-section-title', 'Play mode'));
      const p3 = el('p', 'help-p');
      p3.innerHTML = 'Rigidbody components fall and collide with the ground and other meshes (root objects only). Behaviors, JavaScript scripts and PlayMaker FSMs run only in Play mode, and stopping restores the scene exactly as it was.';
      body.appendChild(p3);

      body.appendChild(el('div', 'help-section-title', 'Textures, lights & FSM'));
      const p3b = el('p', 'help-p');
      p3b.innerHTML = 'Add a <b>Texture / Material</b> component to any mesh, then pick a preset, upload an image or open <b>Window → Texture Painter…</b>. <b>Window → Environment / Lighting…</b> controls ambient light, the grid and fog. Add a <b>PlayMaker FSM</b> component to build a state graph with <b>Window → FSM Graph Editor…</b>.';
      body.appendChild(p3b);

      body.appendChild(el('div', 'help-section-title', 'PlayMaker actions & triggers'));
      const fsmMeta = UW.FSM;
      const pActs = el('p', 'help-p');
      const catLabels = fsmMeta.categories.map((c) => c.label).join(', ');
      pActs.innerHTML = 'FSMs include <b>' + fsmMeta.actionTypes.length + ' actions</b> in <b>' +
        fsmMeta.categories.length + ' categories</b> (' + catLabels + '). Actions can move, rotate and scale objects with tweens, ' +
        'wait, send events, do variable math and branching, change materials and textures, control lights and cameras, ' +
        'apply physics impulses, play tones, toast messages and start or stop other FSMs. Actions run in order when a state is entered; ' +
        'tween actions can block the remaining list until they finish. Every action works through the shared scene runtime, so it behaves identically on every engine.';
      body.appendChild(pActs);
      const pTrig = el('p', 'help-p');
      pTrig.innerHTML = 'Transitions can fire <b>after a delay</b>, <b>on an event</b>, <b>while a key is held</b>, ' +
        '<b>on key down</b>, <b>on key up</b> or <b>on a variable comparison</b>. The first matching transition from the current state wins, and transitions are checked every frame.';
      body.appendChild(pTrig);
    }

    body.appendChild(el('div', 'help-section-title', 'Script component'));
    const code = document.createElement('pre');
    code.style.cssText = 'margin:0;padding:10px;background:#171a1e;border:1px solid #343a42;border-radius:4px;font-family:var(--mono);font-size:10px;color:#c9d8ea;overflow:auto;line-height:1.6';
    code.textContent = [
      'function onStart(ctx) {',
      '  ctx.log("ready: " + ctx.node.name);',
      '}',
      '',
      'function onUpdate(ctx, dt) {',
      '  ctx.node.transform.rotation.y += 55 * dt;',
      '  ctx.node.transform.position.y += Math.sin(ctx.time * 2) * 0.003;',
      '}',
    ].join('\n');
    body.appendChild(code);
    const p4 = el('p', 'help-p');
    p4.innerHTML = 'Add one from <b>Add Component → JavaScript Script</b>, or from the Component menu. The context exposes <code>node</code>, <code>scene</code>, <code>find()</code>, <code>log()</code>, <code>emitEvent()</code>, <code>time</code>, <code>dt</code> and the shared math helpers.';
    body.appendChild(p4);

    if (section === 'api') {
      body.appendChild(el('div', 'help-section-title', 'Registering a rendering engine'));
      const api = document.createElement('pre');
      api.style.cssText = code.style.cssText;
      api.textContent = [
        'UnityWeb.engines.register({',
        '  id: "engine-id", name: "Engine name", version: "1.0",',
        '  license: "MIT", vendor: "…", url: "https://…",',
        '',
        '  async load() {',
        '    // inject the engine runtime (script tag, dynamic import, wasm…)',
        '  },',
        '',
        '  create(def) {',
        '    return {',
        '      async init(host) {},     // host = #stage element',
        '      resize(w, h, dpr) {},',
        '      update(frame) {},        // frame: { scene, cam, viewMode, selected, env }',
        '      render() {},',
        '      getStats() {},',
        '      dispose() {},',
        '    };',
        '  }',
        '});',
      ].join('\n');
      body.appendChild(api);
      body.appendChild(el('p', 'help-p', 'Because the adapter only reads the scene model, every engine automatically gets hierarchy, inspector, gizmos, play mode and saving for free.'));
    }

    openModal({
      title: section === 'api' ? 'Engine & Scripting API' : 'WebForge 3D — Help',
      icon: 'i-help',
      wide: true,
      body,
      actions: [{ label: 'Close', kind: 'primary' }],
    });
  }

  function aboutDialog() {
    const body = div();
    const p = el('p', 'help-p');
    p.innerHTML = '<b>WebForge 3D</b> is a Unity-inspired web scene editor written in plain HTML, CSS and JavaScript. No build step, no Node.js, no server, no database.';
    body.appendChild(p);
    body.appendChild(el('p', 'help-p', 'Engines: Three.js (MIT), Babylon.js (Apache 2.0), Native Canvas (built in). Add adapters at runtime through the plugin API.'));
    body.appendChild(el('p', 'help-p', 'Scene format: plain JSON, saved to localStorage or downloaded as a file.'));
    openModal({ title: 'About', icon: 'i-cube', body, actions: [{ label: 'Close', kind: 'primary' }] });
  }

  /* ------------------------------------------------------------
     textures, painting & environment
     ------------------------------------------------------------ */
  function ensureTexture(node) {
    if (!node || node.type !== 'mesh') return null;
    if (!node.mesh.texture) editor.addComponent(node.id, 'texture');
    node.mesh.texture = UW.textures.normalize(node.mesh.texture) || UW.textures.defaultTexture('checker');
    return node.mesh.texture;
  }

  function uploadTexture(node) {
    const tex = ensureTexture(node);
    if (!tex) return;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = () => {
      const file = input.files && input.files[0];
      if (!file) return;
      if (file.size > 4 * 1024 * 1024) {
        toast('Image is larger than 4 MB. Pick a smaller texture.', 'warn');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        editor.beginEdit();
        tex.data = String(reader.result);
        tex.preset = 'uploaded';
        tex.enabled = true;
        editor.touch();
        editor.commitEdit('Upload texture');
        UW.textures.rev++;
        renderInspector();
        toast('Texture applied: ' + file.name, 'ok');
      };
      reader.onerror = () => toast('Could not read that image.', 'error');
      reader.readAsDataURL(file);
    };
    input.click();
  }

  function openTexturePainter(node) {
    const tex = ensureTexture(node);
    if (!tex) { toast('Select a mesh object to paint a texture.', 'warn'); return; }

    const body = div();
    const bar = div('painter-toolbar');
    const color = document.createElement('input');
    color.type = 'color';
    color.value = '#5b9bd5';
    color.title = 'Brush color';
    bar.appendChild(color);

    const modes = div('seg painter-modes');
    const brushBtn = el('button', 'active', 'Brush');
    const eraseBtn = el('button', null, 'Eraser');
    modes.appendChild(brushBtn);
    modes.appendChild(eraseBtn);
    bar.appendChild(modes);

    const sizeLabel = el('span', 'painter-label', 'Size');
    bar.appendChild(sizeLabel);
    const size = document.createElement('input');
    size.type = 'range';
    size.min = '1';
    size.max = '64';
    size.step = '1';
    size.value = '16';
    size.className = 'painter-size';
    bar.appendChild(size);
    const sizeRead = el('span', 'painter-read', '16');
    bar.appendChild(sizeRead);

    const fillBtn = el('button', 'btn', 'Fill');
    const clearBtn = el('button', 'btn ghost', 'Clear');
    bar.appendChild(fillBtn);
    bar.appendChild(clearBtn);
    body.appendChild(bar);

    const holder = div('texture-paint-holder');
    const canvas = document.createElement('canvas');
    canvas.className = 'texture-paint-canvas';
    canvas.width = 512;
    canvas.height = 512;
    holder.appendChild(canvas);
    body.appendChild(holder);

    const hint = el('div', 'hint', 'Paint with the mouse. “Fill” floods the whole texture with the brush color; “Clear” resets it to white. Saving stores the painted image inside the scene (offline, no assets folder required).');
    body.appendChild(hint);

    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#2a2f36';
    ctx.fillRect(0, 0, 512, 512);
    const base = UW.textures.getBase(tex);
    if (base) {
      try { ctx.drawImage(base, 0, 0, 512, 512); } catch (e) { /* ignore */ }
    }

    let mode = 'brush';
    let drawing = false;
    let last = null;
    const point = (e) => {
      const r = canvas.getBoundingClientRect();
      return [
        (e.clientX - r.left) * (canvas.width / Math.max(1, r.width)),
        (e.clientY - r.top) * (canvas.height / Math.max(1, r.height)),
      ];
    };
    const stroke = (a, b) => {
      ctx.save();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = +size.value;
      ctx.strokeStyle = mode === 'erase' ? '#ffffff' : color.value;
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.lineTo(b[0], b[1]);
      ctx.stroke();
      ctx.restore();
    };
    canvas.addEventListener('pointerdown', (e) => {
      drawing = true;
      last = point(e);
      canvas.setPointerCapture(e.pointerId);
      stroke(last, [last[0] + 0.01, last[1] + 0.01]);
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!drawing) return;
      const p = point(e);
      stroke(last, p);
      last = p;
    });
    const end = () => { drawing = false; last = null; };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    canvas.addEventListener('pointerleave', () => { if (!drawing) last = null; });

    brushBtn.addEventListener('click', () => {
      mode = 'brush';
      brushBtn.classList.add('active');
      eraseBtn.classList.remove('active');
    });
    eraseBtn.addEventListener('click', () => {
      mode = 'erase';
      eraseBtn.classList.add('active');
      brushBtn.classList.remove('active');
    });
    size.addEventListener('input', () => { sizeRead.textContent = size.value; });
    fillBtn.addEventListener('click', () => {
      ctx.fillStyle = mode === 'erase' ? '#ffffff' : color.value;
      ctx.fillRect(0, 0, 512, 512);
    });
    clearBtn.addEventListener('click', () => {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 512, 512);
    });

    openModal({
      title: 'Texture Painter — ' + node.name,
      icon: 'i-grid',
      wide: true,
      cls: 'painter-modal',
      body,
      actions: [
        { label: 'Cancel', kind: 'ghost' },
        {
          label: 'Save texture', kind: 'primary',
          action: () => {
            editor.beginEdit();
            tex.data = canvas.toDataURL('image/jpeg', 0.9);
            tex.preset = 'painted';
            tex.enabled = true;
            editor.touch();
            editor.commitEdit('Paint texture');
            UW.textures.rev++;
            renderInspector();
            toast('Painted texture saved to ' + node.name + '.', 'ok');
            setTimeout(() => { if (editor.selectedNode === node) renderInspector(); }, 260);
          },
        },
      ],
    });
  }

  function textureComponent(node) {
    const tex = node.mesh.texture;
    const sec = componentSection('Texture', 'i-grid', {
      sub: tex.data ? 'custom' : tex.preset,
      onRemove: () => {
        editor.removeComponent(node.id, 'texture');
        renderInspector();
      },
    });

    const preview = div('texture-preview');
    const pv = UW.textures.makePreview(tex, 64);
    pv.className = 'texture-preview-canvas';
    preview.appendChild(pv);
    const meta = div('texture-preview-meta');
    meta.appendChild(el('div', 'texture-preview-title', tex.data ? 'Painted / image' : (UW.textures.presets.find((p) => p.id === tex.preset) || { label: tex.preset }).label));
    meta.appendChild(el('div', 'texture-preview-sub', tex.enabled === false ? 'not displayed' : 'applied to mesh'));
    const btns = div('texture-buttons');
    const paint = el('button', 'btn', 'Paint…');
    paint.style.height = '22px';
    paint.style.padding = '0 9px';
    paint.addEventListener('click', () => openTexturePainter(node));
    btns.appendChild(paint);
    const up = el('button', 'btn', 'Upload…');
    up.style.height = '22px';
    up.style.padding = '0 9px';
    up.addEventListener('click', () => uploadTexture(node));
    btns.appendChild(up);
    meta.appendChild(btns);
    preview.appendChild(meta);
    sec.body.appendChild(preview);

    const options = UW.textures.presets.map((p) => ({ value: p.id, label: p.label }));
    if (tex.data) options.unshift({ value: '__custom', label: 'Custom image / painting' });
    sec.body.appendChild(row('Source', selectField(options, tex.data ? '__custom' : tex.preset, (v) => {
      if (v === '__custom') return;
      editor.beginEdit();
      tex.data = null;
      tex.preset = v;
      tex.enabled = true;
      editor.touch();
      editor.commitEdit('Texture preset');
      renderInspector();
    })));

    sec.body.appendChild(row('Visible', checkField('Show texture', tex.enabled !== false, (v) => {
      editor.beginEdit();
      tex.enabled = v;
      editor.touch();
      editor.commitEdit('Texture visibility');
      renderInspector();
    })));

    const tiling = div('vec-row');
    const offs = div('vec-row');
    [0, 1].forEach((i) => {
      const g = div('vec-axis ' + (i ? 'y' : 'x'));
      g.appendChild(el('span', null, i ? 'Y' : 'X'));
      g.appendChild(numInput(tex.tiling[i], (v) => {
        tex.tiling[i] = Math.max(0.05, Math.min(16, v));
        editor.touch();
      }, { step: 0.1, min: 0.05, max: 16, label: 'Texture tiling' }));
      tiling.appendChild(g);
    });
    [0, 1].forEach((i) => {
      const g = div('vec-axis ' + (i ? 'y' : 'x'));
      g.appendChild(el('span', null, i ? 'Y' : 'X'));
      g.appendChild(numInput(tex.offset[i], (v) => {
        tex.offset[i] = v;
        editor.touch();
      }, { step: 0.05, label: 'Texture offset' }));
      offs.appendChild(g);
    });
    sec.body.appendChild(row('Tiling', tiling));
    sec.body.appendChild(row('Offset', offs));
    sec.body.appendChild(el('div', 'help-note', 'Tiling repeats the image across UVs. Offset shifts it. Textures are procedural, uploaded or painted and are shared by every render engine.'));
    return sec;
  }

  function openEnvironmentDialog() {
    const env = editor.scene.env || UW.scene.defaultEnv();
    const body = div();

    const amb = componentSection('Ambient Light', 'i-light', { sub: 'scene-wide' });
    amb.body.appendChild(row('Intensity', sliderField(env.ambient, 0, 2, 0.01, (v) => {
      env.ambient = v;
      editor.setEnv('ambient', v);
    }, (v) => v.toFixed(2))));
    amb.body.appendChild(row('Color', colorField(env.ambientColor || '#ffffff', (v) => {
      env.ambientColor = v;
      editor.setEnv('ambientColor', v);
    })));
    body.appendChild(amb.root);

    const sceneSec = componentSection('Scene', 'i-grid', { sub: 'viewport' });
    sceneSec.body.appendChild(row('Grid', checkField('Show grid in Scene view', env.showGrid !== false, (v) => {
      editor.beginEdit();
      editor.setEnv('showGrid', v);
      editor.commitEdit('Environment');
      syncToolbar();
    })));
    body.appendChild(sceneSec.root);

    const fog = componentSection('Fog', 'i-settings', { sub: env.fogEnabled ? 'on' : 'off' });
    fog.body.appendChild(row('Enabled', checkField('Enable distance fog', !!env.fogEnabled, (v) => {
      editor.beginEdit();
      editor.setEnv('fogEnabled', v);
      editor.commitEdit('Environment');
      fog.root.querySelector('.comp-sub').textContent = v ? 'on' : 'off';
    })));
    fog.body.appendChild(row('Color', colorField(env.fogColor || '#1d2025', (v) => {
      env.fogColor = v;
      editor.setEnv('fogColor', v);
    })));
    fog.body.appendChild(row('Near', numInput(env.fogNear, (v) => {
      env.fogNear = Math.max(0, Math.min(Math.max(0, env.fogFar - 0.1), v));
      editor.setEnv('fogNear', env.fogNear);
    }, { step: 1, min: 0, label: 'Fog' })));
    fog.body.appendChild(row('Far', numInput(env.fogFar, (v) => {
      env.fogFar = Math.max(env.fogNear + 0.1, v);
      editor.setEnv('fogFar', env.fogFar);
    }, { step: 5, min: 0.1, label: 'Fog' })));
    fog.body.appendChild(el('div', 'help-note', 'Fog is applied by every engine. It fades distant geometry toward the fog color; it does not affect the grid.'));
    body.appendChild(fog.root);

    const reset = el('button', 'btn ghost', 'Reset environment defaults');
    reset.addEventListener('click', () => {
      editor.beginEdit();
      editor.scene.env = UW.scene.defaultEnv();
      editor.touch();
      editor.commitEdit('Reset environment');
      syncToolbar();
      openEnvironmentDialog();
      toast('Environment reset.', 'info');
    });
    body.appendChild(reset);

    openModal({
      title: 'Environment & Lighting',
      icon: 'i-settings',
      body,
      actions: [{ label: 'Done', kind: 'primary' }],
    });
  }

  function openFsmGraph() {
    const node = editor.selectedNode;
    if (!node) { toast('Select an object to edit its FSM.', 'warn'); return; }
    if (!node.fsm) {
      editor.addComponent(node.id, 'fsm');
      renderInspector();
    }
    if (UW.Graph) UW.Graph.open(node, editor);
  }


  function renderHierarchy() {
    const list = els.treeList;
    if (!list) return;
    clear(list);
    const scene = editor.scene;
    const filter = S.filter.toLowerCase();
    const selected = editor.selected;

    if (!scene.nodes.length) {
      list.appendChild(el('div', 'tree-empty', 'Scene is empty. Use + to create an object.'));
      return;
    }

    if (filter) {
      for (const node of scene.nodes) {
        if (!node.name.toLowerCase().includes(filter)) continue;
        list.appendChild(treeItem(node, 0, selected, true));
      }
      return;
    }

    const kids = new Map();
    for (const n of scene.nodes) {
      const p = n.parent || '__root__';
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p).push(n);
    }
    const walk = (parentId, depth) => {
      const arr = kids.get(parentId) || [];
      for (const node of arr) {
        const children = kids.get(node.id) || [];
        list.appendChild(treeItem(node, depth, selected, children.length > 0));
        if (children.length && !S.collapsed.has(node.id)) walk(node.id, depth + 1);
      }
    };
    walk('__root__', 0);
  }

  function treeItem(node, depth, selected, hasChildren) {
    const item = el('div', 'tree-item' + (node.id === selected ? ' selected' : '') + (node.visible ? '' : ' hidden-node') + (depth > 0 ? ' is-child' : ''));
    item.style.setProperty('--indent', depth * 13 + 'px');
    item.dataset.id = node.id;
    item.draggable = true;

    const twist = el('span', 'twist' + (hasChildren ? '' : ' empty'));
    twist.appendChild(iconEl('i-chevron'));
    if (hasChildren) {
      if (!S.collapsed.has(node.id)) item.classList.add('expanded');
      twist.addEventListener('click', (e) => {
        e.stopPropagation();
        if (S.collapsed.has(node.id)) S.collapsed.delete(node.id);
        else S.collapsed.add(node.id);
        renderHierarchy();
      });
    }
    item.appendChild(twist);

    const ic = iconEl(UW.scene.icon(node), 'icon tree-icon');
    item.appendChild(ic);
    item.appendChild(el('span', 'tree-name', node.name));

    const vis = el('button', 'tree-vis');
    vis.appendChild(iconEl(node.visible ? 'i-eye' : 'i-eye-off'));
    vis.title = node.visible ? 'Hide' : 'Show';
    vis.addEventListener('click', (e) => {
      e.stopPropagation();
      editor.toggleVisible(node.id);
    });
    item.appendChild(vis);

    item.addEventListener('click', () => editor.select(node.id));
    item.addEventListener('dblclick', (e) => {
      if (e.target.closest('button')) return;
      editor.select(node.id);
      editor.focus(node.id);
    });
    item.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', node.id);
      e.dataTransfer.effectAllowed = 'move';
      item.style.opacity = '0.55';
    });
    item.addEventListener('dragend', () => { item.style.opacity = ''; });
    item.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      item.classList.add('drop-inside');
    });
    item.addEventListener('dragleave', () => item.classList.remove('drop-inside'));
    item.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      item.classList.remove('drop-inside');
      const src = e.dataTransfer.getData('text/plain');
      if (src && src !== node.id) {
        editor.reparent(src, node.id);
        S.collapsed.delete(node.id);
        renderHierarchy();
      }
    });
    return item;
  }

  function bindHierarchy() {
    const body = els.hierarchy;
    clear(body);
    const search = div('tree-search');
    const input = document.createElement('input');
    input.type = 'search';
    input.placeholder = 'Search objects…';
    input.value = S.filter;
    input.addEventListener('input', () => { S.filter = input.value; renderHierarchy(); });
    search.appendChild(input);
    body.appendChild(search);
    const list = div('tree-list');
    list.id = 'tree-list';
    body.appendChild(list);
    els.treeList = list;

    list.addEventListener('dragover', (e) => {
      if (e.target === list || e.target === body) e.preventDefault();
    });
    list.addEventListener('drop', (e) => {
      if (e.target !== list) return;
      e.preventDefault();
      const src = e.dataTransfer.getData('text/plain');
      if (src) { editor.reparent(src, null); renderHierarchy(); }
    });
  }

  /* ------------------------------------------------------------
     inspector building blocks
     ------------------------------------------------------------ */
  function numInput(value, onChange, opts) {
    opts = opts || {};
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'num';
    input.step = opts.step != null ? opts.step : '0.1';
    if (opts.min != null) input.min = opts.min;
    if (opts.max != null) input.max = opts.max;
    input.value = fmt(value);
    let editing = false;
    const begin = () => {
      if (!editing) { editing = true; editor.beginEdit(); }
    };
    input.addEventListener('focus', begin);
    input.addEventListener('pointerdown', begin);
    input.addEventListener('input', () => {
      begin();
      const v = parseFloat(input.value);
      if (Number.isFinite(v)) onChange(v, input);
    });
    const commit = () => {
      editor.commitEdit(opts.label || 'Edit');
      editing = false;
    };
    input.addEventListener('change', commit);
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
    });
    return input;
  }

  function vec3Control(values, onChange, refs) {
    const wrap = div('vec-row');
    ['x', 'y', 'z'].forEach((axis, i) => {
      const group = div('vec-axis ' + axis);
      group.appendChild(el('span', null, axis.toUpperCase()));
      const input = numInput(values[i], (v) => {
        const next = values.slice();
        next[i] = v;
        onChange(next);
      }, { label: 'Transform', step: 0.1 });
      group.appendChild(input);
      wrap.appendChild(group);
      if (refs) refs.push(input);
    });
    return wrap;
  }

  function row(labelText, control, cls) {
    const r = div('row' + (cls ? ' ' + cls : ''));
    if (labelText != null) r.appendChild(el('label', 'row-label', labelText));
    const c = div('row-control');
    if (control) c.appendChild(control);
    r.appendChild(c);
    return r;
  }

  function checkField(labelText, checked, onChange) {
    const label = el('label', 'check');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !!checked;
    cb.addEventListener('change', () => onChange(cb.checked));
    label.appendChild(cb);
    label.appendChild(el('span', null, labelText));
    return label;
  }

  function selectField(options, value, onChange) {
    const sel = document.createElement('select');
    sel.className = 'select';
    let group = null;
    let groupName = null;
    for (const opt of options) {
      if (opt.group && opt.group !== groupName) {
        groupName = opt.group;
        group = document.createElement('optgroup');
        group.label = opt.group;
        sel.appendChild(group);
      } else if (!opt.group) {
        groupName = null;
        group = null;
      }
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.label;
      if (opt.value === value) o.selected = true;
      (group || sel).appendChild(o);
    }
    sel.addEventListener('change', () => onChange(sel.value));
    return sel;
  }

  function sliderField(value, min, max, step, onChange, format) {
    const wrap = div();
    wrap.style.cssText = 'display:flex;align-items:center;gap:7px;flex:1';
    const range = document.createElement('input');
    range.type = 'range';
    range.min = min; range.max = max; range.step = step;
    range.value = value;
    const read = el('span', null, String(value));
    read.style.cssText = 'font-family:var(--mono);font-size:10px;color:#8d96a2;width:28px;text-align:right;flex:none';
    let editing = false;
    range.addEventListener('pointerdown', () => { if (!editing) { editing = true; editor.beginEdit(); } });
    range.addEventListener('input', () => {
      if (!editing) { editing = true; editor.beginEdit(); }
      const v = parseFloat(range.value);
      read.textContent = format ? format(v) : String(v);
      onChange(v);
    });
    range.addEventListener('change', () => { editor.commitEdit('Material'); editing = false; });
    wrap.appendChild(range);
    wrap.appendChild(read);
    return wrap;
  }

  function colorField(hex, onChange) {
    const wrap = div('color-field');
    const picker = document.createElement('input');
    picker.type = 'color';
    picker.value = hex;
    const text = document.createElement('input');
    text.type = 'text';
    text.className = 'num color-hex';
    text.value = hex.toUpperCase();
    let editing = false;
    const begin = () => { if (!editing) { editing = true; editor.beginEdit(); } };
    picker.addEventListener('pointerdown', begin);
    picker.addEventListener('input', () => {
      begin();
      text.value = picker.value.toUpperCase();
      onChange(picker.value);
    });
    picker.addEventListener('change', () => { editor.commitEdit('Color'); editing = false; });
    text.addEventListener('focus', begin);
    text.addEventListener('change', () => {
      let v = text.value.trim();
      if (!v.startsWith('#')) v = '#' + v;
      if (/^#[0-9a-f]{6}$/i.test(v)) {
        begin();
        picker.value = v;
        onChange(v);
        text.value = v.toUpperCase();
        editor.commitEdit('Color');
      } else {
        text.value = picker.value.toUpperCase();
      }
      editing = false;
    });
    wrap.appendChild(picker);
    wrap.appendChild(text);
    return wrap;
  }

  function componentSection(title, iconName, opts) {
    opts = opts || {};
    const root = div('component');
    const head = div('component-head');
    head.appendChild(iconEl(iconName, 'icon comp-icon'));
    head.appendChild(el('span', 'comp-title', title));
    if (opts.sub) head.appendChild(el('span', 'comp-sub', opts.sub));
    if (opts.onRemove) {
      const rm = el('button', 'icon-btn sm');
      rm.appendChild(iconEl('i-minus'));
      rm.title = 'Remove component';
      rm.addEventListener('click', (e) => { e.stopPropagation(); opts.onRemove(); });
      head.appendChild(rm);
    }
    const collapse = el('span', 'collapse');
    collapse.appendChild(iconEl('i-chevron'));
    head.appendChild(collapse);
    const body = div('component-body');
    root.appendChild(head);
    root.appendChild(body);
    head.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      root.classList.toggle('collapsed');
    });
    return { root, body, head };
  }

  /* ------------------------------------------------------------
     inspector
     ------------------------------------------------------------ */
  function renderInspector() {
    const panel = els.inspector;
    clear(panel);
    S.transformRefs = null;
    const node = editor.selectedNode;
    els.inspectorType.textContent = node ? node.type : '—';

    if (!node) {
      const empty = div('inspector-empty');
      empty.appendChild(iconEl('i-select', 'icon'));
      empty.appendChild(el('div', null, 'Select an object in the Hierarchy or the Scene view to edit its components.'));
      panel.appendChild(empty);
      return;
    }

    const header = div('insp-header');
    const titleRow = div('insp-title-row');
    titleRow.appendChild(iconEl(UW.scene.icon(node), 'icon obj-icon'));
    const name = document.createElement('input');
    name.className = 'insp-name';
    name.value = node.name;
    name.title = 'Object name';
    name.addEventListener('change', () => {
      const v = name.value.trim();
      if (!v || v === node.name) { name.value = node.name; return; }
      editor.renameNode(node.id, v);
      renderHierarchy();
    });
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') name.blur(); });
    titleRow.appendChild(name);
    header.appendChild(titleRow);

    const meta = div('insp-meta');
    const active = el('label', 'active-toggle');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = node.visible;
    cb.addEventListener('change', () => {
      editor.beginEdit();
      node.visible = cb.checked;
      editor.touch();
      editor.commitEdit('Visibility');
    });
    active.appendChild(cb);
    active.appendChild(el('span', null, 'Active'));
    meta.appendChild(active);
    meta.appendChild(el('span', null, 'ID ' + node.id));
    const spacer = div('spacer');
    meta.appendChild(spacer);

    const dup = el('button', 'icon-btn sm');
    dup.appendChild(iconEl('i-copy'));
    dup.title = 'Duplicate (Ctrl+D)';
    dup.addEventListener('click', () => editor.duplicateNode(node.id));
    meta.appendChild(dup);
    const del = el('button', 'icon-btn sm');
    del.appendChild(iconEl('i-trash'));
    del.title = 'Delete (Del)';
    del.addEventListener('click', () => editor.deleteNode(node.id));
    meta.appendChild(del);
    header.appendChild(meta);
    panel.appendChild(header);

    /* ---- Transform ---- */
    const tr = componentSection('Transform', 'i-move', { sub: 'local' });
    const posRefs = [], rotRefs = [], scaleRefs = [];
    tr.body.appendChild(row('Position', vec3Control(node.transform.position, (v) => {
      node.transform.position = v;
      editor.touch();
    }, posRefs)));
    tr.body.appendChild(row('Rotation', vec3Control(node.transform.rotation, (v) => {
      node.transform.rotation = v;
      editor.touch();
    }, rotRefs)));
    tr.body.appendChild(row('Scale', vec3Control(node.transform.scale, (v) => {
      node.transform.scale = v;
      editor.touch();
    }, scaleRefs)));
    const resetRow = div('row');
    resetRow.appendChild(el('label', 'row-label', ''));
    const resetWrap = div('row-control');
    const resetBtn = el('button', 'text-btn', 'Reset transform');
    resetBtn.style.padding = '2px 0';
    resetBtn.addEventListener('click', () => {
      editor.transact('Reset transform', () => {
        node.transform.position = [0, 0, 0];
        node.transform.rotation = [0, 0, 0];
        node.transform.scale = [1, 1, 1];
      });
    });
    resetWrap.appendChild(resetBtn);
    resetRow.appendChild(resetWrap);
    tr.body.appendChild(resetRow);
    panel.appendChild(tr.root);
    S.transformRefs = { pos: posRefs, rot: rotRefs, scale: scaleRefs };

    /* ---- Mesh renderer ---- */
    if (node.type === 'mesh' && node.mesh) {
      const mr = componentSection('Mesh Renderer', 'i-cube', { sub: UW.geom.shapeLabel(node.mesh.shape) });
      mr.body.appendChild(row('Shape', selectField(
        UW.geom.shapes.map((s) => ({ value: s.id, label: s.label })),
        node.mesh.shape,
        (v) => {
          editor.beginEdit();
          node.mesh.shape = v;
          editor.touch();
          editor.commitEdit('Mesh shape');
          renderInspector();
        }
      )));
      mr.body.appendChild(row('Material', null));
      mr.body.appendChild(row('Color', colorField(node.mesh.color, (v) => {
        node.mesh.color = v;
        editor.touch();
      })));
      mr.body.appendChild(row('Roughness', sliderField(node.mesh.roughness, 0, 1, 0.01, (v) => {
        node.mesh.roughness = v;
        editor.touch();
      }, (v) => v.toFixed(2))));
      mr.body.appendChild(row('Metalness', sliderField(node.mesh.metalness, 0, 1, 0.01, (v) => {
        node.mesh.metalness = v;
        editor.touch();
      }, (v) => v.toFixed(2))));
      mr.body.appendChild(row('Opacity', sliderField(node.mesh.opacity != null ? node.mesh.opacity : 1, 0.05, 1, 0.01, (v) => {
        node.mesh.opacity = v;
        editor.touch();
      }, (v) => v.toFixed(2))));
      mr.body.appendChild(row('Wireframe', checkField('Show wireframe', node.mesh.wireframe, (v) => {
        editor.beginEdit();
        node.mesh.wireframe = v;
        editor.touch();
        editor.commitEdit('Wireframe');
      })));
      panel.appendChild(mr.root);
    }

    /* ---- Light ---- */
    if (node.type === 'light' && node.light) {
      const lg = componentSection('Light', 'i-light', { sub: node.light.kind });
      lg.body.appendChild(row('Type', selectField([
        { value: 'directional', label: 'Directional / Sun' },
        { value: 'point', label: 'Point' },
        { value: 'spot', label: 'Spot' },
      ], node.light.kind, (v) => {
        editor.beginEdit();
        node.light.kind = v;
        editor.touch();
        editor.commitEdit('Light type');
        renderInspector();
      })));
      lg.body.appendChild(row('Color', colorField(node.light.color, (v) => {
        node.light.color = v;
        editor.touch();
      })));
      lg.body.appendChild(row('Intensity', numInput(node.light.intensity, (v) => {
        node.light.intensity = v;
        editor.touch();
      }, { step: 0.05, min: 0, label: 'Light' })));
      if (node.light.kind === 'point' || node.light.kind === 'spot') {
        lg.body.appendChild(row('Range', numInput(node.light.range, (v) => {
          node.light.range = v;
          editor.touch();
        }, { step: 0.5, min: 0.1, label: 'Light' })));
      }
      if (node.light.kind === 'spot') {
        lg.body.appendChild(row('Cone angle', numInput(node.light.angle, (v) => {
          node.light.angle = Math.max(1, Math.min(89, v));
          editor.touch();
        }, { step: 1, min: 1, max: 89, label: 'Light' })));
        lg.body.appendChild(row('Penumbra', sliderField(node.light.penumbra != null ? node.light.penumbra : 0.35, 0, 1, 0.01, (v) => {
          node.light.penumbra = v;
          editor.touch();
        }, (v) => v.toFixed(2))));
      }
      const lightNote = node.light.kind === 'directional'
        ? 'Direction comes from the object rotation (+Z axis).'
        : node.light.kind === 'spot'
          ? 'A spotlight points along the object +Z axis. Cone angle and penumbra shape the beam.'
          : 'Position drives the falloff; range is in world units.';
      lg.body.appendChild(el('div', 'help-note', lightNote));
      panel.appendChild(lg.root);
    }

    /* ---- Texture ---- */
    if (node.type === 'mesh' && node.mesh && node.mesh.texture) {
      panel.appendChild(textureComponent(node).root);
    }

    /* ---- FSM ---- */
    if (node.fsm && UW.FSM) {
      const fsm = UW.FSM.normalize(node.fsm);
      const fsmSec = componentSection('PlayMaker FSM', 'i-link', {
        sub: UW.FSM.summary(fsm),
        onRemove: () => {
          editor.removeComponent(node.id, 'fsm');
          renderInspector();
        },
      });
      fsmSec.body.appendChild(row('Enabled', checkField('Run in Play mode', fsm.enabled, (v) => {
        editor.beginEdit();
        fsm.enabled = v;
        editor.touch();
        editor.commitEdit('FSM');
      })));
      const box = div('fsm-summary-box');
      const start = UW.FSM.state(fsm, fsm.start);
      box.appendChild(el('div', 'fsm-summary-title', start ? 'Start state: ' + start.name : 'No start state'));
      box.appendChild(el('div', 'fsm-summary-sub', fsm.states.length + ' states · ' + fsm.transitions.length + ' transitions · ' + fsm.variables.length + ' variables'));
      fsmSec.body.appendChild(box);
      const open = el('button', 'btn primary fsm-open', 'Open Graph Editor');
      open.addEventListener('click', () => UW.Graph.open(node, editor));
      fsmSec.body.appendChild(open);
      fsmSec.body.appendChild(el('div', 'help-note', 'States run actions on entry. Transitions fire after a delay, on an event, a key press or a variable condition.'));
      panel.appendChild(fsmSec.root);
    }

    /* ---- Camera ---- */
    if (node.type === 'camera' && node.camera) {
      const cam = componentSection('Camera', 'i-camera', { sub: 'Game view' });
      cam.body.appendChild(row('Field of view', numInput(node.camera.fov, (v) => {
        node.camera.fov = Math.min(120, Math.max(10, v));
        editor.touch();
      }, { step: 1, min: 10, max: 120, label: 'Camera' })));
      cam.body.appendChild(row('Near', numInput(node.camera.near, (v) => {
        node.camera.near = Math.max(0.01, v);
        editor.touch();
      }, { step: 0.01, min: 0.01, label: 'Camera' })));
      cam.body.appendChild(row('Far', numInput(node.camera.far, (v) => {
        node.camera.far = Math.max(1, v);
        editor.touch();
      }, { step: 10, min: 1, label: 'Camera' })));
      cam.body.appendChild(row('Background', colorField(node.camera.bg || '#1d2025', (v) => {
        node.camera.bg = v;
        editor.touch();
      })));
      cam.body.appendChild(el('div', 'help-note', 'Switch the viewport to Game to look through this camera.'));
      panel.appendChild(cam.root);
    }

    /* ---- Rigidbody ---- */
    if (node.rigidbody && node.type === 'mesh') {
      const rb = componentSection('Rigidbody', 'i-sphere', {
        sub: 'AABB',
        onRemove: () => editor.removeComponent(node.id, 'rigidbody'),
      });
      rb.body.appendChild(row('Mass', numInput(node.rigidbody.mass, (v) => {
        node.rigidbody.mass = Math.max(0.05, v);
        editor.touch();
      }, { step: 0.1, min: 0.05, label: 'Rigidbody' })));
      rb.body.appendChild(row('Gravity', checkField('Use gravity', node.rigidbody.useGravity, (v) => {
        editor.beginEdit();
        node.rigidbody.useGravity = v;
        editor.touch();
        editor.commitEdit('Rigidbody');
      })));
      rb.body.appendChild(row('Bounce', sliderField(node.rigidbody.restitution, 0, 1, 0.05, (v) => {
        node.rigidbody.restitution = v;
        editor.touch();
      }, (v) => v.toFixed(2))));
      rb.body.appendChild(el('div', 'help-note', 'Play-mode only. Uses the mesh bounds as an axis-aligned collider; parented bodies are ignored.'));
      panel.appendChild(rb.root);
    }

    /* ---- Behaviors ---- */
    if (node.behaviors && node.behaviors.length) {
      const bh = componentSection('Behaviors', 'i-rotate', { sub: String(node.behaviors.length) });
      for (const beh of node.behaviors) {
        const wrap = div('behavior-row');
        const name = el('span', 'b-name', beh.kind.charAt(0).toUpperCase() + beh.kind.slice(1));
        wrap.appendChild(name);
        const rm = el('button', 'icon-btn sm');
        rm.appendChild(iconEl('i-close'));
        rm.title = 'Remove behavior';
        rm.addEventListener('click', () => editor.removeBehavior(node.id, beh.id));
        wrap.appendChild(rm);
        bh.body.appendChild(wrap);
        const params = div();
        params.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap;padding:0 2px 2px';
        const p = beh.params;
        const addParam = (label, key, step) => {
          const g = div('vec-axis');
          g.appendChild(el('span', null, label));
          g.style.flex = '1';
          g.style.minWidth = '70px';
          g.appendChild(numInput(p[key] != null ? p[key] : 0, (v) => {
            p[key] = v;
            editor.touch();
          }, { step: step || 0.1, label: 'Behavior' }));
          params.appendChild(g);
        };
        if (beh.kind === 'spin') { addParam('X', 'x', 5); addParam('Y', 'y', 5); addParam('Z', 'z', 5); }
        else if (beh.kind === 'bob') { addParam('AMP', 'amplitude'); addParam('SPD', 'speed'); }
        else if (beh.kind === 'pulse') { addParam('AMT', 'amount'); addParam('SPD', 'speed'); }
        else if (beh.kind === 'orbit') { addParam('RAD', 'radius'); addParam('SPD', 'speed', 5); addParam('Y', 'height'); }
        bh.body.appendChild(params);
      }
      const addRow = div('row');
      addRow.appendChild(el('label', 'row-label', 'Add'));
      const addWrap = div('row-control');
      const sel = selectField([
        { value: 'spin', label: 'Spin' },
        { value: 'bob', label: 'Bob' },
        { value: 'pulse', label: 'Pulse' },
        { value: 'orbit', label: 'Orbit' },
      ], 'spin', () => {});
      addWrap.appendChild(sel);
      const addBtn = el('button', 'btn', 'Add');
      addBtn.style.height = '21px';
      addBtn.style.padding = '0 8px';
      addBtn.addEventListener('click', () => editor.addBehavior(node.id, sel.value));
      addWrap.appendChild(addBtn);
      addRow.appendChild(addWrap);
      bh.body.appendChild(addRow);
      panel.appendChild(bh.root);
    }

    /* ---- Script ---- */
    if (node.script) {
      const sc = componentSection('JavaScript Script', 'i-code', {
        sub: 'play mode',
        onRemove: () => editor.removeComponent(node.id, 'script'),
      });
      const box = div('script-box');
      const ico = div('script-ico');
      ico.appendChild(iconEl('i-code'));
      box.appendChild(ico);
      const meta2 = div();
      meta2.style.flex = '1';
      meta2.appendChild(el('div', 'script-name', node.script.name || 'Script'));
      meta2.appendChild(el('div', 'script-sub', (node.script.code || '').split('\n').length + ' lines'));
      box.appendChild(meta2);
      const edit = el('button', 'btn', 'Edit');
      edit.style.height = '22px';
      edit.style.padding = '0 9px';
      edit.addEventListener('click', () => openScriptEditor(node));
      box.appendChild(edit);
      sc.body.appendChild(box);
      panel.appendChild(sc.root);
    }

    /* ---- Add component ---- */
    const add = el('button', 'add-component');
    add.appendChild(iconEl('i-plus'));
    add.appendChild(el('span', null, 'Add Component'));
    add.addEventListener('click', () => {
      const items = [];
      if (node.type === 'mesh' && !node.rigidbody) items.push({ label: 'Rigidbody', icon: 'i-sphere', action: () => editor.addComponent(node.id, 'rigidbody') });
      if (node.type === 'mesh' && !node.mesh.texture) items.push({ label: 'Texture / Material', icon: 'i-grid', action: () => { editor.addComponent(node.id, 'texture'); renderInspector(); } });
      if (!node.script) items.push({ label: 'JavaScript Script', icon: 'i-code', action: () => { editor.addComponent(node.id, 'script'); renderInspector(); openScriptEditor(node); } });
      if (!node.fsm) items.push({ label: 'PlayMaker FSM', icon: 'i-link', action: () => { editor.addComponent(node.id, 'fsm'); renderInspector(); UW.Graph.open(node, editor); } });
      if (node.type !== 'camera') items.push({ label: 'Camera', icon: 'i-camera', action: () => editor.addComponent(node.id, 'camera') });
      items.push({ header: 'Behaviors' });
      items.push({ label: 'Spin', action: () => editor.addBehavior(node.id, 'spin') });
      items.push({ label: 'Bob', action: () => editor.addBehavior(node.id, 'bob') });
      items.push({ label: 'Pulse', action: () => editor.addBehavior(node.id, 'pulse') });
      items.push({ label: 'Orbit', action: () => editor.addBehavior(node.id, 'orbit') });
      showPopup(items, add);
    });
    panel.appendChild(add);
  }

  function syncLiveValues() {
    const refs = S.transformRefs;
    const node = editor.selectedNode;
    if (!refs || !node) return;
    const a = document.activeElement;
    const set = (input, v) => { if (input !== a) input.value = fmt(v); };
    for (let i = 0; i < 3; i++) {
      set(refs.pos[i], node.transform.position[i]);
      set(refs.rot[i], node.transform.rotation[i]);
      set(refs.scale[i], node.transform.scale[i]);
    }
  }

  /* ------------------------------------------------------------
     engines
     ------------------------------------------------------------ */
  function renderEngineSelect() {
    const sel = els.engineSelect;
    clear(sel);
    for (const def of UW.engines.list()) {
      const o = document.createElement('option');
      o.value = def.id;
      o.textContent = def.name + (def.version ? ' · ' + def.version : '');
      if (def.id === editor.engineId) o.selected = true;
      sel.appendChild(o);
    }
    const plug = document.createElement('option');
    plug.value = '__connect';
    plug.textContent = '＋ Connect engine…';
    sel.appendChild(plug);
  }

  function renderEngines() {
    const list = els.engineList;
    clear(list);
    for (const def of UW.engines.list()) {
      const active = def.id === editor.engineId;
      const card = div('engine-card' + (active ? ' active' : '') + (def.id === editor.engineId ? ' ready' : ''));
      const logo = div('eng-logo');
      logo.textContent = def.short || def.name.slice(0, 2).toUpperCase();
      logo.style.background = def.id === 'three' ? '#8fb8ff' : def.id === 'babylon' ? '#e8a05c' : def.id === 'native' ? '#9fd6b4' : '#b6a6e6';
      card.appendChild(logo);
      const meta = div('eng-meta');
      meta.appendChild(el('div', 'eng-name', def.name));
      meta.appendChild(el('div', 'eng-sub', (def.version || '') + ' · ' + (def.license || '') + (def.badge ? ' · ' + def.badge : '')));
      card.appendChild(meta);
      card.appendChild(el('span', 'eng-state', active ? 'ACTIVE' : 'READY'));
      card.title = def.description || def.name;
      card.addEventListener('click', () => { if (def.id !== editor.engineId) app.setEngine(def.id); });
      list.appendChild(card);
    }
    const connect = div('engine-card');
    const logo = div('eng-logo');
    logo.textContent = '+';
    logo.style.background = '#4b515b';
    logo.style.color = '#dfe5ed';
    connect.appendChild(logo);
    const meta = div('eng-meta');
    meta.appendChild(el('div', 'eng-name', 'Connect engine…'));
    meta.appendChild(el('div', 'eng-sub', 'load an adapter script at runtime'));
    connect.appendChild(meta);
    connect.addEventListener('click', connectEngineDialog);
    list.appendChild(connect);
  }

  function renderEngineDoc() {
    const box = els.engineDoc;
    clear(box);
    const def = app.activeDef;
    if (!def) {
      box.appendChild(el('div', 'doc-note', 'No engine active.'));
      return;
    }
    box.appendChild(el('div', 'doc-title', def.name + (def.version ? ' ' + def.version : '')));
    box.appendChild(el('div', 'doc-note', def.description || ''));
    const rows = [
      ['Vendor', def.vendor || '—'],
      ['License', def.license || '—'],
      ['Adapter', def.id],
      ['Runtime', def.badge || 'built-in'],
    ];
    for (const [k, v] of rows) {
      const r = div('doc-row');
      r.appendChild(el('span', null, k));
      r.appendChild(el('span', null, v));
      box.appendChild(r);
    }

    const caps = UW.engines.capabilities(def);
    const capRows = [
      ['Shadows', 'shadows'],
      ['Lights', 'directional'],
      ['Spot lights', 'spot'],
      ['Textures', 'textures'],
      ['Transparency', 'transparency'],
      ['PBR', 'pbr'],
      ['Offline', 'offline'],
    ];
    box.appendChild(el('div', 'doc-title', 'Rendering capabilities'));
    for (const [label, id] of capRows) {
      const cap = caps[id];
      if (!cap) continue;
      const r = div('doc-row');
      r.appendChild(el('span', null, label));
      const v = el('span', 'doc-cap ' + cap.level, capLabel(cap.level));
      if (cap.note) v.title = cap.note;
      r.appendChild(v);
      box.appendChild(r);
    }
    box.appendChild(el('div', 'doc-note', 'Open Window → Engine Compatibility… for the full matrix.'));

    if (def.url) {
      const a = document.createElement('a');
      a.href = def.url;
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = 'Documentation ↗';
      box.appendChild(a);
    }
    const note = el('div', 'doc-note');
    note.style.marginTop = '6px';
    note.innerHTML = 'Plugins: <code>UnityWeb.engines.register({…})</code> — see Help → API.';
    box.appendChild(note);
  }

  /* ------------------------------------------------------------
     project / assets
     ------------------------------------------------------------ */
  function assetCard(opts) {
    const card = div('asset' + (opts.cls ? ' ' + opts.cls : ''));
    card.title = opts.title || opts.label;
    const ic = div('asset-ico');
    ic.appendChild(iconEl(opts.icon));
    card.appendChild(ic);
    card.appendChild(el('div', 'asset-name', opts.label));
    if (opts.sub) card.appendChild(el('div', 'asset-sub', opts.sub));
    if (opts.onClick) card.addEventListener('click', opts.onClick);
    if (opts.onDelete) {
      const del = el('button', 'asset-del');
      del.appendChild(iconEl('i-close'));
      del.title = 'Delete';
      del.addEventListener('click', (e) => { e.stopPropagation(); opts.onDelete(); });
      card.appendChild(del);
    }
    return card;
  }

  function renderAssets() {
    const prim = els.assetPrimitives;
    clear(prim);
    for (const s of UW.geom.shapes) {
      prim.appendChild(assetCard({
        icon: s.icon, label: s.label, title: 'Add ' + s.label,
        onClick: () => editor.addPrimitive(s.id),
      }));
    }

    const actors = els.assetActors;
    clear(actors);
    actors.appendChild(assetCard({ icon: 'i-cube', label: 'Empty', title: 'Create empty object', onClick: () => editor.addNode('empty') }));
    actors.appendChild(assetCard({ icon: 'i-camera', label: 'Camera', title: 'Create camera', onClick: () => editor.addNode('camera') }));
    actors.appendChild(assetCard({ icon: 'i-light', label: 'Sun', title: 'Directional light', onClick: () => editor.addNode('light.directional') }));
    actors.appendChild(assetCard({ icon: 'i-light', label: 'Point', title: 'Point light', onClick: () => editor.addNode('light.point') }));
    actors.appendChild(assetCard({ icon: 'i-light', label: 'Spot', title: 'Spot light', onClick: () => editor.addNode('light.spot') }));
    actors.appendChild(assetCard({
      icon: 'i-code', label: 'Script', cls: 'script', title: 'Attach JavaScript to selection',
      onClick: () => {
        const node = editor.selectedNode;
        if (node) {
          if (!node.script) editor.addComponent(node.id, 'script');
          openScriptEditor(node);
        } else {
          const cube = editor.addPrimitive('cube');
          editor.addComponent(cube.id, 'script');
          openScriptEditor(cube);
        }
      },
    }));

    const scenes = els.assetScenes;
    clear(scenes);
    const saved = editor.storage();
    els.savedCount.textContent = saved.length ? '(' + saved.length + ')' : '';
    if (!saved.length) {
      const e = el('div', 'assets-empty', 'No saved scenes. Ctrl+S saves here.');
      e.style.width = '200px';
      scenes.appendChild(e);
    } else {
      for (const entry of saved) {
        scenes.appendChild(assetCard({
          icon: 'i-folder', label: entry.name, cls: 'scene',
          sub: fmtDate(entry.savedAt),
          title: 'Open scene ' + entry.name,
          onClick: () => { editor.loadScene(entry.name); toast('Loaded scene: ' + entry.name, 'ok'); },
          onDelete: () => { editor.deleteScene(entry.name); renderAssets(); toast('Deleted: ' + entry.name, 'warn'); },
        }));
      }
    }
  }

  /* ------------------------------------------------------------
     console
     ------------------------------------------------------------ */
  function renderConsole() {
    const list = els.consoleList;
    const stick = list.scrollTop + list.clientHeight >= list.scrollHeight - 40;
    clear(list);
    const logs = editor.logs.filter((l) => S.logFilter === 'all' || l.level === S.logFilter);
    els.consoleCount.textContent = editor.logs.length;
    if (!logs.length) {
      list.appendChild(el('div', 'console-empty', 'Console is empty. Logs, warnings and runtime errors appear here.'));
      return;
    }
    for (const log of logs) {
      const row = div('log-row ' + log.level);
      row.appendChild(el('span', 'log-time', fmtTime(log.time)));
      const mark = log.level === 'error' ? '✕' : log.level === 'warn' ? '▲' : '•';
      row.appendChild(el('span', 'log-icon', mark));
      row.appendChild(el('span', 'log-msg', log.message));
      list.appendChild(row);
    }
    if (stick) list.scrollTop = list.scrollHeight;
  }

  /* ------------------------------------------------------------
     status / toolbar / play state
     ------------------------------------------------------------ */
  function renderStatus() {
    const node = editor.selectedNode;
    els.statusSelection.textContent = node ? 'Selected: ' + node.name + '  ·  ' + node.type : 'Nothing selected';
    els.statusSaved.textContent = editor.dirty ? 'Unsaved changes' : 'Scene saved';
    els.statusEngine.textContent = editor.engineName || '—';
    els.sceneNameLabel.textContent = editor.sceneName + (editor.dirty ? ' *' : '');
    els.savedSceneLabel.textContent = editor.sceneName;
  }

  function syncToolbar() {
    document.querySelectorAll('#tool-tools .tool').forEach((b) => {
      b.classList.toggle('active', b.dataset.tool === editor.tool);
    });
    document.querySelectorAll('#space-toggle button').forEach((b) => {
      b.classList.toggle('active', b.dataset.space === editor.space);
    });
    document.querySelectorAll('#view-toggle button').forEach((b) => {
      b.classList.toggle('active', b.dataset.view === editor.viewMode);
    });
    els.btnPlay.classList.toggle('active', editor.playing);
    els.btnPause.disabled = !editor.playing;
    els.btnStep.disabled = !editor.playing;
    els.btnStop.disabled = !editor.playing;
    els.btnPause.classList.toggle('active', editor.paused);
    els.btnGrid.classList.toggle('active', editor.scene.env.showGrid !== false);
    els.viewLabel.textContent = editor.viewMode === 'game' ? 'Game' : 'Scene';
    els.viewport.classList.toggle('playing', editor.playing);
    els.playBanner.classList.toggle('hidden', !editor.playing);
    if (els.engineSelect.value !== editor.engineId && editor.engineId) els.engineSelect.value = editor.engineId;
    renderViewState();
  }

  function renderViewState() {
    const hasCamera = editor.scene.nodes.some((n) => n.type === 'camera' && n.visible);
    els.gameEmpty.classList.toggle('hidden', !(editor.viewMode === 'game' && !hasCamera));
  }

  function updateStats(stats) {
    if (!els.hudFps) return;
    els.hudFps.textContent = stats.fps + ' fps';
    els.hudTris.textContent = stats.triangles >= 1000 ? (stats.triangles / 1000).toFixed(1) + 'k tris' : stats.triangles + ' tris';
    els.hudObjects.textContent = stats.objects + ' objects';
    els.hudTime.textContent = stats.time.toFixed(1) + 's';
    els.hudEngine.textContent = stats.engine;
    els.statusFps.textContent = stats.fps + ' fps';
    const dot = els.statusFps.parentElement;
    if (dot) dot.style.color = stats.fps < 24 ? '#c07f5b' : '#7faa8f';
  }

  /* ------------------------------------------------------------
     init & events
     ------------------------------------------------------------ */
  function init(a) {
    app = a;
    editor = a.editor;

    els.hierarchy = $('hierarchy');
    els.inspector = $('inspector');
    els.inspectorType = $('inspector-type');
    els.engineList = $('engine-list');
    els.engineDoc = $('engine-doc');
    els.engineSelect = $('engine-select');
    els.engineBadge = $('engine-badge');
    els.engineBadgeName = $('engine-badge-name');
    els.consoleList = $('console-list');
    els.consoleCount = $('console-count');
    els.assetPrimitives = $('asset-primitives');
    els.assetActors = $('asset-actors');
    els.assetScenes = $('asset-scenes');
    els.savedCount = $('saved-count');
    els.statusSelection = $('status-selection');
    els.statusSaved = $('status-saved');
    els.statusEngine = $('status-engine');
    els.statusFps = $('status-fps');
    els.sceneNameLabel = $('scene-name-label');
    els.savedSceneLabel = $('scene-name-label');
    els.treeList = null;
    els.viewLabel = $('view-label');
    els.viewport = $('viewport');
    els.playBanner = $('play-banner');
    els.gameEmpty = $('game-empty');
    els.btnPlay = $('btn-play');
    els.btnPause = $('btn-pause');
    els.btnStep = $('btn-step');
    els.btnStop = $('btn-stop');
    els.btnGrid = $('btn-grid');
    els.hudFps = $('hud-fps');
    els.hudTris = $('hud-tris');
    els.hudObjects = $('hud-objects');
    els.hudTime = $('hud-time');
    els.hudEngine = $('hud-engine');
    els.loading = $('loading');
    els.loadingTitle = $('loading-title');
    els.loadingSub = $('loading-sub');

    bindHierarchy();
    bindMenus();
    bindToolbar();
    bindBottom();
    bindShortcutsAndLifecycle();

    editor.on('structure', () => {
      renderHierarchy();
      renderInspector();
      renderStatus();
      renderAssets();
    });
    editor.on('selection', () => {
      renderHierarchy();
      renderInspector();
      renderStatus();
    });
    editor.on('values', syncLiveValues);
    editor.on('transform', syncLiveValues);
    editor.on('restore', () => {
      renderHierarchy();
      renderInspector();
      renderStatus();
      renderAssets();
      syncToolbar();
    });
    editor.on('play', (state) => {
      syncToolbar();
      if (state.playing) {
        if (editor.viewMode !== 'game') editor.setViewMode('game');
      } else if (editor.viewMode !== 'scene') {
        editor.setViewMode('scene');
      }
      syncToolbar();
    });
    editor.on('tool', syncToolbar);
    editor.on('space', syncToolbar);
    editor.on('view', () => { syncToolbar(); renderViewState(); });
    editor.on('log', () => renderConsole());
    editor.on('saved', () => { renderAssets(); renderStatus(); });
    editor.on('history', () => renderStatus());
    editor.on('engine', () => {
      els.engineBadgeName.textContent = editor.engineName;
      els.engineBadge.classList.remove('loading', 'error');
      const def = app.activeDef;
      els.engineBadge.title = def ? def.description || def.name : '';
      renderEngineSelect();
      renderEngines();
      renderEngineDoc();
      renderStatus();
      syncToolbar();
    });
    editor.on('engine-loading', (state) => {
      if (state.state === 'loading') {
        els.loading.classList.remove('hidden');
        els.loadingTitle.textContent = 'Loading ' + state.name + '…';
        els.loadingSub.textContent = 'fetching the engine runtime (CDN) — the editor keeps the scene';
        els.engineBadge.classList.add('loading');
        els.engineBadgeName.textContent = 'loading ' + state.name + '…';
        els.engineSelect.disabled = true;
      } else if (state.state === 'ready') {
        els.loading.classList.add('hidden');
        els.engineBadge.classList.remove('loading', 'error');
        els.engineSelect.disabled = false;
        renderEngineSelect();
        renderEngines();
        renderEngineDoc();
      } else if (state.state === 'error') {
        els.loading.classList.add('hidden');
        els.engineBadge.classList.remove('loading');
        els.engineBadge.classList.add('error');
        els.engineSelect.disabled = false;
        toast('Engine failed: ' + state.name + ' — ' + (state.message || 'unknown error'), 'error');
      }
    });

    window.addEventListener('error', (e) => {
      editor.log('error', (e.message || 'Unknown error') + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : ''));
    });
    window.addEventListener('unhandledrejection', (e) => {
      editor.log('error', 'Unhandled promise rejection: ' + (e.reason && e.reason.message ? e.reason.message : e.reason));
    });

    renderEngineSelect();
    renderEngines();
    renderEngineDoc();
    renderHierarchy();
    renderInspector();
    renderAssets();
    renderConsole();
    renderStatus();
    updateStats({ fps: 60, triangles: 0, objects: editor.scene.nodes.length, calls: 0, engine: editor.engineName, time: 0 });
    syncToolbar();
  }

  /* ------------------------------------------------------------ */
  function bindMenus() {
    document.querySelectorAll('#menus button').forEach((btn) => {
      btn.classList.add('menu-anchor');
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (S.menuAnchor === btn) { closeMenu(); return; }
        openMenu(btn.dataset.menu, btn);
      });
    });
    $('btn-help').addEventListener('click', () => openHelp());
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const layer = $('modal-layer');
        if (layer.classList.contains('open')) { closeModal(); return; }
        closeMenu();
      }
    });
  }

  function bindToolbar() {
    document.querySelectorAll('#tool-tools .tool').forEach((btn) => {
      btn.addEventListener('click', () => { editor.setTool(btn.dataset.tool); syncToolbar(); });
    });
    document.querySelectorAll('#space-toggle button').forEach((btn) => {
      btn.addEventListener('click', () => { editor.setSpace(btn.dataset.space); syncToolbar(); });
    });
    document.querySelectorAll('#view-toggle button').forEach((btn) => {
      btn.addEventListener('click', () => { editor.setViewMode(btn.dataset.view); syncToolbar(); });
    });
    els.btnPlay.addEventListener('click', () => { editor.playing ? editor.pause() : editor.play(); });
    els.btnPause.addEventListener('click', () => editor.pause());
    els.btnStep.addEventListener('click', () => editor.step());
    els.btnStop.addEventListener('click', () => editor.stop());
    $('btn-play-banner-stop').addEventListener('click', () => editor.stop());

    els.btnGrid.addEventListener('click', () => {
      editor.scene.env.showGrid = editor.scene.env.showGrid === false;
      editor.touch();
      syncToolbar();
    });
    $('btn-focus').addEventListener('click', () => editor.focus());
    $('btn-hierarchy-focus').addEventListener('click', () => editor.focus());
    $('btn-screenshot').addEventListener('click', () => {
      const data = app.screenshot();
      if (!data) { toast('Nothing to capture yet.', 'warn'); return; }
      const a = document.createElement('a');
      a.href = data;
      a.download = (editor.sceneName || 'scene').replace(/[^\w\-]+/g, '_') + '-viewport.png';
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast('Viewport screenshot saved.', 'ok');
    });
    $('btn-create').addEventListener('click', (e) => {
      showPopup(menuItems('gameobject'), e.currentTarget);
    });
    $('btn-connect-engine').addEventListener('click', connectEngineDialog);

    els.engineSelect.addEventListener('change', () => {
      const val = els.engineSelect.value;
      if (val === '__connect') {
        els.engineSelect.value = editor.engineId || '';
        connectEngineDialog();
        return;
      }
      app.setEngine(val);
    });

    els.btnPlay.addEventListener('dblclick', (e) => e.preventDefault());
    $('btn-save-scene').addEventListener('click', saveSceneDialog);
  }

  function bindBottom() {
    document.querySelectorAll('#bottom-tabs > button').forEach((btn) => {
      btn.addEventListener('click', () => {
        S.tab = btn.dataset.tab;
        document.querySelectorAll('#bottom-tabs > button').forEach((b) => b.classList.toggle('active', b === btn));
        document.querySelectorAll('.tab-page').forEach((p) => p.classList.toggle('active', p.id === 'tab-' + S.tab));
        if (S.tab === 'console') renderConsole();
      });
    });

    document.querySelectorAll('[data-log-filter]').forEach((btn) => {
      btn.addEventListener('click', () => {
        S.logFilter = btn.dataset.logFilter;
        document.querySelectorAll('[data-log-filter]').forEach((b) => b.classList.toggle('active', b === btn));
        renderConsole();
      });
    });
    $('btn-clear-console').addEventListener('click', () => editor.clearLogs());

    const resizer = $('bottom-resizer');
    const panel = $('bottom-panel');
    let drag = null;
    resizer.addEventListener('pointerdown', (e) => {
      drag = { y: e.clientY, h: panel.getBoundingClientRect().height };
      resizer.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    resizer.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const next = Math.max(120, Math.min(window.innerHeight * 0.62, drag.h - (e.clientY - drag.y)));
      panel.style.height = next + 'px';
    });
    const up = () => { drag = null; app.resize(); };
    resizer.addEventListener('pointerup', up);
    resizer.addEventListener('pointercancel', up);
  }

  function bindShortcutsAndLifecycle() {
    $('btn-connect-engine').title = 'Connect an engine adapter script';
  }

  /* ------------------------------------------------------------ */
  UW.UI = {
    init,
    updateStats,
    syncToolbar,
    saveSceneDialog,
    newSceneDialog,
    openScenesDialog,
    openHelp,
    importSceneFile,
    toast,
    renderAssets,
    renderInspector,
    openModal,
    closeModal,
    iconEl,
    el,
    div,
    row,
    numInput,
    selectField,
    colorField,
    checkField,
    sliderField,
    componentSection,
    openTexturePainter,
    openEnvironmentDialog,
    openCompatibilityDialog,
  };
})();
