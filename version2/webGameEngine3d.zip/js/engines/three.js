/* ============================================================
   three.js adapter — renders the shared scene model with Three.js
   Loaded lazily from a CDN as a classic script (no bundler).
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  UW.adapters = UW.adapters || {};

  UW.adapters.Three = class ThreeAdapter {
    constructor(def) {
      this.def = def;
      this.canvas = null;
      this.objects = new Map();
      this.geoms = new Map();
      this.stats = { triangles: 0, objects: 0, calls: 0 };
      this.frame = null;
      this.selectionId = null;
    }

    async init(host) {
      const THREE = (this.THREE = window.THREE);
      if (!THREE) throw new Error('Three.js global not found');
      this.host = host;
      this.canvas = document.createElement('canvas');
      this.canvas.className = 'engine-canvas';
      host.appendChild(this.canvas);

      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: true,
        alpha: true,
        preserveDrawingBuffer: true,
        powerPreference: 'high-performance',
      });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      if ('outputColorSpace' in this.renderer) this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.05;
      this.renderer.setClearColor(0x000000, 0);

      this.scene = new THREE.Scene();
      this.camera = new THREE.PerspectiveCamera(48, 1, 0.08, 900);

      this.ambient = new THREE.HemisphereLight(0xa9c6ea, 0x2a2d33, 0.7);
      this.scene.add(this.ambient);

      this.grid = new THREE.GridHelper(44, 44, 0x59708a, 0x37404b);
      this.grid.position.y = 0.003;
      this.grid.material.transparent = true;
      this.grid.material.opacity = 0.72;
      this.grid.material.depthWrite = false;
      this.scene.add(this.grid);

      const box = new THREE.BoxGeometry(1, 1, 1);
      this.selBox = new THREE.LineSegments(
        new THREE.EdgesGeometry(box),
        new THREE.LineBasicMaterial({ color: 0x56aaff, transparent: true, opacity: 0.95, depthTest: false })
      );
      this.selBox.matrixAutoUpdate = false;
      this.selBox.renderOrder = 999;
      this.scene.add(this.selBox);
      this.selBox.visible = false;
      box.dispose();
    }

    geometry(node) {
      const key = UW.geom.keyFor(node);
      if (this.geoms.has(key)) return this.geoms.get(key);
      const THREE = this.THREE;
      const g = UW.geom.forNode(node);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(g.positions, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(g.normals, 3));
      if (g.uvs) geo.setAttribute('uv', new THREE.BufferAttribute(g.uvs, 2));
      geo.computeBoundingSphere();
      this.geoms.set(key, geo);
      return geo;
    }

    createObject(node) {
      const THREE = this.THREE;
      if (node.type === 'mesh') {
        const mat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(node.mesh.color),
          roughness: node.mesh.roughness,
          metalness: node.mesh.metalness,
          side: THREE.DoubleSide,
          transparent: node.mesh.opacity < 1,
          opacity: node.mesh.opacity,
        });
        const mesh = new THREE.Mesh(this.geometry(node), mat);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData.nodeId = node.id;
        this.scene.add(mesh);
        return { type: 'mesh', obj: mesh, mat };
      }
      if (node.type === 'light') {
        const holder = { type: 'light', obj: null, kind: node.light.kind };
        this.rebuildLight(node, holder);
        return holder;
      }
      return { type: 'other', obj: null };
    }

    rebuildLight(node, holder) {
      const THREE = this.THREE;
      if (holder.obj) {
        this.scene.remove(holder.obj);
        if (holder.target) this.scene.remove(holder.target);
        if (holder.obj.dispose) holder.obj.dispose();
      }
      holder.kind = node.light.kind;
      const color = new THREE.Color(node.light.color);
      if (holder.kind === 'point') {
        const light = new THREE.PointLight(color, node.light.intensity * 12, node.light.range || 14, 2);
        light.castShadow = false;
        this.scene.add(light);
        holder.obj = light;
        holder.target = null;
      } else if (holder.kind === 'spot') {
        const light = new THREE.SpotLight(
          color,
          node.light.intensity * 14,
          node.light.range || 18,
          ((node.light.angle || 38) * Math.PI) / 180,
          node.light.penumbra != null ? node.light.penumbra : 0.35,
          2
        );
        light.castShadow = true;
        light.shadow.mapSize.set(1024, 1024);
        light.shadow.camera.near = 0.2;
        light.shadow.camera.far = Math.max(2, node.light.range || 18);
        light.shadow.bias = -0.0012;
        light.shadow.normalBias = 0.02;
        const target = new THREE.Object3D();
        this.scene.add(target);
        light.target = target;
        this.scene.add(light);
        holder.obj = light;
        holder.target = target;
      } else {
        const light = new THREE.DirectionalLight(color, node.light.intensity * 2.4);
        light.castShadow = true;
        light.shadow.mapSize.set(2048, 2048);
        light.shadow.camera.left = -18;
        light.shadow.camera.right = 18;
        light.shadow.camera.top = 18;
        light.shadow.camera.bottom = -18;
        light.shadow.camera.near = 0.5;
        light.shadow.camera.far = 70;
        light.shadow.bias = -0.0008;
        light.shadow.normalBias = 0.02;
        const target = new THREE.Object3D();
        this.scene.add(target);
        light.target = target;
        this.scene.add(light);
        holder.obj = light;
        holder.target = target;
      }
    }

    /* Textures are plain scene data; the shared texture library produces a
       canvas and we wrap it in a Three canvas texture with repeat/offset. */
    syncTexture(entry, node) {
      const THREE = this.THREE;
      const mat = entry.mat;
      const tex = node.mesh.texture;
      const active = !!(tex && tex.enabled !== false && UW.textures);
      if (!active) {
        if (entry.texture) {
          entry.texture.dispose();
          entry.texture = null;
        }
        entry.texSig = null;
        if (mat.map) {
          mat.map = null;
          mat.needsUpdate = true;
        }
        return;
      }
      const sig = UW.textures.signature(tex);
      if (!entry.texture || entry.texSig !== sig) {
        const base = UW.textures.getBase(tex);
        if (!base) return;
        if (entry.texture) entry.texture.dispose();
        const canvasTex = new THREE.CanvasTexture(base);
        canvasTex.wrapS = THREE.RepeatWrapping;
        canvasTex.wrapT = THREE.RepeatWrapping;
        if ('colorSpace' in canvasTex) canvasTex.colorSpace = THREE.SRGBColorSpace;
        if (this.renderer) canvasTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
        entry.texture = canvasTex;
        entry.texSig = sig;
        entry.texRev = UW.textures.rev;
        mat.map = canvasTex;
        mat.needsUpdate = true;
      } else if (entry.texRev !== UW.textures.rev) {
        // uploaded images resolve asynchronously into the cached canvas
        const base = UW.textures.getBase(tex);
        if (base && entry.texture.image !== base) {
          entry.texture.image = base;
          entry.texture.needsUpdate = true;
        }
        entry.texRev = UW.textures.rev;
      }
      const tiling = tex.tiling || [1, 1];
      const offset = tex.offset || [0, 0];
      entry.texture.repeat.set(tiling[0] || 1, tiling[1] || 1);
      entry.texture.offset.set(offset[0] || 0, offset[1] || 0);
    }

    update(frame) {
      this.frame = frame;
      const { scene, cam, viewMode, selected, env } = frame;
      const THREE = this.THREE;
      const world = UW.scene.worldMatrices(scene);
      const actives = UW.scene.activeMap(scene);
      const alive = new Set();
      this.selectionId = selected;

      if (this.ambient) {
        this.ambient.intensity = 0.25 + (env.ambient != null ? env.ambient : 0.4) * 0.95;
        this.ambient.color.set(env.ambientColor || '#ffffff');
      }
      if (env.fogEnabled) {
        if (!this.scene.fog) this.scene.fog = new THREE.Fog(env.fogColor || '#1d2025', env.fogNear || 14, env.fogFar || 70);
        this.scene.fog.color.set(env.fogColor || '#1d2025');
        this.scene.fog.near = env.fogNear || 14;
        this.scene.fog.far = env.fogFar || 70;
      } else if (this.scene.fog) {
        this.scene.fog = null;
      }

      for (const node of scene.nodes) {
        alive.add(node.id);
        let entry = this.objects.get(node.id);

        if (!entry) {
          entry = this.createObject(node);
          this.objects.set(node.id, entry);
        }
        if (node.type === 'light' && entry.type === 'light' && entry.kind !== node.light.kind) {
          this.rebuildLight(node, entry);
        }

        const obj = entry.obj;
        if (!obj) continue;

        // parenting mirrors the scene hierarchy
        const desiredParent = node.parent ? this.objects.get(node.parent) : null;
        const parentObj = desiredParent && desiredParent.obj ? desiredParent.obj : this.scene;
        if (obj.parent !== parentObj) parentObj.add(obj);

        obj.position.set(node.transform.position[0], node.transform.position[1], node.transform.position[2]);
        const m = M.mat4.compose(node.transform.position, node.transform.rotation, node.transform.scale);
        const q = M.mat4.quatFrom(m);
        obj.quaternion.set(q[0], q[1], q[2], q[3]);
        obj.scale.set(node.transform.scale[0], node.transform.scale[1], node.transform.scale[2]);
        obj.visible = node.visible && actives.get(node.id) !== false;

        if (entry.type === 'mesh') {
          const mat = entry.mat;
          mat.color.set(node.mesh.color);
          mat.roughness = node.mesh.roughness;
          mat.metalness = node.mesh.metalness;
          mat.wireframe = !!node.mesh.wireframe;
          const transparent = node.mesh.opacity < 1;
          if (mat.transparent !== transparent) {
            mat.transparent = transparent;
            mat.needsUpdate = true;
          }
          mat.opacity = node.mesh.opacity != null ? node.mesh.opacity : 1;
          entry.obj.castShadow = !node.mesh.wireframe;
          entry.obj.receiveShadow = true;
          if (entry.geoShape !== UW.geom.keyFor(node)) {
            entry.obj.geometry = this.geometry(node);
            entry.geoShape = UW.geom.keyFor(node);
            entry.obj.material.needsUpdate = true;
          }
          this.syncTexture(entry, node);
        }

        if (entry.type === 'light') {
          const wm = world.get(node.id);
          const pos = [wm[12], wm[13], wm[14]];
          const dir = V.norm([wm[8], wm[9], wm[10]]);
          entry.obj.color.set(node.light.color);
          if (entry.kind === 'point') {
            entry.obj.intensity = node.light.intensity * 12;
            entry.obj.distance = node.light.range || 14;
            entry.obj.position.set(pos[0], pos[1], pos[2]);
          } else if (entry.kind === 'spot') {
            entry.obj.intensity = node.light.intensity * 14;
            entry.obj.distance = node.light.range || 18;
            entry.obj.angle = ((node.light.angle || 38) * Math.PI) / 180;
            entry.obj.penumbra = node.light.penumbra != null ? node.light.penumbra : 0.35;
            entry.obj.position.set(pos[0], pos[1], pos[2]);
            if (entry.target) entry.target.position.set(pos[0] + dir[0] * 10, pos[1] + dir[1] * 10, pos[2] + dir[2] * 10);
            if (entry.obj.shadow) entry.obj.shadow.needsUpdate = true;
          } else {
            entry.obj.intensity = node.light.intensity * 2.4;
            entry.obj.position.set(pos[0] - dir[0] * 18, pos[1] - dir[1] * 18, pos[2] - dir[2] * 18);
            if (entry.target) entry.target.position.set(pos[0], pos[1], pos[2]);
            if (entry.obj.shadow) entry.obj.shadow.needsUpdate = true;
          }
        }
      }

      // remove deleted
      for (const [id, entry] of this.objects) {
        if (alive.has(id)) continue;
        if (entry.obj) {
          if (entry.obj.parent) entry.obj.parent.remove(entry.obj);
          if (entry.type === 'mesh') {
            if (entry.obj.geometry && entry.obj.geometry.dispose) entry.obj.geometry.dispose();
            if (entry.texture) entry.texture.dispose();
            entry.mat.dispose();
          }
          if (entry.target && entry.target.parent) entry.target.parent.remove(entry.target);
          if (entry.obj.dispose) entry.obj.dispose();
        }
        this.objects.delete(id);
      }

      // selection box
      const sel = selected && UW.scene.find(scene, selected);
      if (sel && viewMode === 'scene') {
        const wm = world.get(sel.id);
        if (wm) {
          const b = UW.scene.bounds(sel);
          const size = [b.max[0] - b.min[0], b.max[1] - b.min[1], b.max[2] - b.min[2]];
          const center = [(b.max[0] + b.min[0]) / 2, (b.max[1] + b.min[1]) / 2, (b.max[2] + b.min[2]) / 2];
          const local = M.mat4.mul(M.mat4.translation(center), [size[0], 0, 0, 0, 0, size[1], 0, 0, 0, 0, size[2], 0, 0, 0, 0, 1]);
          const final = M.mat4.mul(wm, local);
          this.selBox.matrix.fromArray(final);
          this.selBox.matrixWorldNeedsUpdate = true;
          this.selBox.visible = true;
        } else {
          this.selBox.visible = false;
        }
      } else {
        this.selBox.visible = false;
      }

      this.grid.visible = viewMode === 'scene' && env.showGrid !== false;

      // camera
      this.camera.position.set(cam.eye[0], cam.eye[1], cam.eye[2]);
      this.camera.quaternion.set(cam.quat[0], cam.quat[1], cam.quat[2], cam.quat[3]);
      this.camera.fov = cam.fov;
      this.camera.aspect = cam.aspect;
      this.camera.near = Math.max(0.01, cam.near);
      this.camera.far = cam.far;
      this.camera.updateProjectionMatrix();

      if (viewMode === 'game' && cam.backgroundColor) {
        this.renderer.setClearColor(new THREE.Color(cam.backgroundColor), 1);
      } else {
        this.renderer.setClearColor(0x000000, 0);
      }
    }

    render() {
      if (!this.renderer) return;
      this.renderer.render(this.scene, this.camera);
      const info = this.renderer.info.render;
      this.stats.triangles = info.triangles;
      this.stats.calls = info.calls;
      this.stats.objects = this.objects.size;
    }

    resize(w, h, dpr) {
      if (!this.renderer) return;
      this.renderer.setPixelRatio(Math.min(dpr || 1, 2));
      this.renderer.setSize(w, h, false);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
    }

    getStats() {
      return this.stats;
    }

    dispose() {
      for (const [, entry] of this.objects) {
        if (entry.mat) entry.mat.dispose();
        if (entry.texture) entry.texture.dispose();
        if (entry.obj && entry.obj.geometry && entry.obj.geometry.dispose) entry.obj.geometry.dispose();
      }
      this.objects.clear();
      for (const [, g] of this.geoms) if (g.dispose) g.dispose();
      this.geoms.clear();
      if (this.renderer) this.renderer.dispose();
      if (this.canvas && this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
      this.renderer = null;
      this.scene = null;
      this.canvas = null;
    }
  };

  UW.engines.register({
    id: 'three',
    name: 'Three.js',
    short: 'TH',
    version: 'r157',
    license: 'MIT',
    vendor: 'three.js',
    url: 'https://threejs.org',
    description: 'The most widely used WebGL library. Lightweight scene graph, PBR materials, soft shadows.',
    badge: 'CDN',
    capabilities: {
      webgl: { level: 'full', note: 'WebGL 2 / WebGL 1 fallback' },
      shadows: { level: 'full', note: 'PCFSoft shadow maps for sun and spot lights' },
      directional: 'full',
      point: { level: 'full', note: 'Point lights (no shadow map)' },
      spot: { level: 'full', note: 'Shadow-casting spot lights' },
      fog: 'full',
      textures: { level: 'full', note: 'CanvasTexture for presets, uploads and paintings' },
      tiling: 'full',
      transparency: 'full',
      wireframe: 'full',
      pbr: { level: 'full', note: 'MeshStandardMaterial' },
      antialias: { level: 'full', note: 'MSAA where the browser supports it' },
      offline: { level: 'none', note: 'Runtime is fetched from jsDelivr; browser cache may help' },
      runtime: 'full',
    },
    cdn: 'https://cdn.jsdelivr.net/npm/three@0.157.0/build/three.min.js',
    async load() {
      await UW.engines.loadScript(this.cdn, 'THREE');
    },
    create(def) {
      return new UW.adapters.Three(def);
    },
  });
})();
