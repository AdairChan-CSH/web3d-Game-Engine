/* ============================================================
   babylon.js adapter — renders the same scene model with Babylon
   Loaded lazily from the official CDN. Uses right-handed mode so
   the scene data matches every other engine.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  UW.adapters = UW.adapters || {};

  UW.adapters.Babylon = class BabylonAdapter {
    constructor(def) {
      this.def = def;
      this.canvas = null;
      this.meshes = new Map();
      this.lights = new Map();
      this.shadowGens = [];
      this.geoms = new Map();
      this.stats = { triangles: 0, objects: 0, calls: 0 };
      this.frame = null;
    }

    async init(host) {
      const B = (this.B = window.BABYLON);
      if (!B) throw new Error('Babylon.js global not found');
      this.host = host;
      this.canvas = document.createElement('canvas');
      this.canvas.className = 'engine-canvas';
      host.appendChild(this.canvas);

      this.engine = new B.Engine(this.canvas, true, {
        preserveDrawingBuffer: true,
        stencil: true,
        alpha: true,
        premultipliedAlpha: false,
        powerPreference: 'high-performance',
      });
      this.scene = new B.Scene(this.engine);
      this.scene.useRightHandedSystem = true;
      this.scene.clearColor = new B.Color4(0, 0, 0, 0);
      this.scene.skipPointerMovePicking = true;
      this.scene.autoClear = true;

      this.camera = new B.FreeCamera('editorCamera', new B.Vector3(0, 2, 9), this.scene);
      if (this.camera.inputs) this.camera.inputs.clear();
      this.camera.minZ = 0.08;
      this.camera.maxZ = 900;
      this.camera.fov = (48 * Math.PI) / 180;
      this.camera.setTarget(new B.Vector3(0, 1, 0));

      this.hemi = new B.HemisphericLight('ambient', new B.Vector3(0.2, 1, 0.1), this.scene);
      this.hemi.intensity = 0.7;
      this.hemi.diffuse = new B.Color3(0.75, 0.83, 0.95);
      this.hemi.groundColor = new B.Color3(0.16, 0.18, 0.21);

      this.buildGrid();

      this.bboxRenderer = this.scene.getBoundingBoxRenderer();
      this.bboxRenderer.frontColor = new B.Color3(0.36, 0.67, 1);
      this.bboxRenderer.backColor = new B.Color3(0.2, 0.42, 0.66);
    }

    buildGrid() {
      const B = this.B;
      const minor = [];
      const major = [];
      const range = 22;
      for (let i = -range; i <= range; i++) {
        const arr = i % 5 === 0 ? major : minor;
        arr.push([new B.Vector3(i, 0.004, -range), new B.Vector3(i, 0.004, range)]);
        arr.push([new B.Vector3(-range, 0.004, i), new B.Vector3(range, 0.004, i)]);
      }
      this.gridMinor = B.MeshBuilder.CreateLineSystem('gridMinor', { lines: minor }, this.scene);
      this.gridMinor.color = new B.Color3(0.28, 0.33, 0.4);
      this.gridMinor.alpha = 0.6;
      this.gridMinor.isPickable = false;
      this.gridMajor = B.MeshBuilder.CreateLineSystem('gridMajor', { lines: major }, this.scene);
      this.gridMajor.color = new B.Color3(0.36, 0.44, 0.55);
      this.gridMajor.alpha = 0.85;
      this.gridMajor.isPickable = false;

      const axes = [
        [new B.Vector3(-range, 0.006, 0), new B.Vector3(range, 0.006, 0)],
        [new B.Vector3(0, 0.006, -range), new B.Vector3(0, 0.006, range)],
      ];
      this.gridAxes = B.MeshBuilder.CreateLineSystem('gridAxes', { lines: axes }, this.scene);
      this.gridAxes.color = new B.Color3(0.55, 0.55, 0.6);
      this.gridAxes.alpha = 0.5;
      this.gridAxes.isPickable = false;
    }

    vertexData(node) {
      const key = UW.geom.keyFor(node);
      if (this.geoms.has(key)) return this.geoms.get(key);
      const B = this.B;
      const g = UW.geom.forNode(node);
      const vd = new B.VertexData();
      vd.positions = Array.from(g.positions);
      vd.normals = Array.from(g.normals);
      if (g.uvs) vd.uvs = Array.from(g.uvs);
      const n = g.positions.length / 3;
      const idx = new Array(n);
      for (let i = 0; i < n; i++) idx[i] = i;
      vd.indices = idx;
      this.geoms.set(key, vd);
      return vd;
    }

    createMesh(node) {
      const B = this.B;
      const mesh = new B.Mesh('m_' + node.id, this.scene);
      this.vertexData(node).applyToMesh(mesh);
      mesh.isPickable = false;
      const mat = new B.StandardMaterial('mat_' + node.id, this.scene);
      mat.backFaceCulling = false;
      mat.specularPower = 64;
      mesh.material = mat;
      mesh.receiveShadows = true;
      const entry = { type: 'mesh', mesh, mat, shape: UW.geom.keyFor(node), color: null };
      this.meshes.set(node.id, entry);
      for (const gen of this.shadowGens) {
        try { gen.addShadowCaster(mesh); } catch (e) { /* ignore */ }
      }
      return entry;
    }

    createLight(node) {
      const B = this.B;
      const holder = { type: 'light', light: null, kind: node.light.kind, gen: null };
      this.rebuildLight(node, holder, true);
      this.lights.set(node.id, holder);
      return holder;
    }

    rebuildLight(node, holder, initial) {
      const B = this.B;
      if (holder.light) holder.light.dispose();
      if (holder.gen) {
        this.shadowGens = this.shadowGens.filter((g) => g !== holder.gen);
        holder.gen.dispose();
      }
      holder.kind = node.light.kind;
      if (holder.kind === 'point') {
        const light = new B.PointLight('light_' + node.id, new B.Vector3(0, 3, 0), this.scene);
        light.range = node.light.range || 14;
        light.intensity = node.light.intensity * 1.8;
        holder.light = light;
        holder.gen = null;
      } else if (holder.kind === 'spot') {
        const light = new B.SpotLight(
          'light_' + node.id,
          new B.Vector3(0, 4, 0),
          new B.Vector3(0, -1, 0),
          ((node.light.angle || 38) * Math.PI) / 180,
          2,
          this.scene
        );
        light.range = node.light.range || 18;
        light.intensity = node.light.intensity * 2;
        light.exponent = 2 + (1 - (node.light.penumbra != null ? node.light.penumbra : 0.35)) * 18;
        holder.light = light;
        holder.gen = null;
      } else {
        const light = new B.DirectionalLight('light_' + node.id, new B.Vector3(0, -1, 0), this.scene);
        light.intensity = node.light.intensity * 1.3;
        light.position = new B.Vector3(4, 12, 4);
        const gen = new B.ShadowGenerator(2048, light);
        gen.usePercentageCloserFiltering = true;
        gen.filteringQuality = B.ShadowGenerator.QUALITY_MEDIUM;
        gen.bias = 0.0015;
        for (const [, entry] of this.meshes) {
          try { gen.addShadowCaster(entry.mesh); } catch (e) { /* ignore */ }
        }
        holder.light = light;
        holder.gen = gen;
        this.shadowGens.push(gen);
      }
      if (initial) return;
    }

    syncTexture(entry, node) {
      const B = this.B;
      const mat = entry.mat;
      const tex = node.mesh.texture;
      const active = !!(tex && tex.enabled !== false && UW.textures);
      if (!active) {
        if (entry.texture) {
          entry.texture.dispose();
          entry.texture = null;
        }
        entry.texSig = null;
        if (mat.diffuseTexture) mat.diffuseTexture = null;
        return;
      }
      const sig = UW.textures.signature(tex);
      const base = UW.textures.getBase(tex);
      if (!base) return;
      if (!entry.texture || entry.texSig !== sig || entry.texRev !== UW.textures.rev) {
        if (entry.texture) entry.texture.dispose();
        const w = Math.max(1, base.width);
        const h = Math.max(1, base.height);
        const dt = new B.DynamicTexture('tex_' + node.id, { width: w, height: h }, this.scene, true, B.Texture.TRILINEAR_SAMPLINGMODE);
        const ctx = dt.getContext();
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(base, 0, 0, w, h);
        dt.update();
        dt.hasAlpha = false;
        dt.wrapU = B.Texture.WRAP_ADDRESSMODE;
        dt.wrapV = B.Texture.WRAP_ADDRESSMODE;
        dt.coordinatesMode = B.Texture.EXPLICIT_MODE;
        entry.texture = dt;
        entry.texSig = sig;
        entry.texRev = UW.textures.rev;
        mat.diffuseTexture = dt;
      }
      const tiling = tex.tiling || [1, 1];
      const offset = tex.offset || [0, 0];
      entry.texture.uScale = tiling[0] || 1;
      entry.texture.vScale = tiling[1] || 1;
      entry.texture.uOffset = offset[0] || 0;
      entry.texture.vOffset = offset[1] || 0;
    }

    update(frame) {
      this.frame = frame;
      const { scene, cam, viewMode, selected, env } = frame;
      const B = this.B;
      const world = UW.scene.worldMatrices(scene);
      const actives = UW.scene.activeMap(scene);
      const alive = new Set();

      if (this.hemi) {
        this.hemi.intensity = 0.18 + (env.ambient != null ? env.ambient : 0.4) * 1.25;
        this.hemi.diffuse = B.Color3.FromHexString(env.ambientColor || '#ffffff');
      }
      if (env.fogEnabled) {
        this.scene.fogEnabled = true;
        this.scene.fogMode = B.Scene.FOGMODE_LINEAR;
        this.scene.fogColor = B.Color3.FromHexString(env.fogColor || '#1d2025');
        this.scene.fogStart = env.fogNear != null ? env.fogNear : 14;
        this.scene.fogEnd = env.fogFar != null ? env.fogFar : 70;
      } else {
        this.scene.fogEnabled = false;
      }
      this.gridMinor.setEnabled(viewMode === 'scene' && env.showGrid !== false);
      this.gridMajor.setEnabled(viewMode === 'scene' && env.showGrid !== false);
      this.gridAxes.setEnabled(viewMode === 'scene' && env.showGrid !== false);

      for (const node of scene.nodes) {
        alive.add(node.id);

        if (node.type === 'mesh') {
          let entry = this.meshes.get(node.id);
          if (!entry) entry = this.createMesh(node);
          const mesh = entry.mesh;
          const desiredParent = node.parent ? this.meshes.get(node.parent) : null;
          const parentMesh = desiredParent && desiredParent.mesh ? desiredParent.mesh : null;
          if (mesh.parent !== parentMesh) {
            if (parentMesh) mesh.parent = parentMesh;
            else mesh.parent = null;
          }
          mesh.position.set(node.transform.position[0], node.transform.position[1], node.transform.position[2]);
          const m = M.mat4.compose(node.transform.position, node.transform.rotation, node.transform.scale);
          const q = M.mat4.quatFrom(m);
          if (!mesh.rotationQuaternion) mesh.rotationQuaternion = new B.Quaternion();
          mesh.rotationQuaternion.set(q[0], q[1], q[2], q[3]);
          mesh.scaling.set(node.transform.scale[0], node.transform.scale[1], node.transform.scale[2]);
          mesh.setEnabled(node.visible && actives.get(node.id) !== false);

          if (entry.shape !== UW.geom.keyFor(node)) {
            this.vertexData(node).applyToMesh(mesh);
            entry.shape = UW.geom.keyFor(node);
          }
          const mat = entry.mat;
          if (entry.color !== node.mesh.color) {
            const c = B.Color3.FromHexString(node.mesh.color);
            mat.diffuseColor = c;
            const metal = node.mesh.metalness || 0;
            mat.specularColor = new B.Color3(metal * 0.55 + 0.05, metal * 0.55 + 0.05, metal * 0.55 + 0.05);
            entry.color = node.mesh.color;
          }
          mat.specularPower = 96 - (node.mesh.roughness || 0) * 80;
          mat.wireframe = !!node.mesh.wireframe;
          mat.alpha = node.mesh.opacity != null ? node.mesh.opacity : 1;
          this.syncTexture(entry, node);
          mesh.showBoundingBox = viewMode === 'scene' && selected === node.id;
        } else {
          const old = this.meshes.get(node.id);
          if (old) {
            old.mesh.dispose();
            this.meshes.delete(node.id);
          }
        }

        if (node.type === 'light') {
          let holder = this.lights.get(node.id);
          if (!holder) holder = this.createLight(node);
          if (holder.kind !== node.light.kind) this.rebuildLight(node, holder);
          const wm = world.get(node.id);
          if (wm) {
            const pos = [wm[12], wm[13], wm[14]];
            const dir = V.norm([wm[8], wm[9], wm[10]]);
            if (holder.kind === 'point') {
              holder.light.position.set(pos[0], pos[1], pos[2]);
              holder.light.intensity = node.light.intensity * 1.8;
              holder.light.range = node.light.range || 14;
              holder.light.diffuse = B.Color3.FromHexString(node.light.color);
            } else if (holder.kind === 'spot') {
              holder.light.position.set(pos[0], pos[1], pos[2]);
              holder.light.direction.set(dir[0], dir[1], dir[2]);
              holder.light.range = node.light.range || 18;
              holder.light.intensity = node.light.intensity * 2;
              holder.light.angle = ((node.light.angle || 38) * Math.PI) / 180;
              holder.light.exponent = 2 + (1 - (node.light.penumbra != null ? node.light.penumbra : 0.35)) * 18;
              holder.light.diffuse = B.Color3.FromHexString(node.light.color);
            } else {
              holder.light.direction.set(dir[0], dir[1], dir[2]);
              holder.light.position.set(pos[0] - dir[0] * 18, pos[1] - dir[1] * 18, pos[2] - dir[2] * 18);
              holder.light.intensity = node.light.intensity * 1.3;
              holder.light.diffuse = B.Color3.FromHexString(node.light.color);
            }
            holder.light.setEnabled(node.visible && actives.get(node.id) !== false);
          }
        }
      }

      for (const [id, entry] of this.meshes) {
        if (!alive.has(id)) {
          if (entry.texture) entry.texture.dispose();
          entry.mesh.dispose();
          this.meshes.delete(id);
        }
      }
      for (const [id, holder] of this.lights) {
        if (!alive.has(id)) {
          if (holder.gen) {
            this.shadowGens = this.shadowGens.filter((g) => g !== holder.gen);
            holder.gen.dispose();
          }
          if (holder.light) holder.light.dispose();
          this.lights.delete(id);
        }
      }

      // camera
      this.camera.position.set(cam.eye[0], cam.eye[1], cam.eye[2]);
      this.camera.setTarget(new B.Vector3(cam.target[0], cam.target[1], cam.target[2]));
      this.camera.fov = (cam.fov * Math.PI) / 180;
      this.camera.minZ = Math.max(0.01, cam.near);
      this.camera.maxZ = cam.far;

      if (viewMode === 'game' && cam.backgroundColor) {
        const c = B.Color3.FromHexString(cam.backgroundColor);
        this.scene.clearColor = new B.Color4(c.r, c.g, c.b, 1);
      } else {
        this.scene.clearColor = new B.Color4(0, 0, 0, 0);
      }
    }

    render() {
      if (!this.scene) return;
      this.scene.render();
      this.stats.objects = this.scene.getActiveMeshes ? this.scene.getActiveMeshes().length : this.meshes.size;
      this.stats.calls = this.stats.objects;
      let tris = 0;
      for (const [, e] of this.meshes) {
        if (e.mesh.isEnabled()) tris += Math.floor(e.mesh.getTotalIndices() / 3);
      }
      this.stats.triangles = tris;
      this.stats.fps = this.engine.getFps();
    }

    resize(w, h, dpr) {
      if (!this.engine) return;
      this.engine.setHardwareScalingLevel(1 / Math.min(dpr || 1, 2));
      this.engine.resize();
    }

    getStats() {
      return this.stats;
    }

    screenshot() {
      return this.canvas ? this.canvas.toDataURL('image/png') : null;
    }

    dispose() {
      for (const [, e] of this.meshes) {
        try { if (e.texture) e.texture.dispose(); e.mesh.dispose(); } catch (err) { /* ignore */ }
      }
      this.meshes.clear();
      for (const g of this.shadowGens) {
        try { g.dispose(); } catch (err) { /* ignore */ }
      }
      this.shadowGens = [];
      for (const [, l] of this.lights) {
        try { l.light.dispose(); } catch (err) { /* ignore */ }
      }
      this.lights.clear();
      if (this.scene) this.scene.dispose();
      if (this.engine) this.engine.dispose();
      if (this.canvas && this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
      this.scene = null;
      this.engine = null;
      this.canvas = null;
    }
  };

  UW.engines.register({
    id: 'babylon',
    name: 'Babylon.js',
    short: 'BB',
    version: '8.x',
    license: 'Apache 2.0',
    vendor: 'Microsoft / BabylonJS',
    url: 'https://www.babylonjs.com',
    description: 'Batteries-included WebGL engine with a strong material and shadow system.',
    badge: 'CDN',
    capabilities: {
      webgl: { level: 'full', note: 'WebGL 2 / WebGL 1 fallback' },
      shadows: { level: 'full', note: 'ShadowGenerator, medium filtering' },
      directional: 'full',
      point: { level: 'full', note: 'Point lights are supported; shadow maps are emitted by sun/spot lights' },
      spot: { level: 'full', note: 'Shadow-casting spot lights' },
      fog: 'full',
      textures: { level: 'full', note: 'DynamicTexture for presets, uploads and paintings' },
      tiling: 'full',
      transparency: 'full',
      wireframe: 'full',
      pbr: { level: 'full', note: 'PBRMaterial' },
      antialias: { level: 'full', note: 'Engine anti-aliasing enabled by default' },
      offline: { level: 'none', note: 'Runtime is fetched from babylonjs.com; browser cache may help' },
      runtime: 'full',
    },
    cdn: 'https://cdn.babylonjs.com/babylon.js',
    async load() {
      await UW.engines.loadScript(this.cdn, 'BABYLON');
    },
    create(def) {
      return new UW.adapters.Babylon(def);
    },
  });
})();
