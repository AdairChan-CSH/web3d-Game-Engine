/* ============================================================
   registry.js — pluggable rendering engine registry
   Any script can call UnityWeb.engines.register({...}) to add an
   engine adapter. Built-ins register themselves when their file
   loads; adapters only fetch their engine runtime when selected.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});

  const defs = new Map();
  const listeners = [];

  /* Feature matrix used by the compatibility dialog, the engine docs
     panel and plugin authors. Levels: full | partial | none | unknown. */
  const FEATURES = [
    { id: 'webgl', label: 'GPU / WebGL', help: 'Hardware-accelerated rasterization.' },
    { id: 'shadows', label: 'Shadow maps', help: 'Cast/receive shadows from scene lights.' },
    { id: 'directional', label: 'Directional / sun', help: 'Parallel world lighting.' },
    { id: 'point', label: 'Point lights', help: 'Omnidirectional lights with range falloff.' },
    { id: 'spot', label: 'Spot lights', help: 'Cone lights with angle, range and penumbra.' },
    { id: 'fog', label: 'Distance fog', help: 'Linear fog blended with scene colour.' },
    { id: 'textures', label: 'Textures & painting', help: 'Procedural, uploaded and painted textures.' },
    { id: 'tiling', label: 'Texture tiling', help: 'Repeat and offset UV mapping.' },
    { id: 'transparency', label: 'Opacity', help: 'Per-mesh transparency.' },
    { id: 'wireframe', label: 'Wireframe', help: 'Wireframe mesh rendering.' },
    { id: 'pbr', label: 'PBR shading', help: 'Metalness / roughness based shading.' },
    { id: 'antialias', label: 'Anti-aliasing', help: 'Smooth geometry edges.' },
    { id: 'offline', label: 'Works offline', help: 'No network request is required to render.' },
    { id: 'runtime', label: 'FSM · scripts · physics', help: 'Shared Play-mode runtime. Engine-independent.' },
  ];

  const DEFAULT_CAPS = {
    webgl: 'unknown',
    shadows: 'unknown',
    directional: 'unknown',
    point: 'unknown',
    spot: 'unknown',
    fog: 'unknown',
    textures: 'unknown',
    tiling: 'unknown',
    transparency: 'unknown',
    wireframe: 'unknown',
    pbr: 'unknown',
    antialias: 'unknown',
    offline: 'unknown',
    runtime: 'full',
  };

  function normalizeCap(raw) {
    if (typeof raw === 'string') return { level: raw, note: '' };
    if (raw && typeof raw === 'object' && raw.level) {
      return { level: raw.level, note: raw.note ? String(raw.note) : '' };
    }
    return { level: 'unknown', note: '' };
  }

  const R = (UW.engines = {
    features: FEATURES,
    defaultCapabilities() {
      return Object.assign({}, DEFAULT_CAPS);
    },
    capabilities(def) {
      const caps = {};
      const declared = (def && def.capabilities) || {};
      for (const f of FEATURES) {
        caps[f.id] = normalizeCap(declared[f.id] || DEFAULT_CAPS[f.id]);
      }
      return caps;
    },
    capability(def, featureId) {
      return R.capabilities(def)[featureId] || { level: 'unknown', note: '' };
    },
    register(def) {
      if (!def || !def.id || typeof def.load !== 'function' || typeof def.create !== 'function') {
        throw new Error('registerEngine(): expected { id, name, load(), create() }');
      }
      defs.set(def.id, def);
      listeners.forEach((fn) => {
        try { fn(defs); } catch (e) { console.error(e); }
      });
      return def;
    },
    list() {
      return Array.from(defs.values());
    },
    get(id) {
      return defs.get(id) || null;
    },
    onChange(fn) {
      listeners.push(fn);
    },
    async instance(id) {
      const def = defs.get(id);
      if (!def) throw new Error('Unknown engine "' + id + '"');
      await def.load();
      return def.create(def);
    },
  });

  /* helper used by built-in adapters to inject a CDN script only once */
  R.loadScript = function (src, globalName) {
    if (globalName && window[globalName]) return Promise.resolve(window[globalName]);
    const existing = Array.from(document.scripts).find((s) => s.src === src);
    if (existing) {
      return new Promise((resolve, reject) => {
        existing.addEventListener('load', () => resolve(globalName ? window[globalName] : true));
        existing.addEventListener('error', () => reject(new Error('Failed to load ' + src)));
        if (globalName && window[globalName]) resolve(window[globalName]);
      });
    }
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      const timer = setTimeout(() => {
        reject(new Error('Timed out loading ' + src));
      }, 20000);
      s.src = src;
      s.async = true;
      s.onload = () => {
        clearTimeout(timer);
        if (globalName && !window[globalName]) reject(new Error('Script loaded but global "' + globalName + '" is missing'));
        else resolve(globalName ? window[globalName] : true);
      };
      s.onerror = () => {
        clearTimeout(timer);
        reject(new Error('Failed to load ' + src + ' (are you offline?)'));
      };
      document.head.appendChild(s);
    });
  };

  UW.engines.loadScript = R.loadScript;
})();
