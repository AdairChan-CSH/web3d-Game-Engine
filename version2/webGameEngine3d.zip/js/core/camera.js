/* ============================================================
   camera.js — editor orbit camera + game camera + projection
   Projection is computed once per frame and shared with every
   engine adapter and with the gizmo / picking code.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  UW.CameraRig = class CameraRig {
    constructor(editor) {
      this.editor = editor;
      this.width = 1;
      this.height = 1;
      this.aspect = 1;
      this.eye = [0, 3, 10];
      this.target = [0, 1, 0];
      this.up = [0, 1, 0];
      this.fov = 48;
      this.near = 0.08;
      this.far = 800;
      this.view = M.mat4.identity();
      this.proj = M.mat4.identity();
      this.vp = M.mat4.identity();
      this.invVp = M.mat4.identity();
      this.quat = [0, 0, 0, 1];
      this.activeCamera = null;
      this.gameCamera = null;
      this.backgroundColor = '#1d2025';
    }

    setViewport(w, h) {
      this.width = Math.max(1, w);
      this.height = Math.max(1, h);
      this.aspect = this.width / this.height;
    }

    update() {
      const ed = this.editor;
      const cam = ed.camera;
      this.activeCamera = null;

      if (ed.viewMode === 'game') {
        const camNode = ed.scene.nodes.find((n) => n.type === 'camera' && n.visible);
        this.gameCamera = camNode || null;
        if (camNode) {
          const wm = ed.world().get(camNode.id) || M.mat4.identity();
          const eye = [wm[12], wm[13], wm[14]];
          const forward = V.norm([-wm[8], -wm[9], -wm[10]]);
          const up = V.norm([wm[4], wm[5], wm[6]]);
          const target = V.add(eye, forward);
          this.eye = eye;
          this.target = target;
          this.up = Math.abs(V.dot(forward, up)) > 0.999 ? [0, 0, 1] : up;
          this.fov = camNode.camera.fov || 55;
          this.near = camNode.camera.near || 0.1;
          this.far = camNode.camera.far || 600;
          this.backgroundColor = camNode.camera.bg || '#1d2025';
          this.activeCamera = camNode;
        } else {
          // fallback so the viewport isn't blank
          this.eye = [0, 2, 9];
          this.target = [0, 1, 0];
          this.up = [0, 1, 0];
          this.fov = 50;
          this.near = 0.1;
          this.far = 600;
          this.backgroundColor = '#1d2025';
        }
      } else {
        const pitch = M.clamp(cam.pitch, -1.45, 1.45);
        const cp = Math.cos(pitch);
        this.eye = [
          cam.target[0] + Math.sin(cam.yaw) * cp * cam.distance,
          cam.target[1] + Math.sin(pitch) * cam.distance,
          cam.target[2] + Math.cos(cam.yaw) * cp * cam.distance,
        ];
        this.target = cam.target.slice();
        this.up = [0, 1, 0];
        this.fov = 48;
        this.near = 0.08;
        this.far = 900;
        this.backgroundColor = '#1d2025';
      }

      this.view = M.mat4.lookAt(this.eye, this.target, this.up);
      this.proj = M.mat4.perspective(this.fov, this.aspect, this.near, this.far);
      this.vp = M.mat4.mul(this.proj, this.view);
      this.invVp = M.mat4.invert(this.vp);
      this.quat = M.mat4.quatFrom(M.mat4.invert(this.view));
      this.forward = V.norm(V.sub(this.target, this.eye));
    }

    /* screen (CSS px) -> ray */
    ray(x, y) {
      const nx = (x / this.width) * 2 - 1;
      const ny = 1 - (y / this.height) * 2;
      const near = this.unproject(nx, ny, -1);
      const far = this.unproject(nx, ny, 1);
      return { origin: near, dir: V.norm(V.sub(far, near)) };
    }

    unproject(nx, ny, nz) {
      const p = M.mat4.point4(this.invVp, [nx, ny, nz]);
      const w = p[3] || 1e-9;
      return [p[0] / w, p[1] / w, p[2] / w];
    }

    project(p) {
      const c = M.mat4.point4(this.vp, p);
      if (c[3] <= 1e-6) return { x: 0, y: 0, z: 2, visible: false };
      const nx = c[0] / c[3];
      const ny = c[1] / c[3];
      const nz = c[2] / c[3];
      return {
        x: (nx * 0.5 + 0.5) * this.width,
        y: (0.5 - ny * 0.5) * this.height,
        z: nz,
        visible: nz > -1 && nz < 1,
      };
    }

    /* pixels per world unit at a given world point (approx) */
    pixelScale(p) {
      const d = V.dist(p, this.eye);
      return this.height / (2 * Math.max(0.0001, d) * Math.tan((this.fov * Math.PI) / 360));
    }

    orbit(dx, dy) {
      const cam = this.editor.camera;
      cam.yaw -= dx * 0.007;
      cam.pitch = M.clamp(cam.pitch + dy * 0.007, -1.45, 1.45);
      this.editor.emit('camera');
    }

    pan(dx, dy) {
      const cam = this.editor.camera;
      const forward = V.norm(V.sub(this.target, this.eye));
      const right = V.norm(V.cross(forward, this.up));
      const up = V.norm(V.cross(right, forward));
      const scale = (cam.distance * 1.1) / this.height;
      cam.target = V.add(cam.target, V.add(V.scale(right, -dx * scale), V.scale(up, dy * scale)));
      this.editor.emit('camera');
    }

    zoom(delta) {
      const cam = this.editor.camera;
      const factor = Math.pow(1.0015, delta);
      cam.distance = M.clamp(cam.distance * factor, 0.6, 220);
      this.editor.emit('camera');
    }
  };
})();
