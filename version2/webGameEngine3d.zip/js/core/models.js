/* ============================================================
   models.js — imported 3D models (.glb / .gltf / .obj / .blend)
   glTF/GLB is parsed natively here; OBJ and Blender files are
   translated into the same glTF-shaped documents by their own
   parsers (UW.obj / UW.blend), so geometry, materials, embedded
   images and the node tree flow through one shared pipeline
   (no GLTFLoader, no CDN, no modules — everything works offline
   and on every rendering engine).

   A model is stored ONCE per scene in scene.models[]:
     { id, name, format: 'glb'|'gltf'|'obj'|'blend',
       data: <data URL of the file>,
       mtl / images: <OBJ companions, as data URLs> }
   Mesh nodes reference it with:
     mesh: { shape: 'model', modelId, meshIndex, primitiveIndex, ... }
   and UW.models.geometryFor(node) expands the referenced
   primitive into the same triangle-soup buffers UW.geom.get()
   produces for primitives, so engines need no special code.

   Unsupported features are skipped with Console warnings:
   glTF skins/animations/morphs/cameras/lights, external glTF
   buffers, Blender curves/lattices/lights and animation data.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const MODELS = (UW.models = {});

  const GLB_MAGIC = 0x46546c67;    // 'glTF'
  const CHUNK_JSON = 0x4e4f534a;  // 'JSON'
  const CHUNK_BIN = 0x004e4942;   // 'BIN\0'
  const COMPONENT_SIZE = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
  const TYPE_COUNT = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };

  const parsedCache = new Map(); // modelId → parsed document
  const geoCache = new Map();    // 'id|mesh|prim' → triangle soup
  const failedIds = new Set();   // model ids that failed to warm

  let idSeq = 0;
  const newId = () => 'mdl_' + Date.now().toString(36) + '_' + (idSeq++).toString(36);
  const r5 = (v) => Math.round(v * 100000) / 100000;
  const r4 = (v) => Math.round(v * 10000) / 10000;

  /* ---------------- base64 / data URL helpers ---------------- */

  function bytesToBase64(bytes) {
    let str = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      str += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
    }
    return btoa(str);
  }

  function base64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function dataUrlToBuffer(url) {
    const comma = url.indexOf(',');
    if (comma < 0 || !/^data:/i.test(url)) throw new Error('Not a data URL');
    const meta = url.slice(5, comma);
    const payload = url.slice(comma + 1);
    if (/;base64/i.test(meta)) return base64ToBytes(payload).buffer;
    const bytes = new Uint8Array(payload.length);
    for (let i = 0; i < payload.length; i++) bytes[i] = payload.charCodeAt(i) & 0xff;
    return bytes.buffer;
  }

  /* ---------------- container + JSON parsing ---------------- */

  function parseGLB(buffer) {
    const view = new DataView(buffer);
    if (buffer.byteLength < 20) throw new Error('File is too small to be a GLB container');
    if (view.getUint32(0, true) !== GLB_MAGIC) throw new Error('Not a binary glTF (.glb) file');
    const version = view.getUint32(4, true);
    if (version !== 2) throw new Error('Only GLB version 2 is supported (this file reports version ' + version + ')');
    let off = 12;
    let json = null;
    let bin = null;
    while (off + 8 <= buffer.byteLength) {
      const len = view.getUint32(off, true);
      const type = view.getUint32(off + 4, true);
      if (off + 8 + len > buffer.byteLength) throw new Error('Corrupt GLB: a chunk overruns the file');
      const chunk = buffer.slice(off + 8, off + 8 + len);
      if (type === CHUNK_JSON) {
        if (json) throw new Error('Corrupt GLB: multiple JSON chunks');
        json = JSON.parse(new TextDecoder('utf-8').decode(chunk));
      } else if (type === CHUNK_BIN) {
        if (!bin) bin = chunk;
      }
      off += 8 + len;
    }
    if (!json) throw new Error('Corrupt GLB: missing JSON chunk');
    return { json, bin };
  }

  function resolveBuffers(json, bin) {
    const list = json.buffers || [];
    const out = [];
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      if (b && typeof b.uri === 'string' && b.uri) {
        if (/^data:/i.test(b.uri)) {
          out.push(dataUrlToBuffer(b.uri));
          continue;
        }
        throw new Error('External buffer "' + b.uri + '" — export a .glb (or embed the buffer as a data URI) instead');
      }
      if (i === 0 && bin) { out.push(bin); continue; }
      throw new Error('Buffer ' + i + ' has no data');
    }
    return out;
  }

  /* ---------------- accessor reading ---------------- */

  function readAccessor(json, buffers, index) {
    const acc = json.accessors && json.accessors[index];
    if (!acc) throw new Error('Accessor ' + index + ' does not exist');
    const compSize = COMPONENT_SIZE[acc.componentType];
    if (!compSize) throw new Error('Unsupported accessor componentType ' + acc.componentType);
    const numComp = TYPE_COUNT[acc.type] || 1;
    if (acc.bufferView == null) throw new Error('Accessor ' + index + ' has no bufferView');
    const bv = json.bufferViews && json.bufferViews[acc.bufferView];
    if (!bv) throw new Error('Accessor ' + index + ' references a missing bufferView');
    const buffer = buffers[bv.buffer];
    if (!buffer) throw new Error('Accessor ' + index + ' references missing buffer ' + bv.buffer);
    const stride = bv.byteStride && bv.byteStride > 0 ? bv.byteStride : compSize * numComp;
    const base = (bv.byteOffset || 0) + (acc.byteOffset || 0);
    const count = acc.count | 0;
    if (base < 0 || count < 0) throw new Error('Accessor ' + index + ' has invalid offsets');
    const dv = new DataView(buffer);
    if (base + count * stride > buffer.byteLength + 0.001) throw new Error('Accessor ' + index + ' overruns its buffer');
    const out = new Float32Array(count * numComp);
    const normalized = acc.normalized === true;
    for (let i = 0; i < count; i++) {
      for (let c = 0; c < numComp; c++) {
        const at = base + i * stride + c * compSize;
        let v = 0;
        switch (acc.componentType) {
          case 5120: v = dv.getInt8(at); if (normalized) v = Math.max(v / 127, -1); break;
          case 5121: v = dv.getUint8(at); if (normalized) v = v / 255; break;
          case 5122: v = dv.getInt16(at, true); if (normalized) v = Math.max(v / 32767, -1); break;
          case 5123: v = dv.getUint16(at, true); if (normalized) v = v / 65535; break;
          case 5125: v = dv.getUint32(at, true); if (normalized) v = v / 4294967295; break;
          case 5126: v = dv.getFloat32(at, true); break;
        }
        out[i * numComp + c] = v;
      }
    }
    return { data: out, count, numComp };
  }

  /* ---------------- images ---------------- */

  function sniffMime(bytes) {
    if (bytes.length > 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png';
    if (bytes.length > 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
    return null;
  }

  function extractImages(json, buffers, warnings) {
    const out = [];
    (json.images || []).forEach((img, i) => {
      let url = null;
      try {
        if (img && img.bufferView != null) {
          const bv = json.bufferViews && json.bufferViews[img.bufferView];
          if (bv && buffers[bv.buffer]) {
            const bytes = new Uint8Array(buffers[bv.buffer], bv.byteOffset || 0, bv.byteLength || 0);
            const mime = img.mimeType || sniffMime(bytes);
            if (mime) url = 'data:' + mime + ';base64,' + bytesToBase64(bytes);
            else warnings.push('Image ' + i + ': unknown image format — skipped');
          }
        } else if (img && typeof img.uri === 'string' && /^data:image\//i.test(img.uri)) {
          url = img.uri;
        } else {
          warnings.push('Image ' + i + ' is an external file — only embedded images are supported');
        }
      } catch (e) {
        warnings.push('Image ' + i + ' could not be read: ' + (e.message || e));
      }
      if (url && url.length > 2 * 1024 * 1024) warnings.push('Image ' + i + ' is very large (' + Math.round(url.length / 1024) + ' KB as text) — saving may be limited');
      out.push(url);
    });
    return out;
  }

  /* ---------------- materials ---------------- */

  function rgbToHex(r, g, b) {
    const c = (v) => {
      const n = Math.max(0, Math.min(255, Math.round((Number(v) || 0) * 255)));
      return ('0' + n.toString(16)).slice(-2);
    };
    return '#' + c(r) + c(g) + c(b);
  }

  function materialFor(doc, matIndex) {
    const json = doc.json;
    if (matIndex == null || !json.materials || !json.materials[matIndex]) {
      return { color: '#c9ced6', roughness: 0.6, metalness: 0.08, opacity: 1, texture: null, doubleSided: false };
    }
    const mat = json.materials[matIndex];
    const pbr = mat.pbrMetallicRoughness || {};
    const f = Array.isArray(pbr.baseColorFactor) ? pbr.baseColorFactor : [1, 1, 1, 1];
    let opacity = f.length > 3 && Number.isFinite(f[3]) && f[3] < 1 ? f[3] : 1;
    if (mat.alphaMode === 'MASK') {
      doc.warnings.push('Material "' + (mat.name || matIndex) + '": alpha MASK is treated as transparent (cut-off ignored)');
    }
    let texture = null;
    const texInfo = pbr.baseColorTexture;
    if (texInfo && texInfo.index != null && doc.images[texInfo.index]) {
      const tiling = [1, 1];
      const offset = [0, 0];
      const tt = texInfo.extensions && texInfo.extensions.KHR_texture_transform;
      if (tt) {
        if (Array.isArray(tt.scale)) tiling[0] = tt.scale[0] || 1, tiling[1] = tt.scale[1] || 1;
        if (Array.isArray(tt.offset)) offset[0] = tt.offset[0] || 0, offset[1] = tt.offset[1] || 0;
      }
      if (UW.textures) {
        texture = UW.textures.normalize({
          enabled: true,
          preset: 'uploaded',
          data: doc.images[texInfo.index],
          tiling,
          offset,
        });
      }
    }
    return {
      color: rgbToHex(f[0], f[1], f[2]),
      roughness: pbr.roughnessFactor != null ? pbr.roughnessFactor : 1,
      metalness: pbr.metallicFactor != null ? pbr.metallicFactor : 1,
      opacity,
      texture,
      doubleSided: mat.doubleSided === true,
    };
  }

  /* ---------------- primitive → triangle soup ---------------- */

  function buildPrimitiveGeometry(doc, modelId, meshIndex, primIndex) {
    const json = doc.json;
    const mesh = json.meshes[meshIndex];
    const prim = mesh && mesh.primitives && mesh.primitives[primIndex];
    if (!prim) throw new Error('Primitive ' + meshIndex + '/' + primIndex + ' does not exist');
    if (prim.mode != null && prim.mode !== 4) {
      doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '" primitive ' + primIndex + ': mode ' + prim.mode + ' — only triangles are supported, skipped');
      return null;
    }
    if (prim.targets && prim.targets.length) {
      doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '": morph targets are ignored');
    }
    const posIdx = prim.attributes ? prim.attributes.POSITION : null;
    if (posIdx == null) {
      doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '" primitive ' + primIndex + ' has no POSITION attribute — skipped');
      return null;
    }
    const pos = readAccessor(json, doc.buffers, posIdx);
    if (pos.numComp !== 3) throw new Error('POSITION must be VEC3');

    let N = null;
    if (prim.attributes.NORMAL != null) {
      const na = readAccessor(json, doc.buffers, prim.attributes.NORMAL);
      if (na.numComp === 3 && na.count === pos.count) N = na.data;
      else doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '": invalid NORMAL attribute — using flat normals');
    }
    let UV = null;
    if (prim.attributes.TEXCOORD_0 != null) {
      const ua = readAccessor(json, doc.buffers, prim.attributes.TEXCOORD_0);
      if (ua.numComp === 2 && ua.count === pos.count) UV = ua.data;
      else doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '": invalid TEXCOORD_0 — using planar UVs');
    }

    let idx = null;
    if (prim.indices != null) {
      const ia = readAccessor(json, doc.buffers, prim.indices);
      if (ia.numComp !== 1) throw new Error('Indices must be SCALAR');
      idx = ia.data;
    }

    const P = pos.data;
    const vertCount = pos.count;
    let triCount = idx ? idx.length / 3 : vertCount / 3;
    if (triCount < 1 || Math.floor(triCount) !== triCount) {
      doc.warnings.push('Mesh "' + (mesh.name || meshIndex) + '" primitive ' + primIndex + ' is not made of whole triangles — skipped');
      return null;
    }
    triCount = Math.floor(triCount);

    const positions = new Float32Array(triCount * 9);
    const normals = new Float32Array(triCount * 9);
    const uvs = new Float32Array(triCount * 6);

    for (let t = 0; t < triCount; t++) {
      for (let k = 0; k < 3; k++) {
        const v = idx ? idx[t * 3 + k] : t * 3 + k;
        const vo = v * 3;
        const to = (t * 3 + k) * 3;
        positions[to] = P[vo];
        positions[to + 1] = P[vo + 1];
        positions[to + 2] = P[vo + 2];
        if (N) {
          normals[to] = N[vo];
          normals[to + 1] = N[vo + 1];
          normals[to + 2] = N[vo + 2];
        }
        if (UV) {
          const uo = (t * 3 + k) * 2;
          uvs[uo] = UV[v * 2];
          uvs[uo + 1] = UV[v * 2 + 1];
        }
      }
    }

    /* flat normals when the file has none */
    if (!N) {
      for (let t = 0; t < triCount; t++) {
        const o = t * 9;
        const ax = positions[o], ay = positions[o + 1], az = positions[o + 2];
        const bx = positions[o + 3], by = positions[o + 4], bz = positions[o + 5];
        const cx = positions[o + 6], cy = positions[o + 7], cz = positions[o + 8];
        const ux = bx - ax, uy = by - ay, uz = bz - az;
        const vx = cx - ax, vy = cy - ay, vz = cz - az;
        let nx = uy * vz - uz * vy;
        let ny = uz * vx - ux * vz;
        let nz = ux * vy - uy * vx;
        const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len > 1e-12) { nx /= len; ny /= len; nz /= len; }
        else { nx = 0; ny = 1; nz = 0; }
        for (let k = 0; k < 3; k++) {
          normals[o + k * 3] = nx;
          normals[o + k * 3 + 1] = ny;
          normals[o + k * 3 + 2] = nz;
        }
      }
    }

    /* bounds */
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < positions.length; i += 3) {
      for (let a = 0; a < 3; a++) {
        const v = positions[i + a];
        if (v < min[a]) min[a] = v;
        if (v > max[a]) max[a] = v;
      }
    }

    /* planar UVs when the file has none: project on the two widest axes */
    if (!UV) {
      const ext = [max[0] - min[0], max[1] - min[1], max[2] - min[2]];
      let drop = 0;
      if (ext[1] <= ext[drop]) drop = 1;
      if (ext[2] <= ext[drop]) drop = 2;
      const a1 = drop === 0 ? 1 : 0;
      const a2 = drop === 2 ? 1 : 2;
      const s1 = Math.max(ext[a1], 1e-9);
      const s2 = Math.max(ext[a2], 1e-9);
      for (let i = 0, u = 0; i < positions.length; i += 3, u += 2) {
        uvs[u] = (positions[i + a1] - min[a1]) / s1;
        uvs[u + 1] = (positions[i + a2] - min[a2]) / s2;
      }
    }

    const mat = materialFor(doc, prim.material);
    return {
      shape: 'model',
      positions,
      normals,
      uvs,
      bounds: { min, max },
      twoSided: false,
      doubleSided: mat.doubleSided,
      triangles: triCount,
    };
  }

  /* ---------------- glTF node transforms ---------------- */

  function eulerFromMat(m) {
    // matches UW.math.mat4.compose, which builds R = Rz · Ry · Rx
    const r20 = m[2], r21 = m[6], r22 = m[10], r10 = m[1], r00 = m[0];
    const r01 = m[4], r11 = m[5];
    let x, y, z;
    if (Math.abs(r20) < 0.99999) {
      y = Math.asin(-r20);
      x = Math.atan2(r21, r22);
      z = Math.atan2(r10, r00);
    } else {
      // gimbal lock
      y = r20 > 0 ? -Math.PI / 2 : Math.PI / 2;
      x = 0;
      z = Math.atan2(-r01, r11);
    }
    const RAD = 180 / Math.PI;
    return [r4(x * RAD), r4(y * RAD), r4(z * RAD)];
  }

  function decomposeMat(m) {
    const tx = m[12], ty = m[13], tz = m[14];
    const col = (c) => [m[c * 4], m[c * 4 + 1], m[c * 4 + 2]];
    const c0 = col(0), c1 = col(1), c2 = col(2);
    const len = (v) => Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    let sx = len(c0), sy = len(c1), sz = len(c2);
    const det =
      m[0] * (m[5] * m[10] - m[6] * m[9]) -
      m[4] * (m[1] * m[10] - m[2] * m[9]) +
      m[8] * (m[1] * m[6] - m[2] * m[5]);
    if (det < 0) {
      sz = -sz;
      c2[0] = -c2[0]; c2[1] = -c2[1]; c2[2] = -c2[2];
    }
    const scale = [r5(sx), r5(sy), r5(sz)];
    const rot = [r5(tx), r5(ty), r5(tz)];
    if (sx < 1e-9 || sy < 1e-9 || Math.abs(sz) < 1e-9) {
      return { position: rot, rotation: [0, 0, 0], scale, degenerate: true };
    }
    // column-normalised pure rotation matrix (column-major, like UW.math)
    const az = Math.abs(sz);
    const r = [
      c0[0] / sx, c0[1] / sx, c0[2] / sx, 0,
      c1[0] / sy, c1[1] / sy, c1[2] / sy, 0,
      c2[0] / az, c2[1] / az, c2[2] / az, 0,
      0, 0, 0, 1,
    ];
    return { position: rot, rotation: eulerFromMat(r), scale };
  }

  function nodeTransform(g) {
    if (Array.isArray(g.matrix) && g.matrix.length === 16) {
      const d = decomposeMat(g.matrix);
      if (d.degenerate) MODELS._warnOnce('degenerate', 'A node has a degenerate (flattened) matrix — rotation may be off');
      return { position: d.position, rotation: d.rotation, scale: d.scale };
    }
    const t = g.translation || [0, 0, 0];
    const s = g.scale || [1, 1, 1];
    let rotation = [0, 0, 0];
    if (Array.isArray(g.rotation) && g.rotation.length === 4) {
      rotation = eulerFromMat(M.mat4.fromQuat(g.rotation));
    }
    return {
      position: [r5(t[0] || 0), r5(t[1] || 0), r5(t[2] || 0)],
      rotation,
      scale: [r5(s[0] == null ? 1 : s[0]), r5(s[1] == null ? 1 : s[1]), r5(s[2] == null ? 1 : s[2])],
    };
  }

  /* ---------------- document parsing ---------------- */

  function parseDocument(buffer, extras) {
    const head = new Uint8Array(buffer, 0, Math.min(12, buffer.byteLength));

    // Blender .blend (raw or gzip-compressed) and Wavefront .obj are translated
    // into the same glTF-shaped document by their own parsers, so everything
    // below (geometry, materials, images, node tree) is shared.
    const looksBlend = head[0] === 0x42 && head[1] === 0x4c && head[2] === 0x45 && head[3] === 0x4e &&
      head[4] === 0x44 && head[5] === 0x45 && head[6] === 0x52;
    const looksGzip = head[0] === 0x1f && head[1] === 0x8b;
    if (looksBlend || looksGzip) {
      if (!UW.blend || !UW.blend.parse) throw new Error('Blender .blend import is not loaded');
      const doc = UW.blend.parse(buffer);
      doc.images = extractImages(doc.json, doc.buffers, doc.warnings);
      return doc;
    }
    if (UW.obj && UW.obj.sniff && UW.obj.sniff(buffer)) {
      const doc = UW.obj.parse(buffer, extras);
      doc.images = extractImages(doc.json, doc.buffers, doc.warnings);
      return doc;
    }

    const looksGLB = head[0] === 0x67 && head[1] === 0x6c && head[2] === 0x54 && head[3] === 0x46;
    let json, bin, format;
    if (looksGLB) {
      const parsed = parseGLB(buffer);
      json = parsed.json;
      bin = parsed.bin;
      format = 'glb';
    } else {
      try {
        json = JSON.parse(new TextDecoder('utf-8').decode(buffer));
      } catch (e) {
        throw new Error('Not a valid model file (supported: .glb, .gltf, .obj, .blend)');
      }
      format = 'gltf';
    }
    if (!json || typeof json !== 'object' || !json.asset) throw new Error('Not a glTF 2.0 file (missing asset info)');
    const ver = parseFloat((json.asset.version || '2').charAt(0));
    if (ver < 2) throw new Error('Only glTF 2.0 is supported (found ' + json.asset.version + ')');

    const doc = { json, format, warnings: [] };
    doc.buffers = resolveBuffers(json, bin);
    doc.images = extractImages(json, doc.buffers, doc.warnings);
    if (json.animations && json.animations.length) doc.warnings.push('Animations are not supported — nodes keep their rest pose');
    return doc;
  }

  /* ---------------- node tree ---------------- */

  function rootIdsOf(doc) {
    const json = doc.json;
    const sceneIdx = json.scene != null ? json.scene : 0;
    let roots = [];
    if (json.scenes && json.scenes[sceneIdx] && Array.isArray(json.scenes[sceneIdx].nodes)) {
      roots = json.scenes[sceneIdx].nodes.slice();
    }
    if (!roots.length && json.nodes) {
      const childSet = new Set();
      for (const n of json.nodes) if (Array.isArray(n.children)) for (const c of n.children) childSet.add(c);
      roots = json.nodes.map((n, i) => i).filter((i) => !childSet.has(i));
    }
    return roots;
  }

  function buildNodeTree(doc, modelId, baseName) {
    const json = doc.json;
    const nodes = [];
    const container = UW.scene.makeNode({
      name: baseName,
      type: 'empty',
      // Blender files are Z-up; the parser asks for a root rotation here
      transform: doc.rootTransform || undefined,
    });
    nodes.push(container);

    if (!json.nodes || !json.nodes.length) {
      if (!json.meshes || !json.meshes.length) throw new Error('The model contains no nodes or meshes');
      // mesh-only file: one child node per mesh
      json.meshes.forEach((mesh, mi) => {
        (mesh.primitives || []).forEach((prim, pi) => {
          nodes.push(meshNode(doc, modelId, baseName + (json.meshes.length > 1 ? ' ' + (mi + 1) : ''),
            container.id, { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, mi, pi));
        });
      });
      return nodes;
    }

    const visited = new Set();
    const visit = (gi, parentId) => {
      if (visited.has(gi)) return;
      visited.add(gi);
      const g = json.nodes[gi];
      if (!g) return;
      const trs = nodeTransform(g);
      let nodeId = container.id;
      const meshRef = g.mesh != null && json.meshes[g.mesh] ? json.meshes[g.mesh] : null;
      if (meshRef && (meshRef.primitives || []).length) {
        const main = meshNode(doc, modelId, g.name || baseName, parentId, trs, g.mesh, 0);
        nodes.push(main);
        nodeId = main.id;
        for (let pi = 1; pi < meshRef.primitives.length; pi++) {
          const part = meshNode(doc, modelId, (g.name || baseName) + ' · part ' + (pi + 1), main.id,
            { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, g.mesh, pi);
          nodes.push(part);
        }
      } else {
        const n = UW.scene.makeNode({
          name: g.name || 'Node',
          parent: parentId,
          type: 'empty',
          transform: trs,
        });
        nodes.push(n);
        nodeId = n.id;
      }
      if (g.skin != null) MODELS._warnOnce('skins', 'Skins are not supported — bind-pose geometry is used');
      if (g.camera != null) MODELS._warnOnce('cameras', 'Camera nodes are ignored');
      if (g.extensions && g.extensions.KHR_lights_punctual) {
        MODELS._warnOnce('gltfLights', 'glTF light nodes are ignored');
      }
      if (Array.isArray(g.children)) for (const c of g.children) visit(c, nodeId);
    };
    for (const r of rootIdsOf(doc)) visit(r, container.id);
    return nodes;
  }

  function meshNode(doc, modelId, name, parent, trs, meshIndex, primIndex) {
    const prim = doc.json.meshes[meshIndex].primitives[primIndex];
    const mat = materialFor(doc, prim.material);
    return UW.scene.makeNode({
      name,
      parent: parent || null,
      type: 'mesh',
      transform: trs,
      mesh: {
        shape: 'model',
        modelId,
        meshIndex,
        primitiveIndex: primIndex,
        color: mat.color,
        roughness: M.clamp(mat.roughness, 0, 1),
        metalness: M.clamp(mat.metalness, 0, 1),
        wireframe: false,
        opacity: mat.opacity,
        texture: mat.texture,
      },
    });
  }

  /* ---------------- caches ---------------- */

  function cacheKey(modelId, meshIndex, primIndex) {
    return modelId + '|' + (meshIndex || 0) + '|' + (primIndex || 0);
  }

  function trimCache(map, max) {
    if (map.size <= max) return;
    let drop = map.size - Math.floor(max * 0.75);
    for (const key of map.keys()) {
      if (drop-- <= 0) break;
      map.delete(key);
    }
  }

  /* ---------------- public API ---------------- */

  MODELS.parse = parseDocument;

  function bytesDataUrl(bytes, mime) {
    if (bytes instanceof ArrayBuffer) bytes = new Uint8Array(bytes);
    return 'data:' + mime + ';base64,' + bytesToBase64(bytes);
  }

  MODELS.register = function (scene, buffer, filename, extras) {
    if (!scene) throw new Error('No scene to import into');
    extras = extras || {};
    const doc = parseDocument(buffer, extras);
    const base = (filename || 'Model')
      .replace(/\.(glb|gltf|obj|blend)$/i, '')
      .replace(/[\\/:*?"<>|]+/g, '_')
      .trim() || 'Model';
    const id = newId();

    // validate + warm every primitive so stats and engines are instant
    const stats = { meshes: 0, primitives: 0, triangles: 0 };
    for (let mi = 0; mi < (doc.json.meshes || []).length; mi++) {
      const prims = doc.json.meshes[mi].primitives || [];
      for (let pi = 0; pi < prims.length; pi++) {
        const geo = buildPrimitiveGeometry(doc, id, mi, pi);
        if (geo) {
          geoCache.set(cacheKey(id, mi, pi), geo);
          stats.primitives++;
          stats.triangles += geo.triangles;
        }
      }
      stats.meshes++;
    }
    stats.textures = doc.images.filter(Boolean).length;
    if (!stats.primitives) throw new Error('No importable triangle meshes were found in this model');

    parsedCache.set(id, doc);
    trimCache(parsedCache, 8);
    trimCache(geoCache, 24);

    const record = {
      id,
      name: base,
      format: doc.format,
      data: (doc.format === 'glb'
        ? 'data:model/gltf-binary;base64,'
        : doc.format === 'gltf'
          ? 'data:application/json;base64,'
          : 'data:application/octet-stream;base64,') + bytesToBase64(new Uint8Array(buffer)),
    };
    // OBJ imports keep their material library and textures so the model
    // survives save / reload exactly as imported
    if (doc.format === 'obj') {
      if (extras.mtl) record.mtl = bytesDataUrl(extras.mtl, 'text/plain');
      if (extras.images && typeof extras.images === 'object') {
        record.images = {};
        for (const key of Object.keys(extras.images)) {
          record.images[key] = bytesDataUrl(extras.images[key], 'application/octet-stream');
        }
      }
    }
    const nodes = buildNodeTree(doc, id, base);
    if (!scene.models) scene.models = [];
    scene.models.push(record);
    return { record, nodes, stats, warnings: doc.warnings };
  };

  MODELS.warm = function (scene) {
    const list = scene && Array.isArray(scene.models) ? scene.models : [];
    for (const rec of list) {
      if (!rec || !rec.id || typeof rec.data !== 'string' || !/^data:/i.test(rec.data)) continue;
      if (parsedCache.has(rec.id) || failedIds.has(rec.id)) continue;
      try {
        const extras = {};
        if (rec.format === 'obj') {
          if (rec.mtl) extras.mtl = dataUrlToBuffer(rec.mtl);
          if (rec.images && typeof rec.images === 'object') {
            extras.images = {};
            for (const key of Object.keys(rec.images)) extras.images[key] = dataUrlToBuffer(rec.images[key]);
          }
        }
        const doc = parseDocument(dataUrlToBuffer(rec.data), extras);
        parsedCache.set(rec.id, doc);
      } catch (e) {
        failedIds.add(rec.id);
        console.warn('[WebForge] Model "' + rec.name + '" could not be loaded: ' + (e.message || e));
      }
    }
    trimCache(parsedCache, 8);
  };

  MODELS.geometry = function (modelId, meshIndex, primIndex) {
    const key = cacheKey(modelId, meshIndex, primIndex);
    if (geoCache.has(key)) return geoCache.get(key);
    const doc = parsedCache.get(modelId);
    if (!doc) return null;
    const geo = buildPrimitiveGeometry(doc, modelId, meshIndex, primIndex);
    if (geo) {
      geoCache.set(key, geo);
      trimCache(geoCache, 24);
    }
    return geo;
  };

  MODELS.geometryFor = function (node) {
    const mesh = node && node.mesh;
    if (!mesh || mesh.shape !== 'model' || mesh.modelId == null) return null;
    const geo = MODELS.geometry(mesh.modelId, mesh.meshIndex || 0, mesh.primitiveIndex || 0);
    if (geo) return geo;
    // unknown / failed model — render a placeholder cube so the node stays usable
    return UW.geom.get('cube');
  };

  MODELS.key = function (node) {
    const mesh = node && node.mesh;
    return 'model|' + (mesh ? mesh.modelId : '?') + '|' + ((mesh && mesh.meshIndex) || 0) + '|' + ((mesh && mesh.primitiveIndex) || 0);
  };

  MODELS.record = function (scene, node) {
    const mesh = node && node.mesh;
    if (!mesh || mesh.modelId == null || !scene || !Array.isArray(scene.models)) return null;
    return scene.models.find((m) => m && m.id === mesh.modelId) || null;
  };

  MODELS.stats = { parsedCache, geoCache };

  const warnOnceSet = new Set();
  MODELS._warnOnce = function (key, message) {
    if (warnOnceSet.has(key)) return;
    warnOnceSet.add(key);
    // surface through the active editor console when possible
    const ed = UW.app && UW.app.editor;
    if (ed && ed.log) ed.log('warn', 'Import: ' + message);
  };
})();
