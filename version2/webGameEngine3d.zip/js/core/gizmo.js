/* ============================================================
   gizmo.js — move / rotate / scale handles drawn on a 2D overlay
   Handles are engine independent: all math runs against the shared
   camera matrices, then edits the scene model directly.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;
  const AXIS_COLORS = ['#e2605e', '#68bd6d', '#5b93e6'];
  const AXIS_HOVER = '#ffd166';
  const AXIS_NAMES = ['X', 'Y', 'Z'];

  UW.Gizmo = class Gizmo {
    constructor(app) {
      this.app = app;
      this.editor = app.editor;
      this.cam = app.cameraRig;
      this.canvas = document.getElementById('gizmo');
      this.ctx = this.canvas.getContext('2d');
      this.w = 1;
      this.h = 1;
      this.dpr = 1;
      this.hover = null;
      this.drag = null;
      this.size = 1;
      this.origin = [0, 0, 0];
      this.axes = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
      this.cache = null;
      this.enabled = true;
    }

    resize(w, h, dpr) {
      this.w = w;
      this.h = h;
      this.dpr = dpr;
      this.canvas.width = Math.max(1, Math.round(w * dpr));
      this.canvas.height = Math.max(1, Math.round(h * dpr));
    }

    selectedNode() {
      return this.editor.selectedNode;
    }

    worldOrigin() {
      const node = this.selectedNode();
      if (!node) return null;
      const wm = this.editor.world().get(node.id);
      return wm ? [wm[12], wm[13], wm[14]] : [0, 0, 0];
    }

    axesFor(node) {
      if (this.editor.space === 'local') {
        const wm = this.editor.world().get(node.id);
        if (wm) {
          return [
            V.norm([wm[0], wm[1], wm[2]]),
            V.norm([wm[4], wm[5], wm[6]]),
            V.norm([wm[8], wm[9], wm[10]]),
          ];
        }
      }
      return [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    }

    refreshGeometry() {
      const node = this.selectedNode();
      if (!node || this.editor.viewMode !== 'scene') {
        this.cache = null;
        this.origin = null;
        return null;
      }
      const origin = this.worldOrigin();
      if (!origin) { this.cache = null; return null; }
      const scale = this.cam.pixelScale(origin);
      const size = M.clamp(72 / Math.max(1e-4, scale), 0.18, Math.max(0.5, this.editor.camera.distance * 0.55));
      const axes = this.axesFor(node);
      const proj = this.cam.project(origin);
      this.origin = origin;
      this.axes = axes;
      this.size = size;
      this.cache = { node, origin, size, axes, proj };
      return this.cache;
    }

    /* ---------------- drawing ---------------- */
    draw() {
      const ctx = this.ctx;
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.clearRect(0, 0, this.w, this.h);
      if (!this.enabled) return;
      this.drawTriad();
      if (this.editor.viewMode !== 'scene') return;
      const cache = this.refreshGeometry();
      if (!cache) return;
      const { node, origin, size, axes, proj } = cache;
      if (!proj.visible) return;
      const tool = this.editor.tool;
      if (tool === 'select') {
        this.drawOriginDot(proj);
        return;
      }

      for (let a = 0; a < 3; a++) {
        const hovered = this.hover && this.hover.axis === a;
        const color = hovered ? AXIS_HOVER : AXIS_COLORS[a];
        if (tool === 'rotate') {
          this.drawRotateRing(origin, axes[a], size, color, hovered);
        } else {
          this.drawAxis(origin, axes[a], size, color, hovered, tool);
        }
      }

      if (tool === 'scale') {
        const hovered = this.hover && this.hover.axis === -1;
        this.drawCenterCube(proj, hovered);
      }
      this.drawOriginDot(proj);
    }

    drawAxis(origin, axis, size, color, hovered, tool) {
      const ctx = this.ctx;
      const a = this.cam.project(origin);
      const tip = this.cam.project(V.add(origin, V.scale(axis, size)));
      if (!a.visible || !tip.visible) return;
      const dx = tip.x - a.x, dy = tip.y - a.y;
      const len = Math.hypot(dx, dy);
      if (len < 6) return;

      ctx.save();
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.45)';
      ctx.lineWidth = hovered ? 6 : 5;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(tip.x, tip.y);
      ctx.stroke();

      ctx.strokeStyle = color;
      ctx.lineWidth = hovered ? 3 : 2;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(tip.x, tip.y);
      ctx.stroke();

      const ux = dx / len, uy = dy / len;
      if (tool === 'scale') {
        ctx.fillStyle = color;
        ctx.strokeStyle = 'rgba(0,0,0,.5)';
        ctx.lineWidth = 1;
        const s = hovered ? 7 : 6;
        ctx.fillRect(tip.x - s / 2, tip.y - s / 2, s, s);
        ctx.strokeRect(tip.x - s / 2, tip.y - s / 2, s, s);
      } else {
        const hw = hovered ? 6.5 : 5.5;
        const hl = hovered ? 15 : 13;
        const bx = tip.x - ux * hl, by = tip.y - uy * hl;
        ctx.fillStyle = color;
        ctx.strokeStyle = 'rgba(0,0,0,.5)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(tip.x, tip.y);
        ctx.lineTo(bx - uy * hw, by + ux * hw);
        ctx.lineTo(bx + uy * hw, by - ux * hw);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      if (hovered) {
        ctx.fillStyle = '#fff';
        ctx.font = '600 9px "Segoe UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(AXIS_NAMES[this.axes.indexOf(axis)] || '', tip.x + ux * 14, tip.y + uy * 14 + 3);
      }
      ctx.restore();
    }

    ringPoints(origin, axis, size, segments) {
      const a = V.norm(axis);
      const tmp = Math.abs(a[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
      const u = V.norm(V.cross(tmp, a));
      const v = V.cross(a, u);
      const pts = [];
      for (let i = 0; i <= segments; i++) {
        const t = (i / segments) * Math.PI * 2;
        const p = V.add(origin, V.add(V.scale(u, Math.cos(t) * size), V.scale(v, Math.sin(t) * size)));
        pts.push(this.cam.project(p));
      }
      return pts;
    }

    drawRotateRing(origin, axis, size, color, hovered) {
      const ctx = this.ctx;
      const pts = this.ringPoints(origin, axis, size, 64);
      const visible = pts.filter((p) => p.visible);
      if (visible.length < 8) return;
      ctx.save();
      ctx.lineJoin = 'round';
      const stroke = (width, style) => {
        ctx.lineWidth = width;
        ctx.strokeStyle = style;
        ctx.beginPath();
        let started = false;
        for (const p of pts) {
          if (!p.visible) { started = false; continue; }
          if (!started) { ctx.moveTo(p.x, p.y); started = true; }
          else ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      };
      stroke(hovered ? 6 : 4.5, 'rgba(0,0,0,.4)');
      stroke(hovered ? 3 : 2, color);
      ctx.restore();
    }

    drawCenterCube(p, hovered) {
      const ctx = this.ctx;
      ctx.save();
      ctx.fillStyle = hovered ? AXIS_HOVER : '#d6dbe2';
      ctx.strokeStyle = 'rgba(0,0,0,.6)';
      ctx.lineWidth = 1;
      const s = 11;
      ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      ctx.strokeRect(p.x - s / 2, p.y - s / 2, s, s);
      ctx.restore();
    }

    drawOriginDot(p) {
      const ctx = this.ctx;
      ctx.save();
      ctx.fillStyle = 'rgba(235,240,248,.9)';
      ctx.strokeStyle = 'rgba(0,0,0,.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 2.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    drawTriad() {
      const ctx = this.ctx;
      const size = 25;
      const cx = 42, cy = this.h - 66;
      const inv = M.mat4.invert(this.cam.view);
      const axes = [
        [inv[0], inv[1], inv[2]],
        [inv[4], inv[5], inv[6]],
        [inv[8], inv[9], inv[10]],
      ];
      ctx.save();
      ctx.font = '600 8.5px "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(12,15,19,.35)';
      ctx.beginPath();
      ctx.arc(cx, cy, 31, 0, Math.PI * 2);
      ctx.fill();
      const items = axes.map((a, i) => ({ x: a[0] * size, y: -a[1] * size, z: a[2], i })).sort((a, b) => a.z - b.z);
      for (const it of items) {
        ctx.strokeStyle = AXIS_COLORS[it.i];
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + it.x, cy + it.y);
        ctx.stroke();
        ctx.fillStyle = AXIS_COLORS[it.i];
        ctx.beginPath();
        ctx.arc(cx + it.x, cy + it.y, 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillText(AXIS_NAMES[it.i], cx + it.x * 1.24, cy + it.y * 1.24 + 3);
      }
      ctx.restore();
    }

    /* ---------------- hit testing ---------------- */
    hitTest(x, y) {
      if (this.editor.viewMode !== 'scene' || this.editor.tool === 'select') return null;
      const cache = this.cache || this.refreshGeometry();
      if (!cache) return null;
      const tool = this.editor.tool;
      const origin = cache.origin, size = cache.size, axes = cache.axes;
      const p = [x, y];

      if (tool === 'scale') {
        const c = this.cam.project(origin);
        if (c.visible && Math.hypot(c.x - x, c.y - y) <= 8) return { axis: -1, tool };
      }

      if (tool === 'rotate') {
        for (let a = 0; a < 3; a++) {
          const pts = this.ringPoints(origin, axes[a], size, 64);
          for (let i = 0; i < pts.length - 1; i++) {
            if (!pts[i].visible || !pts[i + 1].visible) continue;
            if (M.pointSegDist(p, [pts[i].x, pts[i].y], [pts[i + 1].x, pts[i + 1].y]) < 8) {
              return { axis: a, tool };
            }
          }
        }
        return null;
      }

      // translate / scale axis handles
      const originP = this.cam.project(origin);
      for (let a = 0; a < 3; a++) {
        const tipP = this.cam.project(V.add(origin, V.scale(axes[a], size)));
        if (!originP.visible || !tipP.visible) continue;
        if (Math.hypot(tipP.x - originP.x, tipP.y - originP.y) < 8) continue;
        if (M.pointSegDist(p, [originP.x, originP.y], [tipP.x, tipP.y]) < 9) {
          return { axis: a, tool };
        }
      }
      return null;
    }

    isHovering() {
      return !!this.hover;
    }

    updateHover(x, y) {
      const hit = this.hitTest(x, y);
      const prev = this.hover;
      this.hover = hit;
      if (JSON.stringify(prev) !== JSON.stringify(hit)) this.draw();
      return !!hit;
    }

    /* ---------------- dragging ---------------- */
    startDrag(hit, x, y) {
      const node = this.selectedNode();
      if (!node) return false;
      const cache = this.refreshGeometry();
      if (!cache) return false;
      const ray = this.cam.ray(x, y);
      this.editor.beginEdit();
      const drag = {
        node,
        axis: hit.axis,
        tool: hit.tool,
        startX: x,
        startY: y,
        initial: JSON.parse(JSON.stringify(node.transform)),
        origin: cache.origin.slice(),
        axes: cache.axes.map((a) => a.slice()),
        size: cache.size,
        t0: 0,
        angle0: 0,
        sign: 1,
      };
      if (hit.tool === 'rotate' && hit.axis >= 0) {
        const p = this.cam.project(cache.origin);
        drag.angle0 = Math.atan2(y - p.y, x - p.x);
        drag.sign = V.dot(drag.axes[hit.axis], V.norm(V.sub(this.cam.eye, cache.origin))) > 0 ? 1 : -1;
      } else if (hit.axis >= 0) {
        drag.t0 = M.closestLineParam(cache.origin, drag.axes[hit.axis], ray.origin, ray.dir);
      }
      this.drag = drag;
      return true;
    }

    moveDrag(x, y, shift) {
      const d = this.drag;
      if (!d) return;
      const node = d.node;
      node.transform.position = d.initial.position.slice();
      node.transform.rotation = d.initial.rotation.slice();
      node.transform.scale = d.initial.scale.slice();

      const parentMat = node.parent ? (this.editor.world().get(node.parent) || M.mat4.identity()) : M.mat4.identity();
      const invParent = M.mat4.invert(parentMat);

      if (d.tool === 'rotate' && d.axis >= 0) {
        const p = this.cam.project(d.origin);
        let ang = Math.atan2(y - p.y, x - p.x);
        let delta = ang - d.angle0;
        while (delta > Math.PI) delta -= Math.PI * 2;
        while (delta < -Math.PI) delta += Math.PI * 2;
        let deg = (delta * M.RAD) * d.sign;
        if (shift) deg = Math.round(deg / 15) * 15;
        node.transform.rotation[d.axis] = M.round(d.initial.rotation[d.axis] + deg, 2);
      } else if (d.tool === 'translate') {
        if (d.axis < 0) return;
        const ray = this.cam.ray(x, y);
        const t = M.closestLineParam(d.origin, d.axes[d.axis], ray.origin, ray.dir);
        const dist = t - d.t0;
        const worldDelta = V.scale(d.axes[d.axis], dist);
        const local = M.mat4.dir(invParent, worldDelta);
        node.transform.position = [
          M.round(d.initial.position[0] + local[0], 3),
          M.round(d.initial.position[1] + local[1], 3),
          M.round(d.initial.position[2] + local[2], 3),
        ];
      } else if (d.tool === 'scale') {
        if (d.axis >= 0) {
          const ray = this.cam.ray(x, y);
          const t = M.closestLineParam(d.origin, d.axes[d.axis], ray.origin, ray.dir);
          const f = Math.max(0.02, 1 + (t - d.t0) / d.size);
          node.transform.scale[d.axis] = M.round(Math.max(0.01, d.initial.scale[d.axis] * f), 3);
        } else {
          const dy = (d.startY - y) / 130;
          const f = Math.max(0.02, 1 + dy);
          node.transform.scale = d.initial.scale.map((s) => Math.round(Math.max(0.01, s * f) * 1000) / 1000);
        }
      }
      this.editor.emit('values');
      this.editor.emit('transform', node.id);
    }

    endDrag() {
      if (!this.drag) return;
      this.drag = null;
      this.editor.commitEdit(this.editor.tool === 'rotate' ? 'Rotate' : this.editor.tool === 'scale' ? 'Scale' : 'Move');
      this.editor.emit('values');
    }
  };
})();
