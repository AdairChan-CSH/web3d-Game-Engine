/* ============================================================
   textures.js — procedural + painted + uploaded texture library
   Textures live in the scene model as plain data:
     { enabled, preset, data, tiling:[x,y], offset:[x,y] }
   Every engine reads the same cached canvas, so switching
   renderers never loses a texture. Works offline.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});

  const T = (UW.textures = {});
  T.rev = 0;

  const PRESETS = [
    { id: 'checker', label: 'Checker' },
    { id: 'grid', label: 'Grid' },
    { id: 'bricks', label: 'Bricks' },
    { id: 'tiles', label: 'Tiles' },
    { id: 'noise', label: 'Noise' },
    { id: 'gradient', label: 'Gradient' },
    { id: 'stripes', label: 'Stripes' },
    { id: 'dots', label: 'Dots' },
    { id: 'wood', label: 'Wood' },
    { id: 'marble', label: 'Marble' },
  ];
  T.presets = PRESETS;

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  }

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a += 0x6d2b79f5;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  T.defaultTexture = function (preset) {
    return {
      enabled: true,
      preset: preset || 'checker',
      data: null,
      tiling: [1, 1],
      offset: [0, 0],
    };
  };

  T.normalize = function (tex) {
    if (tex === false || tex == null) return null;
    if (typeof tex !== 'object') tex = {};
    const t = {
      enabled: tex.enabled !== false,
      preset: tex.preset || 'checker',
      data: typeof tex.data === 'string' && tex.data ? tex.data : null,
      tiling: Array.isArray(tex.tiling) ? [Number(tex.tiling[0]) || 1, Number(tex.tiling[1]) || 1] : [1, 1],
      offset: Array.isArray(tex.offset) ? [Number(tex.offset[0]) || 0, Number(tex.offset[1]) || 0] : [0, 0],
    };
    t.tiling[0] = clamp(t.tiling[0], 0.05, 16);
    t.tiling[1] = clamp(t.tiling[1], 0.05, 16);
    return t;
  };

  T.signature = function (tex) {
    if (!tex) return 'none';
    const d = tex.data || '';
    return [
      tex.enabled ? 'on' : 'off',
      tex.preset || 'checker',
      (tex.tiling && tex.tiling[0]) + 'x' + (tex.tiling && tex.tiling[1]),
      (tex.offset && tex.offset[0]) + ',' + (tex.offset && tex.offset[1]),
      d ? hash(d) + ':' + d.length : 'proc',
    ].join('|');
  };

  T.isCustom = (tex) => !!(tex && tex.data);

  /* ---------------- procedural presets ---------------- */
  function paintPreset(ctx, preset, size) {
    const R = rng(1337 + preset.length * 71);
    const S = size;
    const fill = (c) => { ctx.fillStyle = c; ctx.fillRect(0, 0, S, S); };

    if (preset === 'checker') {
      const n = 8, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        ctx.fillStyle = (x + y) & 1 ? '#e9edf2' : '#3d4652';
        ctx.fillRect(x * c, y * c, c + 0.5, c + 0.5);
      }
      return;
    }
    if (preset === 'grid') {
      fill('#222a33');
      ctx.strokeStyle = 'rgba(128,196,255,.75)';
      ctx.lineWidth = Math.max(1, S / 170);
      const n = 8;
      for (let i = 0; i <= n; i++) {
        const p = (i / n) * S;
        ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, S); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(S, p); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(190,228,255,.95)'; ctx.lineWidth = Math.max(2, S / 110);
      ctx.strokeRect(1, 1, S - 2, S - 2);
      return;
    }
    if (preset === 'bricks') {
      fill('#5b4440');
      const rows = 8, bh = S / rows;
      for (let y = 0; y < rows; y++) {
        const off = y % 2 ? -S / 8 : 0;
        for (let x = -1; x < 5; x++) {
          const bx = off + x * (S / 4) + 2;
          const v = 0.82 + R() * 0.22;
          ctx.fillStyle = 'rgb(' + Math.round(150 * v) + ',' + Math.round(77 * v) + ',' + Math.round(59 * v) + ')';
          ctx.fillRect(bx, y * bh + 2, S / 4 - 4, bh - 4);
        }
      }
      return;
    }
    if (preset === 'tiles') {
      fill('#2b3036');
      const n = 4, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const v = 0.86 + R() * 0.12;
        ctx.fillStyle = 'rgb(' + Math.round(112 * v) + ',' + Math.round(132 * v) + ',' + Math.round(146 * v) + ')';
        ctx.fillRect(x * c + 3, y * c + 3, c - 6, c - 6);
        ctx.fillStyle = 'rgba(255,255,255,.10)';
        ctx.fillRect(x * c + 3, y * c + 3, c - 6, 2);
      }
      return;
    }
    if (preset === 'noise') {
      const img = ctx.createImageData(S, S);
      for (let i = 0; i < img.data.length; i += 4) {
        const v = 70 + Math.floor(R() * 150);
        img.data[i] = v;
        img.data[i + 1] = v + 4;
        img.data[i + 2] = v + 10;
        img.data[i + 3] = 255;
      }
      ctx.putImageData(img, 0, 0);
      return;
    }
    if (preset === 'gradient') {
      const g = ctx.createLinearGradient(0, 0, S, S);
      g.addColorStop(0, '#79b8ff');
      g.addColorStop(0.48, '#7f7ce0');
      g.addColorStop(1, '#ee8ab4');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, S, S);
      return;
    }
    if (preset === 'stripes') {
      fill('#27313b');
      ctx.save();
      ctx.translate(S / 2, S / 2);
      ctx.rotate(-Math.PI / 4);
      ctx.translate(-S, -S);
      const w = S / 10;
      for (let i = 0; i < 20; i++) {
        ctx.fillStyle = i % 2 ? '#dbe6f2' : '#33465c';
        ctx.fillRect(i * w, 0, w, S * 3);
      }
      ctx.restore();
      return;
    }
    if (preset === 'dots') {
      fill('#1c242d');
      const n = 6, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const cx = x * c + c / 2, cy = y * c + c / 2;
        ctx.beginPath();
        ctx.arc(cx, cy, c * 0.24, 0, Math.PI * 2);
        ctx.fillStyle = (x + y) & 1 ? '#ffd98a' : '#8fd6c0';
        ctx.fill();
      }
      return;
    }
    if (preset === 'wood') {
      fill('#6b4a2d');
      for (let y = 0; y < S; y++) {
        const v = 0.72 + Math.sin(y * 0.21) * 0.08 + Math.sin(y * 0.047 + 1.7) * 0.09 + (R() - 0.5) * 0.05;
        ctx.fillStyle = 'rgba(' + Math.round(138 * v) + ',' + Math.round(92 * v) + ',' + Math.round(52 * v) + ',.55)';
        ctx.fillRect(0, y, S, 1.4);
      }
      return;
    }
    if (preset === 'marble') {
      fill('#d8dde4');
      const img = ctx.getImageData(0, 0, S, S);
      for (let y = 0; y < S; y++) {
        for (let x = 0; x < S; x++) {
          const i = (y * S + x) * 4;
          const n = Math.sin(x * 0.035 + Math.sin(y * 0.021) * 2.2) * 0.5 + 0.5;
          const v = 170 + n * 70 + (R() - 0.5) * 18;
          img.data[i] = clamp(v + 8, 0, 255);
          img.data[i + 1] = clamp(v + 2, 0, 255);
          img.data[i + 2] = clamp(v - 4, 0, 255);
          img.data[i + 3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
      return;
    }
    paintPreset(ctx, 'checker', size);
  }

  T.paintPreset = paintPreset;

  /* ---------------- base canvas cache ---------------- */
  const baseCache = Object.create(null);
  const imageCache = Object.create(null);

  function drawPlaceholder(ctx, S) {
    ctx.fillStyle = '#3a414a';
    ctx.fillRect(0, 0, S, S);
    ctx.strokeStyle = 'rgba(255,255,255,.08)';
    ctx.lineWidth = 2;
    for (let i = -S; i < S * 2; i += 28) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + S, S);
      ctx.stroke();
    }
  }

  function loadImage(url, cb) {
    // Hashing the data URL keeps cache keys small (paintings can be hundreds
    // of KB) while still distinguishing every uploaded image.
    const key = hash(url) + ':' + url.length;
    if (imageCache[key]) {
      if (imageCache[key].ready) cb(imageCache[key].img);
      else imageCache[key].listeners.push(cb);
      return;
    }
    const rec = { ready: false, img: new Image(), listeners: [cb] };
    imageCache[key] = rec;
    rec.img.onload = () => {
      rec.ready = true;
      T.rev++;
      for (const fn of rec.listeners) {
        try { fn(rec.img); } catch (e) { /* ignore */ }
      }
      rec.listeners.length = 0;
    };
    rec.img.onerror = () => { rec.listeners.length = 0; };
    rec.img.src = url;

    const keys = Object.keys(imageCache);
    if (keys.length > 48) {
      let count = keys.length;
      for (const k of keys) {
        if (count <= 32) break;
        if (k === key || !imageCache[k].ready) continue;
        delete imageCache[k];
        count--;
      }
    }
  }

  T.getBase = function (tex) {
    const t = T.normalize(tex);
    if (!t) return null;
    // The base image only depends on its source, not on tiling/offset, so
    // those do not create duplicate canvases.
    const sig = (t.data ? hash(t.data) + ':' + t.data.length : 'proc') + '|' + t.preset;
    if (baseCache[sig]) return baseCache[sig];
    const size = 256;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!t.data) {
      paintPreset(ctx, t.preset, size);
    } else {
      drawPlaceholder(ctx, size);
      loadImage(t.data, (img) => {
        const max = 512;
        const scale = Math.min(1, max / Math.max(img.width || 1, img.height || 1));
        const w = Math.max(1, Math.round((img.width || 1) * scale));
        const h = Math.max(1, Math.round((img.height || 1) * scale));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const c2 = canvas.getContext('2d');
        c2.clearRect(0, 0, w, h);
        c2.drawImage(img, 0, 0, w, h);
        T.rev++;
      });
    }
    baseCache[sig] = canvas;
    const bkeys = Object.keys(baseCache);
    if (bkeys.length > 64) {
      for (let i = 0; i < bkeys.length - 48; i++) delete baseCache[bkeys[i]];
    }
    return canvas;
  };

  T.getImage = function (tex) {
    return T.getBase(tex);
  };

  /* ---------------- tiled canvas for the software renderer ---------------- */
  const tiledCache = Object.create(null);

  T.getTiled = function (tex) {
    const t = T.normalize(tex);
    if (!t) return null;
    const sig = T.signature(t) + '|rev' + T.rev;
    if (tiledCache[sig]) return tiledCache[sig];
    const base = T.getBase(t);
    if (!base) return null;
    const tx = clamp(t.tiling[0], 0.05, 16);
    const ty = clamp(t.tiling[1], 0.05, 16);
    const cols = clamp(Math.ceil(tx + 1), 1, 9);
    const rows = clamp(Math.ceil(ty + 1), 1, 9);
    const periodW = base.width;
    const periodH = base.height;
    const scale = Math.min(1, 2048 / (periodW * cols), 2048 / (periodH * rows));
    const pw = Math.max(1, periodW * scale);
    const ph = Math.max(1, periodH * scale);
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(pw * cols));
    canvas.height = Math.max(1, Math.round(ph * rows));
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        ctx.drawImage(base, Math.round(x * pw), Math.round(y * ph), Math.ceil(pw), Math.ceil(ph));
      }
    }
    const out = {
      canvas,
      periodW: pw,
      periodH: ph,
      repeatX: tx,
      repeatY: ty,
      offsetX: ((t.offset[0] % 1) + 1) % 1,
      offsetY: ((t.offset[1] % 1) + 1) % 1,
    };
    tiledCache[sig] = out;
    if (Object.keys(tiledCache).length > 80) {
      const keys = Object.keys(tiledCache);
      for (let i = 0; i < keys.length - 60; i++) delete tiledCache[keys[i]];
    }
    return out;
  };

  /* ---------------- previews ---------------- */
  T.makePreview = function (tex, size) {
    size = size || 56;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    const t = T.normalize(tex);
    if (!t || !t.enabled) {
      ctx.fillStyle = '#1b1e22';
      ctx.fillRect(0, 0, size, size);
      ctx.strokeStyle = '#3b424b';
      ctx.lineWidth = 1;
      ctx.strokeRect(0.5, 0.5, size - 1, size - 1);
      ctx.fillStyle = '#68717c';
      ctx.font = '9px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('no texture', size / 2, size / 2 + 3);
      return canvas;
    }
    const tiled = T.getTiled(t);
    if (tiled) ctx.drawImage(tiled.canvas, 0, 0, size, size);
    return canvas;
  };

  T.previewDataURL = function (tex, size) {
    try { return T.makePreview(tex, size).toDataURL('image/png'); } catch (e) { return ''; }
  };

  /* draw a texture into an existing 2D context (used by the painter) */
  T.drawInto = function (ctx, tex, w, h) {
    const t = T.normalize(tex);
    ctx.clearRect(0, 0, w, h);
    if (!t) {
      ctx.fillStyle = '#2a2f36';
      ctx.fillRect(0, 0, w, h);
      return;
    }
    if (t.data) {
      loadImage(t.data, (img) => {
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
      });
    } else {
      const tmp = document.createElement('canvas');
      tmp.width = 256;
      tmp.height = 256;
      paintPreset(tmp.getContext('2d'), t.preset, 256);
      ctx.drawImage(tmp, 0, 0, w, h);
    }
  };
})();
