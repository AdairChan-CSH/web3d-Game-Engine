/* ============================================================
   scene.js — scene model, defaults, transforms and serialization
   The scene is a flat list of nodes with parent links, serialized
   to plain JSON (which is also the format the plugin API speaks).
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  let seq = 1;
  const uid = () => 'n' + Date.now().toString(36).slice(-4) + (seq++).toString(36);

  const S = (UW.scene = {});

  S.uid = uid;

  S.defaultEnv = function () {
    return {
      ambient: 0.42,
      ambientColor: '#ffffff',
      showGrid: true,
      fogEnabled: false,
      fogColor: '#1d2025',
      fogNear: 14,
      fogFar: 70,
    };
  };

  S.makeNode = function (partial) {
    const n = {
      id: uid(),
      name: 'GameObject',
      parent: null,
      type: 'empty',
      visible: true,
      tag: '',
      active: true,
      transform: {
        position: [0, 0, 0],
        rotation: [0, 0, 0],
        scale: [1, 1, 1],
      },
      behaviors: [],
    };
    if (partial) {
      // never let an explicitly-undefined field clobber a default
      // (e.g. makeNode({ transform: undefined }) keeps the identity transform)
      for (const key of Object.keys(partial)) {
        if (partial[key] !== undefined) n[key] = partial[key];
      }
      if (partial.transform) {
        n.transform = {
          position: (partial.transform.position || [0, 0, 0]).slice(),
          rotation: (partial.transform.rotation || [0, 0, 0]).slice(),
          scale: (partial.transform.scale || [1, 1, 1]).slice(),
        };
      }
    }
    n.behaviors = n.behaviors || [];
    return n;
  };

  S.createNode = function (kind, opts = {}) {
    const base = {
      name: opts.name || 'GameObject',
      parent: opts.parent || null,
      transform: {
        position: (opts.position || [0, 0, 0]).slice(),
        rotation: (opts.rotation || [0, 0, 0]).slice(),
        scale: (opts.scale || [1, 1, 1]).slice(),
      },
    };
    if (opts.id) base.id = opts.id;

    if (kind === 'light' || kind === 'light.directional' || kind === 'light.point' || kind === 'light.spot') {
      const spot = kind === 'light.spot';
      const point = kind === 'light.point';
      base.type = 'light';
      base.name = opts.name || (spot ? 'Spot Light' : point ? 'Point Light' : 'Directional Light');
      base.light = {
        kind: spot ? 'spot' : point ? 'point' : 'directional',
        color: opts.color || (spot ? '#fff2d6' : point ? '#ffd7a0' : '#fff4e2'),
        intensity: spot ? 1.7 : point ? 1.4 : 1.05,
        range: spot ? 18 : 14,
        angle: 38,
        penumbra: 0.35,
      };
      return S.makeNode(base);
    }

    if (kind === 'camera') {
      base.type = 'camera';
      base.name = opts.name || 'Main Camera';
      base.camera = { fov: 55, near: 0.1, far: 600, bg: '#1d2025' };
      return S.makeNode(base);
    }

    if (kind === 'empty') {
      base.type = 'empty';
      base.name = opts.name || 'Empty';
      return S.makeNode(base);
    }

    base.type = 'mesh';
    base.name = opts.name || UW.geom.shapeLabel(kind);
    base.mesh = {
      shape: kind,
      color: opts.color || '#c9ced6',
      roughness: opts.roughness != null ? opts.roughness : 0.6,
      metalness: opts.metalness != null ? opts.metalness : 0.08,
      wireframe: false,
      opacity: 1,
      texture: null,
    };
    return S.makeNode(base);
  };

  S.defaultScene = function () {
    const ground = S.createNode('plane', {
      id: 'n_ground',
      name: 'Ground',
      position: [0, 0, 0],
      scale: [26, 1, 26],
    });
    ground.mesh.color = '#343941';
    ground.mesh.roughness = 0.95;
    ground.mesh.metalness = 0;

    const cube = S.createNode('cube', {
      id: 'n_cube',
      name: 'Cube',
      position: [0, 0.5, 0],
    });
    cube.mesh.color = '#c7cdd6';
    cube.rigidbody = { mass: 1, useGravity: true, restitution: 0.25 };

    const sphere = S.createNode('sphere', {
      id: 'n_sphere',
      name: 'Sphere',
      position: [-2.4, 0.5, 1.55],
    });
    sphere.mesh.color = '#5b9bd5';
    sphere.mesh.roughness = 0.3;
    sphere.mesh.metalness = 0.35;
    sphere.behaviors.push({ id: uid(), kind: 'spin', params: { x: 0, y: 55, z: 0 } });

    const cylinder = S.createNode('cylinder', {
      id: 'n_cylinder',
      name: 'Falling Cylinder',
      position: [2.4, 2.6, 1.45],
    });
    cylinder.mesh.color = '#d9a441';
    cylinder.mesh.metalness = 0.45;
    cylinder.mesh.roughness = 0.35;
    cylinder.rigidbody = { mass: 1.4, useGravity: true, restitution: 0.42 };

    const torus = S.createNode('torus', {
      id: 'n_torus',
      name: 'Torus',
      position: [1.7, 0.16, -1.7],
      rotation: [0, 0, 0],
      scale: [0.9, 0.9, 0.9],
    });
    torus.mesh.color = '#9d86e0';
    torus.mesh.metalness = 0.3;

    const light = S.createNode('light.directional', {
      id: 'n_light',
      name: 'Directional Light',
      position: [4, 6, 4],
      rotation: [52, -34, 0],
    });

    const camera = S.createNode('camera', {
      id: 'n_camera',
      name: 'Main Camera',
      position: [0, 1.9, 7.4],
    });

    return {
      version: 1,
      name: 'Sample Scene',
      env: S.defaultEnv(),
      nodes: [light, camera, ground, cube, sphere, cylinder, torus],
    };
  };

  S.emptyScene = function () {
    return {
      version: 1,
      name: 'Untitled Scene',
      env: S.defaultEnv(),
      nodes: [S.createNode('camera', { name: 'Main Camera', position: [0, 1.9, 7.4] }), S.createNode('light.directional')],
    };
  };

  S.find = (scene, id) => scene.nodes.find((n) => n.id === id) || null;

  /* Effective "is this object on" map: a node is inactive when it or any
     ancestor has active === false (Unity GameObject semantics). */
  S.activeMap = function (scene) {
    const map = new Map();
    const kids = new Map();
    for (const n of scene.nodes) {
      const p = n.parent || '__root__';
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p).push(n);
    }
    const walk = (parentId, parentActive) => {
      for (const n of kids.get(parentId) || []) {
        const active = parentActive && n.active !== false;
        map.set(n.id, active);
        walk(n.id, active);
      }
    };
    walk('__root__', true);
    return map;
  };

  S.isActive = function (scene, node) {
    let n = node;
    let guard = 0;
    while (n && guard++ < 64) {
      if (n.active === false) return false;
      n = n.parent ? S.find(scene, n.parent) : null;
    }
    return true;
  };

  /* First active object carrying the given tag (case-insensitive, trimmed).
     Like Unity's FindGameObjectWithTag, inactive objects are skipped. */
  S.findByTag = function (scene, tag) {
    const key = String(tag == null ? '' : tag).trim().toLowerCase();
    if (!key) return null;
    const active = S.activeMap(scene);
    return scene.nodes.find((n) =>
      String(n.tag == null ? '' : n.tag).trim().toLowerCase() === key && active.get(n.id) !== false
    ) || null;
  };

  S.children = (scene, parentId) => scene.nodes.filter((n) => (n.parent || null) === (parentId || null));

  S.descendants = function (scene, id) {
    const out = [];
    const walk = (pid) => {
      for (const c of scene.nodes) {
        if ((c.parent || null) === pid) {
          out.push(c);
          walk(c.id);
        }
      }
    };
    walk(id);
    return out;
  };

  S.path = function (scene, id) {
    const out = [];
    let n = S.find(scene, id);
    let guard = 0;
    while (n && guard++ < 64) {
      out.unshift(n);
      n = n.parent ? S.find(scene, n.parent) : null;
    }
    return out;
  };

  S.localMatrix = (node) => M.mat4.compose(node.transform.position, node.transform.rotation, node.transform.scale);

  S.worldMatrices = function (scene) {
    const map = new Map();
    const kids = new Map();
    for (const n of scene.nodes) {
      const p = n.parent || '__root__';
      if (!kids.has(p)) kids.set(p, []);
      kids.get(p).push(n);
    }
    const walk = (parentId, parentMat) => {
      const list = kids.get(parentId) || [];
      for (const n of list) {
        const world = M.mat4.mul(parentMat, S.localMatrix(n));
        map.set(n.id, world);
        walk(n.id, world);
      }
    };
    walk('__root__', M.mat4.identity());
    return map;
  };

  S.bounds = function (node) {
    if (node.type === 'mesh') return UW.geom.forNode(node).bounds;
    if (node.type === 'light') return { min: [-0.18, -0.18, -0.18], max: [0.18, 0.18, 0.18] };
    if (node.type === 'camera') return { min: [-0.22, -0.22, -0.22], max: [0.22, 0.22, 0.22] };
    return { min: [-0.25, -0.25, -0.25], max: [0.25, 0.25, 0.25] };
  };

  S.worldBounds = function (node, worldMat) {
    const b = S.bounds(node);
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < 8; i++) {
      const p = [
        i & 1 ? b.max[0] : b.min[0],
        i & 2 ? b.max[1] : b.min[1],
        i & 4 ? b.max[2] : b.min[2],
      ];
      const w = M.mat4.point(worldMat, p);
      for (let a = 0; a < 3; a++) {
        if (w[a] < min[a]) min[a] = w[a];
        if (w[a] > max[a]) max[a] = w[a];
      }
    }
    return { min, max, center: [(min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2] };
  };

  S.icon = function (node) {
    if (node.type === 'light') return 'i-light';
    if (node.type === 'camera') return 'i-camera';
    if (node.type === 'mesh') {
      const s = node.mesh.shape;
      if (s === 'sphere' || s === 'torus' || s === 'capsule') return 'i-sphere';
      if (s === 'plane') return 'i-grid';
      return 'i-cube';
    }
    return 'i-cube';
  };

  S.cloneSubtree = function (scene, id) {
    const root = S.find(scene, id);
    if (!root) return null;
    const idMap = new Map();
    const nodes = [root, ...S.descendants(scene, id)];
    const clones = nodes.map((n) => {
      const c = JSON.parse(JSON.stringify(n));
      c.id = uid();
      idMap.set(n.id, c.id);
      return c;
    });
    clones.forEach((c) => {
      if (c.parent && idMap.has(c.parent)) c.parent = idMap.get(c.parent);
      else if (c.id !== clones[0].id) c.parent = clones[0].id;
    });
    clones[0].parent = root.parent || null;
    clones[0].name = root.name + ' (1)';
    clones[0].transform.position = clones[0].transform.position.slice();
    clones[0].transform.position[0] += 0.6;
    clones[0].transform.position[2] += 0.6;
    return { root: clones[0], nodes: clones };
  };

  S.normalize = function (scene) {
    if (!scene || !Array.isArray(scene.nodes)) throw new Error('Not a valid scene file');
    scene.version = 1;
    const env = Object.assign(S.defaultEnv(), scene.env || {});
    env.ambient = Number.isFinite(+env.ambient) ? M.clamp(+env.ambient, 0, 2) : 0.42;
    env.ambientColor = /^#[0-9a-f]{6}$/i.test(env.ambientColor || '') ? env.ambientColor : '#ffffff';
    env.showGrid = env.showGrid !== false;
    env.fogEnabled = env.fogEnabled === true;
    env.fogColor = /^#[0-9a-f]{6}$/i.test(env.fogColor || '') ? env.fogColor : '#1d2025';
    env.fogNear = Number.isFinite(+env.fogNear) ? Math.max(0, +env.fogNear) : 14;
    env.fogFar = Number.isFinite(+env.fogFar) ? Math.max(env.fogNear + 0.1, +env.fogFar) : 70;
    env.fogNear = Math.min(env.fogNear, env.fogFar - 0.1);
    scene.env = env;
    scene.nodes = scene.nodes.map((n) => {
      const node = S.makeNode(n);
      if (!node.transform) node.transform = { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] };
      node.transform.position = node.transform.position || [0, 0, 0];
      node.transform.rotation = node.transform.rotation || [0, 0, 0];
      node.transform.scale = node.transform.scale || [1, 1, 1];
      node.visible = node.visible !== false;
      node.tag = typeof node.tag === 'string' ? node.tag.trim ? node.tag : '' : '';
      node.active = node.active !== false;
      node.behaviors = node.behaviors || [];
      if (node.type === 'mesh' && !node.mesh) node.mesh = { shape: 'cube', color: '#c9ced6', roughness: .6, metalness: .08, opacity: 1 };
      if (node.mesh) {
        node.mesh.shape = node.mesh.shape || 'cube';
        node.mesh.color = node.mesh.color || '#c9ced6';
        node.mesh.roughness = node.mesh.roughness != null ? node.mesh.roughness : .6;
        node.mesh.metalness = node.mesh.metalness != null ? node.mesh.metalness : .08;
        node.mesh.opacity = node.mesh.opacity != null ? node.mesh.opacity : 1;
        node.mesh.texture = UW.textures ? UW.textures.normalize(node.mesh.texture) : (node.mesh.texture || null);
        if (node.mesh.shape === 'model') {
          node.mesh.modelId = node.mesh.modelId != null ? node.mesh.modelId : null;
          node.mesh.meshIndex = Math.max(0, node.mesh.meshIndex | 0);
          node.mesh.primitiveIndex = Math.max(0, node.mesh.primitiveIndex | 0);
        }
      }
      if (node.type === 'light' && node.light) {
        const kinds = ['directional', 'point', 'spot'];
        if (kinds.indexOf(node.light.kind) < 0) node.light.kind = 'directional';
        node.light.color = node.light.color || '#fff4e2';
        node.light.intensity = node.light.intensity != null ? node.light.intensity : 1;
        node.light.range = node.light.range != null ? node.light.range : 14;
        node.light.angle = node.light.angle != null ? node.light.angle : 38;
        node.light.penumbra = node.light.penumbra != null ? node.light.penumbra : 0.35;
      }
      if (node.fsm && UW.FSM) {
        const fsm = UW.FSM.normalize(node.fsm);
        if (fsm) node.fsm = fsm;
        else delete node.fsm;
      }
      return node;
    });
    // repair dangling parent links
    const ids = new Set(scene.nodes.map((n) => n.id));
    scene.nodes.forEach((n) => {
      if (n.parent && !ids.has(n.parent)) n.parent = null;
    });
    // imported models: keep valid records and warm the parser cache
    scene.models = Array.isArray(scene.models)
      ? scene.models.filter((m) => m && typeof m.id === 'string' && m.id && typeof m.data === 'string' && /^data:/i.test(m.data))
      : [];
    if (UW.models && scene.models.length) {
      try { UW.models.warm(scene); } catch (e) { console.warn('[WebForge] Model cache warm-up failed: ' + (e.message || e)); }
    }
    return scene;
  };

  S.uniqueName = function (scene, base, excludeId) {
    const names = new Set(
      scene.nodes.filter((n) => n.id !== excludeId).map((n) => n.name)
    );
    if (!names.has(base)) return base;
    let i = 1;
    while (names.has(base + ' (' + i + ')')) i++;
    return base + ' (' + i + ')';
  };

  S.stats = function (scene) {
    let tris = 0;
    const active = S.activeMap(scene);
    for (const n of scene.nodes) {
      if (!n.visible || active.get(n.id) === false || n.type !== 'mesh') continue;
      tris += UW.geom.forNode(n).positions.length / 9;
    }
    return { objects: scene.nodes.length, triangles: tris, models: (scene.models || []).length };
  };
})();
