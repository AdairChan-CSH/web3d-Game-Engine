/* ============================================================
   modeldoc.js — shared builder for "glTF-shaped" model docs
   The OBJ and Blender translators convert their formats into
   this common document shape (a synthetic binary buffer +
   accessors + materials + node tree in glTF 2.0 JSON form), so
   UW.models' whole pipeline — geometry building, materials,
   embedded images, node tree, caches, all engines — is reused
   without any engine-specific code.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const DOC = (UW.modeldoc = {});

  const TYPE_NAMES = { 1: 'SCALAR', 2: 'VEC2', 3: 'VEC3', 4: 'VEC4' };

  DOC.sniffImageMime = function (bytes) {
    if (!bytes || bytes.length < 4) return null;
    if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png';
    if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
    if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) return 'image/webp';
    if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) return 'image/gif';
    if (bytes[0] === 0x42 && bytes[1] === 0x4d) return 'image/bmp';
    return null;
  };

  /* builds a fresh document; call finish() at the end */
  DOC.create = function (generator) {
    const chunks = [];
    let byteLength = 0;
    const bufferViews = [];
    const accessors = [];
    const images = [];
    const materials = [];
    const meshes = [];
    const nodes = [];
    const warnings = [];
    let rootIndices = [];

    function addView(bytes, align) {
      align = align || 4;
      const pad = (align - (byteLength % align)) % align;
      if (pad) {
        chunks.push(new Uint8Array(pad));
        byteLength += pad;
      }
      const view = { buffer: 0, byteOffset: byteLength, byteLength: bytes.byteLength };
      chunks.push(new Uint8Array(bytes)); // copy (source may alias another buffer)
      byteLength += bytes.byteLength;
      bufferViews.push(view);
      return bufferViews.length - 1;
    }

    function addAccessor(view, componentType, count, type) {
      const acc = { bufferView: view, componentType, count, type };
      accessors.push(acc);
      return accessors.length - 1;
    }

    function addFloats(arr, numComp) {
      if (!arr || !arr.length) throw new Error('Empty float array cannot be added to the model');
      const view = addView(new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength), 4);
      return addAccessor(view, 5126, Math.floor(arr.length / numComp), TYPE_NAMES[numComp] || 'SCALAR');
    }

    function addIndices(arr) {
      if (!arr || !arr.length) throw new Error('Empty index array cannot be added to the model');
      const view = addView(new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength), 4);
      return addAccessor(view, 5125, arr.length, 'SCALAR');
    }

    function addImage(bytes) {
      const mime = DOC.sniffImageMime(bytes);
      if (!mime) {
        warnings.push('An image file was not PNG / JPEG / WebP / GIF / BMP — skipped');
        return null;
      }
      const view = addView(bytes, 1);
      images.push({ bufferView: view, mimeType: mime });
      return images.length - 1;
    }

    /* spec: { name, color:[r,g,b] 0..1, opacity, roughness, metalness,
               image: imageIndex|null, doubleSided } */
    function addMaterial(spec) {
      spec = spec || {};
      const c = spec.color || [0.78, 0.78, 0.78];
      const opacity = spec.opacity != null ? spec.opacity : 1;
      const mat = {
        name: spec.name || 'Material ' + (materials.length + 1),
        pbrMetallicRoughness: {
          baseColorFactor: [c[0], c[1], c[2], opacity],
          metallicFactor: spec.metalness != null ? spec.metalness : 0.05,
          roughnessFactor: spec.roughness != null ? spec.roughness : 0.8,
        },
      };
      if (spec.image != null) mat.pbrMetallicRoughness.baseColorTexture = { index: spec.image };
      if (opacity < 1) mat.alphaMode = 'BLEND';
      if (spec.doubleSided) mat.doubleSided = true;
      materials.push(mat);
      return materials.length - 1;
    }

    /* primitive: { positions:F32(3n), normals?:F32(3n), uvs?:F32(2n),
                     indices?:U32|null, material?: index|null } */
    function addMesh(name, primitives) {
      const prims = [];
      for (const p of primitives) {
        if (!p || !p.positions || !p.positions.length) continue;
        const out = { mode: 4, attributes: { POSITION: addFloats(p.positions, 3) } };
        if (p.normals && p.normals.length === p.positions.length) {
          out.attributes.NORMAL = addFloats(p.normals, 3);
        }
        if (p.uvs && p.uvs.length === (p.positions.length / 3) * 2) {
          out.attributes.TEXCOORD_0 = addFloats(p.uvs, 2);
        }
        if (p.indices && p.indices.length) out.indices = addIndices(p.indices);
        if (p.material != null) out.material = p.material;
        prims.push(out);
      }
      if (!prims.length) return null;
      meshes.push({ name: name || 'Mesh ' + (meshes.length + 1), primitives: prims });
      return meshes.length - 1;
    }

    /* specs: [{ name, matrix?:[16], mesh?: idx, children?: [...] }] */
    function setTree(specs) {
      nodes.length = 0;
      rootIndices = [];
      const emit = (spec) => {
        const n = { name: spec.name || 'Node' };
        if (Array.isArray(spec.matrix) && spec.matrix.length === 16) n.matrix = spec.matrix.slice();
        if (spec.mesh != null) n.mesh = spec.mesh;
        const idx = nodes.length;
        nodes.push(n);
        if (Array.isArray(spec.children) && spec.children.length) {
          n.children = spec.children.map(emit);
        }
        return idx;
      };
      rootIndices = (specs || []).map(emit);
    }

    function finish(opts) {
      const buffer = new ArrayBuffer(byteLength || 4);
      const out8 = new Uint8Array(buffer);
      let p = 0;
      for (const c of chunks) {
        out8.set(c, p);
        p += c.byteLength;
      }
      const json = {
        asset: { version: '2.0', generator: generator || 'WebForge model import' },
        scene: 0,
        scenes: [{ nodes: rootIndices.slice() }],
        nodes,
        meshes,
      };
      if (materials.length) json.materials = materials;
      if (images.length) json.images = images;
      if (bufferViews.length) json.bufferViews = bufferViews;
      if (accessors.length) json.accessors = accessors;
      const doc = { json, buffers: [buffer], warnings, format: (opts && opts.format) || 'obj' };
      if (opts && opts.rootTransform) doc.rootTransform = opts.rootTransform;
      return doc;
    }

    return { addFloats, addIndices, addImage, addMaterial, addMesh, setTree, finish, warnings };
  };
})();
