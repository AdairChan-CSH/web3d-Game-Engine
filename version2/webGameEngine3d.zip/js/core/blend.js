/* ============================================================
   blend.js — Blender .blend import (written from scratch)
   Reads the file's own DNA (self-describing struct catalogue)
   to locate Mesh, Object, Material and CustomData data across
   Blender versions (2.63 MPoly/MLoop era, older MFace era and
   the 4.x "position / .corner_vert / .face_offsets" attribute
   era). Supports both endiannesses, 32/64-bit builds and
   gzip-compressed saves (own DEFLATE inflater, no libraries).

   Coordinate note: Blender is Z-up; this editor is Y-up (like
   glTF/Unity), so the imported root gets a -90° X rotation and
   every object keeps its exact Blender local transform.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const BLEND = (UW.blend = {});

  const IDENTITY = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];

  /* ---------------- DEFLATE / gzip ---------------- */

  const LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
  const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
  const DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
  const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];

  function buildHuff(lengths) {
    const counts = new Array(16).fill(0);
    let total = 0;
    for (const l of lengths) if (l) { counts[l]++; total++; }
    if (!total) return null;
    const offs = new Array(17).fill(0);
    for (let i = 1; i <= 15; i++) offs[i + 1] = offs[i] + counts[i];
    const next = offs.slice(0, 16);
    const symbols = new Array(total);
    for (let s = 0; s < lengths.length; s++) {
      const l = lengths[s];
      if (l) symbols[next[l]++] = s;
    }
    return { counts, symbols };
  }

  function inflateRaw(src) {
    let pos = 0;
    let bitBuf = 0;
    let bitCnt = 0;
    function bits(n) {
      while (bitCnt < n) {
        if (pos >= src.length) throw new Error('Unexpected end of compressed data');
        bitBuf |= src[pos++] << bitCnt;
        bitCnt += 8;
      }
      const v = bitBuf & ((1 << n) - 1);
      bitBuf >>>= n;
      bitCnt -= n;
      return v;
    }
    function decodeSym(h) {
      let code = 0;
      let first = 0;
      let index = 0;
      for (let len = 1; len <= 15; len++) {
        code |= bits(1);
        const count = h.counts[len] || 0;
        if (code - first < count) return h.symbols[index + (code - first)];
        index += count;
        first = (first + count) << 1;
        code <<= 1;
      }
      throw new Error('Bad Huffman code in compressed data');
    }

    let out = new Uint8Array(Math.max(1024, src.length * 3));
    let outLen = 0;
    function ensure(n) {
      if (outLen + n <= out.length) return;
      let cap = out.length * 2;
      while (cap < outLen + n) cap *= 2;
      const bigger = new Uint8Array(cap);
      bigger.set(out.subarray(0, outLen));
      out = bigger;
    }

    const fixedLit = buildHuff((function () {
      const l = new Array(288).fill(8);
      for (let i = 144; i < 256; i++) l[i] = 9;
      for (let i = 256; i < 280; i++) l[i] = 7;
      return l;
    })());
    const fixedDist = buildHuff(new Array(30).fill(5));

    let final;
    do {
      final = bits(1);
      const type = bits(2);
      if (type === 0) {
        // stored block: discard remaining bits to the byte boundary
        bitBuf = 0;
        bitCnt = 0;
        if (pos + 4 > src.length) throw new Error('Bad stored block');
        const len = src[pos] | (src[pos + 1] << 8);
        pos += 4;
        if (pos + len > src.length) throw new Error('Bad stored block');
        ensure(len);
        out.set(src.subarray(pos, pos + len), outLen);
        outLen += len;
        pos += len;
      } else if (type === 1 || type === 2) {
        let lit = fixedLit;
        let dist = fixedDist;
        if (type === 2) {
          const hlit = bits(5) + 257;
          const hdist = bits(5) + 1;
          const hclen = bits(4) + 4;
          const order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
          const cl = new Array(19).fill(0);
          for (let i = 0; i < hclen; i++) cl[order[i]] = bits(3);
          const clHuff = buildHuff(cl);
          if (!clHuff) throw new Error('Bad deflate code lengths');
          const lengths = [];
          while (lengths.length < hlit + hdist) {
            const sym = decodeSym(clHuff);
            if (sym < 16) lengths.push(sym);
            else if (sym === 16) {
              const prev = lengths.length ? lengths[lengths.length - 1] : 0;
              const rep = 3 + bits(2);
              for (let r = 0; r < rep; r++) lengths.push(prev);
            } else if (sym === 17) {
              const rep = 3 + bits(3);
              for (let r = 0; r < rep; r++) lengths.push(0);
            } else {
              const rep = 11 + bits(7);
              for (let r = 0; r < rep; r++) lengths.push(0);
            }
          }
          if (lengths.length > hlit + hdist) lengths.length = hlit + hdist;
          lit = buildHuff(lengths.slice(0, hlit));
          dist = buildHuff(lengths.slice(hlit));
        }
        if (!lit || !dist) throw new Error('Bad deflate tables');
        for (;;) {
          const sym = decodeSym(lit);
          if (sym === 256) break;
          if (sym < 256) {
            ensure(1);
            out[outLen++] = sym;
          } else {
            const li = sym - 257;
            if (li >= LEN_BASE.length) throw new Error('Bad deflate length code');
            const len = LEN_BASE[li] + bits(LEN_EXTRA[li]);
            const dsym = decodeSym(dist);
            if (dsym >= DIST_BASE.length) throw new Error('Bad deflate distance code');
            const d = DIST_BASE[dsym] + bits(DIST_EXTRA[dsym]);
            if (d > outLen) throw new Error('Compressed data references before its start');
            ensure(len);
            let from = outLen - d;
            for (let i = 0; i < len; i++) out[outLen++] = out[from++];
          }
        }
      } else {
        throw new Error('Unsupported deflate block type');
      }
    } while (!final);
    return out.subarray(0, outLen);
  }

  function inflateGzip(bytes) {
    if (bytes.length < 18 || bytes[0] !== 0x1f || bytes[1] !== 0x8b) throw new Error('Not a gzip file');
    if (bytes[2] !== 8) throw new Error('Unsupported gzip compression method ' + bytes[2]);
    const flg = bytes[3];
    let p = 10;
    if (flg & 4) { // FEXTRA
      const xlen = bytes[p] | (bytes[p + 1] << 8);
      p += 2 + xlen;
    }
    if (flg & 8) { while (p < bytes.length && bytes[p]) p++; p++; } // FNAME
    if (flg & 16) { while (p < bytes.length && bytes[p]) p++; p++; } // FCOMMENT
    if (flg & 2) p += 2; // FHCRC
    return inflateRaw(bytes.subarray(p));
  }

  /* ---------------- 4x4 matrix helpers (column-major) ---------------- */

  function mul4(a, b) {
    const out = new Array(16);
    for (let c = 0; c < 4; c++) {
      for (let r = 0; r < 4; r++) {
        out[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
    }
    return out;
  }

  function invert4(m) {
    const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3];
    const a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7];
    const a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11];
    const a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15];
    const b00 = a00 * a11 - a01 * a10;
    const b01 = a00 * a12 - a02 * a10;
    const b02 = a00 * a13 - a03 * a10;
    const b03 = a01 * a12 - a02 * a11;
    const b04 = a01 * a13 - a03 * a11;
    const b05 = a02 * a13 - a03 * a12;
    const b06 = a20 * a31 - a21 * a30;
    const b07 = a20 * a32 - a22 * a30;
    const b08 = a20 * a33 - a23 * a30;
    const b09 = a21 * a32 - a22 * a31;
    const b10 = a21 * a33 - a23 * a31;
    const b11 = a22 * a33 - a23 * a32;
    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    if (!det) return null;
    det = 1 / det;
    return [
      (a11 * b11 - a12 * b10 + a13 * b09) * det,
      (a02 * b10 - a01 * b11 - a03 * b09) * det,
      (a31 * b05 - a32 * b04 + a33 * b03) * det,
      (a22 * b04 - a21 * b05 - a23 * b03) * det,
      (a12 * b08 - a10 * b11 - a13 * b07) * det,
      (a00 * b11 - a02 * b08 + a03 * b07) * det,
      (a32 * b02 - a30 * b05 - a33 * b01) * det,
      (a20 * b05 - a22 * b02 + a23 * b01) * det,
      (a10 * b10 - a11 * b08 + a13 * b06) * det,
      (a01 * b08 - a00 * b10 - a03 * b06) * det,
      (a30 * b04 - a31 * b02 + a33 * b00) * det,
      (a21 * b02 - a20 * b04 - a23 * b00) * det,
      (a11 * b07 - a10 * b09 - a12 * b06) * det,
      (a00 * b09 - a01 * b07 + a02 * b06) * det,
      (a31 * b01 - a30 * b03 - a32 * b00) * det,
      (a20 * b03 - a21 * b01 + a22 * b00) * det,
    ];
  }

  /* ---------------- parser ---------------- */

  BLEND.parse = function (buffer) {
    let bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    if (bytes.length > 2 && bytes[0] === 0x1f && bytes[1] === 0x8b) {
      bytes = inflateGzip(bytes);
    }
    if (bytes.length < 16) throw new Error('File is too small to be a Blender file');
    const headAt = (i) => String.fromCharCode(bytes[i]);
    if (headAt(0) !== 'B' || headAt(1) !== 'L' || headAt(2) !== 'E' || headAt(3) !== 'N' ||
        headAt(4) !== 'D' || headAt(5) !== 'E' || headAt(6) !== 'R') {
      throw new Error('Not a Blender .blend file (missing BLENDER header)');
    }
    const ptrChar = headAt(7);
    const ptrSize = ptrChar === '_' ? 4 : ptrChar === '-' ? 8 : 0;
    if (!ptrSize) throw new Error('Unknown Blender pointer size "' + ptrChar + '"');
    const endChar = headAt(8);
    if (endChar !== 'v' && endChar !== 'V') throw new Error('Unknown Blender endianness "' + endChar + '"');
    const little = endChar === 'v';
    const version = parseInt(headAt(9) + headAt(10) + headAt(11), 10) || 0;
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

    const readPtr = (at) => {
      if (ptrSize === 4) return dv.getUint32(at, little);
      if (typeof dv.getBigUint64 === 'function') return Number(dv.getBigUint64(at, little));
      const lo = dv.getUint32(at, little);
      const hi = dv.getUint32(at + 4, little);
      return hi * 4294967296 + lo;
    };
    const i32At = (at) => dv.getInt32(at, little);
    const u32At = (at) => dv.getUint32(at, little);
    const i16At = (at) => dv.getInt16(at, little);
    const f32At = (at) => dv.getFloat32(at, little);
    const strMax = (at, max) => {
      let s = '';
      for (let i = 0; i < max && at + i < bytes.length; i++) {
        const c = bytes[at + i];
        if (!c) break;
        s += String.fromCharCode(c);
      }
      return s;
    };

    /* ---- file blocks ---- */
    const headerSize = 16 + ptrSize;
    const blocks = [];
    let dnaBlock = null;
    let off = 12;
    while (off + headerSize <= bytes.length) {
      const code = strMax(off, 4).replace(/\0+/g, '');
      const size = dv.getUint32(off + 4, little);
      const address = readPtr(off + 8);
      const sdna = dv.getUint32(off + 8 + ptrSize, little);
      const count = dv.getUint32(off + 12 + ptrSize, little);
      if (code === 'ENDB') break;
      if (size > bytes.length) break; // corrupt guard
      const block = { code, address, sdna, count, size, dataStart: off + headerSize };
      blocks.push(block);
      if (code === 'DNA1') dnaBlock = block;
      off = block.dataStart + size;
    }
    if (!dnaBlock) throw new Error('This .blend file has no DNA block and cannot be read');

    const blockByAddr = new Map();
    for (const b of blocks) {
      if (b.address && !blockByAddr.has(b.address)) blockByAddr.set(b.address, b);
    }

    /* ---- DNA1: names, types, type lengths, structs ---- */
    let p = dnaBlock.dataStart + 4; // skip 'SDNA'
    const expect = (tag) => {
      const got = strMax(p, 4);
      if (got !== tag) throw new Error('Corrupt DNA: expected ' + tag + ' but found "' + got + '"');
      p += 4;
    };
    const readStrings = (count) => {
      const list = [];
      for (let i = 0; i < count; i++) {
        const s = strMax(p, 512);
        list.push(s);
        p += s.length + 1;
      }
      return list;
    };
    const skipPad = () => { while (p < bytes.length && bytes[p] === 0) p++; };

    expect('NAME');
    const nameCount = dv.getUint32(p, little); p += 4;
    const names = readStrings(nameCount);
    skipPad();
    expect('TYPE');
    const typeCount = dv.getUint32(p, little); p += 4;
    const types = readStrings(typeCount);
    skipPad();
    expect('TLEN');
    const typeLen = new Array(typeCount);
    for (let i = 0; i < typeCount; i++) { typeLen[i] = dv.getUint16(p, little); p += 2; }
    skipPad();
    expect('STRC');
    const structCount = dv.getUint32(p, little); p += 4;
    const structs = new Array(structCount);
    const structByTypeIdx = new Map();
    for (let s = 0; s < structCount; s++) {
      const typeIdx = dv.getUint16(p, little); p += 2;
      const fieldCount = dv.getUint16(p, little); p += 2;
      const fields = new Array(fieldCount);
      for (let f = 0; f < fieldCount; f++) {
        const fType = dv.getUint16(p, little); p += 2;
        const fName = dv.getUint16(p, little); p += 2;
        fields[f] = { typeIdx: fType, typeName: types[fType] || '?', name: names[fName] || '?' };
      }
      const st = { index: s, typeIdx, name: types[typeIdx] || '?', size: typeLen[typeIdx] || 0, fields };
      structs[s] = st;
      if (!structByTypeIdx.has(typeIdx)) structByTypeIdx.set(typeIdx, st);
    }
    const structByName = new Map();
    for (const st of structs) if (!structByName.has(st.name)) structByName.set(st.name, st);

    /* ---- field offsets: try C-style natural alignment, then fully packed,
            and pick per struct whichever matches the file's own size table ---- */
    function computeLayouts(aligned) {
      const layouts = new Map(); // typeIdx → { size, align, fields: Map(key→field) }
      const alignCache = new Map();
      const structAlignOf = (typeIdx) => {
        if (alignCache.has(typeIdx)) return alignCache.get(typeIdx);
        let a = 1;
        const lay = layoutOf(typeIdx);
        if (lay) a = lay.align || 1;
        alignCache.set(typeIdx, a);
        return a;
      };
      const layoutOf = (typeIdx) => {
        if (layouts.has(typeIdx)) return layouts.get(typeIdx);
        const st = structByTypeIdx.get(typeIdx);
        if (!st) return null;
        layouts.set(typeIdx, null); // cycle guard (never happens in valid DNA)
        let cursor = 0;
        let maxAlign = 1;
        const fields = new Map();
        for (const f of st.fields) {
          const raw = f.name;
          const isPointer = raw[0] === '*' || (raw[0] === '(' && raw[1] === '*');
          const dims = [];
          const dm = raw.match(/\[\d+\]/g);
          if (dm) for (const d of dm) dims.push(parseInt(d.slice(1, -1), 10));
          const elemCount = dims.length ? dims.reduce((a, b) => a * b, 1) : 1;
          const elemSize = isPointer ? ptrSize : (typeLen[f.typeIdx] || 1);
          let key = raw.replace(/\[[^\]]*\]/g, '');
          if (key[0] === '(') key = key.replace(/^\(\*/, '').replace(/\(.*/, '');
          else key = key.replace(/^\*+/, '');
          key = key.replace(/:.*/, '').trim() || raw;
          let align = 1;
          if (aligned) {
            if (isPointer) align = ptrSize;
            else if (structByTypeIdx.has(f.typeIdx)) align = structAlignOf(f.typeIdx);
            else align = Math.max(1, Math.min(elemSize, 8));
          }
          const offset = (cursor + align - 1) & ~(align - 1);
          fields.set(key, { key, offset, elemCount, elemSize, isPointer, typeIdx: f.typeIdx });
          cursor = offset + elemCount * elemSize;
          if (align > maxAlign) maxAlign = align;
        }
        const size = aligned ? (cursor + maxAlign - 1) & ~(maxAlign - 1) : cursor;
        const lay = { size, align: maxAlign, fields };
        layouts.set(typeIdx, lay);
        return lay;
      };
      for (const st of structs) layoutOf(st.typeIdx);
      return layouts;
    }

    let alignedLayouts = computeLayouts(true);
    let packedLayouts = computeLayouts(false);
    const layoutScore = (l) => {
      let good = 0;
      for (const st of structs) {
        const lay = l.get(st.typeIdx);
        if (lay && lay.size === st.size) good++;
      }
      return good;
    };
    const useAligned = layoutScore(alignedLayouts) >= layoutScore(packedLayouts);
    const primary = useAligned ? alignedLayouts : packedLayouts;
    const fallbackLayouts = useAligned ? packedLayouts : alignedLayouts;
    const layoutOf = (name) => {
      const st = structByName.get(name);
      if (!st) return null;
      const lay = primary.get(st.typeIdx);
      if (lay && lay.size === st.size) return lay;
      const alt = fallbackLayouts.get(st.typeIdx);
      if (alt && alt.size === st.size) return alt;
      return lay || alt;
    };
    const fieldOf = (structName, key) => {
      const lay = layoutOf(structName);
      return lay ? lay.fields.get(key) || null : null;
    };
    const structSize = (name) => {
      const st = structByName.get(name);
      return st ? st.size : 0;
    };
    const structNameOfBlock = (b) => {
      const st = b && b.sdna != null ? structs[b.sdna] : null;
      return st ? st.name : null;
    };

    const doc = UW.modeldoc.create('WebForge Blender import');
    const warn = (msg) => { if (doc.warnings.indexOf(msg) < 0) doc.warnings.push(msg); };

    /* ---- materials ---- */

    function materialInfo(maBlock) {
      const rF = fieldOf('Material', 'r');
      const gF = fieldOf('Material', 'g');
      const bF = fieldOf('Material', 'b');
      if (!rF || !gF || !bF) return null;
      const s = maBlock.dataStart;
      let name = '';
      const idF = fieldOf('Material', 'id');
      const nameF = idF ? fieldOf('ID', 'name') : null;
      if (idF && nameF) name = strMax(s + idF.offset + nameF.offset, 66).slice(2);
      const color = [f32At(s + rF.offset), f32At(s + gF.offset), f32At(s + bF.offset)];
      return { name, color };
    }

    const matIndexCache = new Map();
    function docMaterial(info) {
      if (!info) return null;
      const key = info.name + '|' + info.color.join(',');
      if (matIndexCache.has(key)) return matIndexCache.get(key);
      const idx = doc.addMaterial({
        name: info.name || 'Blender material',
        color: info.color,
        roughness: 0.85,
        metalness: 0,
      });
      matIndexCache.set(key, idx);
      return idx;
    }

    /* ---- mesh extraction ---- */

    function customDataLayersAt(at, structName) {
      const layersF = fieldOf(structName, 'layers');
      const totF = fieldOf(structName, 'totlayer');
      if (!layersF || !totF) return [];
      const tot = i32At(at + totF.offset);
      if (tot <= 0) return [];
      const arrBlock = blockByAddr.get(readPtr(at + layersF.offset));
      if (!arrBlock) return [];
      const layerSize = structSize('CustomDataLayer');
      if (!layerSize) return [];
      const nameF = fieldOf('CustomDataLayer', 'name');
      const dataF = fieldOf('CustomDataLayer', 'data');
      const typeF = fieldOf('CustomDataLayer', 'type');
      if (!nameF || !dataF) return [];
      const out = [];
      const count = Math.min(tot, Math.floor(arrBlock.size / layerSize) || tot);
      for (let i = 0; i < count; i++) {
        const ls = arrBlock.dataStart + i * layerSize;
        const dataBlock = blockByAddr.get(readPtr(ls + dataF.offset));
        out.push({
          name: strMax(ls + nameF.offset, 64),
          type: typeF ? i32At(ls + typeF.offset) : -1,
          block: dataBlock,
        });
      }
      return out;
    }

    function readMVertArray(block) {
      const stride = structSize('MVert') || 20;
      const coF = fieldOf('MVert', 'co');
      const noF = fieldOf('MVert', 'no');
      if (!coF) return null;
      const count = Math.min(block.count || 0, Math.floor(block.size / stride));
      if (!count) return null;
      const positions = new Float32Array(count * 3);
      let normals = noF ? new Float32Array(count * 3) : null;
      let nz = 0;
      for (let i = 0; i < count; i++) {
        const b = block.dataStart + i * stride;
        positions[i * 3] = f32At(b + coF.offset);
        positions[i * 3 + 1] = f32At(b + coF.offset + 4);
        positions[i * 3 + 2] = f32At(b + coF.offset + 8);
        if (normals) {
          const nb = b + noF.offset;
          const nx = i16At(nb), ny = i16At(nb + 2), nzz = i16At(nb + 4);
          if (nx || ny || nzz) nz++;
          normals[i * 3] = nx / 32767;
          normals[i * 3 + 1] = ny / 32767;
          normals[i * 3 + 2] = nzz / 32767;
        }
      }
      if (normals && !nz) normals = null;
      return { positions, normals, count };
    }

    function readMesh(meBlock) {
      const s = meBlock.dataStart;
      const intField = (keys) => {
        for (const k of keys) {
          const f = fieldOf('Mesh', k);
          if (f) {
            const v = i32At(s + f.offset);
            if (v > 0) return v;
          }
        }
        return -1;
      };
      const totvertHint = intField(['totvert', 'verts_num']);
      const totloopHint = intField(['totloop', 'corners_num']);
      const totpolyHint = intField(['totpoly', 'faces_num', 'totface']);

      const meshName = (function () {
        const idF = fieldOf('Mesh', 'id');
        const nameF = idF ? fieldOf('ID', 'name') : null;
        return idF && nameF ? strMax(s + idF.offset + nameF.offset, 66).slice(2) : '';
      })();

      /* positions + vertex normals */
      let vInfo = null;
      const mvertF = fieldOf('Mesh', 'mvert');
      if (mvertF) {
        const b = blockByAddr.get(readPtr(s + mvertF.offset));
        if (b && structNameOfBlock(b) === 'MVert') vInfo = readMVertArray(b);
      }
      if (!vInfo) {
        const vdataF = fieldOf('Mesh', 'vdata');
        const layers = vdataF ? customDataLayersAt(s + vdataF.offset, 'CustomData') : [];
        for (const ly of layers) {
          if (!ly.block) continue;
          if (structNameOfBlock(ly.block) === 'MVert') { vInfo = readMVertArray(ly.block); if (vInfo) break; }
        }
        if (!vInfo) {
          for (const ly of layers) {
            if (ly.name === 'position' && ly.block) {
              const n = Math.min(Math.floor(ly.block.size / 12), totvertHint > 0 ? totvertHint : Infinity);
              if (n > 0) {
                const positions = new Float32Array(n * 3);
                for (let i = 0; i < n * 3; i++) positions[i] = f32At(ly.block.dataStart + i * 4);
                vInfo = { positions, normals: null, count: n };
                break;
              }
            }
          }
        }
      }
      if (!vInfo) throw new Error('Mesh "' + (meshName || '?') + '" has no readable vertex data');

      /* loop → vertex indices */
      let cornerVerts = null;
      let loopCount = 0;
      const mloopF = fieldOf('Mesh', 'mloop');
      if (mloopF) {
        const b = blockByAddr.get(readPtr(s + mloopF.offset));
        if (b && structNameOfBlock(b) === 'MLoop') {
          const stride = structSize('MLoop') || 8;
          const vF = fieldOf('MLoop', 'v');
          if (vF) {
            const count = Math.min(b.count || 0, Math.floor(b.size / stride));
            if (count > 0) {
              cornerVerts = new Uint32Array(count);
              loopCount = count;
              for (let i = 0; i < count; i++) cornerVerts[i] = u32At(b.dataStart + i * stride + vF.offset);
            }
          }
        }
      }
      if (!cornerVerts) {
        const ldataF = fieldOf('Mesh', 'ldata');
        const layers = ldataF ? customDataLayersAt(s + ldataF.offset, 'CustomData') : [];
        for (const ly of layers) {
          if (!ly.block) continue;
          if (structNameOfBlock(ly.block) === 'MLoop') {
            const stride = structSize('MLoop') || 8;
            const vF = fieldOf('MLoop', 'v');
            if (!vF) continue;
            const count = Math.min(ly.block.count || 0, Math.floor(ly.block.size / stride));
            if (count > 0) {
              cornerVerts = new Uint32Array(count);
              loopCount = count;
              for (let i = 0; i < count; i++) cornerVerts[i] = u32At(ly.block.dataStart + i * stride + vF.offset);
            }
            break;
          }
        }
        if (!cornerVerts) {
          for (const ly of layers) {
            if (ly.name === '.corner_vert' && ly.block) {
              const n = Math.min(Math.floor(ly.block.size / 4), totloopHint > 0 ? totloopHint : Infinity);
              if (n > 0) {
                cornerVerts = new Uint32Array(n);
                loopCount = n;
                for (let i = 0; i < n; i++) cornerVerts[i] = u32At(ly.block.dataStart + i * 4);
                break;
              }
            }
          }
        }
      }

      /* UVs (Blender UV origin is bottom-left; flip to this editor's top-left) */
      let loopUV = null;
      if (loopCount) {
        const mloopuvF = fieldOf('Mesh', 'mloopuv');
        if (mloopuvF) {
          const b = blockByAddr.get(readPtr(s + mloopuvF.offset));
          if (b && structNameOfBlock(b) === 'MLoopUV') loopUV = readMLoopUVArray(b, loopCount);
        }
        if (!loopUV) {
          const ldataF = fieldOf('Mesh', 'ldata');
          const layers = ldataF ? customDataLayersAt(s + ldataF.offset, 'CustomData') : [];
          for (const ly of layers) {
            if (!ly.block) continue;
            if (structNameOfBlock(ly.block) === 'MLoopUV') { loopUV = readMLoopUVArray(ly.block, loopCount); if (loopUV) break; }
          }
          if (!loopUV) {
            for (const ly of layers) {
              if (ly.block && Math.floor(ly.block.size / 8) >= loopCount && /^(uv|UV)/.test(ly.name)) {
                const uvs = new Float32Array(loopCount * 2);
                for (let i = 0; i < loopCount; i++) {
                  const b = ly.block.dataStart + i * 8;
                  uvs[i * 2] = f32At(b);
                  uvs[i * 2 + 1] = 1 - f32At(b + 4);
                }
                loopUV = uvs;
                break;
              }
            }
          }
        }
      }

      /* materials attached to this mesh */
      const matRefs = [];
      const matF = fieldOf('Mesh', 'mat');
      const totcolF = fieldOf('Mesh', 'totcol');
      if (matF && totcolF) {
        const arr = blockByAddr.get(readPtr(s + matF.offset));
        const tot = i32At(s + totcolF.offset);
        if (arr && tot > 0) {
          for (let i = 0; i < tot; i++) {
            const maBlock = blockByAddr.get(readPtr(arr.dataStart + i * ptrSize));
            matRefs.push(maBlock ? materialInfo(maBlock) : null);
          }
        }
      }
      const matFor = (matNr) => {
        if (matNr == null || matNr < 0 || matNr >= matRefs.length) return null;
        return docMaterial(matRefs[matNr]);
      };

      /* faces */
      const faces = []; // {ls, tl, mat}
      let ngonSeen = false;
      if (cornerVerts) {
        const mpolyF = fieldOf('Mesh', 'mpoly');
        let polyList = null;
        if (mpolyF) {
          const b = blockByAddr.get(readPtr(s + mpolyF.offset));
          if (b && structNameOfBlock(b) === 'MPoly') polyList = readMPolyArray(b);
        }
        if (!polyList) {
          const pdataF = fieldOf('Mesh', 'pdata');
          const layers = pdataF ? customDataLayersAt(s + pdataF.offset, 'CustomData') : [];
          for (const ly of layers) {
            if (ly.block && structNameOfBlock(ly.block) === 'MPoly') { polyList = readMPolyArray(ly.block); if (polyList) break; }
          }
          if (!polyList) {
            for (const ly of layers) {
              if ((ly.name === '.face_offsets' || ly.name === 'face_offset_indices') && ly.block) {
                const n = Math.floor(ly.block.size / 4);
                if (n > 1) {
                  const offs = new Array(n);
                  for (let i = 0; i < n; i++) offs[i] = u32At(ly.block.dataStart + i * 4);
                  polyList = [];
                  for (let i = 0; i + 1 < n; i++) {
                    if (offs[i + 1] > offs[i]) polyList.push({ ls: offs[i], tl: offs[i + 1] - offs[i], mat: 0 });
                  }
                }
                break;
              }
            }
          }
        }
        if (polyList) {
          // 4.x keeps the material index in a ".material_index" attribute layer
          let matIndexLayer = null;
          if (polyList.length) {
            const pdataF = fieldOf('Mesh', 'pdata');
            const layers = pdataF ? customDataLayersAt(s + pdataF.offset, 'CustomData') : [];
            for (const ly of layers) {
              if (ly.name === '.material_index' && ly.block) {
                const per = ly.block.size / polyList.length;
                if (per === 2 || per === 4 || per === 1) matIndexLayer = { block: ly.block, per };
                break;
              }
            }
          }
          for (let i = 0; i < polyList.length; i++) {
            const f = polyList[i];
            if (matIndexLayer) {
              const at = matIndexLayer.block.dataStart + i * matIndexLayer.per;
              f.mat = matIndexLayer.per === 2 ? i16At(at) : matIndexLayer.per === 4 ? i32At(at) : (bytes[at] << 8 >> 8);
            }
            faces.push(f);
          }
        }
      }
      if (!faces.length) {
        // pre-2.63 MFace era: quads/triangles only
        const fdataF = fieldOf('Mesh', 'fdata');
        const layers = fdataF ? customDataLayersAt(s + fdataF.offset, 'CustomData') : [];
        for (const ly of layers) {
          if (!ly.block || structNameOfBlock(ly.block) !== 'MFace') continue;
          const stride = structSize('MFace') || 20;
          const g = (key) => fieldOf('MFace', key);
          const f1 = g('v1'), f2 = g('v2'), f3 = g('v3'), f4 = g('v4'), mn = g('mat_nr');
          if (!f1 || !f2 || !f3) continue;
          const count = Math.min(ly.block.count || 0, Math.floor(ly.block.size / stride));
          for (let i = 0; i < count; i++) {
            const b = ly.block.dataStart + i * stride;
            const v1 = u32At(b + f1.offset);
            const v2 = u32At(b + f2.offset);
            const v3 = u32At(b + f3.offset);
            const v4 = f4 ? u32At(b + f4.offset) : 0;
            const mat = mn ? i16At(b + mn.offset) : 0;
            faces.push({ ls: -1, tri: [v1, v2, v3], mat });
            if (v4) faces.push({ ls: -1, tri: [v1, v3, v4], mat });
          }
          break;
        }
        if (!faces.length) throw new Error('Mesh "' + (meshName || '?') + '" has no readable face data');
        if (version && version >= 263) warn('Old-style face data found in this file — export with Blender 2.63+ for UV support');
        const byMat = new Map();
        for (const f of faces) {
          if (f.tri.some((v) => v >= vInfo.count)) continue;
          if (!byMat.has(f.mat)) byMat.set(f.mat, []);
          byMat.get(f.mat).push(f.tri[0], f.tri[1], f.tri[2]);
        }
        const prims = [];
        for (const [matNr, idx] of byMat) {
          prims.push({
            positions: vInfo.positions,
            normals: vInfo.normals,
            uvs: null,
            indices: new Uint32Array(idx),
            material: matFor(matNr),
          });
        }
        if (!prims.length) throw new Error('Mesh "' + (meshName || '?') + '" produced no triangles');
        return { name: meshName, index: doc.addMesh(meshName, prims) };
      }

      /* polygon era: fan-triangulate loops, split per material */
      const byMat = new Map();
      let dropped = 0;
      for (const f of faces) {
        const n = f.tl;
        if (n == null || n < 3) continue;
        if (f.ls < 0 || f.ls + n > loopCount) { dropped++; continue; }
        if (n > 4) ngonSeen = true;
        for (let k = 1; k + 1 < n; k++) {
          const l0 = f.ls, l1 = f.ls + k, l2 = f.ls + k + 1;
          if (cornerVerts[l0] >= vInfo.count || cornerVerts[l1] >= vInfo.count || cornerVerts[l2] >= vInfo.count) { dropped++; continue; }
          const mat = f.mat || 0;
          if (!byMat.has(mat)) byMat.set(mat, []);
          byMat.get(mat).push(l0, l1, l2);
        }
      }
      if (dropped > 4) warn(dropped + ' corrupt faces were skipped');
      if (ngonSeen) warn('N-gons were fan-triangulated (Blender 4.x triangulates differently)');

      const positions = new Float32Array(loopCount * 3);
      const normals = vInfo.normals ? new Float32Array(loopCount * 3) : null;
      const uvs = loopUV ? new Float32Array(loopCount * 2) : null;
      for (let l = 0; l < loopCount; l++) {
        const v = cornerVerts[l] < vInfo.count ? cornerVerts[l] : 0;
        positions[l * 3] = vInfo.positions[v * 3];
        positions[l * 3 + 1] = vInfo.positions[v * 3 + 1];
        positions[l * 3 + 2] = vInfo.positions[v * 3 + 2];
        if (normals) {
          normals[l * 3] = vInfo.normals[v * 3];
          normals[l * 3 + 1] = vInfo.normals[v * 3 + 1];
          normals[l * 3 + 2] = vInfo.normals[v * 3 + 2];
        }
        if (uvs) {
          uvs[l * 2] = loopUV[l * 2];
          uvs[l * 2 + 1] = loopUV[l * 2 + 1];
        }
      }
      const prims = [];
      for (const [matNr, idx] of byMat) {
        prims.push({
          positions,
          normals,
          uvs,
          indices: new Uint32Array(idx),
          material: matFor(matNr),
        });
      }
      if (!prims.length) throw new Error('Mesh "' + (meshName || '?') + '" produced no triangles');
      return { name: meshName, index: doc.addMesh(meshName, prims) };
    }

    function readMLoopUVArray(block, loopCount) {
      const stride = structSize('MLoopUV') || 12;
      const uvF = fieldOf('MLoopUV', 'uv');
      if (!uvF) return null;
      const count = Math.min(block.count || 0, Math.floor(block.size / stride), loopCount);
      if (!count) return null;
      const uvs = new Float32Array(loopCount * 2);
      for (let i = 0; i < count; i++) {
        const b = block.dataStart + i * stride + uvF.offset;
        uvs[i * 2] = f32At(b);
        uvs[i * 2 + 1] = 1 - f32At(b + 4);
      }
      return uvs;
    }

    function readMPolyArray(block) {
      const stride = structSize('MPoly') || 12;
      const lsF = fieldOf('MPoly', 'loopstart');
      const tlF = fieldOf('MPoly', 'totloop');
      const mnF = fieldOf('MPoly', 'mat_nr');
      if (!lsF || !tlF) return null;
      const count = Math.min(block.count || 0, Math.floor(block.size / stride));
      if (!count) return null;
      const out = new Array(count);
      for (let i = 0; i < count; i++) {
        const b = block.dataStart + i * stride;
        out[i] = { ls: i32At(b + lsF.offset), tl: i32At(b + tlF.offset), mat: mnF ? i16At(b + mnF.offset) : 0 };
      }
      return out;
    }

    /* ---- objects ---- */

    const OB_EMPTY = 0;
    const OB_MESH = 1;

    const meshIndexByAddr = new Map();
    const meshNameByAddr = new Map();
    let meshFailed = 0;
    for (const b of blocks) {
      if (b.code !== 'ME' || structNameOfBlock(b) !== 'Mesh') continue;
      try {
        const m = readMesh(b);
        if (m && m.index != null) {
          meshIndexByAddr.set(b.address, m.index);
          meshNameByAddr.set(b.address, m.name);
        }
      } catch (e) {
        meshFailed++;
        if (meshFailed <= 3) warn('Could not read mesh: ' + (e.message || e));
      }
    }

    const objList = [];
    let skippedTypes = 0;
    for (const b of blocks) {
      if (b.code !== 'OB' || structNameOfBlock(b) !== 'Object') continue;
      const s = b.dataStart;
      const idF = fieldOf('Object', 'id');
      const nameF = idF ? fieldOf('ID', 'name') : null;
      const typeF = fieldOf('Object', 'type');
      const parentF = fieldOf('Object', 'parent');
      const dataF = fieldOf('Object', 'data');
      const obmatF = fieldOf('Object', 'obmat');
      if (!typeF) continue;
      const name = idF && nameF ? strMax(s + idF.offset + nameF.offset, 66).slice(2) : 'Object';
      const type = i16At(s + typeF.offset);
      if (type !== OB_MESH && type !== OB_EMPTY) { skippedTypes++; continue; }
      let world = null;
      if (obmatF) {
        const m = new Array(16);
        let allZero = true;
        for (let i = 0; i < 16; i++) {
          m[i] = f32At(s + obmatF.offset + i * 4);
          if (m[i] !== 0) allZero = false;
        }
        // Blender's obmat bytes map 1:1 onto this editor's column-major matrices
        if (!allZero) world = m;
      }
      objList.push({
        address: b.address,
        name,
        isMesh: type === OB_MESH,
        parentAddr: parentF ? readPtr(s + parentF.offset) : 0,
        dataAddr: dataF ? readPtr(s + dataF.offset) : 0,
        world,
      });
    }
    if (skippedTypes) warn(skippedTypes + ' non-mesh objects (curves, lattices, lights…) were skipped');
    if (meshFailed) warn(meshFailed + ' mesh block(s) could not be read');

    const objByAddr = new Map();
    for (const o of objList) objByAddr.set(o.address, o);
    const specByAddr = new Map();
    const inProgress = new Set();
    const treeRoots = [];
    const ensureObj = (o) => {
      const existing = specByAddr.get(o.address);
      if (existing) return existing;
      if (inProgress.has(o.address)) return null;
      inProgress.add(o.address);
      let parentSpec = null;
      const parent = o.parentAddr ? objByAddr.get(o.parentAddr) : null;
      if (parent) parentSpec = ensureObj(parent);
      let local = o.world;
      if (parentSpec && parent && parent.world && o.world) {
        const inv = invert4(parent.world);
        if (inv) local = mul4(inv, o.world);
      }
      if (!local) {
        local = IDENTITY.slice();
        warn('Object "' + o.name + '" has no valid transform — imported at the origin');
      }
      const meshIndex = o.isMesh && meshIndexByAddr.has(o.dataAddr) ? meshIndexByAddr.get(o.dataAddr) : null;
      if (o.isMesh && meshIndex == null && !meshFailed) {
        warn('Object "' + o.name + '" references an unreadable mesh — imported as an empty');
      }
      const spec = { name: o.name, matrix: local, children: [] };
      if (meshIndex != null) spec.mesh = meshIndex;
      specByAddr.set(o.address, spec);
      inProgress.delete(o.address);
      (parentSpec ? parentSpec.children : treeRoots).push(spec);
      return spec;
    };
    for (const o of objList) ensureObj(o);

    if (!treeRoots.length) {
      if (!meshIndexByAddr.size) throw new Error('No importable triangle meshes were found in this .blend file');
      for (const addr of meshIndexByAddr.keys()) {
        treeRoots.push({ name: meshNameByAddr.get(addr) || 'Mesh', mesh: meshIndexByAddr.get(addr), children: [] });
      }
    }

    doc.setTree(treeRoots);
    return doc.finish({
      format: 'blend',
      // Blender is Z-up, this editor is Y-up: rotate the root -90° about X.
      rootTransform: { position: [0, 0, 0], rotation: [-90, 0, 0], scale: [1, 1, 1] },
    });
  };
})();
