/* ============================================================
   fsm.js — PlayMaker-style visual finite state machine
   Each scene node may own an FSM:
     { enabled, start, states[], transitions[], variables[] }
   States run an ordered list of actions when entered. Transitions
   fire on delay, event, key, key edge or variable condition.
   The runtime in runtime.js drives these objects; the graph UI in
   ui/graph.js edits them.

   Every action only touches the shared scene model or the shared
   runtime, never a renderer, so an FSM behaves identically on
   Three.js, Babylon.js, Native Canvas and third-party engines.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const F = (UW.FSM = {});

  let seq = 1;
  const uid = (p) => (p || 'fsm') + Date.now().toString(36).slice(-4) + (seq++).toString(36);

  /* ---------------- metadata helpers ---------------- */
  const CATEGORIES = [
    { id: 'flow', label: 'Flow' },
    { id: 'scene', label: 'Scene & Flow' },
    { id: 'transform', label: 'Transform' },
    { id: 'variables', label: 'Variables & Math' },
    { id: 'string', label: 'String & Text' },
    { id: 'logic', label: 'Logic & Scene' },
    { id: 'gameobject', label: 'GameObject' },
    { id: 'material', label: 'Material & Texture' },
    { id: 'light', label: 'Lighting' },
    { id: 'camera', label: 'Camera' },
    { id: 'physics', label: 'Physics' },
    { id: 'network', label: 'Network & PHP' },
    { id: 'audio', label: 'Audio' },
    { id: 'debug', label: 'Debug & UI' },
  ];

  const EASINGS = [
    { value: 'linear', label: 'Linear' },
    { value: 'easeIn', label: 'Ease in' },
    { value: 'easeOut', label: 'Ease out' },
    { value: 'easeInOut', label: 'Ease in / out' },
  ];
  const PRESETS = (UW.textures && UW.textures.presets ? UW.textures.presets : [{ id: 'checker', label: 'Checker' }])
    .map((p) => ({ value: p.id, label: p.label }));

  const text = (key, label, def, placeholder, help) => ({ key, label, type: 'text', def, placeholder, help });
  const num = (key, label, def, step, min, max, help) => ({ key, label, type: 'number', def, step, min, max, help });
  const bool = (key, label, def, help) => ({ key, label, type: 'bool', def, help });
  const color = (key, label, def, help) => ({ key, label, type: 'color', def, help });
  const select = (key, label, options, def, help) => ({ key, label, type: 'select', options, def, help });
  const target = () => text('target', 'Target', 'self', 'self / name / id', 'Leave as “self” to affect this object.');
  const duration = () => num('duration', 'Duration', 1, 0.1, 0, 3600, 'Seconds. Use 0 for an instant change.');
  const easing = () => select('easing', 'Easing', EASINGS, 'easeInOut');
  const waitFinish = () => bool('wait', 'Wait for finish', true, 'Hold the remaining actions until the tween completes.');

  const ACTION_TYPES = [
    /* ---------------- flow ---------------- */
    { id: 'log', category: 'flow', label: 'Log message', help: 'Write a line to the editor Console.', params: [
      text('message', 'Message', 'State entered'),
      select('level', 'Level', [{ value: 'info', label: 'Info' }, { value: 'warn', label: 'Warning' }, { value: 'error', label: 'Error' }], 'info'),
    ] },
    { id: 'wait', category: 'flow', label: 'Wait', help: 'Pause the following actions for a number of seconds.', params: [
      num('seconds', 'Seconds', 1, 0.1, 0.01, 3600),
    ] },
    { id: 'sendEvent', category: 'flow', label: 'Send event', help: 'Broadcast an FSM event to every state machine on the scene.', params: [
      text('event', 'Event', 'done'),
    ] },
    { id: 'startFsm', category: 'flow', label: 'Start FSM', help: 'Start another object’s FSM at its start state.', params: [
      target(),
    ] },
    { id: 'stopFsm', category: 'flow', label: 'Stop FSM', help: 'Stop another object’s FSM and cancel its pending actions.', params: [
      target(),
    ] },
    { id: 'restartFsm', category: 'flow', label: 'Restart FSM', help: 'Restart another object’s FSM from its start state.', params: [
      target(),
    ] },
    { id: 'enableFsm', category: 'flow', label: 'Enable / disable FSM', help: 'Toggle another object’s FSM component at runtime.', params: [
      target(),
      bool('enabled', 'Enabled', true),
    ] },

    /* ---------------- scene transitions ---------------- */
    { id: 'loadScene', category: 'scene', label: 'Go to scene', help: 'Replace the running scene with another scene saved in browser storage.', params: [
      text('name', 'Scene', 'Level 2', 'saved scene name'),
      bool('keepPlaying', 'Continue playing', true, 'Enter play mode in the new scene immediately.'),
    ] },
    { id: 'loadSceneUrl', category: 'scene', label: 'Go to scene URL', help: 'Download a scene JSON file (for example from a PHP endpoint) and open it.', params: [
      text('url', 'URL', 'https://example.com/scene.php', 'absolute URL'),
      select('method', 'Method', [{ value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' }], 'GET'),
      text('body', 'Body', '', 'sent with POST'),
      text('headers', 'Headers', '', 'one “Name: value” per line'),
      bool('wait', 'Wait for download', true),
      bool('keepPlaying', 'Continue playing', true),
    ] },
    { id: 'restartScene', category: 'scene', label: 'Restart scene', help: 'Reload the scene that was active when Play started, keeping play mode running.', params: [] },
    { id: 'saveSceneAs', category: 'scene', label: 'Save scene as', help: 'Store the current scene in browser storage under a name (useful before switching scenes).', params: [
      text('name', 'Name', 'Checkpoint', 'saved scene name'),
    ] },
    { id: 'exitPlay', category: 'scene', label: 'Exit to editor', help: 'Stop play mode and restore the scene to its pre-play state.', params: [] },

    /* ---------------- transform ---------------- */
    { id: 'move', category: 'transform', label: 'Move (relative)', help: 'Add a one-off offset to local position.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'rotate', category: 'transform', label: 'Rotate (relative)', help: 'Add a one-off rotation in degrees.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 45, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'setPosition', category: 'transform', label: 'Set position', help: 'Set local position immediately.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0.5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setRotation', category: 'transform', label: 'Set rotation', help: 'Set local Euler rotation in degrees immediately.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 0, 5), num('z', 'Z', 0, 5), target(),
    ] },
    { id: 'setScale', category: 'transform', label: 'Set scale', help: 'Set local scale immediately.', params: [
      num('x', 'X', 1, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 1, 0.1), target(),
    ] },
    { id: 'moveTo', category: 'transform', label: 'Move to (tween)', help: 'Smoothly tween local position to an absolute point.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'moveBy', category: 'transform', label: 'Move by (tween)', help: 'Smoothly tween local position by a relative offset.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 1, 0.1), num('z', 'Z', 0, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'rotateTo', category: 'transform', label: 'Rotate to (tween)', help: 'Tween rotation in degrees along the shortest path.', params: [
      num('x', 'X', 0, 5), num('y', 'Y', 90, 5), num('z', 'Z', 0, 5),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'scaleTo', category: 'transform', label: 'Scale to (tween)', help: 'Tween local scale to an absolute value.', params: [
      num('x', 'X', 1.5, 0.1), num('y', 'Y', 1.5, 0.1), num('z', 'Z', 1.5, 0.1),
      duration(), easing(), waitFinish(), target(),
    ] },
    { id: 'lookAt', category: 'transform', label: 'Look at point', help: 'Aim the object’s +Z axis at a world-space point.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0.5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'lookAtObject', category: 'transform', label: 'Look at object', help: 'Aim the object at another object’s current position.', params: [
      target(),
      text('lookAt', 'Look at', 'Main Camera', 'name / id'),
    ] },
    { id: 'resetTransform', category: 'transform', label: 'Reset transform', help: 'Reset position to 0, rotation to 0 and scale to 1.', params: [target()] },
    { id: 'stopMotion', category: 'transform', label: 'Stop tweens', help: 'Cancel all running position/rotation/scale tweens on this FSM.', params: [target()] },

    /* ---------------- variables & math ---------------- */
    { id: 'setVariable', category: 'variables', label: 'Set variable', help: 'Assign a literal value. Numbers are stored as text but compared numerically.', params: [
      text('name', 'Variable', 'score'), text('value', 'Value', '1'),
    ] },
    { id: 'addVariable', category: 'variables', label: 'Add to variable', help: 'Add a numeric amount to a variable.', params: [
      text('name', 'Variable', 'score'), num('value', 'Amount', 1, 0.1),
    ] },
    { id: 'multiplyVariable', category: 'variables', label: 'Multiply variable', help: 'Multiply a variable by a numeric factor.', params: [
      text('name', 'Variable', 'score'), num('value', 'Factor', 2, 0.1),
    ] },
    { id: 'clampVariable', category: 'variables', label: 'Clamp variable', help: 'Keep a variable within a numeric range.', params: [
      text('name', 'Variable', 'score'), num('min', 'Min', 0, 0.1), num('max', 'Max', 100, 0.1),
    ] },
    { id: 'randomFloat', category: 'variables', label: 'Random float', help: 'Store a random decimal number in a variable.', params: [
      text('name', 'Variable', 'chance'), num('min', 'Min', 0, 0.1), num('max', 'Max', 1, 0.1),
    ] },
    { id: 'randomInt', category: 'variables', label: 'Random integer', help: 'Store a random whole number (inclusive range).', params: [
      text('name', 'Variable', 'roll'), num('min', 'Min', 1, 1), num('max', 'Max', 6, 1),
    ] },
    { id: 'toggleVariable', category: 'variables', label: 'Toggle variable', help: 'Flip a boolean-like value between true/false.', params: [
      text('name', 'Variable', 'active'),
    ] },
    { id: 'copyVariable', category: 'variables', label: 'Copy variable', help: 'Copy one FSM variable into another.', params: [
      text('from', 'From', 'score'), text('to', 'To', 'best'),
    ] },
    { id: 'mathOp', category: 'variables', label: 'Math operation', help: 'Apply an arithmetic operation to a variable in place.', params: [
      text('name', 'Variable', 'score'),
      select('op', 'Operation', [
        { value: '+', label: '+' }, { value: '-', label: '−' }, { value: '*', label: '×' },
        { value: '/', label: '÷' }, { value: '%', label: 'Modulo' }, { value: '^', label: 'Power' },
        { value: 'min', label: 'Minimum' }, { value: 'max', label: 'Maximum' },
      ], '+'),
      num('value', 'Value', 1, 0.1),
      text('source', 'Use variable', '', 'optional variable operand'),
    ] },
    { id: 'getTransform', category: 'variables', label: 'Get transform value', help: 'Read position, rotation or scale from an object into a variable.', params: [
      text('name', 'Variable', 'posX'), target(),
      select('property', 'Property', [{ value: 'position', label: 'Position' }, { value: 'rotation', label: 'Rotation' }, { value: 'scale', label: 'Scale' }], 'position'),
      select('axis', 'Axis', [{ value: 'x', label: 'X' }, { value: 'y', label: 'Y' }, { value: 'z', label: 'Z' }], 'x'),
    ] },
    { id: 'getDistance', category: 'variables', label: 'Get distance', help: 'Store the distance between two objects in a variable.', params: [
      text('store', 'Variable', 'distance'), target(), text('other', 'Other', 'Main Camera', 'name / id'),
    ] },
    { id: 'formatString', category: 'variables', label: 'Format string', help: 'Replace {variable} placeholders in a template and store the result.', params: [
      text('template', 'Template', 'Hello {name}, score {score}'),
      text('store', 'Store in', 'message'),
    ] },

    /* ---------------- string & text ---------------- */
    { id: 'stringReplace', category: 'string', label: 'Replace text', help: 'Replace every occurrence of a substring inside a variable.', params: [
      text('variable', 'Variable', 'message'), text('find', 'Find', 'old'), text('replace', 'Replace with', 'new'),
    ] },
    { id: 'splitString', category: 'string', label: 'Split string', help: 'Split a variable by a separator and store one part (0 = first).', params: [
      text('source', 'Source', 'message'), text('separator', 'Separator', ','),
      num('index', 'Part index', 0, 1, 0, 999), text('store', 'Store in', 'part'),
    ] },
    { id: 'stringCase', category: 'string', label: 'Change text case', help: 'Convert a variable to upper case, lower case, trimmed or capitalised.', params: [
      text('variable', 'Variable', 'message'),
      select('mode', 'Mode', [
        { value: 'upper', label: 'UPPER CASE' }, { value: 'lower', label: 'lower case' },
        { value: 'trim', label: 'Trim spaces' }, { value: 'capitalize', label: 'Capitalize' },
      ], 'upper'),
    ] },
    { id: 'convertVariable', category: 'string', label: 'Convert variable', help: 'Convert a variable between text, integer and decimal forms.', params: [
      text('variable', 'Variable', 'score'),
      select('mode', 'Convert to', [
        { value: 'int', label: 'Integer' }, { value: 'float', label: 'Decimal' },
        { value: 'fixed', label: 'Fixed decimals' }, { value: 'text', label: 'Plain text' },
      ], 'int'),
      num('decimals', 'Decimals', 2, 1, 0, 6),
    ] },

    /* ---------------- logic & scene ---------------- */
    { id: 'branch', category: 'logic', label: 'Branch on variable', help: 'Send one of two events depending on a variable comparison.', params: [
      text('variable', 'Variable', 'score'),
      select('op', 'Operator', ['==', '!=', '>', '<', '>=', '<='].map((o) => ({ value: o, label: o })), '>='),
      text('value', 'Value', '10'),
      text('eventTrue', 'If true', 'win'),
      text('eventFalse', 'If false', 'lose'),
    ] },
    { id: 'setAmbient', category: 'logic', label: 'Set ambient light', help: 'Change scene-wide ambient intensity and colour.', params: [
      num('intensity', 'Intensity', 0.42, 0.05, 0, 4),
      color('color', 'Color', '#ffffff'),
    ] },
    { id: 'setFog', category: 'logic', label: 'Set fog', help: 'Enable or configure scene fog at runtime.', params: [
      bool('enabled', 'Enabled', true),
      color('color', 'Color', '#1d2025'),
      num('near', 'Near', 14, 0.5, 0), num('far', 'Far', 70, 1, 0.1),
    ] },

    /* ---------------- GameObject ---------------- */
    { id: 'setVisible', category: 'gameobject', label: 'Set visible', help: 'Show or hide an object (and its children).', params: [
      bool('visible', 'Visible', true), target(),
    ] },
    { id: 'toggleVisible', category: 'gameobject', label: 'Toggle visible', help: 'Invert an object’s visibility.', params: [target()] },
    { id: 'setParent', category: 'gameobject', label: 'Set parent', help: 'Re-parent an object at runtime. Leave Parent empty to move it to the scene root.', params: [
      target(),
      text('parent', 'Parent', '', 'empty = scene root'),
    ] },
    { id: 'setName', category: 'gameobject', label: 'Set object name', help: 'Rename an object at runtime.', params: [
      text('name', 'Name', 'Object'), target(),
    ] },
    { id: 'destroyObject', category: 'gameobject', label: 'Destroy object', help: 'Remove an object (and optionally its children) from the running scene.', params: [
      target(), bool('includeChildren', 'Include children', true),
    ] },
    { id: 'cloneObject', category: 'gameobject', label: 'Clone object', help: 'Create a copy of an object during play, optionally including its FSM.', params: [
      target(),
      text('name', 'New name', '{name} clone', 'supports {name}'),
      num('x', 'Offset X', 0.6, 0.1), num('y', 'Offset Y', 0, 0.1), num('z', 'Offset Z', 0.6, 0.1),
      bool('copyFsm', 'Copy FSM', false),
      text('store', 'Store in variable', 'clone', 'name of the new object'),
    ] },
    { id: 'setActive', category: 'gameobject', label: 'Activate / deactivate', help: 'Turn an object on or off. Inactive objects stop rendering, physics, scripts, behaviors and FSMs — children too.', params: [
      bool('active', 'Activate', true), target(),
    ] },
    { id: 'toggleActive', category: 'gameobject', label: 'Toggle active', help: 'Flip an object between active and inactive.', params: [target()] },
    { id: 'setTag', category: 'gameobject', label: 'Set tag', help: 'Assign a tag to an object so Find and Compare actions can use it.', params: [
      text('tag', 'Tag', 'Enemy'), target(),
    ] },
    { id: 'getTag', category: 'gameobject', label: 'Get tag', help: 'Store an object’s tag in a variable.', params: [
      target(), text('store', 'Store in', 'tag'),
    ] },
    { id: 'findByTag', category: 'gameobject', label: 'Find object by tag', help: 'Find the first active object with a tag and store its name in a variable.', params: [
      text('tag', 'Tag', 'Enemy'), text('store', 'Store in', 'found'),
    ] },
    { id: 'compareTag', category: 'gameobject', label: 'Compare tag', help: 'Compare an object’s tag, store true/false and send a matching event.', params: [
      target(), text('tag', 'Tag', 'Enemy'), text('store', 'Store in', 'match'),
      text('eventTrue', 'If match', 'tagMatch'), text('eventFalse', 'If not', 'tagMismatch'),
    ] },

    /* ---------------- material & texture ---------------- */
    { id: 'setColor', category: 'material', label: 'Set color', help: 'Set the mesh material colour.', params: [color('color', 'Color', '#5b9bd5'), target()] },
    { id: 'setOpacity', category: 'material', label: 'Set opacity', help: 'Set mesh transparency from 0 (invisible) to 1 (opaque).', params: [
      num('opacity', 'Opacity', 0.5, 0.05, 0, 1), target(),
    ] },
    { id: 'setWireframe', category: 'material', label: 'Set wireframe', help: 'Render the mesh as wireframe or solid.', params: [
      bool('wireframe', 'Wireframe', true), target(),
    ] },
    { id: 'setTexturePreset', category: 'material', label: 'Set texture preset', help: 'Replace the mesh texture with a procedural preset.', params: [
      select('preset', 'Preset', PRESETS, 'checker'), target(),
    ] },
    { id: 'setTextureTiling', category: 'material', label: 'Set texture tiling', help: 'Repeat the current (or a default) texture across the UVs.', params: [
      num('x', 'Repeat X', 2, 0.1, 0.05, 16), num('y', 'Repeat Y', 2, 0.1, 0.05, 16), target(),
    ] },
    { id: 'setTextureOffset', category: 'material', label: 'Set texture offset', help: 'Shift the texture across the UVs.', params: [
      num('x', 'Offset X', 0.5, 0.05), num('y', 'Offset Y', 0, 0.05), target(),
    ] },
    { id: 'clearTexture', category: 'material', label: 'Remove texture', help: 'Remove the mesh texture component.', params: [target()] },

    /* ---------------- lighting ---------------- */
    { id: 'setLightColor', category: 'light', label: 'Set light color', help: 'Set the colour of a light object.', params: [color('color', 'Color', '#ffffff'), target()] },
    { id: 'setLightIntensity', category: 'light', label: 'Set light intensity', help: 'Set a light’s brightness.', params: [
      num('intensity', 'Intensity', 1.5, 0.1, 0, 20), target(),
    ] },
    { id: 'setLightRange', category: 'light', label: 'Set light range', help: 'Set point/spot light falloff distance.', params: [
      num('range', 'Range', 18, 0.5, 0.1, 500), target(),
    ] },
    { id: 'setLightAngle', category: 'light', label: 'Set spot angle', help: 'Set a spot light cone angle in degrees.', params: [
      num('angle', 'Angle', 38, 1, 1, 179), target(),
    ] },
    { id: 'setLightPenumbra', category: 'light', label: 'Set spot penumbra', help: 'Soften the spot light edge (0 hard, 1 soft).', params: [
      num('penumbra', 'Penumbra', 0.35, 0.05, 0, 1), target(),
    ] },
    { id: 'toggleLight', category: 'light', label: 'Toggle light', help: 'Turn a light object on or off.', params: [target()] },

    /* ---------------- camera ---------------- */
    { id: 'setCameraFov', category: 'camera', label: 'Set camera FOV', help: 'Change the active game camera field of view.', params: [
      num('fov', 'FOV', 55, 1, 5, 170), target(),
    ] },
    { id: 'setCameraClip', category: 'camera', label: 'Set camera clipping', help: 'Change the near and far clip planes.', params: [
      num('near', 'Near', 0.1, 0.01, 0.001), num('far', 'Far', 600, 1, 0.1), target(),
    ] },
    { id: 'setCameraBg', category: 'camera', label: 'Set camera background', help: 'Change the Game-view background colour.', params: [
      color('color', 'Color', '#1d2025'), target(),
    ] },

    /* ---------------- physics ---------------- */
    { id: 'addImpulse', category: 'physics', label: 'Add impulse', help: 'Add velocity to a rigidbody (divided by its mass).', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 5, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setVelocity', category: 'physics', label: 'Set velocity', help: 'Replace a rigidbody’s linear velocity.', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 0, 0.1), num('z', 'Z', 0, 0.1), target(),
    ] },
    { id: 'setUseGravity', category: 'physics', label: 'Set body gravity', help: 'Toggle gravity for one rigidbody.', params: [
      bool('enabled', 'Use gravity', true), target(),
    ] },
    { id: 'setGravity', category: 'physics', label: 'Set world gravity', help: 'Change gravity for every rigidbody in the scene.', params: [
      num('value', 'Gravity', 9.81, 0.1, 0, 100),
    ] },
    { id: 'addForce', category: 'physics', label: 'Add force', help: 'Push a rigidbody continuously for a number of seconds (force ÷ mass).', params: [
      num('x', 'X', 0, 0.1), num('y', 'Y', 10, 0.1), num('z', 'Z', 0, 0.1),
      num('seconds', 'Seconds', 0.5, 0.1, 0, 30), target(),
    ] },
    { id: 'setMass', category: 'physics', label: 'Set mass', help: 'Change a rigidbody’s mass.', params: [
      num('mass', 'Mass', 1, 0.1, 0.05, 1000), target(),
    ] },
    { id: 'setRestitution', category: 'physics', label: 'Set bounciness', help: 'Set how much a rigidbody bounces (0 = none, 1 = perfect).', params: [
      num('value', 'Bounciness', 0.3, 0.05, 0, 1), target(),
    ] },
    { id: 'setDrag', category: 'physics', label: 'Set drag', help: 'Slow a rigidbody down over time.', params: [
      num('value', 'Drag', 0.5, 0.1, 0, 20), target(),
    ] },
    { id: 'freezeBody', category: 'physics', label: 'Freeze rigidbody', help: 'Freeze or unfreeze a rigidbody in place.', params: [
      bool('frozen', 'Frozen', true), target(),
    ] },
    { id: 'raycast', category: 'physics', label: 'Raycast', help: 'Cast a ray against scene colliders and store what it hits.', params: [
      num('x', 'Origin X', 0, 0.1), num('y', 'Origin Y', 1, 0.1), num('z', 'Origin Z', 0, 0.1),
      num('dx', 'Direction X', 0, 0.1), num('dy', 'Direction Y', -1, 0.1), num('dz', 'Direction Z', 0, 0.1),
      num('maxDistance', 'Max distance', 50, 1, 0.1, 1000),
      text('storeObject', 'Store hit object', 'hit'), text('storeDistance', 'Store distance', 'hitDistance'),
      bool('ignoreSelf', 'Ignore self', true),
    ] },

    /* ---------------- network / PHP ---------------- */
    { id: 'httpRequest', category: 'network', label: 'HTTP request', help: 'Call an external URL or PHP endpoint, store the response and optionally wait for it.', params: [
      select('method', 'Method', [
        { value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' },
        { value: 'PUT', label: 'PUT' }, { value: 'PATCH', label: 'PATCH' }, { value: 'DELETE', label: 'DELETE' },
      ], 'GET'),
      text('url', 'URL', 'https://example.com/api.php', 'absolute URL'),
      select('contentType', 'Send as', [
        { value: 'none', label: 'No body' }, { value: 'json', label: 'JSON' },
        { value: 'form', label: 'Form fields' }, { value: 'text', label: 'Plain text' },
      ], 'json'),
      text('body', 'Body', '{"action":"hello"}', 'JSON, form fields or plain text'),
      text('headers', 'Headers', '', 'one “Name: value” per line'),
      text('store', 'Store response', 'response'),
      text('storeStatus', 'Store status', 'status'),
      text('doneEvent', 'Success event', 'httpDone'),
      text('errorEvent', 'Failure event', 'httpError'),
      num('timeout', 'Timeout (s)', 15, 1, 1, 120),
      bool('wait', 'Wait for response', true),
    ] },
    { id: 'callPhp', category: 'network', label: 'Call PHP endpoint', help: 'POST form fields to a PHP script and store its response.', params: [
      text('url', 'URL', 'https://example.com/api.php'),
      text('fields', 'Fields', 'name=hero&score=10', 'key=value&key2=value2'),
      text('store', 'Store response', 'response'),
      text('doneEvent', 'Success event', 'phpDone'),
      text('errorEvent', 'Failure event', 'phpError'),
      num('timeout', 'Timeout (s)', 15, 1, 1, 120),
      bool('wait', 'Wait for response', true),
    ] },
    { id: 'jsonGet', category: 'network', label: 'Read JSON value', help: 'Read a dotted path from a JSON variable, for example data.player.name or items[0].id.', params: [
      text('source', 'From variable', 'response'),
      text('path', 'Path', 'data.name', 'dots and [n] indexes'),
      text('store', 'Store in', 'value'),
      text('fallback', 'Fallback', ''),
    ] },
    { id: 'openUrl', category: 'network', label: 'Open URL in browser', help: 'Open a link in a new tab. Popup blockers may ignore calls that are not triggered by a click.', params: [
      text('url', 'URL', 'https://example.com'),
      select('target', 'Target', [{ value: '_blank', label: 'New tab' }, { value: '_self', label: 'Same tab' }], '_blank'),
    ] },

    /* ---------------- audio ---------------- */
    { id: 'playTone', category: 'audio', label: 'Play tone', help: 'Play a short synthesised tone using the browser AudioContext.', params: [
      num('frequency', 'Frequency', 440, 10, 20, 12000),
      num('duration', 'Duration', 0.18, 0.05, 0.03, 10),
      num('volume', 'Volume', 0.18, 0.05, 0, 1),
      select('wave', 'Wave', [{ value: 'sine', label: 'Sine' }, { value: 'square', label: 'Square' }, { value: 'sawtooth', label: 'Sawtooth' }, { value: 'triangle', label: 'Triangle' }], 'sine'),
    ] },
    { id: 'stopAudio', category: 'audio', label: 'Stop all audio', help: 'Close the runtime audio context and stop every tone.', params: [] },

    /* ---------------- debug / UI ---------------- */
    { id: 'toast', category: 'debug', label: 'Show toast', help: 'Show a short notification over the editor.', params: [
      text('message', 'Message', 'Action complete'),
      select('kind', 'Kind', [{ value: 'info', label: 'Info' }, { value: 'ok', label: 'Success' }, { value: 'warn', label: 'Warning' }, { value: 'error', label: 'Error' }], 'info'),
    ] },
  ];

  const TRIGGER_TYPES = [
    { id: 'auto', label: 'After delay' },
    { id: 'event', label: 'On event' },
    { id: 'key', label: 'While key held' },
    { id: 'keyDown', label: 'On key down' },
    { id: 'keyUp', label: 'On key up' },
    { id: 'variable', label: 'On variable' },
  ];
  const OPS = ['==', '!=', '>', '<', '>=', '<='];

  F.categories = CATEGORIES;
  F.actionTypes = ACTION_TYPES;
  F.triggerTypes = TRIGGER_TYPES;
  F.easings = EASINGS;
  F.ops = OPS;
  F.uid = uid;

  F.categoryMeta = (id) => CATEGORIES.find((c) => c.id === id) || CATEGORIES[0];
  F.actionMeta = (id) => ACTION_TYPES.find((a) => a.id === id) || ACTION_TYPES[0];
  F.triggerMeta = (id) => TRIGGER_TYPES.find((t) => t.id === id) || TRIGGER_TYPES[0];

  F.actionsInCategory = function (id) {
    return ACTION_TYPES.filter((a) => a.category === id);
  };

  F.defaultActionParams = function (type) {
    const meta = F.actionMeta(type);
    const out = {};
    for (const p of meta.params) out[p.key] = p.def;
    return out;
  };

  F.defaultAction = function (type) {
    const id = type || 'log';
    return { type: id, params: F.defaultActionParams(id) };
  };

  F.defaultState = function (name, x, y) {
    return {
      id: uid('s'),
      name: name || 'New State',
      x: x != null ? x : 40,
      y: y != null ? y : 60,
      actions: [],
    };
  };

  F.defaultTransition = function (from, to) {
    return {
      id: uid('t'),
      from: from || null,
      to: to || null,
      trigger: 'auto',
      delay: 1,
      event: 'done',
      key: 'Space',
      variable: '',
      op: '==',
      value: '',
    };
  };

  F.defaults = function () {
    const s = F.defaultState('Idle', 46, 62);
    return {
      enabled: true,
      start: s.id,
      states: [s],
      transitions: [],
      variables: [{ name: 'score', value: '0' }],
    };
  };

  F.state = (fsm, id) => (fsm && fsm.states ? fsm.states.find((s) => s.id === id) : null);

  const validColor = (v) => typeof v === 'string' && /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim());

  F.normalize = function (fsm) {
    if (!fsm || typeof fsm !== 'object' || !Array.isArray(fsm.states)) return null;
    const seen = new Set();
    fsm.states = fsm.states.map((s, i) => {
      const st = {
        id: s && s.id && !seen.has(s.id) ? s.id : uid('s'),
        name: (s && s.name) || 'State ' + (i + 1),
        x: Number.isFinite(s && s.x) ? Math.max(0, Math.min(4000, s.x)) : 40 + (i % 4) * 190,
        y: Number.isFinite(s && s.y) ? Math.max(0, Math.min(3000, s.y)) : 60 + Math.floor(i / 4) * 110,
        actions: Array.isArray(s && s.actions) ? s.actions : [],
      };
      seen.add(st.id);
      st.actions = st.actions.map((a) => {
        const known = a && ACTION_TYPES.some((x) => x.id === a.type);
        const type = known ? a.type : 'log';
        const meta = F.actionMeta(type);
        const params = Object.assign({}, F.defaultActionParams(type), (a && a.params) || {});
        for (const p of meta.params) {
          const v = params[p.key];
          if (p.type === 'number') {
            let v2 = +v;
            if (!Number.isFinite(v2)) v2 = +p.def;
            if (!Number.isFinite(v2)) v2 = 0;
            if (p.min != null) v2 = Math.max(p.min, v2);
            if (p.max != null) v2 = Math.min(p.max, v2);
            params[p.key] = v2;
          } else if (p.type === 'bool') {
            params[p.key] = v !== false && v !== 'false' && v !== 0 && v !== '0';
          } else if (p.type === 'color') {
            params[p.key] = validColor(v) ? v : p.def;
          } else if (p.type === 'select') {
            const ok = (p.options || []).some((o) => o.value === v);
            params[p.key] = ok ? v : p.def;
          } else {
            params[p.key] = v != null ? String(v) : p.def;
          }
        }
        return { type, params };
      });
      return st;
    });
    if (!fsm.states.length) fsm.states.push(F.defaultState('Idle', 46, 62));
    const ids = new Set(fsm.states.map((s) => s.id));
    if (!fsm.start || !ids.has(fsm.start)) fsm.start = fsm.states[0].id;

    fsm.transitions = (Array.isArray(fsm.transitions) ? fsm.transitions : []).filter(
      (t) => t && ids.has(t.from) && ids.has(t.to)
    ).map((t) => ({
      id: t.id || uid('t'),
      from: t.from,
      to: t.to,
      trigger: TRIGGER_TYPES.some((x) => x.id === t.trigger) ? t.trigger : 'auto',
      delay: Number.isFinite(t.delay) ? t.delay : 1,
      event: t.event || 'done',
      key: t.key || 'Space',
      variable: t.variable || '',
      op: OPS.indexOf(t.op) >= 0 ? t.op : '==',
      value: t.value != null ? String(t.value) : '',
    }));
    const tseen = new Set();
    for (const t of fsm.transitions) {
      if (tseen.has(t.id)) t.id = uid('t');
      tseen.add(t.id);
    }

    fsm.variables = (Array.isArray(fsm.variables) ? fsm.variables : []).map((v) => ({
      name: (v && v.name) || 'var',
      value: v && v.value != null ? String(v.value) : '0',
    }));
    fsm.enabled = fsm.enabled !== false;
    return fsm;
  };

  F.summary = function (fsm) {
    if (!fsm) return 'not configured';
    return (fsm.states ? fsm.states.length : 0) + ' states · ' +
      (fsm.transitions ? fsm.transitions.length : 0) + ' transitions';
  };

  /* ---------------- comparison / value helpers ---------------- */
  function toNumber(v) {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : null;
  }

  function compare(a, b, op) {
    const na = toNumber(a);
    const nb = toNumber(b);
    const x = na != null && nb != null ? na : String(a);
    const y = na != null && nb != null ? nb : String(b);
    switch (op) {
      case '!=': return x !== y;
      case '>': return x > y;
      case '<': return x < y;
      case '>=': return x >= y;
      case '<=': return x <= y;
      default: return x === y;
    }
  }
  F.compare = compare;

  const n = (v, d) => {
    const x = parseFloat(v);
    return Number.isFinite(x) ? x : (d == null ? 0 : d);
  };
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  function ease(name, t) {
    t = clamp(t, 0, 1);
    switch (name) {
      case 'linear': return t;
      case 'easeIn': return t * t * t;
      case 'easeOut': return 1 - Math.pow(1 - t, 3);
      default: return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }
  }

  function findNode(runtime, ref) {
    const ed = runtime.editor;
    const key = String(ref == null ? '' : ref).trim();
    if (!key || key.toLowerCase() === 'self') return null;
    return ed.scene.nodes.find((x) => x.id === key || x.name === key) || null;
  }

  function actionTarget(node, runtime, p) {
    const ref = String((p && p.target) || 'self').trim();
    if (!ref || ref.toLowerCase() === 'self') return node;
    if (ref.toLowerCase() === 'parent') return node.parent ? runtime.editor.node(node.parent) : null;
    return findNode(runtime, ref);
  }

  function cameraFor(node, runtime, p) {
    const hit = actionTarget(node, runtime, p);
    if (hit && hit.type === 'camera' && hit.camera) return hit;
    return runtime.editor.scene.nodes.find((x) => x.type === 'camera' && x.visible && x.camera) || null;
  }

  function textureFor(node, create) {
    if (!node || !node.mesh) return null;
    let tex = UW.textures.normalize(node.mesh.texture);
    if (!tex && create) tex = UW.textures.defaultTexture('checker');
    if (tex) node.mesh.texture = tex;
    return tex;
  }

  function bodyFor(runtime, node) {
    return runtime.bodies.find((b) => b.node === node) || null;
  }

  function runnerFor(runtime, node, create) {
    let runner = runtime.fsmRunners.find((r) => r.node === node);
    if (!runner && create && typeof runtime.spawnRunner === 'function') {
      runner = runtime.spawnRunner(node);
    }
    return runner || null;
  }

  /* ---------------- tween helpers ---------------- */
  function vectorTween(node, key, to, durationSeconds, easingName, relative) {
    const from = node.transform[key].slice();
    const target = relative ? [from[0] + to[0], from[1] + to[1], from[2] + to[2]] : to.slice();
    if (key === 'rotation' && !relative) {
      for (let i = 0; i < 3; i++) {
        let delta = ((target[i] - from[i] + 540) % 360) - 180;
        target[i] = from[i] + delta;
      }
    }
    const seconds = Math.max(0.001, n(durationSeconds, 1));
    const tw = {
      node,
      kind: key,
      elapsed: 0,
      done: false,
      cancelled: false,
      update(dt) {
        if (tw.done || tw.cancelled) return;
        tw.elapsed += dt;
        const t = ease(easingName, Math.min(1, tw.elapsed / seconds));
        node.transform[key] = [
          M.lerp(from[0], target[0], t),
          M.lerp(from[1], target[1], t),
          M.lerp(from[2], target[2], t),
        ];
        if (tw.elapsed >= seconds) {
          node.transform[key] = target.slice();
          tw.done = true;
        }
      },
    };
    if (seconds <= 0.001) {
      node.transform[key] = target.slice();
      tw.done = true;
    }
    return tw;
  }

  function lookAtPoint(t, x, y, z) {
    const dx = x - t.position[0];
    const dy = y - t.position[1];
    const dz = z - t.position[2];
    const yaw = Math.atan2(dx, dz) * M.RAD;
    const pitch = -Math.atan2(dy, Math.hypot(dx, dz)) * M.RAD;
    t.rotation = [pitch, yaw, 0];
  }

  /* ---------------- network helpers ---------------- */
  function parseHeaders(raw) {
    const out = {};
    String(raw || '').split(/\r?\n/).forEach((line) => {
      const i = line.indexOf(':');
      if (i <= 0) return;
      const key = line.slice(0, i).trim();
      const val = line.slice(i + 1).trim();
      if (key) out[key] = val;
    });
    return out;
  }

  function requestBody(contentType, body) {
    if (contentType === 'none' || body == null || body === '') return null;
    if (contentType === 'json' || contentType === 'text') return String(body);
    // form: accept both "a=1&b=2" and one "a=1" per line
    return String(body).split(/\r?\n/).filter((l) => l.trim()).join('&');
  }

  function jsonValue(text, path) {
    let data;
    try { data = JSON.parse(text); } catch (e) { return undefined; }
    if (!path) return data;
    const parts = String(path).replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
    let cur = data;
    for (const key of parts) {
      if (cur == null) return undefined;
      cur = cur[key];
    }
    return cur;
  }

  function formatTemplate(template, vars) {
    return String(template == null ? '' : template).replace(/\{([A-Za-z0-9_.-]+)\}/g, (m, key) => (
      vars[key] != null ? String(vars[key]) : ''
    ));
  }

  function emitEventSafe(runtime, name) {
    const evt = String(name == null ? '' : name).trim();
    if (evt) runtime.emitEvent(evt);
  }

  /* ---------------- runtime runner ---------------- */
  F.createRunner = function (node, runtime, force) {
    const fsm = F.normalize(node.fsm);
    if (!fsm || (!fsm.enabled && !force)) return null;
    const ed = runtime.editor;
    const vars = {};
    for (const v of fsm.variables) vars[v.name] = v.value;

    const runner = {
      node,
      fsm,
      vars,
      current: fsm.start,
      stateTime: 0,
      entered: false,
      active: false,
      queue: [],
      wait: 0,
      waitTween: null,
      waitRequest: null,
      tweens: [],
      _pumping: false,
      _restart: false,

      start() {
        if (this._pumping) { this._restart = true; return; }
        this.active = true;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.stopTweens();
        this.stateTime = 0;
        this.enter(fsm.start);
      },

      stop() {
        this.active = false;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.stopTweens();
      },

      stopTweens() {
        for (const tw of this.tweens) { tw.cancelled = true; tw.done = true; }
        this.tweens.length = 0;
        this.waitTween = null;
      },

      enter(id) {
        const st = F.state(fsm, id);
        if (!st) return;
        this.current = id;
        this.stateTime = 0;
        this.entered = true;
        this.queue.length = 0;
        this.wait = 0;
        this.waitTween = null;
        this.waitRequest = null;
        this.queue = st.actions.slice();
        this.pump(0);
      },

      pump(dt) {
        if (!this.active || this._pumping) return;
        this._pumping = true;
        let guard = 0;
        while (this.active && this.queue.length && guard++ < 512) {
          if (this.waitRequest) {
            if (!this.waitRequest.settled) break;
            this.waitRequest = null;
          }
          if (this.waitTween) {
            if (!this.waitTween.done) break;
            this.waitTween = null;
          }
          if (this.wait > 0) {
            this.wait -= dt;
            if (this.wait > 0) break;
            this.wait = 0;
          }
          const action = this.queue.shift();
          let res = null;
          try {
            res = F.runAction(action, node, runtime, this);
          } catch (err) {
            ed.log('error', '[FSM] ' + node.name + ': action "' + action.type + '" failed — ' + (err && err.message ? err.message : err));
          }
          if (res && res.wait != null) {
            this.wait = Math.max(0, n(res.wait, 0));
            if (this.wait > 0) break;
          }
          if (res && res.request) {
            if (res.block && !res.request.settled) {
              this.waitRequest = res.request;
              break;
            }
          }
          if (res && res.tween) {
            const tw = res.tween;
            for (const old of this.tweens) {
              if (old.node === tw.node && old.kind === tw.kind) {
                old.cancelled = true;
                old.done = true;
              }
            }
            this.tweens.push(tw);
            if (res.block && !tw.done) {
              this.waitTween = tw;
              break;
            }
          }
        }
        this._pumping = false;
        if (this._restart) {
          this._restart = false;
          this.start();
        }
      },

      updateTweens(dt) {
        for (const tw of this.tweens) {
          if (!tw.done && !tw.cancelled) tw.update(dt);
        }
        this.tweens = this.tweens.filter((tw) => !tw.done || tw === this.waitTween);
      },

      update(dt) {
        if (!this.active) return;
        this.stateTime += dt;
        this.updateTweens(dt);
        this.pump(dt);
        if (!this.active) return;
        const list = fsm.transitions.filter((t) => t.from === this.current);
        for (const tr of list) {
          if (!this.ready(tr)) continue;
          if (tr.trigger === 'event') this.consumeEvent(tr.event);
          this.enter(tr.to);
          break;
        }
      },

      ready(tr) {
        if (tr.trigger === 'auto') return this.stateTime >= (Number(tr.delay) || 0);
        if (tr.trigger === 'event') return this.hasEvent(tr.event);
        if (tr.trigger === 'key') return runtime.pressedKeys.has(tr.key);
        if (tr.trigger === 'keyDown') return runtime.keysDown.has(tr.key);
        if (tr.trigger === 'keyUp') return runtime.keysUp.has(tr.key);
        if (tr.trigger === 'variable') {
          if (!tr.variable) return false;
          return compare(this.vars[tr.variable], tr.value, tr.op);
        }
        return false;
      },

      hasEvent(name) {
        for (const e of runtime.fsmEvents) {
          if (e.name === name && !e.taken.has(this)) return true;
        }
        return false;
      },

      consumeEvent(name) {
        for (const e of runtime.fsmEvents) {
          if (e.name === name && !e.taken.has(this)) {
            e.taken.add(this);
            return;
          }
        }
      },

      event(name) {
        /* events are read from the runtime queue each frame */
      },
    };

    return runner;
  };

  /* ---------------- actions ---------------- */
  F.runAction = function (action, node, runtime, runner) {
    const p = action.params || {};
    const ed = runtime.editor;
    const t = node.transform;
    const getTarget = () => actionTarget(node, runtime, p) || node;

    switch (action.type) {
      case 'log': {
        const level = p.level === 'warn' || p.level === 'error' ? p.level : 'info';
        ed.log(level, '[FSM] ' + node.name + ': ' + (p.message || ''));
        break;
      }
      case 'wait':
        return { wait: Math.max(0.01, n(p.seconds, 1)) };
      case 'sendEvent':
        if (p.event) runtime.emitEvent(p.event);
        break;
      case 'startFsm': {
        const targetNode = getTarget();
        const targetRunner = runnerFor(runtime, targetNode, true);
        if (targetRunner) targetRunner.start();
        break;
      }
      case 'stopFsm': {
        const targetRunner = runnerFor(runtime, getTarget(), false);
        if (targetRunner) targetRunner.stop();
        break;
      }
      case 'restartFsm': {
        const targetRunner = runnerFor(runtime, getTarget(), true);
        if (targetRunner) {
          targetRunner.stop();
          targetRunner.start();
        }
        break;
      }
      case 'enableFsm': {
        const targetNode = getTarget();
        if (!targetNode.fsm) break;
        targetNode.fsm.enabled = p.enabled !== false;
        if (targetNode.fsm.enabled) {
          const targetRunner = runnerFor(runtime, targetNode, true);
          if (targetRunner && !targetRunner.active) targetRunner.start();
        } else {
          const targetRunner = runnerFor(runtime, targetNode, false);
          if (targetRunner) targetRunner.stop();
        }
        break;
      }

      case 'loadScene': {
        const name = String(p.name || '').trim();
        if (!name) break;
        if (!ed.gotoScene(name, { play: p.keepPlaying !== false })) {
          ed.log('warn', '[FSM] Scene "' + name + '" was not found in browser storage.');
        }
        break;
      }
      case 'loadSceneUrl': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const headers = parseHeaders(p.headers);
        const req = runtime.request({
          url,
          method: String(p.method || 'GET').toUpperCase(),
          body: requestBody('json', p.body),
          headers,
          timeout: 20,
          onDone: (res) => {
            if (res.error) {
              ed.log('warn', '[FSM] Could not download scene "' + url + '": ' + res.error);
              emitEventSafe(runtime, 'sceneError');
              return;
            }
            let data = null;
            try { data = JSON.parse(res.data); } catch (e) { /* ignore */ }
            if (!data || !Array.isArray(data.nodes)) {
              ed.log('error', '[FSM] "' + url + '" did not return a valid scene JSON file.');
              emitEventSafe(runtime, 'sceneError');
              return;
            }
            ed.gotoSceneData(data, { play: p.keepPlaying !== false });
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'restartScene':
        ed.restartScene();
        break;
      case 'saveSceneAs':
        if (p.name) ed.saveScene(String(p.name));
        break;
      case 'exitPlay':
        ed.stop();
        break;

      case 'move': {
        const t2 = getTarget().transform;
        t2.position = [t2.position[0] + n(p.x), t2.position[1] + n(p.y), t2.position[2] + n(p.z)];
        break;
      }
      case 'rotate': {
        const t2 = getTarget().transform;
        t2.rotation = [t2.rotation[0] + n(p.x), t2.rotation[1] + n(p.y), t2.rotation[2] + n(p.z)];
        break;
      }
      case 'setPosition': {
        getTarget().transform.position = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setRotation': {
        getTarget().transform.rotation = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setScale': {
        getTarget().transform.scale = [n(p.x, 1), n(p.y, 1), n(p.z, 1)];
        break;
      }
      case 'moveTo':
      case 'moveBy': {
        const targetNode = getTarget();
        const tw = vectorTween(targetNode, 'position', [n(p.x), n(p.y), n(p.z)], p.duration, p.easing || 'easeInOut', action.type === 'moveBy');
        return { tween: tw, block: p.wait !== false };
      }
      case 'rotateTo':
      case 'scaleTo': {
        const targetNode = getTarget();
        const key = action.type === 'rotateTo' ? 'rotation' : 'scale';
        const tw = vectorTween(targetNode, key, [n(p.x, key === 'scale' ? 1 : 0), n(p.y, key === 'scale' ? 1 : 0), n(p.z, key === 'scale' ? 1 : 0)], p.duration, p.easing || 'easeInOut', false);
        return { tween: tw, block: p.wait !== false };
      }
      case 'lookAt': {
        lookAtPoint(getTarget().transform, n(p.x), n(p.y), n(p.z));
        break;
      }
      case 'lookAtObject': {
        const targetNode = getTarget();
        const other = findNode(runtime, p.lookAt);
        if (other) {
          const q = other.transform.position;
          lookAtPoint(targetNode.transform, q[0], q[1], q[2]);
        }
        break;
      }
      case 'resetTransform': {
        const t2 = getTarget().transform;
        t2.position = [0, 0, 0];
        t2.rotation = [0, 0, 0];
        t2.scale = [1, 1, 1];
        break;
      }
      case 'stopMotion':
        runner.stopTweens();
        break;

      case 'setVariable':
        if (p.name) runner.vars[p.name] = p.value != null ? String(p.value) : '';
        break;
      case 'addVariable':
        if (p.name) runner.vars[p.name] = String(M.round(n(runner.vars[p.name], 0) + n(p.value), 4));
        break;
      case 'multiplyVariable':
        if (p.name) runner.vars[p.name] = String(M.round(n(runner.vars[p.name], 0) * n(p.value, 1), 4));
        break;
      case 'clampVariable':
        if (p.name) {
          const a = Math.min(n(p.min), n(p.max));
          const b = Math.max(n(p.min), n(p.max));
          runner.vars[p.name] = String(M.round(clamp(n(runner.vars[p.name], 0), a, b), 4));
        }
        break;
      case 'randomFloat': {
        if (!p.name) break;
        const a = n(p.min), b = n(p.max, 1);
        const lo = Math.min(a, b), hi = Math.max(a, b);
        runner.vars[p.name] = String(M.round(lo + Math.random() * (hi - lo), 4));
        break;
      }
      case 'randomInt': {
        if (!p.name) break;
        const a = Math.round(n(p.min)), b = Math.round(n(p.max, 1));
        const lo = Math.min(a, b), hi = Math.max(a, b);
        runner.vars[p.name] = String(lo + Math.floor(Math.random() * (hi - lo + 1)));
        break;
      }
      case 'toggleVariable': {
        if (!p.name) break;
        const old = String(runner.vars[p.name] == null ? 'false' : runner.vars[p.name]).toLowerCase();
        const on = old === 'true' || old === '1';
        runner.vars[p.name] = on ? 'false' : 'true';
        break;
      }
      case 'copyVariable':
        if (p.to) runner.vars[p.to] = runner.vars[p.from] != null ? String(runner.vars[p.from]) : '';
        break;
      case 'mathOp': {
        if (!p.name) break;
        const current = n(runner.vars[p.name], 0);
        const operand = p.source ? n(runner.vars[p.source], 0) : n(p.value, 0);
        let out = current;
        switch (p.op) {
          case '-': out = current - operand; break;
          case '*': out = current * operand; break;
          case '/':
            if (operand === 0) { ed.log('warn', '[FSM] Division by zero ignored.'); break; }
            out = current / operand;
            break;
          case '%':
            if (operand === 0) { ed.log('warn', '[FSM] Modulo by zero ignored.'); break; }
            out = current % operand;
            break;
          case '^': out = Math.pow(current, operand); break;
          case 'min': out = Math.min(current, operand); break;
          case 'max': out = Math.max(current, operand); break;
          default: out = current + operand;
        }
        runner.vars[p.name] = String(M.round(out, 6));
        break;
      }
      case 'getDistance': {
        const a = getTarget();
        const b = findNode(runtime, p.other);
        if (!p.store || !a || !b) break;
        const pa = a.transform.position;
        const pb = b.transform.position;
        runner.vars[p.store] = String(M.round(Math.hypot(pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]), 4));
        break;
      }
      case 'formatString':
        if (p.store) runner.vars[p.store] = formatTemplate(p.template, runner.vars);
        break;

      case 'stringReplace':
        if (p.variable) {
          const old = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
          runner.vars[p.variable] = old.split(String(p.find == null ? '' : p.find)).join(String(p.replace == null ? '' : p.replace));
        }
        break;
      case 'splitString': {
        const src = runner.vars[p.source] != null ? String(runner.vars[p.source]) : '';
        const parts = src.split(String(p.separator == null ? ',' : p.separator));
        const idx = Math.max(0, Math.round(n(p.index, 0)));
        if (p.store) runner.vars[p.store] = parts[idx] != null ? parts[idx] : '';
        break;
      }
      case 'stringCase': {
        if (!p.variable) break;
        const raw = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
        if (p.mode === 'lower') runner.vars[p.variable] = raw.toLowerCase();
        else if (p.mode === 'trim') runner.vars[p.variable] = raw.trim();
        else if (p.mode === 'capitalize') runner.vars[p.variable] = raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : raw;
        else runner.vars[p.variable] = raw.toUpperCase();
        break;
      }
      case 'convertVariable': {
        if (!p.variable) break;
        const raw = runner.vars[p.variable] != null ? String(runner.vars[p.variable]) : '';
        if (p.mode === 'text') runner.vars[p.variable] = raw;
        else if (p.mode === 'float') runner.vars[p.variable] = String(M.round(n(raw, 0), 6));
        else if (p.mode === 'fixed') runner.vars[p.variable] = n(raw, 0).toFixed(Math.round(clamp(n(p.decimals, 2), 0, 6)));
        else runner.vars[p.variable] = String(Math.round(n(raw, 0)));
        break;
      }
      case 'getTransform': {
        if (!p.name) break;
        const val = getTarget().transform[p.property] || [0, 0, 0];
        const idx = p.axis === 'y' ? 1 : p.axis === 'z' ? 2 : 0;
        runner.vars[p.name] = String(M.round(val[idx], 4));
        break;
      }
      case 'branch': {
        const on = compare(runner.vars[p.variable], p.value, p.op);
        const evt = on ? p.eventTrue : p.eventFalse;
        if (evt) runtime.emitEvent(evt);
        break;
      }
      case 'setAmbient': {
        const env = ed.scene.env || (ed.scene.env = UW.scene.defaultEnv());
        env.ambient = clamp(n(p.intensity, 0.42), 0, 4);
        env.ambientColor = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setFog': {
        const env = ed.scene.env || (ed.scene.env = UW.scene.defaultEnv());
        env.fogEnabled = p.enabled !== false;
        env.fogColor = validColor(p.color) ? p.color : env.fogColor || '#1d2025';
        env.fogNear = Math.max(0, n(p.near, env.fogNear != null ? env.fogNear : 14));
        env.fogFar = Math.max(env.fogNear + 0.01, n(p.far, env.fogFar != null ? env.fogFar : 70));
        break;
      }

      case 'setVisible': {
        const targetNode = getTarget();
        targetNode.visible = p.visible !== false;
        break;
      }
      case 'toggleVisible': {
        const targetNode = getTarget();
        targetNode.visible = targetNode.visible === false;
        break;
      }
      case 'setParent': {
        const targetNode = getTarget();
        const raw = String(p.parent || '').trim();
        if (!raw) {
          targetNode.parent = null;
          break;
        }
        const parent = findNode(runtime, raw);
        if (!parent || parent.id === targetNode.id) break;
        const descendants = UW.scene.descendants(ed.scene, targetNode.id).map((x) => x.id);
        if (descendants.indexOf(parent.id) >= 0) break;
        targetNode.parent = parent.id;
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        break;
      }
      case 'setName': {
        const targetNode = getTarget();
        const name = String(p.name || '').trim();
        if (name) targetNode.name = name;
        break;
      }
      case 'destroyObject': {
        const targetNode = getTarget();
        if (!targetNode || targetNode === node && ed.scene.nodes.length <= 1) break;
        const doomed = new Set([targetNode.id]);
        if (p.includeChildren !== false) {
          for (const d of UW.scene.descendants(ed.scene, targetNode.id)) doomed.add(d.id);
        }
        ed.scene.nodes = ed.scene.nodes.filter((n) => !doomed.has(n.id));
        if (ed.selected && doomed.has(ed.selected)) ed.selected = null;
        if (typeof runtime.removeNodes === 'function') runtime.removeNodes(doomed);
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        ed.touch(true);
        break;
      }
      case 'cloneObject': {
        const source = getTarget();
        const clone = UW.scene.cloneSubtree(ed.scene, source.id);
        if (!clone) break;
        if (p.copyFsm !== true) for (const n of clone.nodes) delete n.fsm;
        const rawName = String(p.name || '{name} clone');
        const name = formatTemplate(rawName, { name: source.name }) || source.name + ' clone';
        clone.root.name = UW.scene.uniqueName(ed.scene, name);
        clone.root.transform.position = [
          clone.root.transform.position[0] + n(p.x, 0),
          clone.root.transform.position[1] + n(p.y, 0),
          clone.root.transform.position[2] + n(p.z, 0),
        ];
        ed.scene.nodes.push(...clone.nodes);
        if (p.store) runner.vars[p.store] = clone.root.name;
        if (typeof runtime.rebuildPhysics === 'function') runtime.rebuildPhysics();
        if (clone.root.fsm && typeof runtime.spawnRunner === 'function') {
          const clonedRunner = runtime.spawnRunner(clone.root);
          if (clonedRunner && runtime.isActive && runtime.isActive(clone.root)) clonedRunner.start();
        }
        ed.touch(true);
        break;
      }
      case 'setActive': {
        const targetNode = getTarget();
        const next = p.active !== false;
        if (targetNode.active === next) break;
        targetNode.active = next;
        if (typeof runtime.refreshActive === 'function') runtime.refreshActive();
        ed.touch(true);
        break;
      }
      case 'toggleActive': {
        const targetNode = getTarget();
        targetNode.active = targetNode.active === false;
        if (typeof runtime.refreshActive === 'function') runtime.refreshActive();
        ed.touch(true);
        break;
      }
      case 'setTag': {
        const targetNode = getTarget();
        targetNode.tag = String(p.tag == null ? '' : p.tag).trim();
        ed.touch(true);
        break;
      }
      case 'getTag': {
        const targetNode = getTarget();
        if (p.store) runner.vars[p.store] = targetNode.tag || '';
        break;
      }
      case 'findByTag': {
        const hit = UW.scene.findByTag(ed.scene, String(p.tag == null ? '' : p.tag));
        if (p.store) runner.vars[p.store] = hit ? hit.name : '';
        break;
      }
      case 'compareTag': {
        const targetNode = getTarget();
        const own = String(targetNode.tag == null ? '' : targetNode.tag).trim().toLowerCase();
        const want = String(p.tag == null ? '' : p.tag).trim().toLowerCase();
        const match = own === want;
        if (p.store) runner.vars[p.store] = match ? 'true' : 'false';
        emitEventSafe(runtime, match ? p.eventTrue : p.eventFalse);
        break;
      }

      case 'setColor': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.color = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setOpacity': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.opacity = clamp(n(p.opacity, 1), 0, 1);
        break;
      }
      case 'setWireframe': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.wireframe = p.wireframe !== false;
        break;
      }
      case 'setTexturePreset': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.texture = UW.textures.defaultTexture(p.preset || 'checker');
        break;
      }
      case 'setTextureTiling': {
        const tex = textureFor(getTarget(), true);
        if (tex) {
          tex.tiling = [clamp(n(p.x, 1), 0.05, 16), clamp(n(p.y, 1), 0.05, 16)];
          tex.enabled = true;
        }
        break;
      }
      case 'setTextureOffset': {
        const tex = textureFor(getTarget(), true);
        if (tex) {
          tex.offset = [n(p.x), n(p.y)];
          tex.enabled = true;
        }
        break;
      }
      case 'clearTexture': {
        const targetNode = getTarget();
        if (targetNode.mesh) targetNode.mesh.texture = null;
        break;
      }

      case 'setLightColor': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.color = validColor(p.color) ? p.color : '#ffffff';
        break;
      }
      case 'setLightIntensity': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.intensity = clamp(n(p.intensity, 1), 0, 20);
        break;
      }
      case 'setLightRange': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.range = clamp(n(p.range, 12), 0.1, 500);
        break;
      }
      case 'setLightAngle': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.angle = clamp(n(p.angle, 38), 1, 179);
        break;
      }
      case 'setLightPenumbra': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.light.penumbra = clamp(n(p.penumbra, 0.35), 0, 1);
        break;
      }
      case 'toggleLight': {
        const targetNode = getTarget();
        if (targetNode.light) targetNode.visible = targetNode.visible === false;
        break;
      }

      case 'setCameraFov': {
        const cam = cameraFor(node, runtime, p);
        if (cam) cam.camera.fov = clamp(n(p.fov, 55), 5, 170);
        break;
      }
      case 'setCameraClip': {
        const cam = cameraFor(node, runtime, p);
        if (cam) {
          const near = clamp(n(p.near, 0.1), 0.001, 100);
          cam.camera.near = near;
          cam.camera.far = Math.max(near + 0.01, n(p.far, 600));
        }
        break;
      }
      case 'setCameraBg': {
        const cam = cameraFor(node, runtime, p);
        if (cam) cam.camera.bg = validColor(p.color) ? p.color : '#1d2025';
        break;
      }

      case 'addImpulse': {
        const body = bodyFor(runtime, getTarget());
        if (body) {
          const inv = 1 / Math.max(0.05, body.mass || 1);
          body.vel[0] += n(p.x) * inv;
          body.vel[1] += n(p.y) * inv;
          body.vel[2] += n(p.z) * inv;
        }
        break;
      }
      case 'setVelocity': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.vel = [n(p.x), n(p.y), n(p.z)];
        break;
      }
      case 'setUseGravity': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.useGravity = p.enabled !== false;
        break;
      }
      case 'setGravity':
        runtime.gravity = clamp(n(p.value, 9.81), 0, 100);
        break;
      case 'addForce': {
        const body = bodyFor(runtime, getTarget());
        if (!body) break;
        const seconds = Math.max(0, n(p.seconds, 0.5));
        if (seconds <= 0.001) {
          const inv = 1 / Math.max(0.05, body.mass || 1);
          body.vel[0] += n(p.x) * inv;
          body.vel[1] += n(p.y) * inv;
          body.vel[2] += n(p.z) * inv;
        } else {
          body.force = [n(p.x), n(p.y), n(p.z)];
          body.forceTime = seconds;
        }
        break;
      }
      case 'setMass': {
        const body = bodyFor(runtime, getTarget());
        const mass = clamp(n(p.mass, 1), 0.05, 1000);
        const targetNode = getTarget();
        if (body) body.mass = mass;
        if (targetNode.rigidbody) targetNode.rigidbody.mass = mass;
        break;
      }
      case 'setRestitution': {
        const body = bodyFor(runtime, getTarget());
        const value = clamp(n(p.value, 0.3), 0, 1);
        const targetNode = getTarget();
        if (body) body.restitution = value;
        if (targetNode.rigidbody) targetNode.rigidbody.restitution = value;
        break;
      }
      case 'setDrag': {
        const body = bodyFor(runtime, getTarget());
        if (body) body.drag = clamp(n(p.value, 0), 0, 20);
        break;
      }
      case 'freezeBody': {
        const body = bodyFor(runtime, getTarget());
        if (body) {
          body.frozen = p.frozen !== false;
          if (body.frozen) body.vel = [0, 0, 0];
        }
        break;
      }
      case 'raycast': {
        const origin = [n(p.x), n(p.y), n(p.z)];
        const dir = [n(p.dx), n(p.dy, -1), n(p.dz)];
        const distance = Math.max(0.1, n(p.maxDistance, 50));
        const ignore = p.ignoreSelf !== false ? getTarget() : null;
        const hit = runtime.raycast ? runtime.raycast(origin, dir, distance, ignore ? ignore.id : null) : null;
        if (p.storeObject) runner.vars[p.storeObject] = hit ? hit.node.name : '';
        if (p.storeDistance) runner.vars[p.storeDistance] = hit ? String(M.round(hit.distance, 3)) : '';
        break;
      }

      case 'httpRequest': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const contentType = p.contentType || 'json';
        const headers = parseHeaders(p.headers);
        const hasType = Object.keys(headers).some((k) => k.toLowerCase() === 'content-type');
        if (!hasType && contentType === 'json') headers['Content-Type'] = 'application/json';
        if (!hasType && contentType === 'form') headers['Content-Type'] = 'application/x-www-form-urlencoded';
        if (!hasType && contentType === 'text') headers['Content-Type'] = 'text/plain';
        const req = runtime.request({
          url,
          method: String(p.method || 'GET').toUpperCase(),
          headers,
          body: requestBody(contentType, p.body),
          timeout: p.timeout,
          onDone: (res) => {
            if (p.store) runner.vars[p.store] = res.error ? '' : String(res.data == null ? '' : res.data);
            if (p.storeStatus) runner.vars[p.storeStatus] = String(res.status || 0);
            if (res.error) {
              ed.log('warn', '[FSM] HTTP ' + (p.method || 'GET') + ' ' + url + ' failed: ' + res.error);
              emitEventSafe(runtime, p.errorEvent);
            } else {
              ed.log('info', '[FSM] HTTP ' + (p.method || 'GET') + ' ' + url + ' → ' + res.status);
              emitEventSafe(runtime, p.doneEvent);
            }
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'callPhp': {
        const url = String(p.url || '').trim();
        if (!url) break;
        const body = requestBody('form', p.fields);
        const req = runtime.request({
          url,
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body,
          timeout: p.timeout,
          onDone: (res) => {
            if (p.store) runner.vars[p.store] = res.error ? '' : String(res.data == null ? '' : res.data);
            if (res.error) {
              ed.log('warn', '[FSM] PHP call ' + url + ' failed: ' + res.error);
              emitEventSafe(runtime, p.errorEvent);
            } else {
              ed.log('info', '[FSM] PHP call ' + url + ' → ' + res.status);
              emitEventSafe(runtime, p.doneEvent);
            }
          },
        });
        return { request: req, block: p.wait !== false };
      }
      case 'jsonGet': {
        const text = runner.vars[p.source] != null ? String(runner.vars[p.source]) : '';
        let value;
        try { value = jsonValue(text, p.path); } catch (e) { value = undefined; }
        if (value === undefined || value === null) value = p.fallback != null ? p.fallback : '';
        if (p.store) runner.vars[p.store] = typeof value === 'object' ? JSON.stringify(value) : String(value);
        break;
      }
      case 'openUrl': {
        const url = String(p.url || '').trim();
        if (!url) break;
        try { window.open(url, p.target === '_self' ? '_self' : '_blank', 'noopener'); } catch (e) { /* ignore */ }
        break;
      }

      case 'playTone':
        runtime.playTone(n(p.frequency, 440), n(p.duration, 0.18), clamp(n(p.volume, 0.18), 0, 1), p.wave || 'sine');
        break;
      case 'stopAudio':
        runtime.stopAudio();
        break;

      case 'toast':
        if (UW.UI && typeof UW.UI.toast === 'function') UW.UI.toast(p.message || '', p.kind || 'info');
        else ed.log('info', '[FSM] ' + (p.message || ''));
        break;
      default:
        break;
    }
    return null;
  };
})();
