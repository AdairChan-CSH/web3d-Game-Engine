/* ============================================================
   runtime.js — play-mode simulation
   A tiny, engine-agnostic runtime: behaviors, user JS scripts and
   a very small AABB physics solver. Works identically on every
   rendering engine because it only touches the scene model.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const M = UW.math;
  const V = M.vec;

  UW.Runtime = class Runtime {
    constructor(editor) {
      this.editor = editor;
      this.time = 0;
      this.bodies = [];
      this.statics = [];
      this.behaviors = [];
      this.scripts = [];
      this.fsmRunners = [];
      this.fsmEvents = [];
      this.requests = [];
      this.activeMap = new Map();
      this.pressedKeys = new Set();
      this.keysDown = new Set();
      this.keysUp = new Set();
      this._audio = null;
      this._emitAcc = 0;
      this.groundY = 0;
      this.gravity = 9.81;
      this._onKeyDown = null;
      this._onKeyUp = null;
      this._onBlur = null;
    }

    start() {
      const ed = this.editor;
      const scene = ed.scene;
      const wm = ed.world();
      this.refreshActive();

      for (const node of scene.nodes) {
        const base = JSON.parse(JSON.stringify(node.transform));
        this._addCollider(node, wm);

        if (node.behaviors && node.behaviors.length) {
          for (const b of node.behaviors) {
            this.behaviors.push({ node, kind: b.kind, params: b.params || {}, base });
          }
        }

        if (node.script && node.script.code) {
          const compiled = this.compile(node);
          if (compiled) {
            this.scripts.push({ node, ...compiled, api: compiled.api, started: false, errorOnce: false, name: node.script.name || 'Script' });
          }
        }

        if (node.fsm && UW.FSM) {
          const runner = UW.FSM.createRunner(node, this);
          if (runner) this.fsmRunners.push(runner);
        }
      }

      for (const s of this.scripts) {
        if (!this.isActive(s.node)) continue; // onStart fires when the object is activated
        if (s.api && s.api.onStart) {
          try {
            s.api.onStart(this.context(s, 0));
            s.started = true;
          } catch (e) {
            this.scriptError(s, e);
          }
        } else {
          s.started = true;
        }
      }

      for (const runner of this.fsmRunners) {
        runner._wfStarted = this.isActive(runner.node);
        if (!runner._wfStarted) continue; // starts on activation instead
        try { runner.start(); } catch (e) {
          this.editor.log('error', '[FSM] "' + runner.node.name + '" failed to start: ' + (e && e.message ? e.message : e));
        }
      }

      this._bindKeys();
    }

    /* Effective active state of a node (a node is off when it or any
       ancestor has active === false). The map is refreshed every frame
       and immediately by the Activate / Deactivate actions. */
    refreshActive() {
      this.activeMap = UW.scene.activeMap(this.editor.scene);
    }

    isActive(node) {
      return !node || this.activeMap.get(node.id) !== false;
    }

    /* Build physics data for one node. Called by start() and by
       rebuildPhysics() after objects are added / re-parented. */
    _addCollider(node, wm) {
      const ed = this.editor;
      const wmat = wm.get(node.id) || M.mat4.identity();
      const wb = UW.scene.worldBounds(node, wmat);

      if (node.rigidbody && node.type === 'mesh') {
        if (node.parent) {
          ed.log('warn', 'Rigidbody on "' + node.name + '" ignored: physics only runs on root objects.');
        } else {
          const half = [
            (wb.max[0] - wb.min[0]) / 2,
            (wb.max[1] - wb.min[1]) / 2,
            (wb.max[2] - wb.min[2]) / 2,
          ];
          const rb = node.rigidbody;
          this.bodies.push({
            node,
            base: JSON.parse(JSON.stringify(node.transform)),
            vel: [0, 0, 0],
            half,
            mass: Math.max(0.05, rb.mass || 1),
            restitution: rb.restitution != null ? rb.restitution : 0.3,
            useGravity: rb.useGravity !== false,
            drag: rb.drag != null ? Math.max(0, rb.drag) : 0.05,
            force: [0, 0, 0],
            forceTime: 0,
            frozen: rb.frozen === true,
            sleeping: false,
          });
        }
      }

      // static AABB colliders: every visible mesh that is not a dynamic body and is not paper-thin
      const isDynamic = node.rigidbody && node.type === 'mesh' && !node.parent;
      if (node.type === 'mesh' && node.visible && !isDynamic) {
        const h = wb.max[1] - wb.min[1];
        if (h > 0.06) {
          this.statics.push({ node, min: wb.min, max: wb.max });
        }
      }
    }

    rebuildPhysics() {
      this.bodies.length = 0;
      this.statics.length = 0;
      const wm = this.editor.world();
      for (const node of this.editor.scene.nodes) this._addCollider(node, wm);
    }

    /* Drop runtime state for objects removed during play. */
    removeNodes(ids) {
      const set = ids instanceof Set ? ids : new Set(ids || []);
      this.bodies = this.bodies.filter((b) => !set.has(b.node.id));
      this.statics = this.statics.filter((s) => !set.has(s.node.id));
      this.behaviors = this.behaviors.filter((b) => !set.has(b.node.id));
      this.scripts = this.scripts.filter((s) => !set.has(s.node.id));
      for (const runner of this.fsmRunners) {
        if (set.has(runner.node.id)) {
          try { if (runner.stop) runner.stop(); } catch (e) { /* ignore */ }
        }
      }
      this.fsmRunners = this.fsmRunners.filter((r) => !set.has(r.node.id));
    }

    /* Ray vs. every scene collider. Returns { node, distance, point } or null. */
    raycast(origin, direction, maxDistance, ignoreId) {
      const o = [Number(origin[0]) || 0, Number(origin[1]) || 0, Number(origin[2]) || 0];
      let d = [Number(direction[0]) || 0, Number(direction[1]) || 0, Number(direction[2]) || 0];
      const len = Math.hypot(d[0], d[1], d[2]);
      if (len < 1e-6) return null;
      d = [d[0] / len, d[1] / len, d[2] / len];
      const max = Math.max(0.001, Number(maxDistance) || 50);

      let best = null;
      const activeMap = this.activeMap;
      const test = (node, min, boxMax) => {
        if (ignoreId && node.id === ignoreId) return;
        if (activeMap.get(node.id) === false) return;
        let tmin = 0;
        let tmax = max;
        for (let i = 0; i < 3; i++) {
          if (Math.abs(d[i]) < 1e-8) {
            if (o[i] < min[i] || o[i] > boxMax[i]) return;
          } else {
            let t1 = (min[i] - o[i]) / d[i];
            let t2 = (boxMax[i] - o[i]) / d[i];
            if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
            tmin = Math.max(tmin, t1);
            tmax = Math.min(tmax, t2);
            if (tmin > tmax) return;
          }
        }
        if (tmin > max || tmax < 0) return;
        const dist = tmin >= 0 ? tmin : tmax;
        if (!best || dist < best.distance) {
          best = {
            node,
            distance: dist,
            point: [o[0] + d[0] * dist, o[1] + d[1] * dist, o[2] + d[2] * dist],
          };
        }
      };

      for (const s of this.statics) test(s.node, s.min, s.max);
      for (const b of this.bodies) {
        const p = b.node.transform.position;
        const min = [p[0] - b.half[0], p[1] - b.half[1], p[2] - b.half[2]];
        const mx = [p[0] + b.half[0], p[1] + b.half[1], p[2] + b.half[2]];
        test(b.node, min, mx);
      }
      return best;
    }

    /* ---------------- HTTP / external calls ---------------- */
    /* Start a fetch and return a live record:
         { settled, error, status, data, aborted, abort() }
       Resolves into onDone(record) once, whether it succeeds, fails
       or times out. Aborting during stop() is silent. */
    request(opts) {
      opts = opts || {};
      const ed = this.editor;
      const record = {
        settled: false,
        error: null,
        status: 0,
        data: '',
        aborted: false,
      };
      const finish = () => {
        if (record.settled) return;
        record.settled = true;
        if (record._timer) {
          clearTimeout(record._timer);
          record._timer = null;
        }
        const idx = this.requests.indexOf(record);
        if (idx >= 0) this.requests.splice(idx, 1);
        if (typeof opts.onDone === 'function') {
          try { opts.onDone(record); } catch (e) {
            ed.log('error', '[HTTP] Response handler failed: ' + (e && e.message ? e.message : e));
          }
        }
      };
      record.abort = () => {
        if (record.settled) return;
        record.aborted = true;
        record.error = 'Aborted';
        try { if (record._controller) record._controller.abort(); } catch (e) { /* ignore */ }
        finish();
      };

      const url = String(opts.url || '').trim();
      if (!url) { record.error = 'Missing URL'; finish(); return record; }
      if (typeof fetch !== 'function') { record.error = 'fetch() is not available in this browser'; finish(); return record; }

      const method = String(opts.method || 'GET').toUpperCase();
      const ms = Math.max(1000, (Number(opts.timeout) || 15) * 1000);
      try {
        record._controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      } catch (e) {
        record._controller = null;
      }

      const init = { method, headers: opts.headers || {} };
      if (record._controller) init.signal = record._controller.signal;
      if (opts.body != null && method !== 'GET' && method !== 'HEAD') init.body = String(opts.body);

      this.requests.push(record);
      record._timer = setTimeout(() => {
        if (record.settled) return;
        record.error = 'Timed out after ' + Math.round(ms / 1000) + 's';
        try { if (record._controller) record._controller.abort(); } catch (e) { /* ignore */ }
        finish();
      }, ms);

      fetch(url, init)
        .then((res) => {
          record.status = res.status;
          return res.text().then((txt) => {
            record.data = txt;
            if (!res.ok) record.error = 'HTTP ' + res.status + (res.statusText ? ' ' + res.statusText : '');
          });
        })
        .then(finish)
        .catch((err) => {
          if (record.settled) return;
          if (!record.error) {
            record.error = record.aborted ? 'Aborted' : (err && err.message ? err.message : 'Network error');
          }
          finish();
        });
      return record;
    }

    abortRequests() {
      for (const record of this.requests.slice()) {
        try { if (record.abort) record.abort(); } catch (e) { /* ignore */ }
      }
      this.requests.length = 0;
    }

    _bindKeys() {
      const isField = (t) => {
        const tag = (t && t.tagName ? t.tagName : '').toLowerCase();
        return tag === 'input' || tag === 'textarea' || tag === 'select' || (t && t.isContentEditable);
      };
      this._onKeyDown = (e) => {
        if (isField(e.target)) return;
        if (!this.pressedKeys.has(e.key)) this.keysDown.add(e.key);
        this.pressedKeys.add(e.key);
      };
      this._onKeyUp = (e) => {
        if (isField(e.target)) return;
        this.pressedKeys.delete(e.key);
        this.keysUp.add(e.key);
      };
      this._onBlur = () => {
        this.pressedKeys.clear();
        this.keysDown.clear();
        this.keysUp.clear();
      };
      window.addEventListener('keydown', this._onKeyDown);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('blur', this._onBlur);
    }

    emitEvent(name) {
      if (!name) return;
      this.fsmEvents.push({ name: String(name), taken: new Set(), life: 2 });
      if (this.fsmEvents.length > 64) this.fsmEvents.shift();
    }

    /* Create (but do not start) an FSM runner on demand. Used by the
       Start/Restart/Enable FSM actions so disabled machines can be
       activated at runtime. */
    spawnRunner(node) {
      if (!node || !node.fsm || !UW.FSM) return null;
      const existing = this.fsmRunners.find((r) => r.node === node);
      if (existing) return existing;
      const runner = UW.FSM.createRunner(node, this, true);
      if (runner) this.fsmRunners.push(runner);
      return runner || null;
    }

    /* ---------------- audio ---------------- */
    audioContext() {
      if (this._audio) {
        if (this._audio.state === 'suspended') this._audio.resume().catch(() => {});
        return this._audio;
      }
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) {
        this.editor.log('warn', 'Audio is not supported by this browser.');
        return null;
      }
      try {
        this._audio = new Ctx();
      } catch (e) {
        this.editor.log('warn', 'Could not start audio: ' + (e && e.message ? e.message : e));
        return null;
      }
      return this._audio;
    }

    playTone(frequency, duration, volume, wave) {
      const ctx = this.audioContext();
      if (!ctx) return;
      const freq = Math.max(20, Number(frequency) || 440);
      const dur = Math.max(0.03, Number(duration) || 0.18);
      const vol = Math.max(0, Math.min(1, Number(volume) || 0.18));
      const types = { sine: 1, square: 1, sawtooth: 1, triangle: 1 };
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = types[wave] ? wave : 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, vol), ctx.currentTime + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + dur + 0.03);
    }

    stopAudio() {
      if (!this._audio) return;
      try { this._audio.close(); } catch (e) { /* ignore */ }
      this._audio = null;
    }

    compile(node) {
      try {
        const code = node.script.code;
        const factory = new Function(
          '"use strict";\n' + code + '\n;return {' +
            'onStart: typeof onStart === "function" ? onStart : null,' +
            'onUpdate: typeof onUpdate === "function" ? onUpdate : null,' +
            'onStop: typeof onStop === "function" ? onStop : null' +
          '};'
        );
        return { api: factory() };
      } catch (e) {
        this.editor.log('error', 'Script "' + (node.script.name || node.name) + '" failed to compile: ' + e.message);
        return null;
      }
    }

    context(s, dt) {
      const ed = this.editor;
      return {
        node: s.node,
        scene: ed.scene,
        time: this.time,
        dt,
        editor: ed,
        engine: ed.engineName,
        vec: V,
        math: M,
        find: (name) => ed.scene.nodes.find((n) => n.name === name) || null,
        log: (...args) => ed.log('info', args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')),
        emitEvent: (name) => this.emitEvent(name),
        setColor: (hex) => {
          if (s.node.mesh) s.node.mesh.color = hex;
        },
        openUrl: (url, target) => {
          const href = String(url == null ? '' : url).trim();
          if (!href) return false;
          try {
            const win = window.open(href, target === '_self' ? '_self' : '_blank');
            if (!win && target !== '_self') {
              ed.log('warn', 'The browser blocked opening "' + href + '" (popup blocker). Trigger it from a click or key.');
            }
            return !!win || target === '_self';
          } catch (e) {
            ed.log('error', 'Could not open URL: ' + (e && e.message ? e.message : e));
            return false;
          }
        },
        setActive: (nodeOrId, active) => {
          const target = typeof nodeOrId === 'string' ? ed.scene.nodes.find((x) => x.id === nodeOrId || x.name === nodeOrId) : nodeOrId;
          if (!target) return false;
          target.active = active !== false;
          this.refreshActive();
          return true;
        },
        findByTag: (tag) => UW.scene.findByTag(ed.scene, tag),
      };
    }

    scriptError(s, e) {
      if (!s.errorOnce) {
        s.errorOnce = true;
        this.editor.log('error', 'Script "' + s.name + '" error: ' + (e && e.message ? e.message : e));
      }
    }

    update(dt) {
      dt = Math.min(dt, 0.05);
      this.time += dt;
      const ed = this.editor;
      this.refreshActive();

      /* ---- behaviors ---- */
      for (const b of this.behaviors) {
        if (!this.isActive(b.node)) continue;
        const t = b.node.transform;
        const base = b.base;
        if (b.kind === 'spin') {
          t.rotation[0] = base.rotation[0] + (b.params.x || 0) * this.time;
          t.rotation[1] = base.rotation[1] + (b.params.y || 0) * this.time;
          t.rotation[2] = base.rotation[2] + (b.params.z || 0) * this.time;
        } else if (b.kind === 'bob') {
          t.position[1] = base.position[1] + Math.sin(this.time * (b.params.speed || 1.6)) * (b.params.amplitude || 0.3);
        } else if (b.kind === 'pulse') {
          const k = 1 + Math.sin(this.time * (b.params.speed || 2.4)) * (b.params.amount || 0.18);
          t.scale[0] = base.scale[0] * k;
          t.scale[1] = base.scale[1] * k;
          t.scale[2] = base.scale[2] * k;
        } else if (b.kind === 'orbit') {
          const radius = b.params.radius || 2.2;
          const a0 = Math.atan2(base.position[0], base.position[2]);
          const a = a0 + (this.time * (b.params.speed || 40) * Math.PI) / 180;
          t.position[0] = Math.sin(a) * radius;
          t.position[2] = Math.cos(a) * radius;
          t.position[1] = base.position[1] + (b.params.height || 0);
        }
      }

      /* ---- user scripts ---- */
      if (this.scripts.length) {
        const subs = {};
        for (const s of this.scripts) subs[s.node.id] = s;
        for (const s of this.scripts) {
          if (!this.isActive(s.node)) continue;
          if (!s.started) {
            // object was inactive when Play began — fire onStart on activation
            s.started = true;
            if (s.api && s.api.onStart) {
              try {
                s.api.onStart(this.context(s, 0));
              } catch (e) {
                this.scriptError(s, e);
              }
            }
          }
          if (!s.api || !s.api.onUpdate) continue;
          try {
            const ctx = this.context(s, dt);
            ctx.sub = subs;
            s.api.onUpdate(ctx, dt);
          } catch (e) {
            this.scriptError(s, e);
          }
        }
      }

      /* ---- state machines ---- */
      if (this.fsmRunners.length) {
        for (const runner of this.fsmRunners) {
          if (!this.isActive(runner.node)) continue;
          if (!runner._wfStarted && !runner.active) {
            // object was inactive when Play began — start its FSM on activation
            runner._wfStarted = true;
            try { runner.start(); } catch (e) {
              ed.log('error', '[FSM] "' + runner.node.name + '" failed to start: ' + (e && e.message ? e.message : e));
            }
          }
          try {
            runner.update(dt);
          } catch (e) {
            if (!runner._errOnce) {
              runner._errOnce = true;
              ed.log('error', '[FSM] "' + runner.node.name + '": ' + (e && e.message ? e.message : e));
            }
          }
        }
        for (const ev of this.fsmEvents) ev.life -= 1;
        this.fsmEvents = this.fsmEvents.filter((ev) => ev.life > 0);
      }
      this.keysDown.clear();
      this.keysUp.clear();

      /* ---- dynamics ---- */
      for (const body of this.bodies) {
        if (body.frozen || !this.isActive(body.node)) continue;
        const p = body.node.transform.position;

        // continuous force (Force action) — force / mass for `forceTime` seconds
        if (body.force && body.forceTime > 0) {
          const inv = 1 / Math.max(0.05, body.mass || 1);
          body.vel[0] += body.force[0] * inv * dt;
          body.vel[1] += body.force[1] * inv * dt;
          body.vel[2] += body.force[2] * inv * dt;
          body.forceTime = Math.max(0, body.forceTime - dt);
          if (body.forceTime === 0) body.force = [0, 0, 0];
        }

        if (body.useGravity) body.vel[1] -= this.gravity * dt;
        const dragK = Math.max(0, 1 - Math.max(0, body.drag || 0) * dt);
        body.vel[0] *= 0.999 * dragK;
        body.vel[2] *= 0.999 * dragK;
        p[0] += body.vel[0] * dt;
        p[1] += body.vel[1] * dt;
        p[2] += body.vel[2] * dt;

        const hy = body.half[1];
        if (p[1] - hy < this.groundY) {
          p[1] = this.groundY + hy;
          if (body.vel[1] < 0) {
            body.vel[1] = -body.vel[1] * body.restitution;
            if (Math.abs(body.vel[1]) < 0.55) body.vel[1] = 0;
          }
          body.vel[0] *= 0.9;
          body.vel[2] *= 0.9;
        }
      }

      // dynamic vs static AABBs
      for (const body of this.bodies) {
        if (body.frozen || !this.isActive(body.node)) continue;
        const p = body.node.transform.position;
        const half = body.half;
        for (const s of this.statics) {
          if (this.activeMap.get(s.node.id) === false) continue;
          const bmin = [p[0] - half[0], p[1] - half[1], p[2] - half[2]];
          const bmax = [p[0] + half[0], p[1] + half[1], p[2] + half[2]];
          if (bmax[0] <= s.min[0] || bmin[0] >= s.max[0]) continue;
          if (bmax[2] <= s.min[2] || bmin[2] >= s.max[2]) continue;
          if (bmax[1] <= s.min[1] || bmin[1] >= s.max[1]) continue;
          // resolve along the axis with the smallest penetration
          const pushX = Math.min(bmax[0] - s.min[0], s.max[0] - bmin[0]);
          const pushY = Math.min(bmax[1] - s.min[1], s.max[1] - bmin[1]);
          const pushZ = Math.min(bmax[2] - s.min[2], s.max[2] - bmin[2]);
          if (pushY <= pushX && pushY <= pushZ) {
            const dir = p[1] > (s.min[1] + s.max[1]) / 2 ? 1 : -1;
            p[1] += pushY * dir;
            if (Math.sign(body.vel[1]) !== Math.sign(dir)) {
              body.vel[1] = -body.vel[1] * body.restitution;
              if (Math.abs(body.vel[1]) < 0.55) body.vel[1] = 0;
            }
            body.vel[0] *= 0.9;
            body.vel[2] *= 0.9;
          } else if (pushX <= pushZ) {
            const dir = p[0] > (s.min[0] + s.max[0]) / 2 ? 1 : -1;
            p[0] += pushX * dir;
            body.vel[0] *= -body.restitution;
          } else {
            const dir = p[2] > (s.min[2] + s.max[2]) / 2 ? 1 : -1;
            p[2] += pushZ * dir;
            body.vel[2] *= -body.restitution;
          }
        }
      }

      // dynamic vs dynamic (sphere-ish, cheap)
      for (let i = 0; i < this.bodies.length; i++) {
        for (let j = i + 1; j < this.bodies.length; j++) {
          const A = this.bodies[i];
          const B = this.bodies[j];
          if (A.frozen && B.frozen) continue;
          if (this.activeMap.get(A.node.id) === false || this.activeMap.get(B.node.id) === false) continue;
          const aMove = A.frozen ? 0 : 1;
          const bMove = B.frozen ? 0 : 1;
          const mover = aMove + bMove;
          const pa = A.node.transform.position;
          const pb = B.node.transform.position;
          const overlapX = Math.min(pa[0] + A.half[0], pb[0] + B.half[0]) - Math.max(pa[0] - A.half[0], pb[0] - B.half[0]);
          const overlapY = Math.min(pa[1] + A.half[1], pb[1] + B.half[1]) - Math.max(pa[1] - A.half[1], pb[1] - B.half[1]);
          const overlapZ = Math.min(pa[2] + A.half[2], pb[2] + B.half[2]) - Math.max(pa[2] - A.half[2], pb[2] - B.half[2]);
          if (overlapX <= 0 || overlapY <= 0 || overlapZ <= 0) continue;
          if (overlapY <= overlapX && overlapY <= overlapZ) {
            const dir = pa[1] >= pb[1] ? 1 : -1;
            pa[1] += (overlapY * aMove / mover) * dir;
            pb[1] -= (overlapY * bMove / mover) * dir;
            const va = A.vel[1], vb = B.vel[1];
            if (aMove) A.vel[1] = vb * 0.7;
            if (bMove) B.vel[1] = va * 0.7;
          } else if (overlapX <= overlapZ) {
            const dir = pa[0] >= pb[0] ? 1 : -1;
            pa[0] += (overlapX * aMove / mover) * dir;
            pb[0] -= (overlapX * bMove / mover) * dir;
            if (aMove) A.vel[0] = -A.vel[0] * 0.6;
            if (bMove) B.vel[0] = -B.vel[0] * 0.6;
          } else {
            const dir = pa[2] >= pb[2] ? 1 : -1;
            pa[2] += (overlapZ * aMove / mover) * dir;
            pb[2] -= (overlapZ * bMove / mover) * dir;
            if (aMove) A.vel[2] = -A.vel[2] * 0.6;
            if (bMove) B.vel[2] = -B.vel[2] * 0.6;
          }
        }
      }

      // ground clamp after pair resolution
      for (const body of this.bodies) {
        if (body.frozen || !this.isActive(body.node)) continue;
        const p = body.node.transform.position;
        if (p[1] - body.half[1] < this.groundY) {
          p[1] = this.groundY + body.half[1];
          body.vel[1] = Math.max(0, body.vel[1]);
        }
      }

      this._emitAcc += dt;
      if (this._emitAcc > 0.08) {
        this._emitAcc = 0;
        ed.emit('values');
      }
    }

    stop() {
      this.abortRequests();
      for (const s of this.scripts) {
        if (s.api && s.api.onStop && s.started) {
          try {
            s.api.onStop(this.context(s, 0));
          } catch (e) {
            this.scriptError(s, e);
          }
        }
      }
      if (this._onKeyDown) window.removeEventListener('keydown', this._onKeyDown);
      if (this._onKeyUp) window.removeEventListener('keyup', this._onKeyUp);
      if (this._onBlur) window.removeEventListener('blur', this._onBlur);
      this._onKeyDown = this._onKeyUp = this._onBlur = null;
      for (const runner of this.fsmRunners) {
        try { if (runner.stop) runner.stop(); } catch (e) { /* ignore */ }
      }
      this.stopAudio();
      this.pressedKeys.clear();
      this.keysDown.clear();
      this.keysUp.clear();
      this.fsmEvents.length = 0;
      this.fsmRunners.length = 0;
    }
  };
})();
