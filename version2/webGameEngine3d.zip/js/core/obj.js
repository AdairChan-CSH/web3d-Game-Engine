/* ============================================================
   obj.js — Wavefront OBJ (+ companion .mtl + textures) import
   Pure vanilla parser: vertices, texture coords, normals,
   polygon faces (fan-triangulated), o/g groups, usemtl
   materials, mtllib material libraries. OBJ/MTL text files
   and any image files dropped together with the model are
   embedded, so the import works fully offline and on every
   engine. Translated into a glTF-shaped doc via UW.modeldoc.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const OBJ = (UW.obj = {});

  function decodeText(buf) {
    if (typeof buf === 'string') return buf;
    return new TextDecoder('utf-8').decode(buf);
  }

  function baseName(p) {
    return String(p || '').replace(/\\/g, '/').split('/').pop() || '';
  }

  function sameFile(a, b) {
    return baseName(a).toLowerCase() === baseName(b).toLowerCase();
  }

  function dataUrlBytes(url) {
    const comma = url.indexOf(',');
    if (comma < 0 || !/^data:/i.test(url)) return null;
    const bin = atob(url.slice(comma + 1));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  const clamp01 = (v) => Math.max(0, Math.min(1, Number.isFinite(v) ? v : 1));

  /* Heuristic "is this an OBJ file" check used before JSON parsing. */
  OBJ.sniff = function (buffer) {
    try {
      if (!buffer || !buffer.byteLength) return false;
      const text = new TextDecoder('utf-8', { fatal: false })
        .decode(new Uint8Array(buffer, 0, Math.min(buffer.byteLength, 4096)));
      const lines = text.split(/\r\n|\r|\n/);
      let good = 0;
      let bad = 0;
      for (const raw of lines) {
        const l = raw.trim();
        if (!l || l[0] === '#') continue;
        if (/^(v|vt|vn|vp|f|o|g|s|l|cstype|usemtl|mtllib)(\s|$)/.test(l)) {
          good++;
          if (good >= 3) break;
        } else {
          bad++;
          if (bad > 1) break;
        }
      }
      return good > 0 && bad === 0;
    } catch (e) {
      return false;
    }
  };

  /* ---------------- MTL ---------------- */

  function parseMTL(text, imageLookup, doc) {
    const out = new Map();
    if (!text) return out;
    let cur = null;
    for (const raw of text.split(/\r\n|\r|\n/)) {
      const line = raw.trim();
      if (!line || line[0] === '#') continue;
      const sp = line.indexOf(' ');
      const key = (sp < 0 ? line : line.slice(0, sp)).toLowerCase();
      const rest = sp < 0 ? '' : line.slice(sp + 1).trim();
      if (key === 'newmtl') {
        cur = { name: rest, color: null, opacity: 1, image: null, seenKd: false };
        out.set(rest, cur);
        continue;
      }
      if (!cur) continue;
      if (key === 'kd') {
        const v = rest.split(/\s+/).map(Number);
        if (v.length >= 3 && v.slice(0, 3).every(Number.isFinite)) {
          cur.color = [clamp01(v[0]), clamp01(v[1]), clamp01(v[2])];
          cur.seenKd = true;
        }
      } else if (key === 'ka' && !cur.seenKd) {
        const v = rest.split(/\s+/).map(Number);
        if (v.length >= 3 && v.slice(0, 3).every(Number.isFinite)) {
          cur.color = [clamp01(v[0]), clamp01(v[1]), clamp01(v[2])];
        }
      } else if (key === 'd') {
        const v = parseFloat(rest);
        if (Number.isFinite(v)) cur.opacity = clamp01(v);
      } else if (key === 'tr' || key === 'trans') {
        const v = parseFloat(rest);
        if (Number.isFinite(v)) cur.opacity = clamp01(1 - v);
      } else if (key === 'map_kd' || key === 'map_d' || key === 'map') {
        const bytes = imageLookup(rest);
        if (bytes) {
          const idx = doc.addImage(bytes);
          if (idx != null) cur.image = idx;
        } else {
          doc.warnings.push('MTL texture "' + baseName(rest) + '" was not dropped together with the model — drop the image file too');
        }
      }
    }
    return out;
  }

  /* ---------------- OBJ ---------------- */

  OBJ.parse = function (buffer, extras) {
    const text = decodeText(buffer);
    extras = extras || {};
    const doc = UW.modeldoc.create('WebForge OBJ import');

    // gather provided images { name -> bytes }
    const providedImages = {};
    if (extras.images && typeof extras.images === 'object') {
      for (const key of Object.keys(extras.images)) {
        const v = extras.images[key];
        if (typeof v === 'string' && /^data:/i.test(v)) {
          const b = dataUrlBytes(v);
          if (b) providedImages[key] = b;
        } else if (v && v.byteLength != null) {
          providedImages[key] = v instanceof Uint8Array ? v : new Uint8Array(v);
        }
      }
    }
    const imageLookup = (ref) => {
      for (const key of Object.keys(providedImages)) {
        if (sameFile(key, ref)) return providedImages[key];
      }
      return null;
    };

    let mtlText = '';
    if (extras.mtl) mtlText = decodeText(extras.mtl);
    const mtlMaterials = parseMTL(mtlText, imageLookup, doc);

    const pos = [];   // flat xyz
    const uv = [];    // flat uv
    const norm = [];  // flat xyz
    const meshList = []; // { name, prims: Map, order: [] }
    const meshByName = new Map();
    let curMesh = null;
    let curMat = null;
    let sawMtllibRef = false;
    let sawLine = false;
    let triCount = 0;

    const autoMesh = () => {
      if (!curMesh) {
        curMesh = { name: null, prims: new Map(), order: [] };
        meshList.push(curMesh);
      }
      return curMesh;
    };

    const primFor = (mesh, matName) => {
      const key = matName || '';
      let prim = mesh.prims.get(key);
      if (!prim) {
        prim = {
          matName,
          verts: new Map(),
          positions: [],
          normals: [],
          uvs: [],
          indices: [],
          hasVt: true,
          hasVn: true,
        };
        mesh.prims.set(key, prim);
        mesh.order.push(prim);
      }
      return prim;
    };

    const resolveIdx = (i, len) => (i > 0 ? i - 1 : len + i);

    const lines = text.split(/\r\n|\r|\n/);
    for (let li = 0; li < lines.length; li++) {
      const raw = lines[li];
      if (!raw.length) continue;
      const line = raw.trim();
      if (!line || line[0] === '#') continue;
      const sp = line.indexOf(' ');
      const key = (sp < 0 ? line : line.slice(0, sp)).toLowerCase();
      const rest = sp < 0 ? '' : line.slice(sp + 1).trim();
      if (key === 'v') {
        const v = rest.split(/\s+/).map(Number);
        if (v.length >= 3 && v.slice(0, 3).every(Number.isFinite)) pos.push(v[0], v[1], v[2]);
      } else if (key === 'vt') {
        const v = rest.split(/\s+/).map(Number);
        if (v.length >= 2 && Number.isFinite(v[0]) && Number.isFinite(v[1])) uv.push(v[0], v[1]);
      } else if (key === 'vn') {
        const v = rest.split(/\s+/).map(Number);
        if (v.length >= 3 && v.slice(0, 3).every(Number.isFinite)) norm.push(v[0], v[1], v[2]);
      } else if (key === 'o' || key === 'g') {
        let name = rest.split(/\s+/)[0] || '';
        name = name.replace(/[\\/:*?"<>|]+/g, '_');
        let mesh = meshByName.get(name);
        if (!mesh) {
          mesh = { name: name || null, prims: new Map(), order: [] };
          meshByName.set(name, mesh);
          meshList.push(mesh);
        }
        curMesh = mesh;
      } else if (key === 'usemtl') {
        curMat = rest.split(/\s+/)[0] || null;
      } else if (key === 'mtllib') {
        sawMtllibRef = true;
        if (!extras.mtl) {
          doc.warnings.push('This OBJ references a material library ("' + baseName(rest) + '") — drop the .mtl file together with the .obj to get materials');
        }
      } else if (key === 'l') {
        sawLine = true;
      } else if (key === 'f') {
        const mesh = autoMesh();
        const parts = rest.split(/\s+/).filter(Boolean);
        if (parts.length < 3) continue;
        const corners = [];
        let ok = true;
        for (const p of parts) {
          const seg = p.split('/');
          const vi = parseInt(seg[0], 10);
          if (!Number.isFinite(vi)) { ok = false; break; }
          const ti = seg.length > 1 && seg[1] ? parseInt(seg[1], 10) : null;
          const ni = seg.length > 2 && seg[2] ? parseInt(seg[2], 10) : null;
          corners.push({ v: vi, t: Number.isFinite(ti) ? ti : null, n: Number.isFinite(ni) ? ni : null });
        }
        if (!ok) continue;
        const prim = primFor(mesh, curMat);
        const posLen = pos.length / 3;
        const uvLen = uv.length / 2;
        const normLen = norm.length / 3;
        const emitCorner = (c) => {
          const vIdx = resolveIdx(c.v, posLen);
          if (vIdx < 0 || vIdx >= posLen) return -1;
          const tIdx = c.t != null ? resolveIdx(c.t, uvLen) : -1;
          const nIdx = c.n != null ? resolveIdx(c.n, normLen) : -1;
          if (tIdx < -1 || tIdx >= uvLen) return -1;
          if (nIdx < -1 || nIdx >= normLen) return -1;
          const kk = vIdx + '/' + tIdx + '/' + nIdx;
          let idx = prim.verts.get(kk);
          if (idx != null) return idx;
          idx = prim.positions.length / 3;
          prim.positions.push(pos[vIdx * 3], pos[vIdx * 3 + 1], pos[vIdx * 3 + 2]);
          if (tIdx >= 0) {
            // OBJ has a bottom-left UV origin; glTF (and this editor) use top-left
            prim.uvs.push(uv[tIdx * 2], 1 - uv[tIdx * 2 + 1]);
          } else {
            prim.hasVt = false;
          }
          if (nIdx >= 0) {
            prim.normals.push(norm[nIdx * 3], norm[nIdx * 3 + 1], norm[nIdx * 3 + 2]);
          } else {
            prim.hasVn = false;
          }
          prim.verts.set(kk, idx);
          return idx;
        };
        for (let k = 1; k + 1 < corners.length; k++) {
          const a = emitCorner(corners[0]);
          const b = emitCorner(corners[k]);
          const c = emitCorner(corners[k + 1]);
          if (a < 0 || b < 0 || c < 0) continue;
          prim.indices.push(a, b, c);
          triCount++;
        }
      }
      // vp, s, cstype, etc. are ignored
    }

    if (sawLine) doc.warnings.push('OBJ line/curve elements are ignored (only faces are imported)');
    if (!pos.length) throw new Error('This OBJ file contains no vertices');
    if (!triCount) throw new Error('This OBJ file contains no faces');

    // materials (dedup by name)
    const matIndex = new Map();
    const materialFor = (matName) => {
      if (matName == null) return null;
      if (matIndex.has(matName)) return matIndex.get(matName);
      const m = mtlMaterials.get(matName);
      if (!m) return null;
      const idx = doc.addMaterial({
        name: matName,
        color: m.color,
        opacity: m.opacity,
        roughness: 0.85,
        metalness: 0,
        image: m.image,
      });
      matIndex.set(matName, idx);
      return idx;
    };

    const treeSpecs = [];
    let meshIdx = 0;
    for (const mesh of meshList) {
      const prims = [];
      for (const prim of mesh.order) {
        if (!prim.indices.length) continue;
        prims.push({
          positions: new Float32Array(prim.positions),
          normals: prim.hasVn ? new Float32Array(prim.normals) : null,
          uvs: prim.hasVt ? new Float32Array(prim.uvs) : null,
          indices: new Uint32Array(prim.indices),
          material: materialFor(prim.matName),
        });
      }
      if (!prims.length) continue;
      const idx = doc.addMesh(mesh.name, prims);
      if (idx == null) continue;
      treeSpecs.push({ name: mesh.name || 'Mesh ' + (meshIdx + 1), mesh: idx });
      meshIdx++;
    }
    if (!treeSpecs.length) throw new Error('No faces could be read from this OBJ file');
    doc.setTree(treeSpecs);
    return doc.finish({ format: 'obj' });
  };
})();
