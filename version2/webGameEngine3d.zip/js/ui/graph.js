/* ============================================================
   graph.js — PlayMaker-style visual FSM editor
   A modal graph of draggable state cards connected by SVG arrows.
   Click a state or an arrow to edit it in the sidebar. Everything
   writes straight into node.fsm, so it is saved with the scene and
   executed by runtime.js in Play mode.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});
  const NS = 'http://www.w3.org/2000/svg';
  const CARD_W = 158;
  const CARD_H = 64;

  const G = (UW.Graph = {});

  function svgEl(tag, attrs) {
    const n = document.createElementNS(NS, tag);
    if (attrs) for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }

  G.open = function (node, editor) {
    if (!node || !editor || !node.fsm || !UW.FSM) return;
    const ui = UW.UI;
    const fsm = (node.fsm = UW.FSM.normalize(node.fsm));
    const el = ui.el;
    const div = ui.div;
    const row = ui.row;

    let selected = { type: 'state', id: fsm.start };
    let linkMode = false;
    let linkFrom = null;

    /* ---------- graph surface ---------- */
    const body = div('fsm-editor');
    const graphCol = div('fsm-graph-col');
    const topbar = div('fsm-toolbar');

    const enabledLabel = ui.checkField('Enabled', fsm.enabled, (v) => {
      change('FSM enabled', () => { fsm.enabled = v; }, false);
      syncTopbar();
    });
    topbar.appendChild(enabledLabel);

    const addState = el('button', 'btn', '+ Add State');
    addState.addEventListener('click', () => {
      const n = fsm.states.length;
      const st = UW.FSM.defaultState('State ' + (n + 1), 56 + (n % 3) * 210, 66 + Math.floor(n / 3) * 118);
      change('Add FSM state', () => { fsm.states.push(st); }, false);
      selected = { type: 'state', id: st.id };
      renderAll();
    });
    topbar.appendChild(addState);

    const linkBtn = el('button', 'btn', '→ Link States');
    linkBtn.title = 'Click a source state, then a target state';
    linkBtn.addEventListener('click', () => {
      linkMode = !linkMode;
      linkFrom = null;
      syncTopbar();
      renderGraph();
    });
    topbar.appendChild(linkBtn);

    const hint = el('span', 'fsm-hint', 'Click a state or arrow to edit it.');
    topbar.appendChild(hint);
    graphCol.appendChild(topbar);

    const scroller = div('fsm-scroll');
    const canvas = div('fsm-canvas');
    const svg = svgEl('svg', { class: 'fsm-edges' });
    canvas.appendChild(svg);
    scroller.appendChild(canvas);
    graphCol.appendChild(scroller);
    body.appendChild(graphCol);

    /* ---------- sidebar ---------- */
    const sidebar = div('fsm-sidebar');
    body.appendChild(sidebar);

    let cardEls = new Map();

    function stateById(id) {
      return UW.FSM.state(fsm, id);
    }

    function change(label, fn, rerender) {
      editor.beginEdit();
      fn();
      editor.touch();
      editor.commitEdit(label || 'FSM');
      if (rerender !== false) renderAll();
    }

    function startLink(id) {
      linkMode = true;
      linkFrom = id;
      selected = { type: 'state', id: id };
      syncTopbar();
      renderGraph();
      renderSidebar();
    }

    function handleStateClick(st) {
      if (linkMode) {
        if (!linkFrom) {
          startLink(st.id);
          hint.textContent = 'Now click the target state.';
          return;
        }
        if (linkFrom === st.id) {
          linkFrom = null;
          hint.textContent = 'Pick a different target state.';
          syncTopbar();
          renderGraph();
          return;
        }
        const from = linkFrom;
        const tr = UW.FSM.defaultTransition(from, st.id);
        change('Add FSM transition', () => { fsm.transitions.push(tr); }, false);
        linkMode = false;
        linkFrom = null;
        selected = { type: 'transition', id: tr.id };
        renderAll();
        return;
      }
      selected = { type: 'state', id: st.id };
      renderAll();
    }

    function selectTransition(id) {
      selected = { type: 'transition', id: id };
      renderAll();
    }

    function syncTopbar() {
      linkBtn.classList.toggle('primary', linkMode);
      addState.disabled = fsm.states.length >= 64;
      if (!linkMode) {
        hint.textContent = 'Click a state or arrow to edit it.';
      } else if (!linkFrom) {
        hint.textContent = 'Link mode: click the source state.';
      } else {
        hint.textContent = 'Link mode: click the target state.';
      }
    }

    function sizeCanvas() {
      let w = 900, h = 520;
      for (const st of fsm.states) {
        w = Math.max(w, st.x + CARD_W + 260);
        h = Math.max(h, st.y + CARD_H + 190);
      }
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      svg.setAttribute('width', w);
      svg.setAttribute('height', h);
      svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    }

    function edgePath(tr) {
      const a = stateById(tr.from);
      const b = stateById(tr.to);
      if (!a || !b) return '';
      if (a.id === b.id) {
        const x = a.x + CARD_W / 2;
        const y = a.y;
        return 'M ' + (x - 26) + ' ' + y +
          ' C ' + (x - 74) + ' ' + (y - 84) + ', ' + (x + 74) + ' ' + (y - 84) + ', ' + (x + 26) + ' ' + y;
      }
      const x1 = a.x + CARD_W;
      const y1 = a.y + CARD_H / 2;
      const x2 = b.x;
      const y2 = b.y + CARD_H / 2;
      const dir = x2 >= x1 ? 1 : -1;
      const bend = Math.max(52, Math.abs(x2 - x1) * 0.42);
      return 'M ' + x1 + ' ' + y1 +
        ' C ' + (x1 + dir * bend) + ' ' + y1 + ', ' + (x2 - dir * bend) + ' ' + y2 + ', ' + x2 + ' ' + y2;
    }

    function triggerText(tr) {
      if (tr.trigger === 'auto') return '⏱ ' + (Number(tr.delay) || 0) + 's';
      if (tr.trigger === 'event') return '⚡ ' + (tr.event || 'event');
      if (tr.trigger === 'key') return '⌨ ' + (tr.key || 'Space');
      if (tr.trigger === 'keyDown') return '⌨↓ ' + (tr.key || 'Space');
      if (tr.trigger === 'keyUp') return '⌨↑ ' + (tr.key || 'Space');
      if (tr.trigger === 'variable') return 'ƒ ' + (tr.variable || 'var') + ' ' + tr.op + ' ' + (tr.value || '');
      return tr.trigger;
    }

    function renderEdges() {
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      const defs = svgEl('defs');
      const defsData = [
        ['fsm-arrow', '#7d9cbe'],
        ['fsm-arrow-sel', '#7dc0ff'],
      ];
      for (const [id, color] of defsData) {
        const marker = svgEl('marker', {
          id, viewBox: '0 0 10 10', refX: '9', refY: '5',
          markerWidth: '7', markerHeight: '7', orient: 'auto',
        });
        marker.appendChild(svgEl('path', { d: 'M0 0 L10 5 L0 10 z', fill: color }));
        defs.appendChild(marker);
      }
      svg.appendChild(defs);

      for (const tr of fsm.transitions) {
        const d = edgePath(tr);
        if (!d) continue;
        const active = selected.type === 'transition' && selected.id === tr.id;
        const path = svgEl('path', {
          d,
          class: 'fsm-edge' + (active ? ' selected' : ''),
          'marker-end': 'url(#' + (active ? 'fsm-arrow-sel' : 'fsm-arrow') + ')',
        });
        svg.appendChild(path);

        const hit = svgEl('path', { d, class: 'fsm-edge-hit' });
        hit.addEventListener('pointerdown', (e) => {
          e.stopPropagation();
          selectTransition(tr.id);
        });
        svg.appendChild(hit);

        let pt = null;
        try { pt = path.getPointAtLength(path.getTotalLength() * 0.5); } catch (e) { /* ignore */ }
        if (!pt) continue;
        const label = svgEl('text', { x: pt.x, y: pt.y - 7, class: 'fsm-edge-label' });
        label.textContent = triggerText(tr);
        svg.appendChild(label);
      }
    }

    function stateActionsSummary(st) {
      if (!st.actions.length) return 'no actions';
      const first = UW.FSM.actionMeta(st.actions[0].type).label;
      return st.actions.length === 1 ? first : first + ' +' + (st.actions.length - 1);
    }

    function renderGraph() {
      sizeCanvas();
      renderEdges();
      canvas.querySelectorAll('.fsm-state').forEach((n) => n.remove());
      cardEls = new Map();
      for (const st of fsm.states) {
        const card = div('fsm-state' + (selected.type === 'state' && selected.id === st.id ? ' selected' : '') +
          (linkFrom === st.id ? ' link-source' : ''));
        card.style.left = st.x + 'px';
        card.style.top = st.y + 'px';
        card.dataset.id = st.id;

        const head = div('fsm-state-head');
        if (st.id === fsm.start) head.appendChild(el('span', 'fsm-star', '★'));
        head.appendChild(el('span', 'fsm-state-name', st.name));
        const link = el('button', 'fsm-state-link', '→');
        link.title = 'Link from this state';
        link.addEventListener('pointerdown', (e) => e.stopPropagation());
        link.addEventListener('click', (e) => {
          e.stopPropagation();
          startLink(st.id);
        });
        head.appendChild(link);
        card.appendChild(head);

        const info = div('fsm-state-info');
        info.appendChild(el('span', 'fsm-state-actions', stateActionsSummary(st)));
        if (st.id === fsm.start) info.appendChild(el('span', 'fsm-start-badge', 'START'));
        card.appendChild(info);

        const connections = fsm.transitions.filter((t) => t.from === st.id).length;
        const out = div('fsm-state-out');
        out.appendChild(el('span', null, connections + (connections === 1 ? ' transition' : ' transitions')));
        card.appendChild(out);

        card.addEventListener('pointerdown', (e) => beginDrag(e, st, card));
        canvas.appendChild(card);
        cardEls.set(st.id, card);
      }
    }

    function beginDrag(e, st, card) {
      if (e.button !== 0) return;
      if (e.target.closest('button')) return;
      e.preventDefault();
      const startX = e.clientX;
      const startY = e.clientY;
      const sx = st.x;
      const sy = st.y;
      let moved = false;
      editor.beginEdit();

      const move = (ev) => {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!moved && Math.hypot(dx, dy) < 3) return;
        moved = true;
        st.x = Math.max(8, Math.min(2400, sx + dx));
        st.y = Math.max(8, Math.min(1800, sy + dy));
        card.style.left = st.x + 'px';
        card.style.top = st.y + 'px';
        sizeCanvas();
        renderEdges();
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
        editor.commitEdit('Move FSM state');
        if (moved) {
          renderAll();
        } else {
          handleStateClick(st);
        }
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', up);
    }

    /* ---------- sidebar widgets ---------- */
    function textInput(value, onChange, label, placeholder, title) {
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'num';
      input.value = value != null ? String(value) : '';
      if (placeholder) input.placeholder = placeholder;
      if (title) input.title = title;
      let editing = false;
      const begin = () => { if (!editing) { editing = true; editor.beginEdit(); } };
      input.addEventListener('focus', begin);
      input.addEventListener('input', () => {
        begin();
        onChange(input.value);
        editor.touch();
      });
      const commit = () => {
        if (editing) {
          editor.commitEdit(label || 'FSM');
          editing = false;
        }
      };
      input.addEventListener('change', commit);
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') input.blur(); });
      return input;
    }

    function paramControl(action, p) {
      const v = action.params[p.key];
      if (p.type === 'number') {
        return ui.numInput(v, (n) => {
          action.params[p.key] = n;
          editor.touch();
        }, {
          step: p.step || 0.1,
          min: p.min,
          max: p.max,
          label: 'FSM action',
        });
      }
      if (p.type === 'color') {
        return ui.colorField(v || '#ffffff', (c) => {
          action.params[p.key] = c;
          editor.touch();
        });
      }
      if (p.type === 'bool') {
        return ui.checkField(p.label, v !== false, (b) => {
          editor.beginEdit();
          action.params[p.key] = b;
          editor.touch();
          editor.commitEdit('FSM action');
        });
      }
      if (p.type === 'select') {
        return ui.selectField(p.options || [], v, (nv) => {
          editor.beginEdit();
          action.params[p.key] = nv;
          editor.touch();
          editor.commitEdit('FSM action');
        });
      }
      return textInput(v, (t) => { action.params[p.key] = t; }, 'FSM action', p.placeholder, p.help);
    }

    function panelTitle(text, onDelete, deleteTitle) {
      const head = div('fsm-panel-title');
      head.appendChild(el('span', null, text));
      if (onDelete) {
        const rm = el('button', 'icon-btn sm');
        rm.appendChild(ui.iconEl('i-trash'));
        rm.title = deleteTitle || 'Delete';
        rm.addEventListener('click', onDelete);
        head.appendChild(rm);
      }
      return head;
    }

    function renderStatePanel(st) {
      sidebar.appendChild(panelTitle('State', () => {
        if (fsm.states.length <= 1) {
          ui.toast('An FSM needs at least one state.', 'warn');
          return;
        }
        change('Delete FSM state', () => {
          fsm.states = fsm.states.filter((s) => s.id !== st.id);
          fsm.transitions = fsm.transitions.filter((t) => t.from !== st.id && t.to !== st.id);
          if (fsm.start === st.id) fsm.start = fsm.states[0].id;
        }, false);
        selected = { type: 'state', id: fsm.start };
        renderAll();
      }, 'Delete state'));

      sidebar.appendChild(row('Name', textInput(st.name, (v) => {
        st.name = v;
        const card = cardEls.get(st.id);
        if (card) card.querySelector('.fsm-state-name').textContent = v;
      }, 'Rename state')));

      const startBtn = el('button', 'btn fsm-wide', st.id === fsm.start ? 'This is the start state' : 'Set as start state');
      startBtn.disabled = st.id === fsm.start;
      startBtn.addEventListener('click', () => {
        change('Set FSM start state', () => { fsm.start = st.id; });
      });
      sidebar.appendChild(startBtn);

      const sec = div('fsm-section');
      const sh = div('fsm-section-head');
      sh.appendChild(el('span', null, 'Actions on entry'));
      sh.appendChild(el('span', 'fsm-count', String(st.actions.length)));
      sec.appendChild(sh);

      st.actions.forEach((action, ai) => {
        const meta = UW.FSM.actionMeta(action.type);
        const cat = UW.FSM.categoryMeta(meta.category);
        const card = div('fsm-action-card');
        const ah = div('fsm-action-head');
        ah.appendChild(el('span', 'fsm-action-cat', cat.label));
        ah.appendChild(el('span', 'fsm-action-name', meta.label));
        const rm = el('button', 'icon-btn sm');
        rm.appendChild(ui.iconEl('i-close'));
        rm.title = 'Remove action';
        rm.addEventListener('click', () => {
          change('Remove FSM action', () => { st.actions.splice(ai, 1); });
        });
        ah.appendChild(rm);
        card.appendChild(ah);
        if (meta.help) card.appendChild(el('div', 'fsm-action-help', meta.help));
        for (const p of meta.params) {
          card.appendChild(row(p.label, paramControl(action, p), 'fsm-param'));
        }
        sec.appendChild(card);
      });

      const addRow = div('fsm-add-action');
      const grouped = [];
      for (const cat of UW.FSM.categories) {
        for (const a of UW.FSM.actionsInCategory(cat.id)) {
          grouped.push({ value: a.id, label: a.label, group: cat.label });
        }
      }
      const typeSel = ui.selectField(grouped, 'log', () => {});
      addRow.appendChild(typeSel);
      const add = el('button', 'btn', 'Add');
      add.addEventListener('click', () => {
        change('Add FSM action', () => { st.actions.push(UW.FSM.defaultAction(typeSel.value)); });
      });
      addRow.appendChild(add);
      sec.appendChild(addRow);
      sec.appendChild(el('div', 'fsm-action-note', 'Actions run in order. Tween actions can wait for completion. Every action uses the shared runtime, so it behaves the same on all engines.'));
      sidebar.appendChild(sec);
    }

    function renderTransitionPanel(tr) {
      sidebar.appendChild(panelTitle('Transition', () => {
        change('Delete FSM transition', () => {
          fsm.transitions = fsm.transitions.filter((t) => t.id !== tr.id);
        }, false);
        selected = { type: 'state', id: tr.from };
        renderAll();
      }, 'Delete transition'));

      const ends = div('fsm-ends');
      ends.appendChild(el('span', null, (stateById(tr.from) || {}).name || '?'));
      ends.appendChild(el('span', 'fsm-ends-arrow', '→'));
      ends.appendChild(el('span', null, (stateById(tr.to) || {}).name || '?'));
      sidebar.appendChild(ends);

      sidebar.appendChild(row('Trigger', ui.selectField(
        UW.FSM.triggerTypes.map((t) => ({ value: t.id, label: t.label })),
        tr.trigger,
        (v) => { change('FSM trigger', () => { tr.trigger = v; }); }
      )));

      if (tr.trigger === 'auto') {
        sidebar.appendChild(row('Delay', ui.numInput(tr.delay, (v) => {
          tr.delay = Math.max(0, v);
          editor.touch();
        }, { step: 0.1, min: 0, label: 'FSM transition' })));
      } else if (tr.trigger === 'event') {
        sidebar.appendChild(row('Event', textInput(tr.event, (v) => { tr.event = v; }, 'FSM transition')));
      } else if (tr.trigger === 'key' || tr.trigger === 'keyDown' || tr.trigger === 'keyUp') {
        sidebar.appendChild(row('Key', textInput(tr.key, (v) => { tr.key = v; }, 'FSM transition', 'Space')));
        const keyHelp = tr.trigger === 'key'
          ? 'True while the key is held down.'
          : tr.trigger === 'keyDown'
            ? 'Fires once on the frame the key is pressed.'
            : 'Fires once on the frame the key is released.';
        sidebar.appendChild(el('div', 'help-note', 'Use KeyboardEvent.key names, for example Space, Enter, a or ArrowUp. ' + keyHelp));
      } else if (tr.trigger === 'variable') {
        sidebar.appendChild(row('Variable', textInput(tr.variable, (v) => { tr.variable = v; }, 'FSM transition')));
        sidebar.appendChild(row('Operator', ui.selectField(
          UW.FSM.ops.map((o) => ({ value: o, label: o })),
          tr.op,
          (v) => { change('FSM condition', () => { tr.op = v; }); }
        )));
        sidebar.appendChild(row('Value', textInput(tr.value, (v) => { tr.value = v; }, 'FSM transition')));
      }
      sidebar.appendChild(el('div', 'help-note', 'Transitions are checked every frame while the source state is active. The first matching transition is taken.'));
    }

    function renderOverview() {
      sidebar.appendChild(panelTitle('Finite State Machine'));
      sidebar.appendChild(el('div', 'help-note', 'Click a state card or a transition arrow in the graph to edit it. Drag state cards to arrange the graph.'));
      const start = stateById(fsm.start);
      if (start) {
        sidebar.appendChild(row('Start', ui.selectField(
          fsm.states.map((s) => ({ value: s.id, label: s.name })),
          fsm.start,
          (v) => { change('FSM start state', () => { fsm.start = v; }); }
        )));
      }
    }

    function renderVariables() {
      const sec = div('fsm-section fsm-vars');
      const sh = div('fsm-section-head');
      sh.appendChild(el('span', null, 'Variables'));
      sh.appendChild(el('span', 'fsm-count', String(fsm.variables.length)));
      sec.appendChild(sh);

      fsm.variables.forEach((v, i) => {
        const line = div('fsm-var-row');
        line.appendChild(textInput(v.name, (t) => {
          v.name = t;
          v.value = v.value;
          editor.touch();
        }, 'FSM variable'));
        line.appendChild(textInput(v.value, (t) => { v.value = t; }, 'FSM variable'));
        const rm = el('button', 'icon-btn sm');
        rm.appendChild(ui.iconEl('i-close'));
        rm.title = 'Remove variable';
        rm.addEventListener('click', () => {
          change('Remove FSM variable', () => { fsm.variables.splice(i, 1); });
        });
        line.appendChild(rm);
        sec.appendChild(line);
      });

      const add = el('button', 'btn fsm-wide', '+ Add variable');
      add.addEventListener('click', () => {
        let n = fsm.variables.length + 1;
        let name = 'var' + n;
        while (fsm.variables.some((v) => v.name === name)) name = 'var' + (++n);
        change('Add FSM variable', () => { fsm.variables.push({ name, value: '0' }); });
      });
      sec.appendChild(add);
      sidebar.appendChild(sec);
    }

    function renderSidebar() {
      while (sidebar.firstChild) sidebar.removeChild(sidebar.firstChild);
      if (selected.type === 'transition') {
        const tr = fsm.transitions.find((t) => t.id === selected.id);
        if (tr) renderTransitionPanel(tr);
        else selected = { type: 'state', id: fsm.start };
      }
      if (selected.type === 'state') {
        const st = stateById(selected.id);
        if (st) renderStatePanel(st);
        else selected = { type: 'state', id: fsm.start };
      }
      if (selected.type === 'state' && !stateById(selected.id)) renderOverview();
      if (selected.type === 'transition') {
        if (!fsm.transitions.some((t) => t.id === selected.id)) renderOverview();
      }
      if (!sidebar.firstChild) renderOverview();
      renderVariables();
    }

    function renderAll() {
      renderGraph();
      renderSidebar();
      syncTopbar();
    }

    canvas.addEventListener('pointerdown', (e) => {
      if (e.target !== canvas && e.target !== svg) return;
      selected = { type: 'state', id: fsm.start };
      renderAll();
    });

    ui.openModal({
      title: 'FSM Graph — ' + node.name,
      icon: 'i-link',
      cls: 'graph-modal',
      body,
      actions: [{ label: 'Done', kind: 'primary' }],
      onClose: () => ui.renderInspector(),
    });

    syncTopbar();
    renderAll();
  };
})();
