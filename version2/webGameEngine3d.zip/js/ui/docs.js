/* ============================================================
   docs.js — searchable documentation manual
   A built-in manual with live search over:
     • hand-written topics (interface, objects, materials, lights,
       models, physics, scripting, FSMs, scenes, networking,
       engines, troubleshooting)
     • every FSM action, generated from UW.FSM.actionTypes so it
       always matches the shipped feature set
     • the script ctx API from the runtime

   Open it with F1 or Help → Documentation manual.
   ============================================================ */
(function () {
  'use strict';
  const UW = (window.UnityWeb = window.UnityWeb || {});

  /* ------------------------------------------------------------
     corpus
     ------------------------------------------------------------ */
  const STATIC_TOPICS = [
    {
      id: 'interface',
      category: 'Basics',
      title: 'Interface & layout',
      keywords: 'layout panels hierarchy inspector project console window ui',
      body:
        '<p class="help-p">The layout mirrors Unity: <b>Hierarchy</b> on the left, the <b>Scene / Game viewport</b> in the middle, the <b>Inspector</b> on the right, the <b>Project / Assets panel</b> and <b>Console</b> at the bottom.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Hierarchy</b> — every object in the scene as a tree. Drag to re-parent, double-click to focus, right-click for context actions.</li>' +
        '<li><b>Viewport</b> — orbit with <kbd>LMB</kbd> drag, pan with <kbd>MMB</kbd> or <kbd>Shift+LMB</kbd>, zoom with the wheel. Double-click an object to select and frame it.</li>' +
        '<li><b>Inspector</b> — properties of the selected object: transform, components, tags, materials, physics, scripts, FSMs.</li>' +
        '<li><b>Project panel</b> — saved scenes and quick actions.</li>' +
        '<li><b>Console</b> — logs from scripts, FSMs, the runtime and imports (max 300 lines).</li>' +
        '</ul>' +
        '<p class="help-p">The toolbar switches tool (select / move / rotate / scale), play / pause / step / stop, and the rendering engine.</p>',
    },
    {
      id: 'navigation',
      category: 'Basics',
      title: 'Viewport navigation & camera',
      keywords: 'camera orbit pan zoom focus view game scene viewmodes',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Orbit</b> — drag with the left mouse button.</li>' +
        '<li><b>Pan</b> — middle mouse button or <kbd>Shift</kbd> + left drag.</li>' +
        '<li><b>Zoom</b> — mouse wheel.</li>' +
        '<li><b>Focus</b> — select an object and press <kbd>F</kbd> (or double-click it in the viewport / hierarchy).</li>' +
        '<li><b>Game view</b> — the view mode dropdown in the toolbar switches between <b>Scene</b> (editor camera) and <b>Game</b> (a Camera object\'s view). Add a Camera from GameObject → Camera.</li>' +
        '</ul>' +
        '<p class="help-p">Holding <kbd>Shift</kbd> while dragging a gizmo snaps movement to a grid and rotation to 15° steps.</p>',
    },
    {
      id: 'shortcuts',
      category: 'Basics',
      title: 'Keyboard shortcuts',
      keywords: 'keys shortcuts hotkeys f1 keyboard bindings',
      body:
        '<table class="docs-table"><tbody>' +
        '<tr><td>Q / W / E / R</td><td>Select / Move / Rotate / Scale tool</td></tr>' +
        '<tr><td>F</td><td>Focus selected object</td></tr>' +
        '<tr><td>Ctrl + P</td><td>Play / stop</td></tr>' +
        '<tr><td>Ctrl + Shift + P</td><td>Pause</td></tr>' +
        '<tr><td>Ctrl + Z / Y</td><td>Undo / redo</td></tr>' +
        '<tr><td>Ctrl + D</td><td>Duplicate object</td></tr>' +
        '<tr><td>Del</td><td>Delete object</td></tr>' +
        '<tr><td>Ctrl + N / O / S</td><td>New / open / save scene</td></tr>' +
        '<tr><td>Shift while dragging</td><td>Snap translate / rotate</td></tr>' +
        '<tr><td>F1</td><td>Open this documentation manual</td></tr>' +
        '</tbody></table>',
    },
    {
      id: 'creating-objects',
      category: 'Objects & components',
      title: 'Creating objects',
      keywords: 'create add gameobject primitive cube sphere cylinder cone torus capsule plane empty light camera',
      body:
        '<p class="help-p">Use the <b>GameObject</b> menu:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>3D Object</b> — Cube, Sphere, Cylinder, Cone, Torus, Capsule, Plane.</li>' +
        '<li><b>Create Empty</b> — a plain transform node, useful as a group or container.</li>' +
        '<li><b>Light</b> — Directional (sun), Point, or Spot.</li>' +
        '<li><b>Camera</b> — for the Game view.</li>' +
        '</ul>' +
        '<p class="help-p">New objects spawn at the camera target. When a mesh or empty is selected, new objects become its children (use Ctrl+D or drag in the hierarchy to reorganise). Imported models come from <b>File → Import 3D model (.glb / .obj / .blend)…</b> — see the Models section.</p>',
    },
    {
      id: 'transform',
      category: 'Objects & components',
      title: 'Transforms & gizmos',
      keywords: 'transform position rotation scale gizmo local world space move rotate snap',
      body:
        '<p class="help-p">Every object has <b>Position</b>, <b>Rotation</b> (Euler degrees) and <b>Scale</b>, editable in the Inspector or with gizmos (W / E / R).</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Local / World</b> toggle in the toolbar — whether gizmo axes follow the object\'s rotation.</li>' +
        '<li><b>Snap</b> — hold <kbd>Shift</kbd> while dragging for grid / 15° snapping.</li>' +
        '<li><b>Reset</b> — the ⌂ button next to the Transform header restores 0/0/1.</li>' +
        '<li>Children inherit their parent\'s transform, exactly like Unity.</li>' +
        '</ul>',
    },
    {
      id: 'inspector',
      category: 'Objects & components',
      title: 'Inspector & components',
      keywords: 'inspector components add rigidbody script fsm texture behaviors mesh renderer',
      body:
        '<p class="help-p">The Inspector shows the selected object\'s header (name, tag, active, visible) followed by its components:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Transform</b> — always present.</li>' +
        '<li><b>Mesh Renderer</b> — shape or imported model, color, roughness, metalness, opacity, wireframe.</li>' +
        '<li><b>Texture / Material</b> — preset or uploaded texture with tiling &amp; offset (Add Component → Texture).</li>' +
        '<li><b>Rigidbody</b> — physics (see Physics).</li>' +
        '<li><b>Behaviors</b> — Spin, Bob, Pulse, Orbit presets.</li>' +
        '<li><b>JavaScript Script</b> — custom code (see Scripting).</li>' +
        '<li><b>PlayMaker FSM</b> — visual state machine (see FSM).</li>' +
        '</ul>' +
        '<p class="help-p">Add components from the <b>Component</b> menu or <b>Add Component</b>; remove them with the ✕ on each section.</p>',
    },
    {
      id: 'tags-active',
      category: 'Objects & components',
      title: 'Tags, active & visible',
      keywords: 'tag tags active deactivate visible find compare player enemy setactive gameobject',
      body:
        '<p class="help-p">Every object has a free-text <b>Tag</b> (Inspector header) with Unity-style suggestions — Player, Enemy, Pickup…</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Active</b> — Unity GameObject semantics: an inactive object stops rendering, colliding and running scripts / behaviors / FSMs, and <b>its whole subtree is disabled too</b>. Toggle in the Inspector or the hierarchy.</li>' +
        '<li><b>Visible</b> — only toggles that object\'s renderer (children keep rendering).</li>' +
        '</ul>' +
        '<p class="help-p">Related FSM actions: <b>Set tag</b>, <b>Get tag</b>, <b>Find object by tag</b>, <b>Compare tag</b>, <b>Activate / deactivate</b>, <b>Toggle active</b>. Script equivalents: <code>ctx.findByTag(tag)</code> and <code>ctx.setActive(node, bool)</code>.</p>',
    },
    {
      id: 'hierarchy',
      category: 'Objects & components',
      title: 'Hierarchy & parenting',
      keywords: 'hierarchy parent child children drag drop duplicate delete empty group organize',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Drag</b> one object onto another to re-parent it; drop on empty space to move it to the scene root.</li>' +
        '<li><b>Double-click</b> a name to focus the object in the viewport.</li>' +
        '<li><b>Ctrl + D</b> duplicates the selected object <i>with its whole subtree</i>.</li>' +
        '<li>Struck-through names are inactive objects (their children are disabled too).</li>' +
        '<li>Imported models arrive as a container node with the model\'s node hierarchy below it.</li>' +
        '</ul>',
    },
    {
      id: 'materials',
      category: 'Materials & textures',
      title: 'Materials (color, roughness, metalness)',
      keywords: 'material color colour roughness metalness opacity wireframe pbr shading',
      body:
        '<p class="help-p">Mesh Renderer properties drive a physically-based look on every engine:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Color</b> — base albedo color (hex).</li>' +
        '<li><b>Roughness</b> — 0 = mirror-like, 1 = diffuse/matte.</li>' +
        '<li><b>Metalness</b> — 0 = dielectric, 1 = metal.</li>' +
        '<li><b>Opacity</b> — below 1 makes the mesh transparent.</li>' +
        '<li><b>Wireframe</b> — render edges only.</li>' +
        '</ul>' +
        '<p class="help-p">Imported models pick up their glTF material\'s base color, metallic / roughness factors, alpha and double-sidedness; you can override them per object afterwards.</p>',
    },
    {
      id: 'textures',
      category: 'Materials & textures',
      title: 'Textures & presets',
      keywords: 'texture preset checker bricks tiles noise gradient upload image tiling offset material',
      body:
        '<p class="help-p">Add a <b>Texture / Material</b> component (Component menu or Add Component), then pick one of the procedural presets — checker, grid, bricks, tiles, noise, gradient, stripes, dots, wood, marble — or upload an image. <b>Tiling</b> repeats the texture across the UVs; <b>Offset</b> shifts it.</p>' +
        '<p class="help-p">Uploaded and painted textures are stored as data URLs inside the scene JSON (8 MB per texture cap). glTF base-color textures from imported models become uploaded textures automatically.</p>',
    },
    {
      id: 'texture-editor',
      category: 'Materials & textures',
      title: 'Texture editor',
      keywords: 'paint painter brush eraser flood fill line rectangle mirror undo export png import image',
      body:
        '<p class="help-p">Select a mesh and open <b>Window → Texture Editor…</b>. Tools: brush, eraser, flood fill, line, rectangle, ellipse, picker. Options include size, hardness, mirroring (X/Y), and a live tiling preview. There is per-stroke undo / redo, PNG export and image import. Painting works on the shared texture object, so every engine shows it identically.</p>',
    },
    {
      id: 'lights',
      category: 'Lights & environment',
      title: 'Lights',
      keywords: 'light directional point spot intensity range angle penumbra color shadow',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Directional</b> — sun-like parallel rays, casts shadows.</li>' +
        '<li><b>Point</b> — omnidirectional with <b>Range</b> falloff.</li>' +
        '<li><b>Spot</b> — cone with <b>Range</b>, <b>Angle</b> and <b>Penumbra</b>.</li>' +
        '</ul>' +
        '<p class="help-p">Change <b>Color</b> and <b>Intensity</b> in the Inspector. When all lights are inactive the renderer falls back to a soft built-in light so the scene never goes fully black. The Native Canvas engine renders shadows approximately; Three.js and Babylon.js use real shadow maps.</p>',
    },
    {
      id: 'environment',
      category: 'Lights & environment',
      title: 'Environment & fog',
      keywords: 'environment ambient grid fog background color showgrid',
      body:
        '<p class="help-p"><b>Window → Environment / Lighting…</b> controls scene-wide settings: <b>ambient intensity</b> and color, the ground grid, and <b>distance fog</b> (color, near, far). Fog fades objects into the background with distance — useful for depth cues. All of these can also be changed at runtime through the FSM actions <b>Set ambient light</b> and <b>Set fog</b>, or via scripts with <code>ctx.scene.env</code>.</p>',
    },
    {
      id: 'model-import',
      category: 'Models',
      title: 'Importing models (.glb / .gltf / .obj / .blend)',
      keywords: 'import model glb gltf obj blend blender mesh wavefront mtl texture import upload drag drop file 3d asset',
      body:
        '<p class="help-p"><b>File → Import 3D model…</b> or simply drag model files onto the viewport. Supported formats: <b>.glb</b>, <b>.gltf</b>, <b>.obj</b> (with <b>.mtl</b> and texture images) and <b>.blend</b> (Blender).</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Every parser is built in — no CDN, no build step, works offline and on every engine.</li>' +
        '<li>The file\'s <b>node hierarchy</b> is recreated under a container object named after the file, with positions, rotations and scales.</li>' +
        '<li><b>Materials</b>: base color, metallic / roughness factors, transparency and double-sidedness are applied; embedded <b>textures</b> become texture components.</li>' +
        '<li>Missing normals get flat per-triangle normals; missing UVs get planar UVs so textures still map.</li>' +
        '<li>The model file is stored <b>once</b> in the scene (<code>scene.models</code>); every mesh node references it by <code>modelId</code> + mesh / primitive index, so duplicating a model\'s nodes is cheap.</li>' +
        '<li>Models survive save / load / undo like any scene data. The HUD shows a model count.</li>' +
        '</ul>' +
        '<p class="help-p">glTF support: glTF 2.0, GLB binary containers, data-URI buffers, indexed or plain triangles, all component types (byte / short / int / float). OBJ support: v/vt/vn data, polygon faces (fan-triangulated), <code>o</code> / <code>g</code> groups as child meshes, <code>usemtl</code> materials from a companion <code>.mtl</code> and embedded texture images (drop the <code>.obj</code>, <code>.mtl</code> and <code>.png</code> files together). Blender support: mesh + object hierarchy, transforms, materials and UVs from modern and classic saves (2.63 → 4.x), including gzip-compressed saves; Blender files are Z-up so the root gets a −90° X rotation.</p>' +
        '<p class="help-p">Not supported (skipped with a Console warning): glTF animations, skins, morph targets, cameras, lights and external .bin / image files; Blender curves, lattices, lights, modifiers that were not applied and animation data. Non-triangle primitive modes are skipped.</p>',
    },
    {
      id: 'model-import-tips',
      category: 'Models',
      title: 'Import tips for OBJ and Blender files',
      keywords: 'obj blend blender mtl texture image png jpeg tips units scale axis z-up compressed gzip',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>OBJ + textures:</b> drop / pick the <code>.obj</code>, its <code>.mtl</code> and the image files together — they are embedded into the scene so everything works offline. Only PNG / JPEG / WebP / GIF / BMP images can be embedded.</li>' +
        '<li><b>Blender units:</b> 1 Blender unit imports as 1 world unit (metres). Apply transforms (Ctrl+A) in Blender if an object looks wrong.</li>' +
        '<li><b>Z-up → Y-up:</b> the imported root is rotated −90° on X, exactly like Unity\'s Blender importer; every child keeps its local Blender transform.</li>' +
        '<li><b>Compressed saves:</b> gzip-compressed .blend files are supported by a built-in decompressor, but uncompressed saves load faster.</li>' +
        '<li><b>N-gons</b> are fan-triangulated (quad-safe); Blender\'s own triangulator may split differently.</li>' +
        '<li><b>Modifiers:</b> apply them in Blender before saving — the importer reads the stored mesh, not the modifier stack.</li>' +
        '<li>One model file = one container object with children per mesh / group, so re-parenting pieces is easy. Select the container to move the whole model.</li>' +
        '</ul>',
    },
    {
      id: 'physics',
      category: 'Physics',
      title: 'Rigidbody physics',
      keywords: 'physics rigidbody gravity mass drag freeze restitution collision ground fall bounce force impulse velocity',
      body:
        '<p class="help-p">Add a <b>Rigidbody</b> component (only meshes) and press Play:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Mass</b>, <b>Drag</b> (air resistance), <b>Restitution</b> (bounciness) and per-axis <b>freeze</b>.</li>' +
        '<li>Bodies fall with scene gravity, collide against the ground plane (y = 0) and other meshes\' world AABBs, and roll to rest.</li>' +
        '<li>Scripts can push bodies with <code>ctx.node.rigidbody.velocity</code>, and the FSM <b>Apply force / impulse</b> actions exist too.</li>' +
        '<li>Imported model nodes participate like any mesh — their world AABB is computed from the model geometry.</li>' +
        '</ul>' +
        '<p class="help-p">Physics runs in the shared runtime, so it behaves identically on every engine. Only root objects collide with each other.</p>',
    },
    {
      id: 'raycast',
      category: 'Physics',
      title: 'Raycast',
      keywords: 'raycast ray hit physics mouse direction distance origin',
      body:
        '<p class="help-p">The FSM <b>Raycast</b> action casts a ray from an object toward a direction and stores what it hits (name / point / distance / normal in variables). Scripts can use the runtime through actions; the editor\'s own picking (double-click) also uses AABB raycasts. Inactive objects are skipped.</p>',
    },
    {
      id: 'scripting',
      category: 'Scripting',
      title: 'JavaScript scripts',
      keywords: 'script javascript code onstart onupdate onstop behavior custom function',
      body:
        '<p class="help-p">Add a <b>JavaScript Script</b> component and edit it in the built-in editor. Scripts run only in Play mode; stopping restores the scene.</p>' +
        '<pre class="docs-code">function onStart(ctx) {\n  ctx.log("ready: " + ctx.node.name);\n}\n\nfunction onUpdate(ctx, dt) {\n  ctx.node.transform.rotation.y += 55 * dt;\n}</pre>' +
        '<p class="help-p">Hooks: <code>onStart(ctx)</code>, <code>onUpdate(ctx, dt)</code>, <code>onStop(ctx)</code>. Compile and runtime errors are reported in the Console. See the <b>Script ctx API</b> entries for everything on <code>ctx</code>.</p>',
    },
    {
      id: 'fsm',
      category: 'PlayMaker FSM',
      title: 'PlayMaker FSM overview',
      keywords: 'fsm playmaker state machine states graph transitions events variables',
      body:
        '<p class="help-p">A <b>PlayMaker FSM</b> component gives an object a visual state machine: <b>states</b> connected by <b>transitions</b>, with <b>actions</b> that run when a state is entered and <b>variables</b> shared between them.</p>' +
        '<ul class="docs-list-bullets">' +
        '<li>Build it in <b>Window → FSM Graph Editor…</b> — add states, wire transitions, pick actions.</li>' +
        '<li>One state is the <b>start</b> state; it runs the moment Play begins.</li>' +
        '<li>Transitions fire on delay, event, key held / down / up, or a variable comparison — first match wins, checked every frame.</li>' +
        '<li>FSMs run in the shared runtime: identical behavior on every engine.</li>' +
        '</ul>' +
        '<p class="help-p">Search this manual for <b>action</b> to browse all ' + (UW.FSM ? UW.FSM.actionTypes.length : '89') + ' built-in actions.</p>',
    },
    {
      id: 'fsm-transitions',
      category: 'PlayMaker FSM',
      title: 'Transitions & triggers',
      keywords: 'transition trigger delay event key keydown keyup variable condition compare branch',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>After delay</b> — fires once N seconds passed in the state.</li>' +
        '<li><b>On event</b> — fires when that FSM event is broadcast (Send event action, scripts, other FSMs).</li>' +
        '<li><b>Key held / down / up</b> — keyboard edges via the input state.</li>' +
        '<li><b>Variable compare</b> — fires while / when a variable meets a comparison.</li>' +
        '</ul>' +
        '<p class="help-p">Transitions are evaluated every frame in declaration order from the current state; the first that matches fires.</p>',
    },
    {
      id: 'fsm-graph',
      category: 'PlayMaker FSM',
      title: 'FSM graph editor',
      keywords: 'graph editor fsm add state action transition wire drag canvas zoom',
      body:
        '<p class="help-p"><b>Window → FSM Graph Editor…</b> (or Component → PlayMaker FSM) opens the node graph: create states, drag them around, connect ports to make transitions, and configure the selected state\'s action list. Actions can be reordered; tween actions can <i>block</i> the rest of the list until they finish. Variables live at the bottom of the panel.</p>',
    },
    {
      id: 'scenes',
      category: 'Scenes & files',
      title: 'Saving & loading scenes',
      keywords: 'save load scene localstorage download json import new open storage',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Ctrl + S / File → Save Scene</b> — stores the scene in browser localStorage under a name.</li>' +
        '<li><b>Ctrl + O / Open Scene…</b> — lists saved scenes; load or delete them.</li>' +
        '<li><b>Download scene as .json</b> — full backup file including imported models (base64 data URLs).</li>' +
        '<li><b>Import scene .json…</b> or drop a .json on the viewport — restores everything.</li>' +
        '<li>The FSM action <b>Go to scene</b> switches scenes at runtime; <b>Go to scene URL</b> fetches one from a server.</li>' +
        '</ul>' +
        '<p class="help-p">Very large models can exceed the browser storage quota (a few MB) — prefer downloading the .json in that case.</p>',
    },
    {
      id: 'json-format',
      category: 'Scenes & files',
      title: 'Scene JSON format',
      keywords: 'json format schema version nodes models export import file structure',
      body:
        '<pre class="docs-code">{\n  "version": 1,\n  "name": "My Scene",\n  "env": { "ambient": 0.42, "showGrid": true, ... },\n  "models": [                        // imported glTF assets\n    { "id": "mdl_x9", "name": "robot",\n      "format": "glb",\n      "data": "data:model/gltf-binary;base64,..." }\n  ],\n  "nodes": [\n    { "id": "n_cube", "name": "Cube", "parent": null,\n      "type": "mesh", "tag": "", "active": true, "visible": true,\n      "transform": { "position": [0,0.5,0], "rotation": [0,0,0], "scale": [1,1,1] },\n      "mesh": { "shape": "cube", "color": "#c7cdd6", ... },\n      "rigidbody": { "mass": 1, ... },          // optional\n      "behaviors": [], "script": {...}, "fsm": {...} }\n  ]\n}</pre>' +
        '<p class="help-p">A mesh that renders an imported model uses <code>mesh: { shape: "model", modelId: "mdl_x9", meshIndex: 0, primitiveIndex: 0, ... }</code> pointing into <code>models[]</code>. Multiple nodes can share one model record.</p>',
    },
    {
      id: 'networking',
      category: 'Networking',
      title: 'HTTP requests & PHP',
      keywords: 'network http fetch php request get post json api server load scene url',
      body:
        '<p class="help-p">The FSM <b>HTTP request</b> action performs GET / POST calls with JSON bodies and headers; responses become FSM variables (status, body, parsed fields). Pair it with <b>Go to scene URL</b> to stream level files from a PHP endpoint, or <b>Format string</b> to compose payloads. This is the supported way to talk to a server — scripts run in a sandboxed context without fetch, so use actions for networking.</p>',
    },
    {
      id: 'engines',
      category: 'Engines & plugins',
      title: 'Rendering engines',
      keywords: 'engine three babylon native canvas renderer switch offline cdn fallback',
      body:
        '<p class="help-p">Pick a renderer from the toolbar dropdown or the Engine menu:</p>' +
        '<ul class="docs-list-bullets">' +
        '<li><b>Three.js</b> — WebGL, loaded on demand from its CDN.</li>' +
        '<li><b>Babylon.js</b> — WebGL, loaded on demand from its CDN.</li>' +
        '<li><b>Native Canvas</b> — the built-in software renderer; works fully offline.</li>' +
        '</ul>' +
        '<p class="help-p">Switching is instant and never touches the scene — every engine reads the same scene model, including imported models. Check <b>Window → Engine Compatibility…</b> for the feature matrix. Heavy imported models render fastest on the WebGL engines.</p>',
    },
    {
      id: 'plugins',
      category: 'Engines & plugins',
      title: 'Engine plugins',
      keywords: 'plugin adapter register custom engine sdk api unityweb engines connect',
      body:
        '<p class="help-p">Register your own renderer at runtime with <code>UnityWeb.engines.register({...})</code> — it appears in the Engine menu instantly. An adapter implements <code>load()</code>, <code>create(def)</code> → <code>{ init, resize, update, render, getStats, dispose }</code>. Read geometry through <code>UnityWeb.geom.forNode(node)</code> (works for primitives and imported models), lights through <code>UnityWeb.scene.collectLights</code> and textures through <code>UnityWeb.textures.getTiled</code>. See <b>Help → Scripting &amp; plugin API</b> and <code>plugins/README.md</code> for the full surface.</p>',
    },
    {
      id: 'play-mode',
      category: 'Basics',
      title: 'Play mode',
      keywords: 'play pause stop step runtime simulate run test gamectrl',
      body:
        '<p class="help-p"><b>Ctrl + P</b> starts Play mode: rigidbodies simulate, behaviors / scripts / FSMs run, and the toolbar shows pause / single-step. <b>Stop</b> restores the scene exactly as it was — any runtime change (moves, activations, spawned clones) is reverted.</p>' +
        '<p class="help-p">The FSM <b>Exit to editor</b> action stops play from inside the game; <b>Restart scene</b> reloads the pre-play state while staying in play mode.</p>',
    },
    {
      id: 'troubleshooting',
      category: 'Troubleshooting',
      title: 'Troubleshooting',
      keywords: 'troubleshoot problem error blank black scene slow storage quota import fails not visible',
      body:
        '<ul class="docs-list-bullets">' +
        '<li><b>Scene is black</b> — all lights may be inactive; the renderer keeps a faint fallback light, but check Environment ambient.</li>' +
        '<li><b>Object not visible</b> — check <b>Visible</b>, <b>Active</b> (parents too — inactive disables the subtree) and opacity.</li>' +
        '<li><b>Model import fails</b> — the Console shows the exact reason: .gltf must embed buffers as data URIs (export .glb instead); OBJ needs faces; .blend must be saved by Blender 2.63+ with mesh data (apply modifiers); non-triangle modes are skipped.</li>' +
        '<li><b>Save fails</b> — browser storage is full, usually from big model data URLs; download the scene as .json instead.</li>' +
        '<li><b>Slow viewport</b> — heavy models render faster on Three.js / Babylon.js than Native Canvas; reduce triangle counts.</li>' +
        '<li><b>Script does nothing</b> — scripts run only in Play mode; compile errors appear in the Console.</li>' +
        '<li><b>Undo missing a step</b> — some edits are grouped; check the Edit menu\'s undo label.</li>' +
        '</ul>',
    },
  ];

  /* script ctx API entries, derived from the runtime context */
  function scriptApiTopics() {
    const api = [
      ['ctx.node', 'The object this script runs on. Its full data: transform, mesh, light, tag, active…', 'node object self this me'],
      ['ctx.scene', 'The whole scene model: nodes, models, env — read/modify it live.', 'scene nodes models env world'],
      ['ctx.find(name)', 'Find a node by exact name. Returns the node object or null.', 'find search name lookup object'],
      ['ctx.findByTag(tag)', 'Find the first <b>active</b> object with a tag (case-insensitive).', 'tag find bytag lookup'],
      ['ctx.setActive(nodeOrId, active)', 'Activate or deactivate an object (Unity semantics — children follow).', 'setactive activate deactivate enable disable'],
      ['ctx.setColor(hex)', 'Set this mesh\'s material color, e.g. ctx.setColor("#ff8800").', 'color colour material setcolor'],
      ['ctx.openUrl(url, target)', 'Open a URL in a new tab (or "_self"). Call it from key / click flows so popup blockers allow it.', 'openurl url open link web page'],
      ['ctx.log(...)', 'Write to the editor Console (objects are JSON-stringified).', 'log console print debug message'],
      ['ctx.emitEvent(name)', 'Broadcast an FSM event that transitions can listen for.', 'event emit send fsm trigger'],
      ['ctx.time / ctx.dt', 'Seconds since play started / seconds since last frame.', 'time delta dt seconds elapsed'],
      ['ctx.editor / ctx.engine', 'The editor instance (undo, selection, logging) and the active engine\'s name.', 'editor engine name access'],
      ['ctx.vec / ctx.math', 'The shared math helpers: vector ops, matrices, clamp, lerp…', 'math vec vector helpers lerp clamp'],
    ];
    return api.map(([title, body, keywords]) => ({
      id: 'api-' + title.replace(/[^a-z]/gi, ''),
      category: 'Scripting API',
      title: title,
      keywords: 'script api ' + keywords,
      body: '<p class="help-p"><code>' + title + '</code> — ' + body + '</p>' +
        '<p class="help-p"><i>See also:</i> JavaScript scripts, PlayMaker FSM.</p>',
    }));
  }

  /* FSM action entries, derived from UW.FSM so they never go stale */
  function fsmActionTopics() {
    const F = UW.FSM;
    if (!F || !F.actionTypes) return [];
    const catLabel = {};
    (F.categories || []).forEach((c) => { catLabel[c.id] = c.label; });
    return F.actionTypes.map((a) => {
      const params = (a.params || []).map((p) => {
        const type = p.type || 'value';
        const def = p.def != null ? String(p.def) : '';
        return '<tr><td>' + p.label + '</td><td>' + type + '</td><td>' + (def || '—') + '</td></tr>';
      }).join('');
      const paramKeywords = (a.params || []).map((p) => (p.key || '') + ' ' + (p.label || '')).join(' ');
      return {
        id: 'action-' + a.id,
        category: 'FSM actions · ' + (catLabel[a.category] || a.category),
        title: a.label,
        keywords: 'fsm action ' + a.id + ' ' + (a.category || '') + ' ' + paramKeywords,
        body:
          '<p class="help-p">' + (a.help || '') + '</p>' +
          (params
            ? '<table class="docs-table"><thead><tr><th>Parameter</th><th>Type</th><th>Default</th></tr></thead><tbody>' + params + '</tbody></table>'
            : '<p class="help-p"><i>No parameters.</i></p>') +
          '<p class="help-p"><i>Category:</i> ' + (catLabel[a.category] || a.category) + ' · <i>Action id:</i> <code>' + a.id + '</code></p>',
      };
    });
  }

  let cachedEntries = null;
  function entries() {
    if (cachedEntries) return cachedEntries;
    cachedEntries = []
      .concat(STATIC_TOPICS)
      .concat(scriptApiTopics())
      .concat(fsmActionTopics())
      .map((e) => {
        const div = document.createElement('div');
        div.innerHTML = e.body;
        return Object.assign({}, e, {
          titleLower: e.title.toLowerCase(),
          keywordsLower: (e.keywords || '').toLowerCase(),
          categoryLower: (e.category || '').toLowerCase(),
          plainText: (div.textContent || '').toLowerCase(),
        });
      });
    return cachedEntries;
  }

  /* ------------------------------------------------------------
     search
     ------------------------------------------------------------ */
  function scoreEntry(entry, terms) {
    let total = 0;
    for (const t of terms) {
      let s = 0;
      if (entry.titleLower.indexOf(t) >= 0) s += 6 + (entry.titleLower.indexOf(t) === 0 ? 3 : 0);
      if (entry.keywordsLower.indexOf(t) >= 0) s += 4;
      if (entry.categoryLower.indexOf(t) >= 0) s += 3;
      if (entry.plainText.indexOf(t) >= 0) s += 1;
      if (!s) return 0; // every term must match somewhere
      total += s;
    }
    return total;
  }

  function search(query) {
    const terms = String(query || '').toLowerCase().split(/\s+/).filter(Boolean);
    const list = entries();
    if (!terms.length) {
      // relevance-ish default order: static topics, api, then actions
      return list.map((e) => ({ e, s: 1 }));
    }
    const out = [];
    for (const e of list) {
      const s = scoreEntry(e, terms);
      if (s > 0) out.push({ e, s });
    }
    out.sort((a, b) => b.s - a.s || a.e.title.localeCompare(b.e.title));
    return out;
  }

  /* ------------------------------------------------------------
     dialog
     ------------------------------------------------------------ */
  function open(query) {
    if (!UW.UI || !UW.UI.openModal) return;
    const UI = UW.UI;
    const body = UI.div('docs-wrap');

    const bar = UI.div('docs-bar');
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'docs-input';
    input.placeholder = 'Search the manual — try "tag", "tween", "import model", "fog"…';
    bar.appendChild(input);
    const count = UI.el('span', 'docs-count', '');
    bar.appendChild(count);
    body.appendChild(bar);

    const panes = UI.div('docs-panes');
    const listEl = UI.div('docs-list');
    const detail = UI.div('docs-detail');
    const detailInner = UI.div('docs-detail-inner');
    detail.appendChild(detailInner);
    panes.appendChild(listEl);
    panes.appendChild(detail);
    body.appendChild(panes);

    let flat = []; // currently visible entries in display order
    let cursor = -1;

    const renderDetail = (entry) => {
      detailInner.innerHTML = '';
      if (!entry) {
        detailInner.appendChild(UI.el('p', 'help-p', 'Select a topic to read it here.'));
        return;
      }
      detailInner.appendChild(UI.el('div', 'docs-detail-cat', entry.category));
      detailInner.appendChild(UI.el('h3', 'docs-detail-title', entry.title));
      const content = UI.div('docs-detail-body');
      content.innerHTML = entry.body;
      detailInner.appendChild(content);
    };

    const highlight = (row) => {
      const prev = listEl.querySelector('.docs-item.active');
      if (prev) prev.classList.remove('active');
      row.classList.add('active');
      row.scrollIntoView({ block: 'nearest' });
    };

    const selectIndex = (i) => {
      if (!flat.length) return;
      cursor = Math.max(0, Math.min(flat.length - 1, i));
      const item = flat[cursor];
      const rows = listEl.querySelectorAll('.docs-item');
      const row = rows[cursor];
      if (row) highlight(row);
      renderDetail(item.e || item);
    };

    const renderList = () => {
      const q = input.value;
      const results = search(q);
      flat = results.map((r) => r.e);
      listEl.innerHTML = '';
      const shown = flat.slice(0, 60);
      count.textContent = flat.length
        ? flat.length + (flat.length > 60 ? ' matches (showing 60)' : ' matches')
        : 'no matches';

      let lastCat = null;
      let idx = 0;
      for (const entry of shown) {
        if (entry.category !== lastCat) {
          lastCat = entry.category;
          listEl.appendChild(UI.el('div', 'docs-group', lastCat));
        }
        const row = UI.el('div', 'docs-item');
        const t = UI.el('div', 'docs-item-title', entry.title);
        row.appendChild(t);
        const snippet = entry.plainText.slice(0, 90).trim();
        row.appendChild(UI.el('div', 'docs-item-snippet', snippet + (entry.plainText.length > 90 ? '…' : '')));
        const myIndex = idx++;
        row.addEventListener('click', () => selectIndex(myIndex));
        listEl.appendChild(row);
      }
      if (!shown.length) {
        listEl.appendChild(UI.el('div', 'docs-empty', 'Nothing found for "' + q + '". Try a shorter word.'));
      }
      cursor = -1;
      selectIndex(0);
    };

    input.addEventListener('input', renderList);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); selectIndex(cursor + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); selectIndex(cursor - 1); }
      else if (e.key === 'Enter') { e.preventDefault(); selectIndex(cursor < 0 ? 0 : cursor); }
    });

    const modal = UI.openModal({
      title: 'Documentation Manual',
      icon: 'i-help',
      wide: true,
      cls: 'docs-modal',
      body,
      actions: [{ label: 'Close', kind: 'primary' }],
    });

    if (query) input.value = query;
    renderList();
    setTimeout(() => { try { input.focus(); input.select(); } catch (e) { /* ignore */ } }, 30);
    return modal;
  }

  UW.Docs = { open, search, entries };
})();
