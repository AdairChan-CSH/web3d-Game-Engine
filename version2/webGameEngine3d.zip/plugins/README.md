# WebForge 3D — engine plugin guide

WebForge renders scenes through **adapters**. An adapter is a small JavaScript object that receives the shared scene model, draws it with some graphics library, and reports statistics. Everything else — hierarchy, inspector, gizmos, play mode, scripts, saving — is handled by the editor and works with any adapter.

A plugin is just a plain script that registers one or more adapters:

```js
UnityWeb.engines.register({
  id: 'my-engine',
  name: 'My Engine',
  version: '1.0',
  license: 'MIT',
  vendor: 'Example',
  url: 'https://example.com',
  description: 'Renders WebForge scenes with My Engine.',
  badge: 'plugin',

  async load() {
    // inject the runtime once (script tag, dynamic import, wasm, ...)
  },

  create(def) {
    return {
      async init(host) {},
      resize(w, h, dpr) {},
      update(frame) {},
      render() {},
      getStats() { return { triangles: 0, objects: 0, calls: 0 }; },
      dispose() {},
    };
  },
});
```

Load the script with **Engine → Connect engine plugin…**, the `+ Connect engine…` card in the Engines panel, or a `<script>` tag in `index.html`.

- Relative URLs (`plugins/my-engine.js`) work when the editor is served over HTTP. When opening `index.html` from disk, some browsers restrict injected local scripts; add a `<script>` tag instead.
- Remote URLs must be reachable and must allow cross-origin classic-script loading.
- A plugin may call `register()` more than once to expose several engines.
- Registration is immediate; menus read the registry live, and the Connect dialog refreshes the engine picker after the script loads.

---

## Engine definition

`UnityWeb.engines.register(def)` validates `id`, `load()` and `create()`.

| Field | Required | Purpose |
| --- | --- | --- |
| `id` | yes | Unique key, e.g. `"three"`. Used by the picker and `localStorage`. |
| `name` | yes | Display name. |
| `load()` | yes | Async; fetch or inject the runtime. Must be idempotent — it is called every time the engine is selected. |
| `create(def)` | yes | Return a new adapter instance. Called after `load()` resolves. |
| `version` | no | Shown in menus, status bar and engine card. |
| `license` | no | Shown in the engine card and logs. |
| `vendor` | no | Shown in the Engines panel documentation block. |
| `url` | no | “Documentation ↗” link target. |
| `description` | no | Tooltip / engine panel description. |
| `badge` | no | Short tag such as `CDN`, `offline` or `plugin`. |
| `short` | no | One- to three-character logo text; defaults to the first two letters of `name`. |
| `cdn` | no | Informational URL for built-in CDN engines. |
| `capabilities` | no | Renderer feature map used by the compatibility matrix (see below). |

The built-in engines register themselves exactly this way:

- `js/engines/native.js` → `native`
- `js/engines/three.js` → `three`
- `js/engines/babylon.js` → `babylon`
- `plugins/blueprint-canvas.js` → `blueprint` (example)

### `capabilities`

Declare what your renderer can draw. Every value is either a level string or `{ level, note }`:

```js
UnityWeb.engines.register({
  id: 'my-engine',
  name: 'My Engine',
  capabilities: {
    webgl: 'full',
    shadows: { level: 'partial', note: 'One directional shadow map only' },
    directional: 'full',
    point: 'full',
    spot: 'none',
    fog: 'full',
    textures: 'full',
    tiling: 'partial',
    transparency: 'partial',
    wireframe: 'none',
    pbr: { level: 'partial', note: 'Lambert + specular approximation' },
    antialias: 'full',
    offline: { level: 'full', note: 'No CDN required' },
    runtime: 'full',
  },
  // load(), create() ...
});
```

| Level | Meaning |
| --- | --- |
| `full` | Implemented natively and matches the built-in engines. |
| `partial` | Approximate or limited; explain it in `note`. |
| `none` | Not rendered by this adapter. |
| `unknown` | Not declared. This is the default, so the matrix never invents a capability. |

`runtime` defaults to `full` because Play mode, scripts, physics, audio, **all FSM actions**, scene switching and HTTP/PHP network calls are handled by the shared runtime before `update(frame)` is called. Your adapter does not need to know anything about FSMs, rigidbodies or `fetch` — it only draws the transformed scene. A feature your renderer cannot display (for example shadows) still works as scene data and appears when the user switches to a capable engine.

The shared runtime currently provides **89 FSM actions in 14 categories** (flow, scene transitions, transforms and tweens, variables and math, strings, logic, GameObject — including tags and activate/deactivate, material/texture, lighting, camera, physics including force/drag/freeze/raycast, network/PHP, audio, debug). All of them mutate the scene model or the runtime, never a renderer, so they behave identically across every engine. Engine-independent highlights:

- **Physics** — AABB bodies with mass, drag, bounciness, gravity, continuous forces, freeze and raycasts; colliders rebuild when objects are cloned, destroyed or re-parented at runtime.
- **Scene flow** — go to saved scene, go to scene URL, restart, save checkpoint and exit to editor; the editor swaps scenes without touching the adapter (a fresh `update(frame)` frame follows).
- **Networking** — `fetch`-based HTTP with timeout and abort, PHP form posts, JSON path reading and browser navigation.
- **Objects** — clone and destroy objects mid-play, activate/deactivate whole subtrees and query objects by tag; prune your per-node caches by node `id` so removed objects disappear from the next frame.

Read the resolved map at runtime:

```js
UnityWeb.engines.features;                    // feature definitions (id, label, help)
UnityWeb.engines.capabilities(def);           // { id: { level, note } }
UnityWeb.engines.capability(def, 'shadows');  // { level, note }
UnityWeb.engines.defaultCapabilities();       // copy of the defaults
```

The compatibility dialog (**Window → Engine Compatibility…**) and the Engines panel use this data automatically. Omitting `capabilities` is valid; the engine simply shows up as Unknown in every column except Play-mode runtime.

---

## Adapter contract

```js
{
  async init(host) {},        // create canvas/renderer and attach it to host (#stage)
  resize(w, h, dpr) {},       // CSS pixels + device pixel ratio
  update(frame) {},           // receive the latest frame description
  render() {},                // draw one frame
  getStats() {},              // { triangles, objects, calls }
  dispose() {},               // remove DOM and free GPU resources
}
```

### `init(host)`

`host` is the `#stage` element inside the viewport. Append a `<canvas class="engine-canvas">` (or any element) to it. Do not read the scene here — `update()` provides it every frame.

### `resize(w, h, dpr)`

Called on startup, on window/panel resize, and after `init()`. Set the drawing-buffer size to `w * dpr` by `h * dpr` and the CSS size to `w` by `h`. The editor caps DPR at 2.

### `update(frame)`

Called once per animation frame before `render()`.

| Field | Type | Meaning |
| --- | --- | --- |
| `frame.scene` | object | `{ version, name, env, nodes }` — the live scene. |
| `frame.cam` | `CameraRig` | Active editor/Game camera. |
| `frame.viewMode` | `"scene"` \| `"game"` | Game view hides the grid and uses the scene camera. |
| `frame.selected` | string \| null | Selected node id. |
| `frame.env` | object | `{ ambient, ambientColor, showGrid, fogEnabled, fogColor, fogNear, fogFar }`. |
| `frame.time` | number | Play-mode time in seconds (`0` while stopped). |

Camera fields available on `frame.cam`:

| Field | Meaning |
| --- | --- |
| `eye` | World-space camera position `[x, y, z]` |
| `target` | Look-at point |
| `up` | Up vector |
| `fov` | Vertical field of view in degrees |
| `near`, `far` | Clip planes |
| `view` | World → view matrix |
| `proj` | View → clip projection matrix |
| `vp` | Combined projection matrix |
| `aspect`, `width`, `height` | Viewport dimensions (CSS pixels) |
| `backgroundColor` | Game-view clear color |
| `forward` | Normalized view direction |
| `quat` | Camera orientation quaternion |

Matrices are column-major arrays of 16 numbers, matching the shared math library (see `js/core/math.js`). Scene transforms are **local**; use `UnityWeb.scene.worldMatrices(scene)` to obtain world matrices, or reconstruct the hierarchy yourself.

Node fields (see the main README for the full schema):

```js
node = {
  id, name, parent, type,                 // 'empty' | 'mesh' | 'light' | 'camera'
  visible,                                // boolean — renderer-only toggle for this node
  tag,                                    // optional free-text label ('' means Untagged)
  active,                                 // boolean — false disables this node and its subtree
  transform: { position, rotation, scale }, // rotation in degrees, local space
  mesh: {
    shape,                                  // 'cube' | 'sphere' | ... | 'model'
    // when shape === 'model' (imported .glb/.gltf/.obj/.blend):
    //   modelId -> scene.models[i].id, meshIndex / primitiveIndex -> the part
    modelId, meshIndex, primitiveIndex,
    color, roughness, metalness, wireframe, opacity, texture
  },
  light: { kind, color, intensity, range, angle, penumbra },
  camera: { fov, near, far, bg },
  rigidbody: { mass, useGravity, restitution, drag, frozen },  // drag & frozen are optional
  behaviors, script, fsm        // play-mode data
}
```

Objects may be added, cloned, renamed, destroyed or re-parented during Play mode by FSM actions and scripts. Keep any engine-side objects in a `Map` keyed by node `id` and reconcile it every `update(frame)` so runtime-created and destroyed nodes appear and disappear correctly.

`mesh.texture` is `{ enabled, preset, data, tiling: [x, y], offset: [x, y] }`. `data` holds a painted/uploaded data URL from the texture editor; `preset` names a procedural texture otherwise. Resolve it through `UnityWeb.textures` so every engine paints the same image:

```js
const base = UnityWeb.textures.getBase(tex);   // HTMLCanvasElement (procedural or uploaded/painted)
const tiled = UnityWeb.textures.getTiled(tex);  // cached repeat/offset canvas + pattern info
```

`light.kind` is `directional`, `point` or `spot`; spot lights also read `angle` (degrees) and `penumbra` (0–1).

### `render()`

Draw the last frame received. The editor does not double-buffer or interpolate for you. Keep per-node engine objects in a `Map` keyed by node `id`, and prune entries whose nodes disappeared.

### `getStats()`

Return `{ triangles, objects, calls }`. The status bar and HUD read these values every ~140 ms. A missing or partial object is tolerated — use zeros.

### `dispose()`

Called when switching engines or when startup fails. Remove the canvas, dispose geometries/materials/scenes, stop render loops and drop listeners. The editor immediately calls `init()` on the next adapter.

---

## Rendering the shared model

The adapter is responsible only for visuals. To stay consistent with the editor:

1. Skip `node.visible === false`.
2. Skip inactive nodes: `const actives = UnityWeb.scene.activeMap(scene); if (actives.get(node.id) === false) continue;`. Active state cascades from parents (Unity semantics), so check the map rather than `node.active` alone. `visible` is renderer-only for one node, `active === false` disables the subtree.
3. Convert degrees to radians for rotations when your engine expects radians.
4. Compose local transforms or use precomputed world matrices.
5. Resolve the selected node's outline if you want selection feedback. The editor's 2D gizmo overlay draws on top independently; the built-in adapters also highlight selection.
6. Respect `mesh.wireframe`, `mesh.opacity`, and `mesh.color`.
7. Use `frame.viewMode === 'game'` to hide the editor grid and clear with `cam.backgroundColor`.
8. Treat the Game camera as `frame.cam` — the editor already picks the first visible camera node in Game view.

Shared geometry is available as CPU data:

```js
// primitives and imported model meshes alike:
const geo = UnityWeb.geom.forNode(node);
// or by shape id for the built-in primitives:
const cube = UnityWeb.geom.get('cube');
// geo.positions : Float32Array (9 floats per triangle)
// geo.normals   : Float32Array (9 floats per triangle)
// geo.uvs       : Float32Array (6 floats per triangle: u,v per vertex)
// geo.bounds    : { min, max }
// geo.twoSided  : boolean
// geo.triangles : number
```

`forNode(node)` resolves both cases: `mesh.shape === 'model'` expands the referenced imported primitive (`.glb` / `.gltf` / `.obj` / `.blend`) through the shared model cache — `UnityWeb.models.geometryFor(node)` — while any other shape returns the built-in primitive geometry. Use `UnityWeb.geom.keyFor(node)` as your engine-side geometry cache key; imported models get a stable key of the form `<modelId>|<meshIndex>|<primitiveIndex>`, so re-registered models (clones, restored scenes) reuse the same buffers.

Imported meshes carry the same material fields as primitives (`color`, `roughness`, `metalness`, `opacity`, `wireframe`, `texture`), and `geo.twoSided` is set from the file's double-sided flag — render both winding orders when it is true.

This lets an adapter work without its own geometry library, as the Native Canvas renderer does.

---

## Lazy-loading a runtime

`UnityWeb.engines.loadScript(src, globalName)` injects a classic script once and resolves when the named global exists. It times out after 20 seconds and rejects on network errors. The built-in adapters use it:

```js
async load() {
  await UnityWeb.engines.loadScript('https://cdn.jsdelivr.net/npm/three@0.157.0/build/three.min.js', 'THREE');
}
```

For ES-module-only runtimes, use dynamic `import()` inside `load()`; classic scripts are not required for the engine itself, only for your plugin file (so `file://` keeps working for the editor).

If loading fails, throw an error. The app logs it and falls back to **Native Canvas** automatically, so never leave the viewport blank on purpose.

---

## Reusing the built-in Canvas renderer

The Native Canvas adapter is exported as `UnityWeb.adapters.Native`. Subclassing it is the fastest way to make a custom look while keeping a fully working offline renderer. This is exactly what `plugins/blueprint-canvas.js` does:

```js
class MyAdapter extends UnityWeb.adapters.Native {
  async init(host) {
    await super.init(host);
    this.canvas.style.background = '#101820';
  }

  // called for each projected triangle
  paintPrim(ctx, prim) {
    // prim = { pts: [[x, y], ...], fill: 'rgb(...)', z, wire, opacity, texture }
    // Textured primitives carry UVs; let the base class draw them.
    if (prim.texture && !prim.wire) return super.paintPrim(ctx, prim);
    ctx.fillStyle = prim.fill;
    ctx.beginPath();
    prim.pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.closePath();
    ctx.fill();
  }

  // world-space grid on the ground plane
  drawGrid(ctx, cam, w, h, near) {
    super.drawGrid(ctx, cam, w, h, near);
  }

  // full frame, after super.render()
  render() {
    super.render();
    // draw HUD text, crosshairs, post effects...
  }
}

UnityWeb.engines.register({
  id: 'my-canvas',
  name: 'My Canvas',
  version: '1.0',
  license: 'MIT',
  badge: 'plugin',
  async load() {},
  create(def) { return new MyAdapter(def); },
});
```

Useful `Native` hooks and fields:

| Member | Purpose |
| --- | --- |
| `this.canvas`, `this.ctx` | Drawing surface (created by `init`) |
| `this.w`, `this.h`, `this.dpr` | Current sizes |
| `this.frame` | Latest frame passed to `update` |
| `paintPrim(ctx, prim)` | Draw one projected triangle/polygon |
| `triangulate(...)` | Project, clip and shade a triangle |
| `drawGrid(ctx, cam, w, h, near)` | Ground grid |
| `drawSelection(ctx, scene, world, id, cam, w, h, near)` | Selection outline |
| `render()` | Full frame pipeline; call `super.render()` first if you only add overlays |

Because the base class already handles near-plane clipping, depth sorting, lighting, textures, fog and selection, a plugin can restyle the viewport in a few dozen lines. The Blueprint example adds a radial background, line-art triangles, drafting corner ticks and a title block, while delegating textured triangles to the base renderer.

---

## Testing a plugin

1. Open the editor and its Console (Project → Console).
2. Use **Engine → Connect engine plugin…** with the plugin URL, or add a `<script>` tag after `app.js`.
3. Confirm the plugin appears in the engine picker and the Engines panel.
4. Switch to it. The Console should log `Engine ready — <name>`.
5. Exercise orbit, selection, gizmos and Play mode; switching away and back must call `dispose()`/`init()` cleanly.
6. Reload the page: the last engine is restored from `localStorage` (`webforge3d.engine`), which also verifies `load()` is idempotent.

If the engine fails to start, the editor reports the error and falls back to Native Canvas. Check the Console for the exact reason — usually a network/CORS failure or a missing global.

---

## API surface used by plugins

```js
UnityWeb.engines.register(def)         // add/override an engine by id
UnityWeb.engines.list()                // array of definitions
UnityWeb.engines.get(id)               // definition or null
UnityWeb.engines.instance(id)          // load + create an adapter
UnityWeb.engines.loadScript(src, g)    // idempotent classic-script loader
UnityWeb.engines.onChange(fn)          // called after registrations
UnityWeb.engines.features              // renderer feature definitions
UnityWeb.engines.capabilities(def)     // resolved { id: { level, note } }
UnityWeb.engines.capability(def, id)   // one resolved feature

UnityWeb.adapters.Native               // offline Canvas adapter base class
UnityWeb.geom.get(shape)               // shared CPU geometry (positions/normals/uvs)
UnityWeb.geom.forNode(node)            // geometry for primitives AND imported meshes
UnityWeb.geom.keyFor(node)             // stable cache key ('cube', 'mdl_..|0|0')
UnityWeb.textures.getBase(tex)          // HTMLCanvasElement for a mesh texture
UnityWeb.textures.getTiled(tex)        // cached repeat/offset texture canvas
UnityWeb.models.register(scene, buffer, filename, extras)
                                       // import a .glb/.gltf/.obj/.blend file
UnityWeb.models.geometryFor(node)      // expand a model node's referenced primitive
UnityWeb.models.geometry(modelId, meshIndex, primIndex)
UnityWeb.models.warm(scene)            // rebuild caches after loading a saved scene
UnityWeb.obj.sniff(buffer)             // OBJ content sniffing (format dispatch helper)
UnityWeb.obj.parse(buffer, extras)     // OBJ/MTL -> glTF-shaped doc
UnityWeb.blend.parse(buffer)           // .blend -> glTF-shaped doc
UnityWeb.modeldoc                     // shared document builder used by importers
UnityWeb.FSM.normalize(fsm)            // validate/repair a node FSM
UnityWeb.FSM.actionTypes               // all 89 action definitions (id, category, params)
UnityWeb.scene.worldMatrices(scene)     // node id -> world matrix
UnityWeb.scene.activeMap(scene)        // node id -> effective active boolean (parent-cascading)
UnityWeb.scene.findByTag(scene, tag)   // first active node with a tag (case-insensitive)
UnityWeb.scene.normalize(scene)        // validate/repair scene JSON
UnityWeb.app                            // running App (frame loop, editor, cameraRig)
UnityWeb.app.editor                     // Editor state and event emitter
UnityWeb.app.editor.runtime             // shared runtime while playing (physics, requests, raycasts)
```

`UnityWeb.app` exists after `DOMContentLoaded`; plugins loaded later can use it immediately. When writing a plugin loaded via `<script>` before boot, defer setup until `DOMContentLoaded` or keep it declarative (registration only).
