/* ============================================================
   blueprint-canvas.js — example engine plugin
   ------------------------------------------------------------
   This is a complete, working adapter that reuses the built-in
   Native Canvas pipeline and re-skins it as a drafting "blueprint".
   Load it from Engine → Connect engine plugin… or with:

       <script src="plugins/blueprint-canvas.js"></script>

   It demonstrates the smallest useful plugin: register an engine
   definition, subclass an existing adapter, and override only the
   drawing calls you care about.
   ============================================================ */
(function () {
  'use strict';
  const UW = window.UnityWeb;
  if (!UW || !UW.engines || !UW.adapters || !UW.adapters.Native) {
    console.error('[blueprint] Load the editor scripts before this plugin.');
    return;
  }

  const LINE = 'rgba(120,214,255,.62)';
  const LINE_SOFT = 'rgba(94,178,224,.20)';

  class BlueprintAdapter extends UW.adapters.Native {
    async init(host) {
      await super.init(host);
      this.canvas.style.background =
        'radial-gradient(120% 90% at 50% 0%, #0d2437 0%, #081724 55%, #050e17 100%)';
    }

    paintPrim(ctx, prim) {
      const pts = prim.pts;
      if (!pts || pts.length < 3) return;
      // Textured primitives keep real UV-mapped images; the blueprint
      // restyle still applies to everything else.
      if (prim.texture && !prim.wire) {
        super.paintPrim(ctx, prim);
        return;
      }
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
      ctx.closePath();
      ctx.fillStyle = 'rgba(22,108,166,.16)';
      ctx.fill();
      ctx.strokeStyle = prim.wire ? 'rgba(176,236,255,.95)' : LINE;
      ctx.lineWidth = prim.wire ? 1.2 : 0.65;
      ctx.stroke();
    }

    drawGrid(ctx, cam, w, h, near) {
      super.drawGrid(ctx, cam, w, h, near);
      // drafting-sheet border ticks
      ctx.save();
      ctx.strokeStyle = LINE_SOFT;
      ctx.lineWidth = 1;
      const s = 14;
      ctx.beginPath();
      ctx.moveTo(s, s + 24); ctx.lineTo(s, s); ctx.lineTo(s + 24, s);
      ctx.moveTo(w - s - 24, s); ctx.lineTo(w - s, s); ctx.lineTo(w - s, s + 24);
      ctx.moveTo(s, h - s - 24); ctx.lineTo(s, h - s); ctx.lineTo(s + 24, h - s);
      ctx.moveTo(w - s - 24, h - s); ctx.lineTo(w - s, h - s); ctx.lineTo(w - s, h - s - 24);
      ctx.stroke();
      ctx.restore();
    }

    render() {
      super.render();
      const ctx = this.ctx;
      if (!ctx) return;
      ctx.save();
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.font = '600 9px ui-monospace, Consolas, monospace';
      ctx.fillStyle = 'rgba(126,206,245,.55)';
      ctx.fillText('WEBFORGE / BLUEPRINT VIEW', 20, 24);
      ctx.fillStyle = 'rgba(126,206,245,.30)';
      ctx.fillText('SCALE 1:1 · AABB WIRE PASS', 20, 36);
      ctx.restore();
    }
  }

  UW.engines.register({
    id: 'blueprint',
    name: 'Blueprint Canvas',
    short: 'BP',
    version: '1.0',
    license: 'example plugin',
    vendor: 'WebForge',
    url: '',
    description: 'Example plugin: the Native Canvas software renderer restyled as a drafting blueprint. Runs offline.',
    badge: 'plugin',
    async load() {},
    create(def) {
      return new BlueprintAdapter(def);
    },
  });
})();
