/* UnirealEngine — renderer.js
 * A small WebGL forward renderer: procedural primitives, imported model meshes,
 * up to eight directional/point/spot lights with projected cookie textures,
 * Lambert + Blinn-Phong shading, grid, soft contact shadows, wireframe overlay,
 * selection outline and transform gizmos. No external assets and no SQL — buffers
 * and cookie textures are generated at runtime. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;
  const AXIS_COLORS = {
    x: [1.0, 0.32, 0.32],
    y: [0.42, 0.92, 0.48],
    z: [0.32, 0.62, 1.0]
  };
  const HOVER = [1.0, 0.82, 0.34];

  /* ------------------------------------------------------------------ shaders */
  const BONE_UNIFORMS = 24;
  const MESH_VS = [
    'attribute vec3 aPos;',
    'attribute vec3 aNormal;',
    'attribute vec2 aUV;',
    'attribute vec4 aJoint;',
    'attribute vec4 aWeight;',
    'uniform mat4 uModel;',
    'uniform mat4 uVP;',
    'uniform mat3 uNormalMat;',
    'uniform vec2 uUVScale;',
    'uniform vec2 uUVOffset;',
    'uniform float uHasSkin;',
    'uniform mat4 uBones[' + BONE_UNIFORMS + '];',
    'varying vec3 vN;',
    'varying vec3 vW;',
    'varying vec2 vUV;',
    'void main() {',
    '  vec4 local = vec4(aPos, 1.0);',
    '  vec3 nrm = aNormal;',
    '  if (uHasSkin > 0.5) {',
    '    mat4 skin = aWeight.x * uBones[int(aJoint.x)] +',
    '                aWeight.y * uBones[int(aJoint.y)] +',
    '                aWeight.z * uBones[int(aJoint.z)] +',
    '                aWeight.w * uBones[int(aJoint.w)];',
    '    local = skin * local;',
    '    nrm = mat3(skin) * nrm;',
    '  }',
    '  vec4 w = uModel * local;',
    '  vW = w.xyz;',
    '  vN = uNormalMat * nrm;',
    '  vUV = aUV * uUVScale + uUVOffset;',
    '  gl_Position = uVP * w;',
    '}'
  ].join('\n');

  const MESH_FS = [
    'precision mediump float;',
    'uniform vec3 uColor;',
    'uniform sampler2D uTex;',
    'uniform float uUseMap;',
    'uniform vec3 uSunDir;',
    'uniform vec3 uSunColor;',
    'uniform vec3 uAmbient;',
    'uniform vec3 uCamPos;',
    'uniform float uShininess;',
    'uniform float uOpacity;',
    'uniform float uUnlit;',
    'uniform float uEmissive;',
    'uniform int uLightCount;',
    'uniform vec3 uLightPos[8];',
    'uniform vec3 uLightColor[8];',
    'uniform vec3 uLightDir[8];',
    'uniform vec4 uLightParams[8];',
    'uniform vec4 uLightCookie[8];',
    'uniform mat4 uLightVP[8];',
    'uniform sampler2D uCookieAtlas;',
    'varying vec3 vN;',
    'varying vec3 vW;',
    'varying vec2 vUV;',
    'void main() {',
    '  vec3 base = uColor;',
    '  if (uUseMap > 0.5) {',
    '    vec3 texel = texture2D(uTex, vUV).rgb;',
    '    base *= pow(max(texel, 0.0), vec3(2.2));',
    '  }',
    '  if (uUnlit > 0.5) {',
    '    gl_FragColor = vec4(pow(base, vec3(1.0 / 2.2)), uOpacity);',
    '    return;',
    '  }',
    '  vec3 N = normalize(vN);',
    '  vec3 V = normalize(uCamPos - vW);',
    '  float ndl = max(dot(N, uSunDir), 0.0);',
    '  float wrap = max(dot(N, uSunDir) * 0.5 + 0.5, 0.0);',
    '  vec3 H = normalize(uSunDir + V);',
    '  float spec = pow(max(dot(N, H), 0.0), uShininess) * 0.32 * ndl;',
    '  float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.08;',
    '  vec3 col = base * (uAmbient + uSunColor * (ndl * 0.85 + wrap * 0.15));',
    '  col += uSunColor * spec + vec3(rim) + base * uEmissive;',
    '  for (int i = 0; i < 8; i++) {',
    '    if (float(i) < float(uLightCount)) {',
    '      vec4 P = uLightParams[i];',
    '      float type = P.x;',
    '      vec3 toLight = uLightPos[i] - vW;',
    '      float dist = length(toLight);',
    '      vec3 L = (type < 0.5) ? -uLightDir[i] : toLight / max(dist, 0.0001);',
    '      float atten = 1.0;',
    '      if (type > 0.5) {',
    '        atten = pow(clamp(1.0 - dist / max(P.y, 0.001), 0.0, 1.0), 1.6);',
    '      }',
    '      float diff = max(dot(N, L), 0.0);',
    '      float spot = 1.0;',
    '      if (type > 1.5) {',
    '        float cd = dot(normalize(vW - uLightPos[i]), normalize(uLightDir[i]));',
    '        spot = smoothstep(P.z, P.w, cd);',
    '      }',
    '      if (diff > 0.0 && atten > 0.0 && spot > 0.0) {',
    '        float cookie = 1.0;',
    '        if (uLightCookie[i].z > 0.5) {',
    '          vec2 uv;',
    '          bool inside = true;',
    '          if (type > 1.5) {',
    '            vec4 clip = uLightVP[i] * vec4(vW, 1.0);',
    '            if (clip.w <= 0.0) inside = false;',
    '            uv = clip.xy / max(clip.w, 0.0001) * 0.5 + 0.5;',
    '            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) inside = false;',
    '          } else {',
    '            vec3 d = normalize(vW - uLightPos[i]);',
    '            uv = vec2(atan(d.z, d.x) / 6.2831853 + 0.5, asin(clamp(d.y, -1.0, 1.0)) / 3.1415926 + 0.5);',
    '          }',
    '          if (inside) {',
    '            cookie = texture2D(uCookieAtlas, uLightCookie[i].xy + uv * uLightCookie[i].w).r;',
    '          } else {',
    '            cookie = 0.0;',
    '          }',
    '        }',
    '        vec3 H2 = normalize(L + V);',
    '        float spec2 = pow(max(dot(N, H2), 0.0), uShininess) * 0.22 * diff;',
    '        col += uLightColor[i] * (base * diff + spec2) * atten * spot * cookie;',
    '      }',
    '    }',
    '  }',
    '  col = pow(max(col, 0.0), vec3(1.0 / 2.2));',
    '  gl_FragColor = vec4(col, uOpacity);',
    '}'
  ].join('\n');

  const LINE_VS = [
    'attribute vec3 aPos;',
    'uniform mat4 uMVP;',
    'void main() { gl_Position = uMVP * vec4(aPos, 1.0); }'
  ].join('\n');

  const LINE_FS = [
    'precision mediump float;',
    'uniform vec3 uColor;',
    'uniform float uAlpha;',
    'void main() { gl_FragColor = vec4(uColor, uAlpha); }'
  ].join('\n');

  /* -------------------------------------------------------------- mesh builder */
  const EDGE_INDEX_LIMIT = 600000; // ~200k triangles; larger meshes skip wireframe edges
  function finishMesh(positions, normals, indices, options) {
    options = options || {};
    const count = positions.length / 3;
    const uvs = options.uvs && options.uvs.length === count * 2 ? options.uvs : null;
    let data = options.data;
    if (!data) {
      data = new Float32Array(count * 8);
      for (let i = 0; i < count; i++) {
        const o = i * 8, p = i * 3;
        data[o] = positions[p];
        data[o + 1] = positions[p + 1];
        data[o + 2] = positions[p + 2];
        data[o + 3] = normals[p];
        data[o + 4] = normals[p + 1];
        data[o + 5] = normals[p + 2];
        data[o + 6] = uvs ? uvs[i * 2] : 0;
        data[o + 7] = uvs ? uvs[i * 2 + 1] : 0;
      }
    }
    let max = 0;
    for (let i = 0; i < indices.length; i++) if (indices[i] > max) max = indices[i];
    const IndexArray = max > 65535 ? Uint32Array : Uint16Array;
    const tri = new IndexArray(indices);
    let edges = new IndexArray(0);
    if (indices.length <= EDGE_INDEX_LIMIT) {
      const seen = new Set();
      const list = [];
      for (let i = 0; i < indices.length; i += 3) {
        for (let k = 0; k < 3; k++) {
          const a = indices[i + k], b = indices[i + (k + 1) % 3];
          const key = a < b ? a + ':' + b : b + ':' + a;
          if (!seen.has(key)) { seen.add(key); list.push(a, b); }
        }
      }
      edges = new IndexArray(list);
    }
    return { data: data, indices: tri, edgeIndices: edges, triangles: indices.length / 3 };
  }

  function buildCube() {
    const faces = [
      { n: [0, 0, 1], v: [[-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5]] },
      { n: [0, 0, -1], v: [[0.5, -0.5, -0.5], [-0.5, -0.5, -0.5], [-0.5, 0.5, -0.5], [0.5, 0.5, -0.5]] },
      { n: [1, 0, 0], v: [[0.5, -0.5, 0.5], [0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [0.5, 0.5, 0.5]] },
      { n: [-1, 0, 0], v: [[-0.5, -0.5, -0.5], [-0.5, -0.5, 0.5], [-0.5, 0.5, 0.5], [-0.5, 0.5, -0.5]] },
      { n: [0, 1, 0], v: [[-0.5, 0.5, 0.5], [0.5, 0.5, 0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5]] },
      { n: [0, -1, 0], v: [[-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, -0.5, 0.5], [-0.5, -0.5, 0.5]] }
    ];
    const positions = [], normals = [], indices = [];
    faces.forEach((f, fi) => {
      f.v.forEach(v => { positions.push(v[0], v[1], v[2]); normals.push(f.n[0], f.n[1], f.n[2]); });
      const b = fi * 4;
      indices.push(b, b + 1, b + 2, b, b + 2, b + 3);
    });
    return finishMesh(positions, normals, indices);
  }

  function buildSphere(segX, segY) {
    segX = segX || 32; segY = segY || 20;
    const positions = [], normals = [], indices = [];
    for (let y = 0; y <= segY; y++) {
      const phi = y / segY * Math.PI;
      const py = Math.cos(phi) * 0.5;
      const r = Math.sin(phi) * 0.5;
      for (let x = 0; x <= segX; x++) {
        const th = x / segX * Math.PI * 2;
        const px = Math.cos(th) * r, pz = Math.sin(th) * r;
        positions.push(px, py, pz);
        const len = Math.hypot(px, py, pz) || 1;
        normals.push(px / len, py / len, pz / len);
      }
    }
    for (let y = 0; y < segY; y++) {
      for (let x = 0; x < segX; x++) {
        const i0 = y * (segX + 1) + x, i1 = i0 + 1;
        const i2 = i0 + segX + 1, i3 = i2 + 1;
        indices.push(i0, i2, i1, i1, i2, i3);
      }
    }
    return finishMesh(positions, normals, indices);
  }

  function buildCylinder(radial, topRadius, bottomRadius) {
    radial = radial || 30;
    const tr = topRadius === undefined ? 0.5 : topRadius;
    const br = bottomRadius === undefined ? 0.5 : bottomRadius;
    const positions = [], normals = [], indices = [];
    for (let i = 0; i <= radial; i++) {
      const th = i / radial * Math.PI * 2;
      const c = Math.cos(th), s = Math.sin(th);
      const slope = (br - tr);
      const nx = c, nz = s, ny = slope * 0.5;
      const nl = Math.hypot(nx, ny, nz) || 1;
      positions.push(c * br, -0.5, s * br, c * tr, 0.5, s * tr);
      normals.push(nx / nl, ny / nl, nz / nl, nx / nl, ny / nl, nz / nl);
    }
    for (let i = 0; i < radial; i++) {
      const a = i * 2, b = a + 1, c = a + 2, d = a + 3;
      indices.push(a, c, b, b, c, d);
    }
    /* caps */
    for (const cap of [{ y: 0.5, r: tr, ny: 1 }, { y: -0.5, r: br, ny: -1 }]) {
      if (cap.r <= 0.0001) continue;
      const center = positions.length / 3;
      positions.push(0, cap.y, 0); normals.push(0, cap.ny, 0);
      for (let i = 0; i <= radial; i++) {
        const th = i / radial * Math.PI * 2;
        positions.push(Math.cos(th) * cap.r, cap.y, Math.sin(th) * cap.r);
        normals.push(0, cap.ny, 0);
      }
      for (let i = 0; i < radial; i++) indices.push(center, center + 1 + i, center + 2 + i);
    }
    return finishMesh(positions, normals, indices);
  }

  function buildPlane(size) {
    const h = (size || 10) / 2;
    const positions = [-h, 0, h, h, 0, h, h, 0, -h, -h, 0, -h];
    const normals = [0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0];
    return finishMesh(positions, normals, [0, 1, 2, 0, 2, 3]);
  }

  function buildDisc(segments) {
    segments = segments || 40;
    const positions = [0, 0, 0], normals = [0, 1, 0], indices = [];
    for (let i = 0; i <= segments; i++) {
      const th = i / segments * Math.PI * 2;
      positions.push(Math.cos(th) * 0.5, 0, Math.sin(th) * 0.5);
      normals.push(0, 1, 0);
    }
    for (let i = 1; i <= segments; i++) indices.push(0, i, i + 1);
    return finishMesh(positions, normals, indices);
  }

  function buildRing(axis, segments) {
    segments = segments || 72;
    const out = [];
    for (let i = 0; i <= segments; i++) {
      const th = i / segments * Math.PI * 2;
      const a = Math.cos(th), b = Math.sin(th);
      if (axis === 'x') out.push(0, a, b);
      else if (axis === 'y') out.push(a, 0, b);
      else out.push(a, b, 0);
    }
    return new Float32Array(out);
  }

  function buildBoxLines() {
    const p = [];
    const c = [[-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5],
      [-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5]];
    const e = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
    for (const [a, b] of e) p.push(c[a][0], c[a][1], c[a][2], c[b][0], c[b][1], c[b][2]);
    return new Float32Array(p);
  }

  function buildGrid() {
    const minor = [], major = [], axisX = [], axisZ = [];
    const extent = 50;
    for (let i = -extent; i <= extent; i++) {
      if (i === 0) continue;
      const target = i % 5 === 0 ? major : minor;
      target.push(-extent, 0, i, extent, 0, i);
      target.push(i, 0, -extent, i, 0, extent);
    }
    axisX.push(-extent, 0, 0, extent, 0, 0);
    axisZ.push(0, 0, -extent, 0, 0, extent);
    return {
      minor: new Float32Array(minor),
      major: new Float32Array(major),
      axisX: new Float32Array(axisX),
      axisZ: new Float32Array(axisZ)
    };
  }

  function srgbToLinear(c) {
    c /= 255;
    return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  }
  function hexToLinear(hex) {
    if (typeof hex !== 'string') return [0.6, 0.6, 0.6];
    let h = hex.trim().replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    if (h.length !== 6) return [0.6, 0.6, 0.6];
    return [srgbToLinear(parseInt(h.slice(0, 2), 16)), srgbToLinear(parseInt(h.slice(2, 4), 16)), srgbToLinear(parseInt(h.slice(4, 6), 16))];
  }

  /* ------------------------------------------------------------------ Renderer */
  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      this.gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: false }) ||
                canvas.getContext('experimental-webgl');
      this.ok = !!this.gl;
      this.uintIndex = this.gl ? !!this.gl.getExtension('OES_element_index_uint') : false;
      this.stats = { objects: 0, triangles: 0, draws: 0 };
      this.width = 1;
      this.height = 1;
      this.dpr = 1;
      this.meshes = {};
      this.modelMeshes = {};
      this.skinMeshes = {};
      this.grid = null;
      this.ringBuffers = {};
      this.boxBuffer = null;
      this.discMesh = null;
      this.cookieTexture = null;
      this.cookieCanvas = null;
      this.cookieCtx = null;
      this.cookieImages = {};
      this.cookieCells = {};
      this.cookieSignature = '';
      this.cookieDirty = true;
      this.lightScratch = {
        pos: new Float32Array(24),
        color: new Float32Array(24),
        dir: new Float32Array(24),
        params: new Float32Array(32),
        cookie: new Float32Array(32),
        vp: new Float32Array(128)
      };
      if (!this.ok) {
        UE.log('error', 'WebGL is not available in this browser; the scene view cannot start.');
        return;
      }
      this._init();
    }

    _init() {
      const gl = this.gl;
      this.program = this._program(MESH_VS, MESH_FS);
      this.lineProgram = this._program(LINE_VS, LINE_FS);
      if (!this.program || !this.lineProgram) { this.ok = false; return; }
      this.u = {
        model: gl.getUniformLocation(this.program, 'uModel'),
        vp: gl.getUniformLocation(this.program, 'uVP'),
        normal: gl.getUniformLocation(this.program, 'uNormalMat'),
        color: gl.getUniformLocation(this.program, 'uColor'),
        tex: gl.getUniformLocation(this.program, 'uTex'),
        useMap: gl.getUniformLocation(this.program, 'uUseMap'),
        uvScale: gl.getUniformLocation(this.program, 'uUVScale'),
        uvOffset: gl.getUniformLocation(this.program, 'uUVOffset'),
        sunDir: gl.getUniformLocation(this.program, 'uSunDir'),
        sunColor: gl.getUniformLocation(this.program, 'uSunColor'),
        ambient: gl.getUniformLocation(this.program, 'uAmbient'),
        camPos: gl.getUniformLocation(this.program, 'uCamPos'),
        shininess: gl.getUniformLocation(this.program, 'uShininess'),
        opacity: gl.getUniformLocation(this.program, 'uOpacity'),
        unlit: gl.getUniformLocation(this.program, 'uUnlit'),
        emissive: gl.getUniformLocation(this.program, 'uEmissive'),
        hasSkin: gl.getUniformLocation(this.program, 'uHasSkin'),
        bones: gl.getUniformLocation(this.program, 'uBones[0]'),
        lightCount: gl.getUniformLocation(this.program, 'uLightCount'),
        lightPos: gl.getUniformLocation(this.program, 'uLightPos[0]'),
        lightColor: gl.getUniformLocation(this.program, 'uLightColor[0]'),
        lightDir: gl.getUniformLocation(this.program, 'uLightDir[0]'),
        lightParams: gl.getUniformLocation(this.program, 'uLightParams[0]'),
        lightCookie: gl.getUniformLocation(this.program, 'uLightCookie[0]'),
        lightVP: gl.getUniformLocation(this.program, 'uLightVP[0]'),
        cookieAtlas: gl.getUniformLocation(this.program, 'uCookieAtlas')
      };
      this.l = {
        mvp: gl.getUniformLocation(this.lineProgram, 'uMVP'),
        color: gl.getUniformLocation(this.lineProgram, 'uColor'),
        alpha: gl.getUniformLocation(this.lineProgram, 'uAlpha')
      };
      this.aPos = gl.getAttribLocation(this.program, 'aPos');
      this.aNormal = gl.getAttribLocation(this.program, 'aNormal');
      this.aUV = gl.getAttribLocation(this.program, 'aUV');
      this.aJoint = gl.getAttribLocation(this.program, 'aJoint');
      this.aWeight = gl.getAttribLocation(this.program, 'aWeight');
      this.aLinePos = gl.getAttribLocation(this.lineProgram, 'aPos');

      /* Light cookies use unit 0; model base-color maps use unit 1. */
      gl.useProgram(this.program);
      gl.uniform1i(this.u.tex, 1);
      gl.uniform1f(this.u.useMap, 0);
      gl.uniform1f(this.u.hasSkin, 0);
      gl.uniform2f(this.u.uvScale, 1, 1);
      gl.uniform2f(this.u.uvOffset, 0, 0);

      this.meshes = {
        cube: this._upload(buildCube()),
        sphere: this._upload(buildSphere(32, 20)),
        cylinder: this._upload(buildCylinder(30)),
        cone: this._upload(buildCylinder(30, 0.0001, 0.5)),
        plane: this._upload(buildPlane(10))
      };
      this.discMesh = this._upload(buildDisc(44));
      const g = buildGrid();
      this.grid = {
        minor: this._buffer(g.minor),
        minorCount: g.minor.length / 3,
        major: this._buffer(g.major),
        majorCount: g.major.length / 3,
        axisX: this._buffer(g.axisX),
        axisZ: this._buffer(g.axisZ)
      };
      this.ringBuffers = { x: this._buffer(buildRing('x')), y: this._buffer(buildRing('y')), z: this._buffer(buildRing('z')) };
      this.ringCount = 73;
      this.boxBuffer = this._buffer(buildBoxLines());
      this.unitLine = this._buffer(new Float32Array([0, 0, 0, 1, 0, 0]));
      this.dirLine = this._buffer(new Float32Array([0, 0, 0, 0, 0, -1]));
      this._initCookieAtlas();
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.disable(gl.CULL_FACE);
    }

    _shader(type, source) {
      const gl = this.gl;
      const s = gl.createShader(type);
      gl.shaderSource(s, source);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        UE.log('error', 'Shader compile error: ' + gl.getShaderInfoLog(s));
        gl.deleteShader(s);
        return null;
      }
      return s;
    }

    _program(vs, fs) {
      const gl = this.gl;
      const v = this._shader(gl.VERTEX_SHADER, vs);
      const f = this._shader(gl.FRAGMENT_SHADER, fs);
      if (!v || !f) return null;
      const p = gl.createProgram();
      gl.attachShader(p, v);
      gl.attachShader(p, f);
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
        UE.log('error', 'Shader link error: ' + gl.getProgramInfoLog(p));
        return null;
      }
      return p;
    }

    _buffer(data) {
      const gl = this.gl;
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      return buf;
    }

    _upload(mesh) {
      const gl = this.gl;
      const indexType = mesh.indices instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
      const edgeType = mesh.edgeIndices instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
      if (indexType === gl.UNSIGNED_INT && !this.uintIndex) {
        UE.log('error', 'This mesh needs 32-bit indices, but the browser does not expose OES_element_index_uint.');
        return null;
      }
      const vbo = this._buffer(mesh.data);
      const ibo = gl.createBuffer();
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.indices, gl.STATIC_DRAW);
      let ebo = null;
      if (mesh.edgeIndices && mesh.edgeIndices.length) {
        ebo = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ebo);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.edgeIndices, gl.STATIC_DRAW);
      }
      return {
        vbo: vbo, ibo: ibo, ebo: ebo, indexType: indexType, edgeType: edgeType,
        edgeCount: mesh.edgeIndices ? mesh.edgeIndices.length : 0,
        count: mesh.indices.length, triangles: mesh.triangles
      };
    }

    resize(w, h) {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.dpr = dpr;
      this.width = w; this.height = h;
      const pw = Math.max(1, Math.round(w * dpr));
      const ph = Math.max(1, Math.round(h * dpr));
      if (this.canvas.width !== pw || this.canvas.height !== ph) {
        this.canvas.width = pw;
        this.canvas.height = ph;
      }
      if (this.ok) this.gl.viewport(0, 0, pw, ph);
    }

    /* --------------------------------------------------------------- rendering */
    render(scene, view, options) {
      if (!this.ok) return;
      const gl = this.gl;
      options = options || {};
      this.stats = { objects: 0, triangles: 0, draws: 0 };

      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.disable(gl.BLEND);

      const vp = view.viewProj;
      const eye = view.eye;
      const sun = this._sunSetup(scene);
      const sunDir = sun.direction;
      const sunColor = sun.color;
      const ambient = sun.ambient;
      const lights = this._packLights(scene);

      this._drawGround(vp, eye);
      if (options.grid !== false) this._drawGrid(vp);
      if (options.shadows !== false) this._drawShadows(scene, vp, eye);

      /* opaque meshes */
      gl.useProgram(this.program);
      gl.uniformMatrix4fv(this.u.vp, false, vp);
      const sunN = V3.normalize(sunDir);
      gl.uniform3fv(this.u.sunDir, new Float32Array([sunN.x, sunN.y, sunN.z]));
      gl.uniform3fv(this.u.sunColor, new Float32Array(sunColor));
      gl.uniform3fv(this.u.ambient, new Float32Array(ambient));
      gl.uniform3fv(this.u.camPos, new Float32Array([eye.x, eye.y, eye.z]));
      this._uploadLights(lights);

      const transparent = [];
      for (const object of scene.objects) {
        if (!object.active) continue;
        const mr = object.getComponent('MeshRenderer');
        if (!mr) continue;
        const mesh = this._resolveMesh(mr);
        if (!mesh) continue;
        const animator = object.getComponent('Animator');
        const model = object.transform.worldMatrix();
        const opacity = mr.opacity === undefined ? 1 : mr.opacity;
        if (opacity < 0.999) { transparent.push({ object, mr, mesh, model, animator }); continue; }
        this._drawMesh(mesh, model, mr, this.u, sunDir, eye, animator);
        this.stats.objects++;
      }

      /* transparent meshes last */
      for (const t of transparent) {
        gl.enable(gl.BLEND);
        gl.depthMask(false);
        this._drawMesh(t.mesh, t.model, t.mr, this.u, sunDir, eye, t.animator);
        this.stats.objects++;
        gl.depthMask(true);
        gl.disable(gl.BLEND);
      }

      if (options.wireframe) this._drawWireframe(scene, vp, eye);

      /* selection outlines */
      for (const id of options.selection || []) {
        const object = scene.get(id);
        if (!object) continue;
        const b = UE.Physics.bounds(object) || this._meshBounds(object);
        if (!b) continue;
        const model = UE.Mat4.compose({ x: b.cx, y: b.cy, z: b.cz }, V3.create(), { x: b.hx * 2.02, y: b.hy * 2.02, z: b.hz * 2.02 });
        this._lines(this.boxBuffer, 24, UE.Mat4.multiply(vp, model), [1.0, 0.62, 0.18], 0.95, gl.LINES);
      }

      if (options.lightIcons) this._drawLightIcons(scene, vp);

      if (options.gizmo && options.selection && options.selection.length) this._drawGizmo(options.gizmo, vp, eye, scene);
    }

    _meshBounds(object) {
      const meshBounds = UE.objectMeshBounds && UE.objectMeshBounds(object);
      if (meshBounds) return meshBounds;
      const mr = object.getComponent('MeshRenderer');
      if (!mr) return null;
      const p = object.transform.worldPosition();
      const s = object.transform.worldScale();
      const size = UE.primitiveSize(mr.primitive);
      return {
        cx: p.x, cy: p.y, cz: p.z,
        hx: Math.max(0.01, Math.abs(s.x) * size.x / 2),
        hy: Math.max(0.01, Math.abs(s.y) * size.y / 2),
        hz: Math.max(0.01, Math.abs(s.z) * size.z / 2)
      };
    }

    /* Imported model assets are uploaded once and shared by every instance. */
    _resolveMesh(mr) {
      if (!mr) return null;
      if (mr.meshId) {
        const mesh = this._modelMesh(mr.meshId);
        if (mesh) return mesh;
      }
      return this.meshes[mr.primitive] || this.meshes.cube;
    }

    _modelMesh(meshId) {
      if (this.modelMeshes[meshId]) return this.modelMeshes[meshId];
      const asset = UE.AssetStore && UE.AssetStore.get(meshId);
      if (!asset || !asset.prims) return null;
      const prims = [];
      for (const prim of asset.prims) {
        const mesh = finishMesh(prim.positions, prim.normals, prim.indices, { uvs: prim.uvs, data: prim.data });
        const uploaded = this._upload(mesh);
        if (!uploaded) continue;
        uploaded.material = prim.material || null;
        if (prim.material && prim.material.texture) {
          this._loadTexture(prim.material.texture).then((tex) => {
            if (tex) uploaded.map = tex;
          });
        }
        prims.push(uploaded);
      }
      if (!prims.length) return null;
      this.modelMeshes[meshId] = { prims: prims };
      return this.modelMeshes[meshId];
    }

    /* GPU skin weights are cached per mesh + rig, because the same imported
     * mesh can be auto-rigged with different skeletons on different objects. */
    _skinMesh(meshId, rig) {
      if (!UE.Animation || !UE.Animation.skinFor) return null;
      const key = meshId + '|' + UE.Animation.rigKey(rig);
      if (this.skinMeshes[key]) return this.skinMeshes[key];
      const skin = UE.Animation.skinFor(meshId, rig);
      if (!skin || !skin.length) return null;
      const gl = this.gl;
      const buffers = [];
      for (const part of skin) {
        const count = part.joints.length / 4;
        const data = new Float32Array(count * 8);
        for (let i = 0; i < count; i++) {
          data[i * 8] = part.joints[i * 4];
          data[i * 8 + 1] = part.joints[i * 4 + 1];
          data[i * 8 + 2] = part.joints[i * 4 + 2];
          data[i * 8 + 3] = part.joints[i * 4 + 3];
          data[i * 8 + 4] = part.weights[i * 4];
          data[i * 8 + 5] = part.weights[i * 4 + 1];
          data[i * 8 + 6] = part.weights[i * 4 + 2];
          data[i * 8 + 7] = part.weights[i * 4 + 3];
        }
        buffers.push(this._buffer(data));
      }
      const keys = Object.keys(this.skinMeshes);
      if (keys.length >= 24) {
        const stale = keys[0];
        for (const buffer of this.skinMeshes[stale] || []) gl.deleteBuffer(buffer);
        delete this.skinMeshes[stale];
      }
      this.skinMeshes[key] = buffers;
      return buffers;
    }

    /* Decode a compressed base-color image and upload it as a texture. GLB
     * images are PNG/JPEG/WebP bytes, so the browser does the heavy lifting. */
    _loadTexture(texture) {
      const gl = this.gl;
      if (!texture || !texture.bytes || !texture.bytes.length) return Promise.resolve(null);
      const blob = new Blob([texture.bytes], { type: texture.mime || 'image/png' });
      let decoded;
      if (typeof createImageBitmap === 'function') {
        decoded = createImageBitmap(blob);
      } else {
        decoded = new Promise((resolve, reject) => {
          const url = URL.createObjectURL(blob);
          const img = new Image();
          img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
          img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('image decode failed')); };
          img.src = url;
        });
      }
      return decoded.then((source) => this._textureFromSource(source)).catch((err) => {
        UE.log('warn', 'Texture "' + (texture.name || 'embedded') + '" could not be decoded: ' + err.message);
        return null;
      });
    }

    _textureFromSource(source) {
      const gl = this.gl;
      const tex = gl.createTexture();
      /* Model maps live on unit 1; unit 0 is reserved for the light-cookie atlas. */
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
      const w = source.width || 0, h = source.height || 0;
      const pot = w > 0 && h > 0 && (w & (w - 1)) === 0 && (h & (h - 1)) === 0;
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, pot ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, pot ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      gl.bindTexture(gl.TEXTURE_2D, null);
      gl.activeTexture(gl.TEXTURE0);
      return tex;
    }

    _sunDirection(sun) {
      const az = (sun.azimuth || 0) * UE.DEG;
      const el = (sun.elevation === undefined ? 50 : sun.elevation) * UE.DEG;
      return {
        x: Math.cos(el) * Math.sin(az),
        y: Math.sin(el),
        z: Math.cos(el) * Math.cos(az)
      };
    }

    /* A Light component of type "sun" takes over the global sun entirely. */
    _sunLight(scene) {
      for (const object of scene.objects) {
        if (!object.active) continue;
        const light = object.getComponent('Light');
        if (light && light.type === 'sun') return { object: object, light: light };
      }
      return null;
    }

    _sunSetup(scene) {
      const base = scene.sun || {};
      const sunLight = this._sunLight(scene);
      let direction, color;
      if (sunLight) {
        const f = sunLight.object.transform.forward();
        direction = { x: -f.x, y: -f.y, z: -f.z };
        color = hexToLinear(sunLight.light.color || '#ffe2b0').map(c => c * (sunLight.light.intensity === undefined ? 1 : sunLight.light.intensity));
      } else {
        direction = this._sunDirection(base);
        color = hexToLinear(base.color || '#ffffff').map(c => c * (base.intensity === undefined ? 1 : base.intensity));
      }
      const amb = base.ambient === undefined ? 0.34 : base.ambient;
      return { direction: direction, color: color, ambient: [amb * 0.72, amb * 0.84, amb * 1.0] };
    }

    _initCookieAtlas() {
      const gl = this.gl;
      this.cookieTexture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.cookieTexture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
      if (typeof document !== 'undefined') {
        this.cookieCanvas = document.createElement('canvas');
        this.cookieCanvas.width = 512;
        this.cookieCanvas.height = 512;
        this.cookieCtx = this.cookieCanvas.getContext('2d');
      }
    }

    /* Cookie textures share one 512×512 atlas: 4×4 cells of 128×128. */
    _syncLightCookies(entries) {
      const cells = {};
      const parts = [];
      let index = 0;
      for (const entry of entries) {
        const light = entry.light;
        const type = light.type || 'point';
        const wants = light.cookie && light.cookie !== 'none' && (type === 'spot' || type === 'point');
        if (wants) cells[entry.object.id] = index++;
        parts.push(entry.object.id + ':' + (wants ? light.cookie : 'none') + ':' +
          (wants && light.cookie === 'texture' && light.cookieTexture
            ? light.cookieTexture.length + ':' + light.cookieTexture.slice(0, 48)
            : ''));
      }
      const signature = parts.join('|');
      if (signature !== this.cookieSignature) {
        this.cookieSignature = signature;
        this.cookieCells = cells;
        this.cookieDirty = true;
      }
      if (this.cookieDirty) {
        this._redrawCookieAtlas(entries);
        this.cookieDirty = false;
      }
      return cells;
    }

    _redrawCookieAtlas(entries) {
      if (!this.cookieCtx) return;
      const ctx = this.cookieCtx;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, 512, 512);
      const byId = {};
      for (const entry of entries) byId[entry.object.id] = entry;
      for (const id of Object.keys(this.cookieCells)) {
        const cell = this.cookieCells[id];
        const entry = byId[id];
        if (!entry) continue;
        const x = (cell % 4) * 128;
        const y = Math.floor(cell / 4) * 128;
        this._drawCookieCell(ctx, x, y, 128, entry.light.cookie, entry.light.cookieTexture);
      }
      const gl = this.gl;
      gl.bindTexture(gl.TEXTURE_2D, this.cookieTexture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.cookieCanvas);
      this.stats.cookieUploads = (this.stats.cookieUploads || 0) + 1;
    }

    _cookieImage(url) {
      if (!url) return null;
      let img = this.cookieImages[url];
      if (!img) {
        img = new Image();
        img._ready = false;
        img.onload = () => {
          img._ready = true;
          this.cookieSignature = '';
          this.cookieDirty = true;
        };
        img.onerror = () => { img._ready = false; };
        img.src = url;
        this.cookieImages[url] = img;
      }
      return img._ready ? img : null;
    }

    _drawCookieCell(ctx, x, y, size, cookie, texture) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, size, size);
      ctx.clip();
      ctx.fillStyle = '#000000';
      ctx.fillRect(x, y, size, size);
      ctx.translate(x, y);
      if (cookie === 'texture') {
        const img = this._cookieImage(texture);
        if (img && img.naturalWidth) {
          const scale = Math.max(size / img.naturalWidth, size / img.naturalHeight);
          ctx.drawImage(img, (size - img.naturalWidth * scale) / 2, (size - img.naturalHeight * scale) / 2,
            img.naturalWidth * scale, img.naturalHeight * scale);
        } else {
          ctx.fillStyle = '#8a8a8a';
          ctx.fillRect(0, 0, size, size);
        }
      } else if (cookie === 'checker') {
        const step = size / 8;
        ctx.fillStyle = '#ffffff';
        for (let row = 0; row < 8; row++) {
          for (let col = 0; col < 8; col++) {
            if ((row + col) % 2 === 0) ctx.fillRect(col * step, row * step, step, step);
          }
        }
      } else if (cookie === 'stripes') {
        ctx.fillStyle = '#ffffff';
        for (let i = 0; i < 8; i++) if (i % 2 === 0) ctx.fillRect(i * size / 8, 0, size / 8, size);
      } else if (cookie === 'grid') {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        for (let i = 0; i <= 8; i++) {
          const p = i * size / 8;
          ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, size); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(size, p); ctx.stroke();
        }
      } else if (cookie === 'dots') {
        ctx.fillStyle = '#ffffff';
        const step = size / 6;
        for (let row = 0; row < 6; row++) {
          for (let col = 0; col < 6; col++) {
            const cx = (col + 0.5) * step;
            const cy = (row + 0.5) * step;
            ctx.beginPath();
            ctx.arc(cx, cy, step * 0.26, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      } else if (cookie === 'rings') {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = size * 0.055;
        for (let r = size * 0.1; r < size * 0.75; r += size * 0.13) {
          ctx.beginPath();
          ctx.arc(size / 2, size / 2, r, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size * 0.06, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, size, size);
      }
      ctx.restore();
    }

    _packLights(scene) {
      const MAX = 8;
      const scratch = this.lightScratch;
      const entries = [];
      for (const object of scene.objects) {
        if (!object.active) continue;
        const light = object.getComponent('Light');
        if (!light || light.type === 'sun') continue;
        entries.push({ object: object, light: light });
        if (entries.length >= MAX) break;
      }
      const cells = this._syncLightCookies(entries);
      let count = 0;
      for (const entry of entries) {
        const light = entry.light;
        const type = light.type === 'spot' ? 2 : light.type === 'directional' ? 0 : 1;
        const world = entry.object.transform.worldPosition();
        const forward = V3.normalize(entry.object.transform.forward());
        const color = hexToLinear(light.color || '#ffffff');
        const intensity = light.intensity === undefined ? 1 : light.intensity;
        const range = Math.max(0.1, light.range || 10);
        const outer = UE.clamp((light.spotAngle || 48) * 0.5, 1, 89) * UE.DEG;
        const inner = UE.clamp(Math.min(light.innerAngle === undefined ? 26 : light.innerAngle, light.spotAngle || 48) * 0.5, 0.5, 89) * UE.DEG;
        const offset = count * 3;
        scratch.pos[offset] = world.x;
        scratch.pos[offset + 1] = world.y;
        scratch.pos[offset + 2] = world.z;
        scratch.dir[offset] = forward.x;
        scratch.dir[offset + 1] = forward.y;
        scratch.dir[offset + 2] = forward.z;
        scratch.color[offset] = color[0] * intensity;
        scratch.color[offset + 1] = color[1] * intensity;
        scratch.color[offset + 2] = color[2] * intensity;
        const pOffset = count * 4;
        scratch.params[pOffset] = type;
        scratch.params[pOffset + 1] = range;
        scratch.params[pOffset + 2] = Math.cos(outer);
        scratch.params[pOffset + 3] = Math.cos(inner);
        const cell = cells[entry.object.id];
        if (cell !== undefined) {
          scratch.cookie[pOffset] = (cell % 4) * 0.25;
          scratch.cookie[pOffset + 1] = Math.floor(cell / 4) * 0.25;
          scratch.cookie[pOffset + 2] = 1;
        } else {
          scratch.cookie[pOffset] = 0;
          scratch.cookie[pOffset + 1] = 0;
          scratch.cookie[pOffset + 2] = 0;
        }
        scratch.cookie[pOffset + 3] = 0.25;
        if (type === 2) {
          const up = Math.abs(forward.y) > 0.985 ? V3.create(0, 0, 1) : V3.create(0, 1, 0);
          const view = UE.Mat4.lookAt(world, V3.add(world, forward), up);
          const proj = UE.Mat4.perspective((light.spotAngle || 48), 1, 0.03, 200);
          const vp = UE.Mat4.multiply(proj, view);
          scratch.vp.set(vp, count * 16);
        }
        count++;
      }
      return {
        count: count,
        pos: scratch.pos,
        color: scratch.color,
        dir: scratch.dir,
        params: scratch.params,
        cookie: scratch.cookie,
        vp: scratch.vp
      };
    }

    _uploadLights(lights) {
      const gl = this.gl;
      const u = this.u;
      gl.uniform1i(u.lightCount, lights.count);
      gl.uniform3fv(u.lightPos, lights.pos);
      gl.uniform3fv(u.lightColor, lights.color);
      gl.uniform3fv(u.lightDir, lights.dir);
      gl.uniform4fv(u.lightParams, lights.params);
      gl.uniform4fv(u.lightCookie, lights.cookie);
      gl.uniformMatrix4fv(u.lightVP, false, lights.vp);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.cookieTexture);
      gl.uniform1i(u.cookieAtlas, 0);
    }

    _drawLightIcons(scene, vp) {
      const gl = this.gl;
      for (const object of scene.objects) {
        if (!object.active) continue;
        const light = object.getComponent('Light');
        if (!light) continue;
        const p = object.transform.worldPosition();
        const linear = hexToLinear(light.color || '#ffe0b0');
        const color = [Math.min(1, linear[0] * 1.35 + 0.05), Math.min(1, linear[1] * 1.35 + 0.05), Math.min(1, linear[2] * 1.35 + 0.05)];
        const size = 0.3;
        const model = UE.Mat4.compose(p, V3.create(), { x: size, y: size, z: size });
        const mvp = UE.Mat4.multiply(vp, model);
        for (const axis of ['x', 'y', 'z']) {
          this._lines(this.ringBuffers[axis], this.ringCount, mvp, color, 0.6, gl.LINE_LOOP);
        }
        if (light.type === 'spot' || light.type === 'directional' || light.type === 'sun') {
          const dirModel = UE.Mat4.compose(p, object.transform.rotation, { x: 1, y: 1, z: 1.6 });
          this._lines(this.dirLine, 2, UE.Mat4.multiply(vp, dirModel), color, 0.5, gl.LINES);
        }
      }
    }

    _drawGround(vp, eye) {
      const gl = this.gl;
      const model = UE.Mat4.compose(V3.create(0, -0.02, 0), V3.create(), V3.create(18, 1, 18));
      gl.useProgram(this.program);
      gl.uniformMatrix4fv(this.u.vp, false, vp);
      gl.uniformMatrix4fv(this.u.model, false, model);
      gl.uniformMatrix3fv(this.u.normal, false, UE.Mat4.normalMatrix(model));
      gl.uniform3fv(this.u.color, new Float32Array(hexToLinear('#12161d')));
      gl.uniform1f(this.u.unlit, 1);
      gl.uniform1f(this.u.useMap, 0);
      gl.uniform1f(this.u.opacity, 1);
      gl.uniform1f(this.u.emissive, 0);
      gl.uniform1f(this.u.shininess, 8);
      gl.uniform1i(this.u.lightCount, 0);
      gl.uniform3fv(this.u.camPos, new Float32Array([eye.x, eye.y, eye.z]));
      this._bindMesh(this.meshes.plane);
      gl.drawElements(gl.TRIANGLES, this.meshes.plane.count, gl.UNSIGNED_SHORT, 0);
      this.stats.draws++;
    }

    _drawGrid(vp) {
      const gl = this.gl;
      gl.useProgram(this.lineProgram);
      gl.uniformMatrix4fv(this.l.mvp, false, vp);
      gl.enable(gl.BLEND);
      gl.depthMask(false);
      this._lineArray(this.grid.minor, this.grid.minorCount, [0.55, 0.63, 0.75], 0.10, gl.LINES);
      this._lineArray(this.grid.major, this.grid.majorCount, [0.62, 0.70, 0.82], 0.17, gl.LINES);
      this._lineArray(this.grid.axisX, 2, [0.95, 0.35, 0.35], 0.55, gl.LINES);
      this._lineArray(this.grid.axisZ, 2, [0.35, 0.55, 0.98], 0.55, gl.LINES);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }

    _drawShadows(scene, vp, eye) {
      const gl = this.gl;
      gl.useProgram(this.program);
      gl.uniformMatrix4fv(this.u.vp, false, vp);
      gl.uniform3fv(this.u.camPos, new Float32Array([eye.x, eye.y, eye.z]));
      gl.uniform3fv(this.u.sunDir, new Float32Array([0, 1, 0]));
      gl.uniform3fv(this.u.sunColor, new Float32Array([0, 0, 0]));
      gl.uniform3fv(this.u.ambient, new Float32Array([1, 1, 1]));
      gl.uniform1f(this.u.unlit, 0);
      gl.uniform1f(this.u.useMap, 0);
      gl.uniform1f(this.u.shininess, 1);
      gl.uniform1i(this.u.lightCount, 0);
      gl.uniform1f(this.u.emissive, 0);
      if (this.u.hasSkin) gl.uniform1f(this.u.hasSkin, 0);
      gl.enable(gl.BLEND);
      gl.depthMask(false);
      for (const object of scene.objects) {
        if (!object.active) continue;
        const mr = object.getComponent('MeshRenderer');
        if (!mr || mr.castShadow === false || mr.primitive === 'plane') continue;
        const bounds = UE.Physics.bounds(object) || this._meshBounds(object);
        if (!bounds) continue;
        const height = Math.max(0, bounds.cy - bounds.hy);
        if (height > 14) continue;
        const radius = Math.max(bounds.hx, bounds.hz);
        const fade = Math.max(0.03, 0.26 - height * 0.018);
        const model = UE.Mat4.compose(
          { x: bounds.cx, y: 0.012, z: bounds.cz },
          V3.create(),
          { x: radius * 2.6, y: 1, z: radius * 2.6 }
        );
        gl.uniformMatrix4fv(this.u.model, false, model);
        gl.uniformMatrix3fv(this.u.normal, false, UE.Mat4.normalMatrix(model));
        gl.uniform3fv(this.u.color, new Float32Array([0, 0, 0]));
        gl.uniform1f(this.u.opacity, fade);
        this._bindMesh(this.discMesh);
        gl.drawElements(gl.TRIANGLES, this.discMesh.count, gl.UNSIGNED_SHORT, 0);
        this.stats.draws++;
      }
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }

    _drawMesh(mesh, model, mr, u, sunDir, eye, animator) {
      const gl = this.gl;
      gl.uniformMatrix4fv(u.model, false, model);
      gl.uniformMatrix3fv(u.normal, false, UE.Mat4.normalMatrix(model));
      const objectColor = hexToLinear(mr.color);
      gl.uniform1f(u.opacity, mr.opacity === undefined ? 1 : mr.opacity);
      gl.uniform1f(u.unlit, 0);
      gl.uniform1f(u.emissive, mr.emissive || 0);
      const uvScale = mr.uvScale || { x: 1, y: 1 };
      const uvOffset = mr.uvOffset || { x: 0, y: 0 };
      gl.uniform2f(u.uvScale, Number(uvScale.x) || 1, Number(uvScale.y) || 1);
      gl.uniform2f(u.uvOffset, Number(uvOffset.x) || 0, Number(uvOffset.y) || 0);
      const rough = mr.roughness === undefined ? 0.55 : UE.clamp(mr.roughness, 0.02, 1);
      gl.uniform1f(u.shininess, Math.max(2, Math.pow(2, (1 - rough) * 10)));
      const prims = mesh.prims || [mesh];

      let skinBuffers = null;
      let bones = null;
      if (animator && animator.skeleton && animator.skeleton.length && mr.meshId) {
        bones = animator.boneMatrices();
        if (bones) {
          gl.uniformMatrix4fv(u.bones, false, bones);
          skinBuffers = this._skinMesh(mr.meshId, animator.skeleton);
          if (skinBuffers && skinBuffers.length !== prims.length) skinBuffers = null;
        }
      }
      gl.uniform1f(u.hasSkin, skinBuffers ? 1 : 0);

      for (let i = 0; i < prims.length; i++) {
        const prim = prims[i];
        const material = prim.material || null;
        const factor = material && material.color ? hexToLinear(material.color) : null;
        gl.uniform3fv(u.color, new Float32Array([
          objectColor[0] * (factor ? factor[0] : 1),
          objectColor[1] * (factor ? factor[1] : 1),
          objectColor[2] * (factor ? factor[2] : 1)
        ]));
        const mapped = !!prim.map;
        gl.uniform1f(u.useMap, mapped ? 1 : 0);
        if (mapped) {
          gl.activeTexture(gl.TEXTURE1);
          gl.bindTexture(gl.TEXTURE_2D, prim.map);
        }
        this._bindMesh(prim, skinBuffers ? skinBuffers[i] : null);
        gl.drawElements(gl.TRIANGLES, prim.count, prim.indexType || gl.UNSIGNED_SHORT, 0);
        this.stats.triangles += prim.triangles;
        this.stats.draws++;
      }
    }

    _bindMesh(mesh, skinBuffer) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vbo);
      gl.enableVertexAttribArray(this.aPos);
      gl.vertexAttribPointer(this.aPos, 3, gl.FLOAT, false, 32, 0);
      gl.enableVertexAttribArray(this.aNormal);
      gl.vertexAttribPointer(this.aNormal, 3, gl.FLOAT, false, 32, 12);
      if (this.aUV >= 0) {
        gl.enableVertexAttribArray(this.aUV);
        gl.vertexAttribPointer(this.aUV, 2, gl.FLOAT, false, 32, 24);
      }
      if (skinBuffer && this.aJoint >= 0 && this.aWeight >= 0) {
        gl.bindBuffer(gl.ARRAY_BUFFER, skinBuffer);
        gl.enableVertexAttribArray(this.aJoint);
        gl.vertexAttribPointer(this.aJoint, 4, gl.FLOAT, false, 32, 0);
        gl.enableVertexAttribArray(this.aWeight);
        gl.vertexAttribPointer(this.aWeight, 4, gl.FLOAT, false, 32, 16);
      } else {
        if (this.aJoint >= 0) gl.disableVertexAttribArray(this.aJoint);
        if (this.aWeight >= 0) gl.disableVertexAttribArray(this.aWeight);
      }
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ibo);
    }

    _drawWireframe(scene, vp, eye) {
      const gl = this.gl;
      gl.useProgram(this.lineProgram);
      gl.uniformMatrix4fv(this.l.mvp, false, vp);
      gl.enable(gl.BLEND);
      gl.depthMask(false);
      gl.uniform3fv(this.l.color, new Float32Array([0.36, 0.78, 1.0]));
      gl.uniform1f(this.l.alpha, 0.28);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.unitLine);
      gl.enableVertexAttribArray(this.aLinePos);
      gl.vertexAttribPointer(this.aLinePos, 3, gl.FLOAT, false, 12, 0);
      for (const object of scene.objects) {
        if (!object.active) continue;
        const mr = object.getComponent('MeshRenderer');
        if (!mr) continue;
        const mesh = this._resolveMesh(mr);
        if (!mesh) continue;
        const mvp = UE.Mat4.multiply(vp, object.transform.worldMatrix());
        gl.uniformMatrix4fv(this.l.mvp, false, mvp);
        const prims = mesh.prims || [mesh];
        for (const prim of prims) {
          if (!prim.ebo) continue;
          gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, prim.ebo);
          gl.drawElements(gl.LINES, prim.edgeCount, prim.edgeType || gl.UNSIGNED_SHORT, 0);
          this.stats.draws++;
        }
      }
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }

    _lines(buffer, count, mvp, color, alpha, mode) {
      const gl = this.gl;
      gl.useProgram(this.lineProgram);
      gl.uniformMatrix4fv(this.l.mvp, false, mvp);
      gl.uniform3fv(this.l.color, new Float32Array(color));
      gl.uniform1f(this.l.alpha, alpha);
      gl.enable(gl.BLEND);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.enableVertexAttribArray(this.aLinePos);
      gl.vertexAttribPointer(this.aLinePos, 3, gl.FLOAT, false, 12, 0);
      gl.drawArrays(mode, 0, count);
      this.stats.draws++;
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }

    _lineArray(buffer, count, color, alpha, mode) {
      const gl = this.gl;
      gl.uniform3fv(this.l.color, new Float32Array(color));
      gl.uniform1f(this.l.alpha, alpha);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.enableVertexAttribArray(this.aLinePos);
      gl.vertexAttribPointer(this.aLinePos, 3, gl.FLOAT, false, 12, 0);
      gl.drawArrays(mode, 0, count);
      this.stats.draws++;
    }

    _drawGizmo(gizmo, vp, eye, scene) {
      const gl = this.gl;
      const origin = gizmo.origin;
      const scale = gizmo.scale;
      const mode = gizmo.mode;
      const hover = gizmo.hover;
      const modelAt = (pos, rot, scl) => UE.Mat4.compose(pos, rot || V3.create(), scl || V3.create(1, 1, 1));

      const axisVec = { x: V3.create(1, 0, 0), y: V3.create(0, 1, 0), z: V3.create(0, 0, 1) };

      if (mode === 'rotate') {
        for (const axis of ['x', 'y', 'z']) {
          const color = hover === axis ? HOVER : AXIS_COLORS[axis];
          const model = modelAt(origin, V3.create(), { x: scale, y: scale, z: scale });
          this._lines(this.ringBuffers[axis], this.ringCount, UE.Mat4.multiply(vp, model), color, 1, gl.LINE_LOOP);
        }
        return;
      }

      const len = mode === 'scale' ? scale * 0.88 : scale;
      for (const axis of ['x', 'y', 'z']) {
        const color = hover === axis ? HOVER : AXIS_COLORS[axis];
        const dir = axisVec[axis];
        const shaftEnd = V3.add(origin, V3.scale(dir, len * (mode === 'scale' ? 0.86 : 0.78)));
        /* draw shaft from origin toward axis using unitLine scaled */
        this._lines(this.unitLine, 2, UE.Mat4.multiply(vp, UE.Mat4.compose(origin, V3.create(), { x: dir.x * len, y: dir.y * len, z: dir.z * len })), color, 1, gl.LINES);
        this._axisCap(axis, shaftEnd, scale * (mode === 'scale' ? 0.12 : 0.17), color, vp, eye);
      }
      if (mode === 'scale') {
        const s = scale * 0.09;
        this._unlitCube(origin, V3.create(s, s, s), [0.85, 0.88, 0.95], vp, eye);
      }
    }

    _axisCap(axis, pos, size, color, vp, eye) {
      const rot = axis === 'x' ? V3.create(0, 0, -90) : axis === 'z' ? V3.create(90, 0, 0) : V3.create();
      const half = size * 0.5;
      const dir = axis === 'x' ? V3.create(1, 0, 0) : axis === 'z' ? V3.create(0, 0, 1) : V3.create(0, 1, 0);
      const center = V3.add(pos, V3.scale(dir, size * 0.5));
      const model = UE.Mat4.compose(center, rot, V3.create(size * 0.55, size, size * 0.55));
      this._drawUnlit(this.meshes.cone, model, color, vp, eye);
    }

    _unlitCube(pos, size, color, vp, eye) {
      const model = UE.Mat4.compose(pos, V3.create(), size);
      this._drawUnlit(this.meshes.cube, model, color, vp, eye);
    }

    _drawUnlit(mesh, model, color, vp, eye) {
      const gl = this.gl;
      gl.useProgram(this.program);
      gl.uniformMatrix4fv(this.u.model, false, model);
      gl.uniformMatrix4fv(this.u.vp, false, vp);
      gl.uniformMatrix3fv(this.u.normal, false, UE.Mat4.normalMatrix(model));
      gl.uniform3fv(this.u.color, new Float32Array(color));
      gl.uniform3fv(this.u.camPos, new Float32Array([eye.x, eye.y, eye.z]));
      gl.uniform3fv(this.u.sunDir, new Float32Array([0, 1, 0]));
      gl.uniform3fv(this.u.sunColor, new Float32Array([0, 0, 0]));
      gl.uniform3fv(this.u.ambient, new Float32Array([1, 1, 1]));
      gl.uniform1f(this.u.unlit, 1);
      gl.uniform1f(this.u.useMap, 0);
      gl.uniform1i(this.u.lightCount, 0);
      gl.uniform1f(this.u.opacity, 1);
      gl.uniform1f(this.u.emissive, 0);
      gl.uniform1f(this.u.shininess, 4);
      if (this.u.hasSkin) gl.uniform1f(this.u.hasSkin, 0);
      gl.disable(gl.BLEND);
      gl.depthMask(true);
      this._bindMesh(mesh);
      gl.drawElements(gl.TRIANGLES, mesh.count, mesh.indexType || gl.UNSIGNED_SHORT, 0);
      this.stats.draws++;
    }
  }

  UE.Renderer = Renderer;
  UE.hexToLinear = hexToLinear;
  return UE;
});
