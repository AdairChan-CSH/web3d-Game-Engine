/* UnirealEngine — manual.js
 * Standalone documentation shell: renders the live PlayMaker action catalog,
 * builds a client-side search index and provides keyboard-friendly search. */
(function () {
  'use strict';

  const $ = function (selector, root) { return (root || document).querySelector(selector); };
  const $$ = function (selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); };

  const searchInput = $('#manualSearch');
  const searchWrap = $('.search-wrap');
  const clearButton = $('#btnClearSearch');
  const searchPanel = $('#searchPanel');
  const searchResults = $('#searchResults');
  const searchStatus = $('#searchStatus');
  const searchEmpty = $('#searchEmpty');
  const searchFoot = $('#searchFoot');
  const showAllButton = $('#btnShowAll');
  const hero = $('#hero');
  const docBody = $('#docBody');
  const sidebar = $('#manualSidebar');
  const navScrim = $('#navScrim');
  const navToggle = $('#btnNav');
  const actionNav = $('#actionNav');
  const actionReference = $('#actionReference');
  const actionFilter = $('#actionFilter');
  const actionCount = $('#actionCount');

  const RESULT_LIMIT = 14;
  const KIND_LABELS = { guide: 'Guide', actions: 'Action', api: 'API', shortcuts: 'Shortcut' };

  let entries = [];
  let activeFilter = 'all';
  let showAll = false;
  let activeResult = -1;
  let searchActive = false;
  let actionCategories = [];

  /* --------------------------------------------------------------- utilities */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }
  function slug(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
  function normalize(value) {
    return String(value || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[+]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  function highlight(text, terms) {
    const list = terms.filter(Boolean).slice().sort(function (a, b) { return b.length - a.length; });
    if (!list.length) return escapeHtml(text);
    const re = new RegExp('(' + list.map(escapeRegExp).join('|') + ')', 'gi');
    return String(text).split(re).map(function (part, index) {
      return index % 2 ? '<mark>' + escapeHtml(part) + '</mark>' : escapeHtml(part);
    }).join('');
  }
  function parseQuery(query) {
    const text = String(query || '').trim();
    const phrases = [];
    const rest = text.replace(/"([^"]+)"/g, function (_, phrase) {
      if (phrase.trim()) phrases.push(normalize(phrase));
      return ' ';
    });
    const words = rest.split(/\s+/).map(normalize).filter(Boolean);
    const seen = new Set();
    return phrases.concat(words).filter(function (term) {
      if (!term || seen.has(term)) return false;
      seen.add(term);
      return true;
    });
  }
  function collapse(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }
  function truncate(value, length) {
    const text = collapse(value);
    return text.length > length ? text.slice(0, length - 1) + '…' : text;
  }

  /* ------------------------------------------------------- action catalog UI */
  function paramType(type) {
    switch (type) {
      case 'text': return 'text';
      case 'number': return 'number';
      case 'select': return 'choice';
      case 'bool': return 'boolean';
      case 'color': return 'color';
      case 'object': return 'object';
      case 'key': return 'key';
      case 'primitive': return 'primitive';
      default: return type || 'value';
    }
  }
  function formatDefault(value) {
    if (value === undefined) return '—';
    if (value === '') return '""';
    if (typeof value === 'boolean') return value ? 'true' : 'false';
    if (typeof value === 'number') return String(value);
    if (value === null) return 'null';
    if (typeof value === 'object') return truncate(JSON.stringify(value), 34);
    return truncate(String(value), 34);
  }
  function buildActions() {
    if (!actionReference) return;
    const PM = window.UE && window.UE.PlayMaker;
    actionReference.replaceChildren();
    actionCategories = [];

    if (!PM || !Array.isArray(PM.catalog) || !PM.catalog.length) {
      const error = el('div', 'action-error');
      error.appendChild(el('strong', null, 'The live action catalog could not be loaded.'));
      error.appendChild(el('p', null, 'The manual search still covers the written guide. Reload the page, or open the editor to inspect PlayMaker actions in the Inspector.'));
      actionReference.appendChild(error);
      if (actionCount) actionCount.textContent = 'Catalog unavailable';
      return;
    }

    const categories = Array.isArray(PM.categories) && PM.categories.length
      ? PM.categories.slice()
      : PM.catalog.map(function (action) { return action.category; }).filter(function (value, index, list) { return list.indexOf(value) === index; });

    categories.forEach(function (category) {
      const actions = PM.catalog.filter(function (action) { return action.category === category; });
      if (!actions.length) return;
      actionCategories.push(category);

      const categoryNode = el('div', 'action-category');
      categoryNode.id = 'action-category-' + slug(category);
      categoryNode.dataset.category = category;

      const head = el('div', 'action-category-head');
      head.appendChild(el('h3', null, category));
      head.appendChild(el('span', null, actions.length + (actions.length === 1 ? ' action' : ' actions')));
      categoryNode.appendChild(head);

      actions.forEach(function (action) {
        const card = document.createElement('details');
        card.className = 'action-card';
        card.id = 'action-' + action.type;
        card.dataset.kind = 'actions';
        card.dataset.title = action.label;
        card.dataset.category = action.category;

        const summary = document.createElement('summary');
        summary.appendChild(el('span', 'action-label', action.label));
        summary.appendChild(el('code', 'action-type', action.type));
        summary.appendChild(el('span', 'action-category-chip', action.category));
        card.appendChild(summary);

        const body = el('div', 'action-body');
        const help = action.help || ('Runs the ' + action.label + ' action in the current FSM state.');
        body.appendChild(el('p', 'action-help', help));

        if (Array.isArray(action.params) && action.params.length) {
          const table = el('table', 'action-params');
          const thead = document.createElement('thead');
          const headRow = document.createElement('tr');
          ['Parameter', 'Type', 'Default'].forEach(function (label) {
            headRow.appendChild(el('th', null, label));
          });
          thead.appendChild(headRow);
          table.appendChild(thead);
          const tbody = document.createElement('tbody');
          action.params.forEach(function (param) {
            const row = document.createElement('tr');
            row.appendChild(el('td', null, param.label || param.key));
            row.appendChild(el('td', null, paramType(param.type)));
            const defaultCell = document.createElement('td');
            defaultCell.appendChild(el('code', null, formatDefault(param.default)));
            if (param.type === 'select' && Array.isArray(param.options) && param.options.length) {
              defaultCell.appendChild(el('span', 'param-options',
                param.options.map(function (option) { return option.label || option.value; }).join(' · ')));
            }
            row.appendChild(defaultCell);
            tbody.appendChild(row);
          });
          table.appendChild(tbody);
          body.appendChild(table);
        } else {
          body.appendChild(el('p', 'action-help', 'This action has no parameters.'));
        }

        const returnNote = el('p', 'action-return');
        returnNote.innerHTML = '<strong>Flow:</strong> instant actions finish in the same step; waiting, motion and request actions can continue across steps.';
        body.appendChild(returnNote);
        card.appendChild(body);
        categoryNode.appendChild(card);
      });

      actionReference.appendChild(categoryNode);
    });

    if (actionCount) {
      actionCount.textContent = PM.catalog.length + ' actions · ' + actionCategories.length + ' categories';
    }
    buildActionNav(PM);
    filterActions();
  }

  function buildActionNav(PM) {
    if (!actionNav) return;
    actionNav.replaceChildren();
    actionCategories.forEach(function (category) {
      const count = PM.catalog.filter(function (action) { return action.category === category; }).length;
      const link = el('a', null, category + ' (' + count + ')');
      link.href = '#action-category-' + slug(category);
      actionNav.appendChild(link);
    });
  }

  function filterActions() {
    if (!actionReference || !actionFilter) return;
    const query = normalize(actionFilter.value);
    const cards = $$('.action-card', actionReference);
    let visible = 0;
    const categoryNodes = $$('.action-category', actionReference);

    cards.forEach(function (card) {
      const haystack = normalize(
        (card.dataset.title || '') + ' ' +
        (card.dataset.category || '') + ' ' +
        (card.textContent || '')
      );
      const matches = !query || query.split(' ').every(function (term) { return haystack.indexOf(term) !== -1; });
      card.hidden = !matches;
      if (matches) visible++;
    });

    categoryNodes.forEach(function (node) {
      const any = $$('.action-card', node).some(function (card) { return !card.hidden; });
      node.hidden = !any;
    });

    let empty = $('#actionFilterEmpty');
    if (!empty) {
      empty = el('div', 'action-loading');
      empty.id = 'actionFilterEmpty';
      actionReference.appendChild(empty);
    }
    empty.hidden = visible !== 0;
    empty.textContent = 'No actions match “' + actionFilter.value.trim() + '”. Clear the filter to show all ' + cards.length + ' actions.';

    if (actionCount) {
      actionCount.textContent = query
        ? visible + ' of ' + cards.length + ' actions'
        : cards.length + ' actions · ' + categoryNodes.length + ' categories';
    }
  }

  /* ------------------------------------------------------------ search index */
  function addEntry(entry) {
    if (!entry || !entry.element) return;
    const title = collapse(entry.title || 'Untitled');
    const crumb = collapse(entry.breadcrumb || '');
    const text = collapse(entry.text || '');
    entries.push({
      id: entry.id || entry.element.id || '',
      kind: entry.kind || 'guide',
      title: title,
      breadcrumb: crumb,
      text: text,
      element: entry.element,
      titleKey: normalize(title),
      crumbKey: normalize(crumb),
      textKey: normalize(title + ' ' + crumb + ' ' + text)
    });
  }

  function headingId(heading, section) {
    if (heading.id) return heading.id;
    let base = (section.id ? section.id + '-' : '') + slug(heading.textContent);
    let id = base;
    let n = 2;
    while (document.getElementById(id)) id = base + '-' + n++;
    heading.id = id;
    return id;
  }

  function nearestHeading(element, section) {
    let node = element;
    while (node && node !== section) {
      if (node.tagName === 'H3') return node;
      node = node.previousElementSibling;
    }
    return null;
  }

  function rowKind(sectionId) {
    if (sectionId === 'shortcuts') return 'shortcuts';
    if (['scripting', 'inspector', 'web', 'tags'].indexOf(sectionId) !== -1) return 'api';
    return 'guide';
  }

  function indexSection(section) {
    const heading = $('h2', section);
    if (!heading) return;
    const title = collapse(heading.textContent);
    const sectionId = section.id;
    const introParts = [];
    let firstHeading = null;

    Array.prototype.forEach.call(section.children, function (child) {
      if (child === heading || child.classList.contains('section-kicker')) return;
      if (child.tagName === 'H3') {
        if (!firstHeading) firstHeading = child;
        return;
      }
      if (firstHeading) return;
      if (child.matches('.action-toolbar, .action-reference, noscript')) return;
      introParts.push(child.textContent || '');
    });

    addEntry({
      id: sectionId,
      kind: section.dataset.kind || 'guide',
      title: title,
      breadcrumb: title,
      text: introParts.join(' '),
      element: section
    });

    const headings = $$('h3', section);
    headings.forEach(function (h3) {
      const id = headingId(h3, section);
      const parts = [h3.textContent];
      let next = h3.nextElementSibling;
      while (next && next.tagName !== 'H3') {
        parts.push(next.textContent || '');
        next = next.nextElementSibling;
      }
      addEntry({
        id: id,
        kind: section.dataset.kind || 'guide',
        title: collapse(h3.textContent),
        breadcrumb: title,
        text: parts.join(' '),
        element: h3
      });
    });

    $$('.doc-table tbody tr', section).forEach(function (row) {
      const cells = $$('td', row);
      if (!cells.length) return;
      const h3 = nearestHeading(row, section);
      addEntry({
        id: h3 ? h3.id : sectionId,
        kind: rowKind(sectionId),
        title: collapse(cells[0].textContent),
        breadcrumb: title + (h3 ? ' › ' + collapse(h3.textContent) : ''),
        text: cells.map(function (cell) { return cell.textContent; }).join(' '),
        element: row
      });
    });

    $$('pre', section).forEach(function (pre) {
      const h3 = nearestHeading(pre, section);
      const isDiagram = pre.classList.contains('diagram');
      addEntry({
        id: h3 ? h3.id : sectionId,
        kind: isDiagram ? 'guide' : 'api',
        title: isDiagram ? 'Layout diagram' : 'Code example',
        breadcrumb: title + (h3 ? ' › ' + collapse(h3.textContent) : ''),
        text: pre.textContent,
        element: pre
      });
    });
  }

  function buildSearchIndex() {
    entries = [];
    addEntry({
      id: 'hero',
      kind: 'guide',
      title: 'UnirealEngine manual',
      breadcrumb: 'Overview',
      text: 'Browser-only editor and engine. Scene editor, WebGL renderer, scripting, physics, model import, animation, auto-rigging, PlayMaker and 54 actions.',
      element: hero
    });

    $$('#docBody > .doc-section').forEach(function (section) {
      if (section.dataset.noSectionIndex === 'true') {
        const heading = $('h2', section);
        if (heading) {
          addEntry({
            id: section.id,
            kind: 'guide',
            title: collapse(heading.textContent),
            breadcrumb: collapse(heading.textContent),
            text: heading.nextElementSibling ? heading.nextElementSibling.textContent : '',
            element: section
          });
        }
        return;
      }
      indexSection(section);
    });

    $$('.action-card', actionReference).forEach(function (card) {
      const category = card.dataset.category || 'PlayMaker';
      addEntry({
        id: card.id,
        kind: 'actions',
        title: card.dataset.title || card.id.replace(/^action-/, ''),
        breadcrumb: 'PlayMaker actions › ' + category,
        text: card.textContent,
        element: card
      });
    });
  }

  /* ---------------------------------------------------------------- searching */
  function snippetFor(entry, terms) {
    const text = collapse(entry.text) || entry.title;
    const lower = normalize(text);
    let position = -1;
    terms.forEach(function (term) {
      const index = lower.indexOf(term);
      if (index !== -1 && (position === -1 || index < position)) position = index;
    });
    if (position === -1) position = 0;
    let start = Math.max(0, position - 52);
    let end = Math.min(text.length, start + 190);
    if (start > 0) {
      const space = text.indexOf(' ', start);
      if (space !== -1 && space < position) start = space + 1;
    }
    if (end < text.length) {
      const space = text.lastIndexOf(' ', end);
      if (space > position) end = space;
    }
    const clipped = text.slice(start, end).trim();
    return (start > 0 ? '… ' : '') + clipped + (end < text.length ? ' …' : '');
  }

  function scoreEntry(entry, terms, fullQuery) {
    let score = 0;
    terms.forEach(function (term) {
      if (entry.titleKey.indexOf(term) !== -1) {
        score += term.indexOf(' ') !== -1 ? 18 : 12;
        if (entry.titleKey.indexOf(term) === 0) score += 8;
      }
      if (entry.crumbKey.indexOf(term) !== -1) score += 5;
      if (entry.textKey.indexOf(term) !== -1) score += 2;
      if (entry.kind === 'actions' && entry.breadcrumb.indexOf('actions') !== -1) score += 1;
    });
    if (fullQuery && entry.titleKey.indexOf(fullQuery) !== -1) score += 20;
    return score;
  }

  function matchingEntries(query) {
    const terms = parseQuery(query);
    if (!terms.length) return { terms: terms, results: [] };
    const fullQuery = normalize(query);
    const results = [];

    entries.forEach(function (entry) {
      if (activeFilter !== 'all' && entry.kind !== activeFilter) return;
      const matches = terms.every(function (term) { return entry.textKey.indexOf(term) !== -1; });
      if (!matches) return;
      results.push({ entry: entry, score: scoreEntry(entry, terms, fullQuery) });
    });

    results.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return a.entry.title.localeCompare(b.entry.title);
    });
    return { terms: terms, results: results };
  }

  function renderResult(result, terms, index) {
    const entry = result.entry;
    const link = document.createElement('a');
    link.className = 'result';
    link.href = '#' + entry.id;
    link.dataset.resultIndex = String(index);
    link.setAttribute('role', 'option');
    link.innerHTML =
      '<span class="result-top">' +
        '<span class="result-kind ' + escapeHtml(entry.kind) + '">' + escapeHtml(KIND_LABELS[entry.kind] || entry.kind) + '</span>' +
        '<span class="result-crumb">' + escapeHtml(entry.breadcrumb) + '</span>' +
      '</span>' +
      '<span class="result-title">' + highlight(entry.title, terms) + '</span>' +
      '<span class="result-snippet">' + highlight(snippetFor(entry, terms), terms) + '</span>';
    link.addEventListener('click', function (event) {
      event.preventDefault();
      openEntry(entry);
    });
    return link;
  }

  function updateFilterButtons() {
    $$('.search-filters button').forEach(function (button) {
      button.classList.toggle('on', button.dataset.filter === activeFilter);
      button.setAttribute('aria-pressed', button.dataset.filter === activeFilter ? 'true' : 'false');
    });
  }

  function setSearchMode(on) {
    searchActive = on;
    searchPanel.hidden = !on;
    hero.hidden = on;
    docBody.hidden = on;
    document.body.classList.toggle('in-search', on);
  }

  function applySearch() {
    const query = searchInput.value.trim();
    const hasValue = searchInput.value.length > 0;
    searchWrap.classList.toggle('has-value', hasValue);
    clearButton.hidden = !hasValue;

    if (!query) {
      setSearchMode(false);
      searchResults.replaceChildren();
      searchStatus.textContent = '';
      searchEmpty.hidden = true;
      searchFoot.hidden = true;
      activeResult = -1;
      showAll = false;
      updateSearchUrl('');
      return;
    }

    showAll = false;
    renderSearch(query);
    updateSearchUrl(query);
  }

  function renderSearch(query) {
    const data = matchingEntries(query);
    const total = data.results.length;
    const visible = showAll ? data.results : data.results.slice(0, RESULT_LIMIT);
    const sectionCount = new Set(data.results.map(function (result) { return result.entry.breadcrumb.split(' › ')[0]; })).size;

    setSearchMode(true);
    searchResults.replaceChildren();
    activeResult = -1;

    searchEmpty.hidden = total !== 0;
    if (total === 0) {
      searchStatus.textContent = 'No results for “' + query + '”' + (activeFilter === 'all' ? '' : ' in ' + KIND_LABELS[activeFilter]);
      searchFoot.hidden = true;
      searchResults.hidden = true;
      return;
    }

    searchResults.hidden = false;
    searchStatus.textContent = total + (total === 1 ? ' result' : ' results') +
      ' in ' + sectionCount + (sectionCount === 1 ? ' section' : ' sections') +
      (activeFilter === 'all' ? '' : ' · ' + KIND_LABELS[activeFilter]) +
      (showAll || total <= RESULT_LIMIT ? '' : ' · showing first ' + RESULT_LIMIT);

    visible.forEach(function (result, index) {
      searchResults.appendChild(renderResult(result, data.terms, index));
    });

    searchFoot.hidden = total <= RESULT_LIMIT;
    if (showAllButton) {
      showAllButton.textContent = showAll ? 'Show first ' + RESULT_LIMIT : 'Show all ' + total + ' results';
    }
  }

  function updateSearchUrl(query) {
    try {
      const base = location.pathname;
      const url = query ? base + '?q=' + encodeURIComponent(query) : base + location.hash;
      history.replaceState(null, '', url);
    } catch (err) {
      /* file:// URLs can reject history updates in some browsers. */
    }
  }

  function setActiveResult(index) {
    const results = $$('.result', searchResults);
    if (!results.length) return;
    if (activeResult >= 0 && results[activeResult]) results[activeResult].classList.remove('active');
    activeResult = (index + results.length) % results.length;
    const active = results[activeResult];
    active.classList.add('active');
    active.setAttribute('aria-selected', 'true');
    active.scrollIntoView({ block: 'nearest' });
  }

  function openEntry(entry) {
    const element = entry.element;
    if (!element) return;
    if (entry.kind === 'actions' && actionFilter && actionFilter.value) {
      actionFilter.value = '';
      filterActions();
    }
    const card = element.tagName === 'DETAILS' ? element : element.closest('details.action-card');
    if (card) card.open = true;

    clearSearch(false, false);
    closeSidebar();

    const target = element;
    requestAnimationFrame(function () {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      target.classList.remove('search-flash');
      void target.offsetWidth;
      target.classList.add('search-flash');
      window.setTimeout(function () { target.classList.remove('search-flash'); }, 1600);
      try {
        if (entry.id) history.replaceState(null, '', '#' + entry.id);
      } catch (err) { /* ignore file:// history restrictions */ }
    });
  }

  function clearSearch(focus, keepUrl) {
    searchInput.value = '';
    searchWrap.classList.remove('has-value');
    clearButton.hidden = true;
    activeFilter = 'all';
    showAll = false;
    activeResult = -1;
    updateFilterButtons();
    setSearchMode(false);
    searchResults.replaceChildren();
    searchStatus.textContent = '';
    searchEmpty.hidden = true;
    searchFoot.hidden = true;
    if (!keepUrl) updateSearchUrl('');
    if (focus !== false) searchInput.focus();
    closeSidebar();
  }

  /* ------------------------------------------------------------- navigation */
  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove('open');
    if (navScrim) navScrim.hidden = true;
    if (navToggle) navToggle.setAttribute('aria-expanded', 'false');
  }

  function toggleSidebar() {
    const open = !sidebar.classList.contains('open');
    sidebar.classList.toggle('open', open);
    if (navScrim) navScrim.hidden = !open;
    if (navToggle) navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function revealHash() {
    let id = '';
    try { id = decodeURIComponent(location.hash.replace(/^#/, '')); }
    catch (err) { id = location.hash.replace(/^#/, ''); }
    if (!id) return;
    const target = document.getElementById(id);
    if (!target) return;
    if (target.tagName === 'DETAILS') target.open = true;
    const card = target.closest && target.closest('details.action-card');
    if (card) card.open = true;
    window.setTimeout(function () {
      target.scrollIntoView({ block: 'start' });
      target.classList.add('search-flash');
      window.setTimeout(function () { target.classList.remove('search-flash'); }, 1400);
    }, 40);
  }

  function updateActiveNav() {
    if (searchActive) return;
    const all = $$('#docBody > .doc-section');
    if (!all.length) return;
    const threshold = 110;
    let current = all[0];
    all.forEach(function (section) {
      if (section.getBoundingClientRect().top <= threshold) current = section;
    });
    $$('#manualNav > a').forEach(function (link) {
      link.classList.toggle('active', link.getAttribute('href') === '#' + current.id);
    });
  }

  function bindEvents() {
    if (searchInput) {
      searchInput.addEventListener('input', applySearch);
      searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'ArrowDown') {
          event.preventDefault();
          setActiveResult(activeResult + 1);
        } else if (event.key === 'ArrowUp') {
          event.preventDefault();
          setActiveResult(activeResult - 1);
        } else if (event.key === 'Enter') {
          const result = activeResult >= 0 ? $$('.result', searchResults)[activeResult] : $('.result', searchResults);
          if (result) {
            event.preventDefault();
            result.click();
          }
        } else if (event.key === 'Escape') {
          if (searchInput.value) {
            event.preventDefault();
            clearSearch(true);
          } else {
            searchInput.blur();
          }
        }
      });
    }

    if (clearButton) {
      clearButton.addEventListener('click', function () { clearSearch(true); });
    }
    if (showAllButton) {
      showAllButton.addEventListener('click', function () {
        showAll = !showAll;
        renderSearch(searchInput.value.trim());
      });
    }
    const emptyClear = $('#btnEmptyClear');
    if (emptyClear) emptyClear.addEventListener('click', function () { clearSearch(true); });
    const heroSearch = $('#btnHeroSearch');
    if (heroSearch) heroSearch.addEventListener('click', function () { searchInput.focus(); searchInput.select(); });

    $$('.search-filters button').forEach(function (button) {
      button.addEventListener('click', function () {
        activeFilter = button.dataset.filter || 'all';
        updateFilterButtons();
        if (searchInput.value.trim()) renderSearch(searchInput.value.trim());
      });
    });

    $$('.suggestion-row button').forEach(function (button) {
      button.addEventListener('click', function () {
        searchInput.value = button.dataset.suggest || button.textContent;
        applySearch();
        searchInput.focus();
      });
    });

    if (navToggle) navToggle.addEventListener('click', toggleSidebar);
    if (navScrim) navScrim.addEventListener('click', closeSidebar);
    if (sidebar) {
      sidebar.addEventListener('click', function (event) {
        const link = event.target.closest('a[href^="#"]');
        if (link) {
          if (searchActive) clearSearch(false, false);
          if (actionFilter && actionFilter.value && link.getAttribute('href').indexOf('#action') === 0) {
            actionFilter.value = '';
            filterActions();
          }
          closeSidebar();
        }
      });
    }

    if (actionFilter) actionFilter.addEventListener('input', filterActions);
    const expandActions = $('#btnExpandActions');
    if (expandActions) {
      expandActions.addEventListener('click', function () {
        $$('.action-card', actionReference).forEach(function (card) { if (!card.hidden) card.open = true; });
      });
    }
    const collapseActions = $('#btnCollapseActions');
    if (collapseActions) {
      collapseActions.addEventListener('click', function () {
        $$('.action-card', actionReference).forEach(function (card) { card.open = false; });
      });
    }

    document.addEventListener('keydown', function (event) {
      const target = event.target;
      const typing = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT');
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchInput.focus();
        searchInput.select();
        return;
      }
      if (!typing && event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey) {
        event.preventDefault();
        searchInput.focus();
      }
      if (event.key === 'Escape' && searchActive && target !== searchInput) {
        clearSearch(false);
      }
    });

    window.addEventListener('hashchange', revealHash);
    window.addEventListener('scroll', function () {
      if (updateActiveNav.pending) return;
      updateActiveNav.pending = true;
      requestAnimationFrame(function () {
        updateActiveNav.pending = false;
        updateActiveNav();
      });
    }, { passive: true });
  }

  function init() {
    buildActions();
    buildSearchIndex();
    bindEvents();
    updateFilterButtons();

    const params = new URLSearchParams(location.search);
    const initial = params.get('q');
    if (initial) {
      searchInput.value = initial;
      applySearch();
    } else {
      updateActiveNav();
      revealHash();
    }
    if (actionFilter) actionFilter.value = '';
    filterActions();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
