/* UnirealEngine — animation.js
 * Model animation without a build step: heuristic humanoid auto-rigging,
 * per-vertex skin weights, layered clip blending (crossfade / mix / additive)
 * and a deterministic 99,999-motion procedural library that is generated
 * lazily in the browser. No external clips, no server and no SQL. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;
  const Q = UE.Q;
  const Mat4 = UE.Mat4;
  if (!UE.Component) throw new Error('engine.js must load before animation.js');

  const BONE_LIMIT = 24;
  const MAX_MOTIONS = 99999;
  const PER_CATEGORY = 4000;

  /* --------------------------------------------------------------- utilities */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function smoothstep(t) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); }
  function seeded(index, salt) {
    let x = Math.imul((index | 0) + 0x9e3779b9, 0x85ebca6b) ^ Math.imul((salt | 0) + 0x27d4eb2d, 0xc2b2ae35);
    x = Math.imul(x ^ (x >>> 13), 0x27d4eb2d);
    x ^= x >>> 16;
    return (x >>> 0) / 4294967296;
  }
  function variation(index) {
    return {
      amp: 0.65 + seeded(index, 1) * 0.7,
      phase: seeded(index, 2) * Math.PI * 2,
      freq: 0.8 + seeded(index, 3) * 0.45,
      lean: (seeded(index, 4) - 0.5) * 12,
      twist: 0.6 + seeded(index, 5) * 0.9,
      bob: 0.8 + seeded(index, 6) * 0.5
    };
  }
  function addRot(pose, name, x, y, z) {
    const cur = pose.rot[name] || (pose.rot[name] = [0, 0, 0]);
    cur[0] += x || 0; cur[1] += y || 0; cur[2] += z || 0;
  }
  function addPos(pose, name, x, y, z) {
    const cur = pose.pos[name] || (pose.pos[name] = [0, 0, 0]);
    cur[0] += x || 0; cur[1] += y || 0; cur[2] += z || 0;
  }
  function emptyPose() { return { rot: {}, pos: {} }; }

  /* ------------------------------------------------------- motion categories */
  const CATEGORIES = [
    { key: 'idle', name: 'Idle', loop: true, duration: [2.4, 5.2] },
    { key: 'walk', name: 'Walk', loop: true, duration: [0.8, 1.4] },
    { key: 'run', name: 'Run', loop: true, duration: [0.55, 0.95] },
    { key: 'sprint', name: 'Sprint', loop: true, duration: [0.42, 0.72] },
    { key: 'jump', name: 'Jump', loop: false, duration: [0.7, 1.15] },
    { key: 'fall', name: 'Fall', loop: true, duration: [1.0, 1.8] },
    { key: 'land', name: 'Land', loop: false, duration: [0.45, 0.8] },
    { key: 'wave', name: 'Wave', loop: true, duration: [1.2, 2.1] },
    { key: 'dance', name: 'Dance', loop: true, duration: [1.4, 2.8] },
    { key: 'fight', name: 'Fight', loop: true, duration: [0.8, 1.5] },
    { key: 'kick', name: 'Kick', loop: false, duration: [0.5, 0.9] },
    { key: 'throw', name: 'Throw', loop: false, duration: [0.7, 1.2] },
    { key: 'swim', name: 'Swim', loop: true, duration: [1.1, 1.9] },
    { key: 'fly', name: 'Fly', loop: true, duration: [1.3, 2.4] },
    { key: 'crouch', name: 'Crouch', loop: true, duration: [1.2, 2.2] },
    { key: 'look', name: 'Look Around', loop: true, duration: [2.2, 4.0] },
    { key: 'emote', name: 'Emote', loop: true, duration: [1.4, 2.6] },
    { key: 'climb', name: 'Climb', loop: true, duration: [1.2, 2.0] },
    { key: 'ride', name: 'Ride', loop: true, duration: [1.4, 2.6] },
    { key: 'hit', name: 'Hit Reaction', loop: false, duration: [0.45, 0.8] },
    { key: 'death', name: 'Death', loop: false, duration: [1.1, 1.9] },
    { key: 'taunt', name: 'Taunt', loop: true, duration: [1.2, 2.2] },
    { key: 'dodge', name: 'Dodge', loop: false, duration: [0.4, 0.75] },
    { key: 'sit', name: 'Sit', loop: true, duration: [2.0, 3.6] },
    { key: 'carry', name: 'Carry', loop: true, duration: [1.5, 2.7] }
  ];
  const CATEGORY_BY_KEY = {};
  for (let i = 0; i < CATEGORIES.length; i++) CATEGORY_BY_KEY[CATEGORIES[i].key] = CATEGORIES[i];

  const infoCache = new Map();
  function motionInfo(index) {
    index = Math.floor(Number(index));
    if (!Number.isFinite(index) || index < 0 || index >= MAX_MOTIONS) return null;
    if (infoCache.has(index)) return infoCache.get(index);
    const catIndex = Math.floor(index / PER_CATEGORY) % CATEGORIES.length;
    const category = CATEGORIES[catIndex];
    const variant = index % PER_CATEGORY;
    const r = seeded(index, 11);
    const duration = category.duration[0] + r * (category.duration[1] - category.duration[0]);
    const info = {
      index: index,
      id: 'motion:' + index,
      category: category.name,
      key: category.key,
      variant: variant + 1,
      name: category.name + ' ' + (variant + 1),
      duration: Math.round(duration * 1000) / 1000,
      loop: category.loop,
      speed: Math.round((0.85 + seeded(index, 12) * 0.35) * 100) / 100,
      tags: category.key + ' ' + category.name.toLowerCase() + ' motion ' + (variant + 1)
    };
    if (infoCache.size > 12000) infoCache.clear();
    infoCache.set(index, info);
    return info;
  }

  /* -------------------------------------------------------- motion sampling */
  function walkLike(pose, phase, v, cfg) {
    const swing = Math.sin(phase);
    const stride = cfg.stride * v.amp;
    addRot(pose, 'Thigh.L', stride * swing, 0, 0);
    addRot(pose, 'Thigh.R', -stride * swing, 0, 0);
    addRot(pose, 'Shin.L', -Math.max(0, -swing) * cfg.knee, 0, 0);
    addRot(pose, 'Shin.R', -Math.max(0, swing) * cfg.knee, 0, 0);
    addRot(pose, 'Foot.L', Math.max(0, swing) * cfg.ankle, 0, 0);
    addRot(pose, 'Foot.R', Math.max(0, -swing) * cfg.ankle, 0, 0);
    addRot(pose, 'UpperArm.L', -stride * cfg.arm * swing, 0, cfg.armOut);
    addRot(pose, 'UpperArm.R', stride * cfg.arm * swing, 0, -cfg.armOut);
    addRot(pose, 'Forearm.L', cfg.elbow + Math.max(0, swing) * 12, 0, 0);
    addRot(pose, 'Forearm.R', cfg.elbow + Math.max(0, -swing) * 12, 0, 0);
    addRot(pose, 'Hips', 0, -cfg.twist * v.amp * swing, 0);
    addRot(pose, 'Chest', 0, cfg.twist * v.amp * swing, 0);
    addRot(pose, 'Spine', cfg.lean + v.lean * 0.4, 0, 0);
    addRot(pose, 'Head', 0, -cfg.twist * 0.4 * v.amp * swing, 0);
    addPos(pose, 'Hips', 0, cfg.bob * v.bob * Math.abs(Math.sin(phase * 2)), 0);
  }

  const SAMPLERS = {
    idle: function (pose, u, phase, v) {
      const b = Math.sin(phase);
      const slow = Math.sin(phase * 0.5 + v.phase);
      addRot(pose, 'Spine', 1.4 * v.amp * b, 0, 0);
      addRot(pose, 'Chest', -1.0 * v.amp * b, 2.0 * slow, 0);
      addRot(pose, 'Neck', -0.8 * v.amp * b, 0, 0);
      addRot(pose, 'Head', 1.2 * v.amp * Math.sin(phase + 1), 5.0 * v.amp * slow, 1.2 * b);
      addRot(pose, 'UpperArm.L', 2.0 * b, 0, 5.0 + 1.6 * b);
      addRot(pose, 'UpperArm.R', 2.0 * b, 0, -5.0 - 1.6 * b);
      addRot(pose, 'Forearm.L', 7.0 + 2.0 * b, 0, 0);
      addRot(pose, 'Forearm.R', 7.0 + 2.0 * b, 0, 0);
      addRot(pose, 'Thigh.L', 0, 0, 1.2);
      addRot(pose, 'Thigh.R', 0, 0, -1.2);
      addPos(pose, 'Hips', 0, 0.004 * v.bob * Math.sin(phase * 2), 0);
    },
    walk: function (pose, u, phase, v) {
      walkLike(pose, phase, v, { stride: 26, knee: 42, ankle: 14, arm: 0.72, armOut: 5, elbow: 12, twist: 5, lean: 2, bob: 0.012 });
    },
    run: function (pose, u, phase, v) {
      walkLike(pose, phase, v, { stride: 40, knee: 68, ankle: 20, arm: 1.05, armOut: 8, elbow: 52, twist: 7, lean: 10, bob: 0.024 });
    },
    sprint: function (pose, u, phase, v) {
      walkLike(pose, phase, v, { stride: 52, knee: 84, ankle: 24, arm: 1.25, armOut: 10, elbow: 70, twist: 9, lean: 18, bob: 0.032 });
    },
    jump: function (pose, u, phase, v) {
      const crouch = u < 0.22 ? u / 0.22 : 0;
      const air = clamp((u - 0.22) / 0.58, 0, 1);
      const land = u > 0.8 ? (u - 0.8) / 0.2 : 0;
      const lift = Math.sin(Math.PI * air);
      addPos(pose, 'Hips', 0, -0.13 * crouch * v.amp + 0.30 * lift - 0.10 * land, 0);
      addRot(pose, 'Thigh.L', 42 * crouch + 28 * lift, 0, 4);
      addRot(pose, 'Thigh.R', 42 * crouch + 28 * lift, 0, -4);
      addRot(pose, 'Shin.L', -66 * crouch - 48 * lift, 0, 0);
      addRot(pose, 'Shin.R', -66 * crouch - 48 * lift, 0, 0);
      addRot(pose, 'Spine', 16 * crouch + 8 * land, 0, 0);
      addRot(pose, 'UpperArm.L', -55 * crouch - 95 * lift, 0, 12 + 16 * lift);
      addRot(pose, 'UpperArm.R', -55 * crouch - 95 * lift, 0, -12 - 16 * lift);
      addRot(pose, 'Forearm.L', 26 + 20 * crouch, 0, 0);
      addRot(pose, 'Forearm.R', 26 + 20 * crouch, 0, 0);
    },
    fall: function (pose, u, phase, v) {
      const f = Math.sin(phase);
      addRot(pose, 'Spine', -8, 2 * f, 0);
      addRot(pose, 'Chest', -4, -3 * f, 0);
      addRot(pose, 'UpperArm.L', -35 + 12 * f, 0, 68);
      addRot(pose, 'UpperArm.R', -35 - 12 * f, 0, -68);
      addRot(pose, 'Forearm.L', 28, 0, 0);
      addRot(pose, 'Forearm.R', 28, 0, 0);
      addRot(pose, 'Thigh.L', 25 + 12 * f, 0, 4);
      addRot(pose, 'Thigh.R', 18 - 12 * f, 0, -4);
      addRot(pose, 'Shin.L', -45, 0, 0);
      addRot(pose, 'Shin.R', -32, 0, 0);
      addPos(pose, 'Hips', 0, 0.01 * f, 0);
    },
    land: function (pose, u, phase, v) {
      const k = Math.sin(Math.PI * clamp(u, 0, 1));
      const settle = 1 - u;
      addPos(pose, 'Hips', 0, -0.18 * k, 0);
      addRot(pose, 'Thigh.L', 48 * k, 0, 5);
      addRot(pose, 'Thigh.R', 48 * k, 0, -5);
      addRot(pose, 'Shin.L', -74 * k, 0, 0);
      addRot(pose, 'Shin.R', -74 * k, 0, 0);
      addRot(pose, 'Spine', 18 * k, 0, 0);
      addRot(pose, 'UpperArm.L', -28 * k, 0, 18 + 20 * k);
      addRot(pose, 'UpperArm.R', -28 * k, 0, -18 - 20 * k);
      addRot(pose, 'Head', 8 * settle, 0, 0);
    },
    wave: function (pose, u, phase, v) {
      const swing = Math.sin(phase * 1.6);
      addRot(pose, 'UpperArm.R', -12, 0, -118 - 8 * v.amp);
      addRot(pose, 'Forearm.R', 18, -28 * swing, -22);
      addRot(pose, 'Hand.R', 0, 0, 18 * swing);
      addRot(pose, 'UpperArm.L', 4, 0, 6);
      addRot(pose, 'Forearm.L', 10, 0, 0);
      addRot(pose, 'Chest', 0, 7 * swing, 3);
      addRot(pose, 'Head', 2, 4 * swing, 0);
      addRot(pose, 'Hips', 0, -3 * swing, 0);
      addPos(pose, 'Hips', 0, 0.004 * Math.abs(swing), 0);
    },
    dance: function (pose, u, phase, v) {
      const a = Math.sin(phase);
      const b = Math.sin(phase * 2 + 0.7);
      addRot(pose, 'Hips', 3 * a, 14 * v.twist * a, 5 * b);
      addRot(pose, 'Spine', 2 * b, -8 * v.twist * a, -4 * b);
      addRot(pose, 'Chest', 0, 12 * v.twist * a, 3 * b);
      addRot(pose, 'Head', 4 * b, -7 * a, 0);
      addRot(pose, 'UpperArm.L', -25 + 35 * a, 0, 52 + 18 * b);
      addRot(pose, 'UpperArm.R', -25 - 35 * a, 0, -52 - 18 * b);
      addRot(pose, 'Forearm.L', 38 + 30 * b, 0, 0);
      addRot(pose, 'Forearm.R', 38 - 30 * b, 0, 0);
      addRot(pose, 'Thigh.L', 12 * Math.max(0, a), 0, 6);
      addRot(pose, 'Thigh.R', 12 * Math.max(0, -a), 0, -6);
      addRot(pose, 'Shin.L', -22 * Math.max(0, a), 0, 0);
      addRot(pose, 'Shin.R', -22 * Math.max(0, -a), 0, 0);
      addPos(pose, 'Hips', 0.02 * a, 0.015 * Math.abs(b), 0);
    },
    fight: function (pose, u, phase, v) {
      const punch = Math.sin(phase);
      const left = Math.max(0, punch);
      const right = Math.max(0, -punch);
      addRot(pose, 'Spine', 7, 10 * punch, 0);
      addRot(pose, 'Chest', 0, -16 * punch, 0);
      addRot(pose, 'UpperArm.L', 52 + 46 * left, 0, 22);
      addRot(pose, 'UpperArm.R', 52 + 46 * right, 0, -22);
      addRot(pose, 'Forearm.L', 78 - 54 * left, 0, 0);
      addRot(pose, 'Forearm.R', 78 - 54 * right, 0, 0);
      addRot(pose, 'Hand.L', 0, 0, 12);
      addRot(pose, 'Hand.R', 0, 0, -12);
      addRot(pose, 'Thigh.L', 16, 0, 7);
      addRot(pose, 'Thigh.R', -12, 0, -7);
      addRot(pose, 'Shin.L', -22, 0, 0);
      addRot(pose, 'Shin.R', -14, 0, 0);
      addPos(pose, 'Hips', 0, -0.03 + 0.008 * Math.abs(punch), 0);
    },
    kick: function (pose, u, phase, v) {
      const k = Math.sin(Math.PI * clamp(u, 0, 1));
      addRot(pose, 'Thigh.L', 78 * k, 0, 8);
      addRot(pose, 'Shin.L', -20 * k, 0, 0);
      addRot(pose, 'Thigh.R', -8, 0, -5);
      addRot(pose, 'Spine', -12 * k, 0, 0);
      addRot(pose, 'Chest', 0, 14 * k, 0);
      addRot(pose, 'UpperArm.L', -30 * k, 0, 38);
      addRot(pose, 'UpperArm.R', 24 * k, 0, -48);
      addRot(pose, 'Forearm.L', 32, 0, 0);
      addRot(pose, 'Forearm.R', 65, 0, 0);
      addPos(pose, 'Hips', 0, -0.02 * k, 0);
    },
    throw: function (pose, u, phase, v) {
      const wind = clamp(u / 0.4, 0, 1);
      const release = clamp((u - 0.4) / 0.25, 0, 1);
      const follow = clamp((u - 0.65) / 0.35, 0, 1);
      addRot(pose, 'UpperArm.R', -80 * wind + 150 * release - 45 * follow, 0, -24);
      addRot(pose, 'Forearm.R', 70 * wind - 40 * release, 0, 0);
      addRot(pose, 'UpperArm.L', 35 * wind - 20 * release, 0, 18);
      addRot(pose, 'Spine', -12 * wind + 16 * release, -20 * wind + 26 * release, 0);
      addRot(pose, 'Chest', 0, -18 * wind + 24 * release, 0);
      addRot(pose, 'Thigh.L', 14 * wind, 0, 5);
      addRot(pose, 'Thigh.R', -10 * wind, 0, -5);
      addPos(pose, 'Hips', 0, -0.02 * wind, 0);
    },
    swim: function (pose, u, phase, v) {
      const a = Math.sin(phase);
      addRot(pose, 'Hips', -62, 0, 0);
      addRot(pose, 'Spine', 4 + 5 * a, 0, 0);
      addRot(pose, 'Neck', 28, 0, 0);
      addRot(pose, 'UpperArm.L', -150 + 55 * a, 0, 26);
      addRot(pose, 'UpperArm.R', -150 - 55 * a, 0, -26);
      addRot(pose, 'Forearm.L', 22 + 20 * a, 0, 0);
      addRot(pose, 'Forearm.R', 22 - 20 * a, 0, 0);
      addRot(pose, 'Thigh.L', 12 * a, 0, 5);
      addRot(pose, 'Thigh.R', -12 * a, 0, -5);
      addRot(pose, 'Shin.L', -18 - 12 * Math.max(0, a), 0, 0);
      addRot(pose, 'Shin.R', -18 - 12 * Math.max(0, -a), 0, 0);
      addPos(pose, 'Hips', 0, 0.02 * Math.abs(a), 0);
    },
    fly: function (pose, u, phase, v) {
      const a = Math.sin(phase);
      addRot(pose, 'Hips', 8, 0, 3 * a);
      addRot(pose, 'Spine', -6 + 2 * a, 0, 0);
      addRot(pose, 'UpperArm.L', -12 + 8 * a, 0, 74 + 8 * v.amp);
      addRot(pose, 'UpperArm.R', -12 - 8 * a, 0, -74 - 8 * v.amp);
      addRot(pose, 'Forearm.L', 16, 0, 0);
      addRot(pose, 'Forearm.R', 16, 0, 0);
      addRot(pose, 'Thigh.L', 16 + 8 * a, 0, 5);
      addRot(pose, 'Thigh.R', 10 - 8 * a, 0, -5);
      addRot(pose, 'Shin.L', -26, 0, 0);
      addRot(pose, 'Shin.R', -20, 0, 0);
      addPos(pose, 'Hips', 0.02 * a, 0.03 * Math.sin(phase * 2), 0);
    },
    crouch: function (pose, u, phase, v) {
      const b = Math.sin(phase);
      addPos(pose, 'Hips', 0, -0.19 + 0.008 * b, 0);
      addRot(pose, 'Thigh.L', 62, 0, 7);
      addRot(pose, 'Thigh.R', 62, 0, -7);
      addRot(pose, 'Shin.L', -96, 0, 0);
      addRot(pose, 'Shin.R', -96, 0, 0);
      addRot(pose, 'Foot.L', 34, 0, 0);
      addRot(pose, 'Foot.R', 34, 0, 0);
      addRot(pose, 'Spine', 20, 2 * b, 0);
      addRot(pose, 'Chest', 4, -3 * b, 0);
      addRot(pose, 'Head', -14, 4 * b, 0);
      addRot(pose, 'UpperArm.L', 28, 0, 20);
      addRot(pose, 'UpperArm.R', 28, 0, -20);
      addRot(pose, 'Forearm.L', 46, 0, 0);
      addRot(pose, 'Forearm.R', 46, 0, 0);
    },
    look: function (pose, u, phase, v) {
      const turn = Math.sin(phase * 0.6);
      const tilt = Math.sin(phase + 1.2);
      addRot(pose, 'Neck', 2 * tilt, 22 * turn, 0);
      addRot(pose, 'Head', 9 * tilt, 34 * turn, 5 * tilt);
      addRot(pose, 'Chest', 0, 9 * turn, 0);
      addRot(pose, 'Spine', 0, 4 * turn, 0);
      addRot(pose, 'UpperArm.L', 3, 0, 6);
      addRot(pose, 'UpperArm.R', 3, 0, -6);
      addRot(pose, 'Forearm.L', 8, 0, 0);
      addRot(pose, 'Forearm.R', 8, 0, 0);
      addPos(pose, 'Hips', 0, 0.003 * Math.sin(phase * 2), 0);
    },
    emote: function (pose, u, phase, v) {
      const nod = Math.sin(phase * 1.5);
      const shrug = Math.max(0, Math.sin(phase));
      addRot(pose, 'Head', 14 * nod, 0, 0);
      addRot(pose, 'Neck', 6 * nod, 0, 0);
      addRot(pose, 'UpperArm.L', -6, 0, 16 + 22 * shrug);
      addRot(pose, 'UpperArm.R', -6, 0, -16 - 22 * shrug);
      addRot(pose, 'Forearm.L', 44 + 20 * shrug, 0, 0);
      addRot(pose, 'Forearm.R', 44 + 20 * shrug, 0, 0);
      addRot(pose, 'Hand.L', 0, 0, 12 * shrug);
      addRot(pose, 'Hand.R', 0, 0, -12 * shrug);
      addRot(pose, 'Spine', -3 * nod, 0, 0);
    },
    climb: function (pose, u, phase, v) {
      const a = Math.sin(phase);
      addRot(pose, 'UpperArm.L', -135 - 30 * a, 0, 20);
      addRot(pose, 'UpperArm.R', -135 + 30 * a, 0, -20);
      addRot(pose, 'Forearm.L', 30 + 18 * Math.max(0, a), 0, 0);
      addRot(pose, 'Forearm.R', 30 + 18 * Math.max(0, -a), 0, 0);
      addRot(pose, 'Thigh.L', 42 + 24 * a, 0, 8);
      addRot(pose, 'Thigh.R', 42 - 24 * a, 0, -8);
      addRot(pose, 'Shin.L', -62 - 18 * Math.max(0, a), 0, 0);
      addRot(pose, 'Shin.R', -62 - 18 * Math.max(0, -a), 0, 0);
      addRot(pose, 'Spine', 10, 8 * a, 0);
      addRot(pose, 'Head', -18, 5 * a, 0);
      addPos(pose, 'Hips', 0, 0.02 * Math.abs(a), 0);
    },
    ride: function (pose, u, phase, v) {
      const b = Math.abs(Math.sin(phase));
      addPos(pose, 'Hips', 0, -0.16 + 0.012 * b, 0);
      addRot(pose, 'Hips', -10, 0, 0);
      addRot(pose, 'Thigh.L', 74, 0, 12);
      addRot(pose, 'Thigh.R', 74, 0, -12);
      addRot(pose, 'Shin.L', -88, 0, 0);
      addRot(pose, 'Shin.R', -88, 0, 0);
      addRot(pose, 'Spine', 16, 0, 0);
      addRot(pose, 'Chest', 4, 2 * b, 0);
      addRot(pose, 'UpperArm.L', 68, 0, 12);
      addRot(pose, 'UpperArm.R', 68, 0, -12);
      addRot(pose, 'Forearm.L', 42, 0, 0);
      addRot(pose, 'Forearm.R', 42, 0, 0);
      addRot(pose, 'Head', -8 + 3 * b, 0, 0);
    },
    hit: function (pose, u, phase, v) {
      const k = Math.sin(Math.PI * clamp(u * 1.6, 0, 1));
      addRot(pose, 'Spine', -22 * k, 14 * k, 6 * k);
      addRot(pose, 'Chest', -14 * k, -18 * k, 0);
      addRot(pose, 'Head', -26 * k, -20 * k, 8 * k);
      addRot(pose, 'UpperArm.L', -35 * k, 0, 48 * k + 8);
      addRot(pose, 'UpperArm.R', -30 * k, 0, -42 * k - 8);
      addRot(pose, 'Forearm.L', 20 + 30 * k, 0, 0);
      addRot(pose, 'Forearm.R', 20 + 26 * k, 0, 0);
      addPos(pose, 'Hips', -0.03 * k, -0.02 * k, 0);
    },
    death: function (pose, u, phase, v) {
      const fall = clamp(u / 0.55, 0, 1);
      const settle = smoothstep(clamp((u - 0.45) / 0.55, 0, 1));
      addRot(pose, 'Hips', -88 * fall, 8 * fall, 0);
      addRot(pose, 'Spine', -14 * fall + 4 * Math.sin(u * 8), 0, 0);
      addRot(pose, 'Chest', -8 * fall, 0, 0);
      addRot(pose, 'Neck', -16 * fall, 12 * fall, 0);
      addRot(pose, 'Head', -22 * fall, 16 * fall, 0);
      addRot(pose, 'UpperArm.L', 22 * fall, 0, 42 + 28 * settle);
      addRot(pose, 'UpperArm.R', 18 * fall, 0, -40 - 26 * settle);
      addRot(pose, 'Forearm.L', 10 + 16 * fall, 0, 0);
      addRot(pose, 'Forearm.R', 8 + 16 * fall, 0, 0);
      addRot(pose, 'Thigh.L', -18 * fall, 0, 10);
      addRot(pose, 'Thigh.R', -14 * fall, 0, -10);
      addRot(pose, 'Shin.L', -24 * fall, 0, 0);
      addRot(pose, 'Shin.R', -20 * fall, 0, 0);
      addPos(pose, 'Hips', 0, -0.42 * settle, 0);
    },
    taunt: function (pose, u, phase, v) {
      const a = Math.sin(phase);
      addRot(pose, 'Chest', -8, 8 * a, 0);
      addRot(pose, 'Head', -10, 12 * a, 4 * a);
      addRot(pose, 'UpperArm.L', -24, 0, 58 + 20 * Math.max(0, a));
      addRot(pose, 'UpperArm.R', -24, 0, -58 - 20 * Math.max(0, -a));
      addRot(pose, 'Forearm.L', 34 + 24 * Math.max(0, a), 0, 0);
      addRot(pose, 'Forearm.R', 34 + 24 * Math.max(0, -a), 0, 0);
      addRot(pose, 'Hand.L', 0, 0, 20 * a);
      addRot(pose, 'Hand.R', 0, 0, -20 * a);
      addRot(pose, 'Thigh.L', 8, 0, 6);
      addRot(pose, 'Thigh.R', -8, 0, -6);
      addPos(pose, 'Hips', 0, 0.012 * Math.abs(a), 0);
    },
    dodge: function (pose, u, phase, v) {
      const k = Math.sin(Math.PI * clamp(u, 0, 1));
      addPos(pose, 'Hips', 0.18 * k * v.amp, -0.06 * k, 0);
      addRot(pose, 'Hips', 0, 0, -22 * k);
      addRot(pose, 'Spine', 6 * k, 0, -14 * k);
      addRot(pose, 'Chest', 0, 12 * k, -8 * k);
      addRot(pose, 'Head', 0, -10 * k, 8 * k);
      addRot(pose, 'UpperArm.L', 12 * k, 0, 24 * k);
      addRot(pose, 'UpperArm.R', -8 * k, 0, -18 * k);
      addRot(pose, 'Thigh.L', 22 * k, 0, 6);
      addRot(pose, 'Thigh.R', 10 * k, 0, -6);
      addRot(pose, 'Shin.L', -32 * k, 0, 0);
      addRot(pose, 'Shin.R', -20 * k, 0, 0);
    },
    sit: function (pose, u, phase, v) {
      const b = Math.sin(phase * 0.7);
      addPos(pose, 'Hips', 0, -0.24, 0);
      addRot(pose, 'Hips', -5, 0, 0);
      addRot(pose, 'Thigh.L', 82, 0, 10);
      addRot(pose, 'Thigh.R', 82, 0, -10);
      addRot(pose, 'Shin.L', -82, 0, 0);
      addRot(pose, 'Shin.R', -82, 0, 0);
      addRot(pose, 'Foot.L', 20, 0, 0);
      addRot(pose, 'Foot.R', 20, 0, 0);
      addRot(pose, 'Spine', 5 + 2 * b, 0, 0);
      addRot(pose, 'Chest', 2, 3 * b, 0);
      addRot(pose, 'Head', 1 + 2 * b, 5 * b, 0);
      addRot(pose, 'UpperArm.L', 18, 0, 12);
      addRot(pose, 'UpperArm.R', 18, 0, -12);
      addRot(pose, 'Forearm.L', 36 + 4 * b, 0, 0);
      addRot(pose, 'Forearm.R', 36 - 4 * b, 0, 0);
    },
    carry: function (pose, u, phase, v) {
      const b = Math.sin(phase * 1.2);
      addRot(pose, 'Spine', -6, 4 * b, 0);
      addRot(pose, 'Chest', -4, -3 * b, 0);
      addRot(pose, 'UpperArm.L', 72, 0, 10);
      addRot(pose, 'UpperArm.R', 72, 0, -10);
      addRot(pose, 'Forearm.L', 86, 0, 0);
      addRot(pose, 'Forearm.R', 86, 0, 0);
      addRot(pose, 'Hand.L', 8, 0, 10);
      addRot(pose, 'Hand.R', 8, 0, -10);
      addRot(pose, 'Thigh.L', 8 * Math.max(0, b), 0, 6);
      addRot(pose, 'Thigh.R', 8 * Math.max(0, -b), 0, -6);
      addRot(pose, 'Shin.L', -14 * Math.max(0, b), 0, 0);
      addRot(pose, 'Shin.R', -14 * Math.max(0, -b), 0, 0);
      addPos(pose, 'Hips', 0, 0.006 * Math.abs(b), 0);
    }
  };

  function sampleMotion(index, time) {
    const info = motionInfo(index);
    const pose = emptyPose();
    if (!info) return pose;
    const u = info.loop ? ((Number(time) || 0) % info.duration + info.duration) % info.duration / info.duration
                        : clamp((Number(time) || 0) / info.duration, 0, 1);
    const v = variation(info.index);
    const phase = u * Math.PI * 2 * v.freq + v.phase;
    const fn = SAMPLERS[info.key] || SAMPLERS.idle;
    fn(pose, u, phase, v);
    return pose;
  }

  /* ---------------------------------------------------------- motion library */
  const Library = {
    capacity: MAX_MOTIONS,
    categories: CATEGORIES,
    info: motionInfo,
    sample: sampleMotion,
    firstIndex: function (key) {
      for (let i = 0; i < CATEGORIES.length; i++) if (CATEGORIES[i].key === key) return i * PER_CATEGORY;
      return 0;
    },
    /** Page through the library without materializing any clip data. */
    list: function (options) {
      options = options || {};
      const offset = Math.max(0, Math.floor(Number(options.offset) || 0));
      const limit = Math.min(400, Math.max(1, Math.floor(Number(options.limit) || 40)));
      const query = String(options.query || '').trim().toLowerCase();
      const category = options.category && options.category !== 'all' ? String(options.category).toLowerCase() : '';
      const out = [];
      let index = offset;
      let guard = 0;
      while (index < MAX_MOTIONS && out.length < limit && guard++ < MAX_MOTIONS) {
        const info = motionInfo(index);
        const haystack = info.name.toLowerCase() + ' ' + info.category.toLowerCase() + ' ' + info.key;
        const match = (!category || info.key === category) && (!query || haystack.indexOf(query) >= 0);
        if (match) out.push(info);
        index++;
      }
      return out;
    },
    count: function (options) {
      options = options || {};
      const category = options.category && options.category !== 'all' ? String(options.category).toLowerCase() : '';
      const query = String(options.query || '').trim().toLowerCase();
      let total = 0;
      for (let i = 0; i < MAX_MOTIONS; i++) {
        const info = motionInfo(i);
        const haystack = info.name.toLowerCase() + ' ' + info.category.toLowerCase() + ' ' + info.key;
        if ((!category || info.key === category) && (!query || haystack.indexOf(query) >= 0)) total++;
      }
      return total;
    },
    resolve: function (value) {
      if (typeof value === 'number') return motionInfo(value) ? motionInfo(value).index : null;
      const text = String(value == null ? '' : value).trim();
      if (!text) return null;
      if (/^\d+$/.test(text)) return motionInfo(parseInt(text, 10)) ? parseInt(text, 10) : null;
      if (/^motion:/i.test(text)) {
        const n = parseInt(text.slice(7), 10);
        return motionInfo(n) ? n : null;
      }
      const needle = text.toLowerCase();
      for (let i = 0; i < MAX_MOTIONS; i++) {
        const info = motionInfo(i);
        if (info.name.toLowerCase() === needle) return i;
      }
      for (let i = 0; i < MAX_MOTIONS; i++) {
        const info = motionInfo(i);
        if (info.name.toLowerCase().indexOf(needle) >= 0) return i;
      }
      return null;
    }
  };

  /* ------------------------------------------------------------- auto-rigging */
  function boundsOf(asset) {
    if (asset && asset.bounds && asset.bounds.min && asset.bounds.max) {
      return { min: asset.bounds.min.slice(), max: asset.bounds.max.slice() };
    }
    let min = [Infinity, Infinity, Infinity];
    let max = [-Infinity, -Infinity, -Infinity];
    for (const prim of (asset && asset.prims) || []) {
      const p = prim.positions || [];
      for (let i = 0; i < p.length; i += 3) {
        for (let k = 0; k < 3; k++) {
          if (p[i + k] < min[k]) min[k] = p[i + k];
          if (p[i + k] > max[k]) max[k] = p[i + k];
        }
      }
    }
    if (!Number.isFinite(min[0])) { min = [-0.5, 0, -0.5]; max = [0.5, 2, 0.5]; }
    return { min: min, max: max };
  }

  /**
   * Build a heuristic humanoid skeleton from a mesh's bounds. The rig uses the
   * model's own units, so a 2 m character and a 200 cm character both work.
   */
  function autoRig(asset, options) {
    options = options || {};
    const b = boundsOf(asset);
    const h = Math.max(0.4, b.max[1] - b.min[1]);
    const w = Math.max(0.2, b.max[0] - b.min[0]);
    const d = Math.max(0.2, b.max[2] - b.min[2]);
    const cx = (b.min[0] + b.max[0]) / 2;
    const cz = (b.min[2] + b.max[2]) / 2;
    const y = function (f) { return b.min[1] + h * f; };
    const x = function (f) { return cx + w * f; };
    const z = function (f) { return cz + d * f; };
    const bones = [];
    function bone(name, parent, head, tail) {
      bones.push({ name: name, parent: parent || '', head: head, tail: tail });
    }
    bone('Root', '', [cx, y(0.02), cz], [cx, y(0.06), cz]);
    bone('Hips', 'Root', [cx, y(0.50), cz], [cx, y(0.56), cz]);
    bone('Spine', 'Hips', [cx, y(0.56), cz], [cx, y(0.65), cz]);
    bone('Chest', 'Spine', [cx, y(0.65), cz], [cx, y(0.76), cz]);
    bone('Neck', 'Chest', [cx, y(0.76), cz], [cx, y(0.82), cz]);
    bone('Head', 'Neck', [cx, y(0.82), cz], [cx, y(0.95), cz]);
    bone('Shoulder.L', 'Chest', [x(0.12), y(0.75), cz], [x(0.25), y(0.75), cz]);
    bone('UpperArm.L', 'Shoulder.L', [x(0.25), y(0.75), cz], [x(0.34), y(0.58), cz]);
    bone('Forearm.L', 'UpperArm.L', [x(0.34), y(0.58), cz], [x(0.38), y(0.43), cz]);
    bone('Hand.L', 'Forearm.L', [x(0.38), y(0.43), cz], [x(0.40), y(0.35), cz]);
    bone('Shoulder.R', 'Chest', [x(-0.12), y(0.75), cz], [x(-0.25), y(0.75), cz]);
    bone('UpperArm.R', 'Shoulder.R', [x(-0.25), y(0.75), cz], [x(-0.34), y(0.58), cz]);
    bone('Forearm.R', 'UpperArm.R', [x(-0.34), y(0.58), cz], [x(-0.38), y(0.43), cz]);
    bone('Hand.R', 'Forearm.R', [x(-0.38), y(0.43), cz], [x(-0.40), y(0.35), cz]);
    bone('Thigh.L', 'Hips', [x(0.09), y(0.48), cz], [x(0.10), y(0.27), cz]);
    bone('Shin.L', 'Thigh.L', [x(0.10), y(0.27), cz], [x(0.11), y(0.07), cz]);
    bone('Foot.L', 'Shin.L', [x(0.11), y(0.07), cz], [x(0.11), y(0.02), z(0.10)]);
    bone('Thigh.R', 'Hips', [x(-0.09), y(0.48), cz], [x(-0.10), y(0.27), cz]);
    bone('Shin.R', 'Thigh.R', [x(-0.10), y(0.27), cz], [x(-0.11), y(0.07), cz]);
    bone('Foot.R', 'Shin.R', [x(-0.11), y(0.07), cz], [x(-0.11), y(0.02), z(0.10)]);
    return {
      name: options.name || 'Auto Humanoid',
      skeleton: bones.slice(0, BONE_LIMIT),
      height: h,
      width: w,
      depth: d,
      bounds: b
    };
  }

  /* ------------------------------------------------------------- skin weights */
  function segmentD2(px, py, pz, ax, ay, az, bx, by, bz) {
    const abx = bx - ax, aby = by - ay, abz = bz - az;
    const apx = px - ax, apy = py - ay, apz = pz - az;
    const len2 = abx * abx + aby * aby + abz * abz;
    let t = len2 > 1e-12 ? (apx * abx + apy * aby + apz * abz) / len2 : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const dx = apx - abx * t, dy = apy - aby * t, dz = apz - abz * t;
    return dx * dx + dy * dy + dz * dz;
  }

  function buildWeights(asset, rig) {
    const bones = [];
    for (let i = 0; i < rig.length && i < BONE_LIMIT; i++) {
      if (rig[i].name === 'Root') continue;
      const head = rig[i].head, tail = rig[i].tail;
      bones.push({ index: i, head: head, tail: tail });
    }
    if (!bones.length) return [];
    const b = boundsOf(asset);
    const h = Math.max(0.3, b.max[1] - b.min[1]);
    const eps = Math.pow(h * 0.018, 2);
    const out = [];
    for (const prim of asset.prims || []) {
      const positions = prim.positions;
      const count = positions.length / 3;
      const joints = new Float32Array(count * 4);
      const weights = new Float32Array(count * 4);
      for (let v = 0; v < count; v++) {
        const px = positions[v * 3], py = positions[v * 3 + 1], pz = positions[v * 3 + 2];
        const best = [
          { j: 0, w: 0 }, { j: 0, w: 0 }, { j: 0, w: 0 }, { j: 0, w: 0 }
        ];
        let sum = 0;
        for (const bone of bones) {
          const d2 = segmentD2(px, py, pz, bone.head[0], bone.head[1], bone.head[2], bone.tail[0], bone.tail[1], bone.tail[2]);
          let w = 1 / Math.pow(d2 + eps, 1.35);
          if (!Number.isFinite(w) || w <= 0) continue;
          if (w > best[0].w) {
            best[3] = best[2]; best[2] = best[1]; best[1] = best[0]; best[0] = { j: bone.index, w: w };
          } else if (w > best[1].w) {
            best[3] = best[2]; best[2] = best[1]; best[1] = { j: bone.index, w: w };
          } else if (w > best[2].w) {
            best[3] = best[2]; best[2] = { j: bone.index, w: w };
          } else if (w > best[3].w) {
            best[3] = { j: bone.index, w: w };
          }
          sum += w;
        }
        if (sum <= 0) { best[0] = { j: bones[0].index, w: 1 }; sum = 1; }
        let total = 0;
        for (let k = 0; k < 4; k++) total += best[k].w;
        if (total <= 0) { best[0] = { j: bones[0].index, w: 1 }; total = 1; }
        for (let k = 0; k < 4; k++) {
          joints[v * 4 + k] = best[k].j;
          weights[v * 4 + k] = best[k].w / total;
        }
      }
      out.push({ joints: joints, weights: weights });
    }
    return out;
  }

  const skinCache = new Map();
  const SKIN_CACHE_LIMIT = 24;
  function hashRig(rig) {
    let hash = 2166136261;
    for (const bone of rig || []) {
      const text = bone.name + ':' + bone.head.join(',') + ':' + bone.tail.join(',') + ':' + (bone.parent || '');
      for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }
    }
    return (hash >>> 0).toString(36) + ':' + (rig ? rig.length : 0);
  }
  function skinFor(meshId, rig) {
    if (!meshId || !rig || !rig.length) return null;
    const key = meshId + '|' + hashRig(rig);
    if (skinCache.has(key)) return skinCache.get(key);
    const asset = UE.AssetStore && UE.AssetStore.get(meshId);
    if (!asset) return null;
    const data = buildWeights(asset, rig);
    if (skinCache.size >= SKIN_CACHE_LIMIT) skinCache.delete(skinCache.keys().next().value);
    skinCache.set(key, data);
    return data;
  }
  function clearSkinCache() { skinCache.clear(); }

  /* --------------------------------------------------------------- quaternions */
  function nlerp(a, b, t) {
    let bx = b.x, by = b.y, bz = b.z, bw = b.w;
    const dot = a.x * bx + a.y * by + a.z * bz + a.w * bw;
    if (dot < 0) { bx = -bx; by = -by; bz = -bz; bw = -bw; }
    const x = a.x + (bx - a.x) * t;
    const y = a.y + (by - a.y) * t;
    const z = a.z + (bz - a.z) * t;
    const w = a.w + (bw - a.w) * t;
    const len = Math.hypot(x, y, z, w) || 1;
    return { x: x / len, y: y / len, z: z / len, w: w / len };
  }
  function scaleQuat(q, t) { return nlerp(Q.identity(), q, t); }
  function mat4FromQuat(pos, q) {
    const x = q.x, y = q.y, z = q.z, w = q.w;
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;
    const m = new Float32Array(16);
    m[0] = 1 - (yy + zz); m[1] = xy + wz; m[2] = xz - wy; m[3] = 0;
    m[4] = xy - wz; m[5] = 1 - (xx + zz); m[6] = yz + wx; m[7] = 0;
    m[8] = xz + wy; m[9] = yz - wx; m[10] = 1 - (xx + yy); m[11] = 0;
    m[12] = pos.x; m[13] = pos.y; m[14] = pos.z; m[15] = 1;
    return m;
  }
  function translate(x, y, z) {
    return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
  }

  /* ------------------------------------------------------------------ Animator */
  class Animator extends UE.Component {
    constructor(object) {
      super(object);
      this.rigName = 'Auto Humanoid';
      this.skeleton = [];
      this.motion = 0;
      this.motionName = '';
      this.blendMotion = -1;
      this.blendWeight = 0;
      this.blendMode = 'mix';
      this.speed = 1;
      this.loop = true;
      this.playing = true;
      this.fade = 0.25;
      this.preview = true;
      this._resetRuntime();
    }
    _resetRuntime() {
      this._time = 0;
      this._blendTime = 0;
      this._fromMotion = -1;
      this._fromTime = 0;
      this._fadeTime = 0;
      this._fadeDuration = 0;
      this._rigSignature = '';
      this._invBind = null;
      this._matrices = null;
      this._height = 0;
      this._names = null;
    }
    applyJSON(props) {
      super.applyJSON(props);
      if (!Array.isArray(this.skeleton)) this.skeleton = [];
      if (!Number.isFinite(Number(this.motion))) this.motion = 0;
      if (!this.motionName) {
        const info = motionInfo(this.motion);
        this.motionName = info ? info.name : '';
      }
      this._resetRuntime();
    }
    pointerRigKey() { return hashRig(this.skeleton); }
    clipInfo() { return motionInfo(this.motion); }
    height() {
      if (this._height > 0) return this._height;
      let min = Infinity, max = -Infinity;
      for (const bone of this.skeleton) {
        for (const p of [bone.head, bone.tail]) {
          if (!p) continue;
          if (p[1] < min) min = p[1];
          if (p[1] > max) max = p[1];
        }
      }
      this._height = Number.isFinite(min) && max > min ? max - min : 1;
      return this._height;
    }
    play(index, options) {
      options = options || {};
      const resolved = Library.resolve(index);
      if (resolved === null) return false;
      const info = motionInfo(resolved);
      if (!info) return false;
      if (this.motion !== resolved && this.playing && Number(this.fade) > 0) {
        this._fromMotion = this.motion;
        this._fromTime = this._time;
        this._fadeTime = 0;
        this._fadeDuration = options.fade === undefined ? Number(this.fade) : Math.max(0, Number(options.fade));
      } else {
        this._fromMotion = -1;
        this._fadeDuration = 0;
      }
      this.motion = resolved;
      this.motionName = info.name;
      this.loop = options.loop === undefined ? info.loop : !!options.loop;
      if (!options.keepTime) this._time = 0;
      this.playing = true;
      return true;
    }
    crossFadeTo(index, seconds) { return this.play(index, { fade: seconds }); }
    setBlend(index, weight, mode) {
      if (index === null || index === undefined || index === '' || index < 0) {
        this.blendMotion = -1;
        this.blendWeight = 0;
        return;
      }
      const resolved = Library.resolve(index);
      if (resolved === null) return;
      this.blendMotion = resolved;
      if (weight !== undefined) this.blendWeight = clamp(Number(weight) || 0, 0, 1);
      if (mode) this.blendMode = mode;
    }
    stop() {
      this.playing = false;
      this._time = 0;
      this._blendTime = 0;
      this._fromMotion = -1;
      this._fadeDuration = 0;
    }
    advance(dt) {
      if (!this.playing || !(dt > 0)) return;
      const speed = Number(this.speed);
      const step = dt * (Number.isFinite(speed) ? speed : 1);
      this._time += step;
      this._blendTime += step;
      this._fromTime += step;
      const info = motionInfo(this.motion);
      if (info) {
        if (this.loop) {
          if (this._time >= info.duration) this._time %= info.duration;
          if (this._blendTime >= info.duration) this._blendTime %= info.duration;
        } else if (this._time >= info.duration) {
          this._time = info.duration;
          this.playing = false;
        }
      }
      if (this._fadeDuration > 0) {
        this._fadeTime += dt;
        if (this._fadeTime >= this._fadeDuration) {
          this._fadeTime = this._fadeDuration;
          this._fromMotion = -1;
        }
      }
    }
    _quatPose(index, time) {
      const raw = sampleMotion(index, time);
      const height = this.height();
      const pose = { q: {}, p: {} };
      for (const bone of this.skeleton) {
        const r = raw.rot[bone.name];
        pose.q[bone.name] = r ? Q.fromEuler({ x: r[0] || 0, y: r[1] || 0, z: r[2] || 0 }) : Q.identity();
        const t = raw.pos[bone.name];
        pose.p[bone.name] = t ? { x: t[0] * height, y: t[1] * height, z: t[2] * height } : { x: 0, y: 0, z: 0 };
      }
      return pose;
    }
    _mix(a, b, t) {
      const out = { q: {}, p: {} };
      for (const bone of this.skeleton) {
        const name = bone.name;
        out.q[name] = nlerp(a.q[name] || Q.identity(), b.q[name] || Q.identity(), t);
        const pa = a.p[name] || { x: 0, y: 0, z: 0 };
        const pb = b.p[name] || { x: 0, y: 0, z: 0 };
        out.p[name] = {
          x: pa.x + (pb.x - pa.x) * t,
          y: pa.y + (pb.y - pa.y) * t,
          z: pa.z + (pb.z - pa.z) * t
        };
      }
      return out;
    }
    _add(a, b, t) {
      const out = { q: {}, p: {} };
      for (const bone of this.skeleton) {
        const name = bone.name;
        out.q[name] = Q.multiply(a.q[name] || Q.identity(), scaleQuat(b.q[name] || Q.identity(), t));
        const pa = a.p[name] || { x: 0, y: 0, z: 0 };
        const pb = b.p[name] || { x: 0, y: 0, z: 0 };
        out.p[name] = { x: pa.x + pb.x * t, y: pa.y + pb.y * t, z: pa.z + pb.z * t };
      }
      return out;
    }
    samplePose() {
      if (!this.skeleton.length) return { q: {}, p: {} };
      let pose = this._quatPose(this.motion, this._time);
      if (this._fromMotion >= 0 && this._fadeDuration > 0) {
        const from = this._quatPose(this._fromMotion, this._fromTime);
        pose = this._mix(from, pose, smoothstep(this._fadeTime / this._fadeDuration));
      }
      if (this.blendMotion >= 0 && this.blendWeight > 0.0001) {
        const secondary = this._quatPose(this.blendMotion, this._blendTime);
        pose = this.blendMode === 'additive'
          ? this._add(pose, secondary, this.blendWeight)
          : this._mix(pose, secondary, this.blendWeight);
      }
      return pose;
    }
    _prepareRig() {
      const key = hashRig(this.skeleton);
      if (key === this._rigSignature) return;
      this._rigSignature = key;
      this._height = 0;
      this._invBind = [];
      this._names = {};
      for (let i = 0; i < this.skeleton.length; i++) {
        const bone = this.skeleton[i];
        this._names[bone.name] = i;
        const head = bone.head || [0, 0, 0];
        this._invBind.push(translate(-head[0], -head[1], -head[2]));
      }
    }
    boneMatrices() {
      if (!this.skeleton.length) return null;
      this._prepareRig();
      const pose = this.samplePose();
      const count = Math.min(BONE_LIMIT, this.skeleton.length);
      if (!this._matrices) this._matrices = new Float32Array(BONE_LIMIT * 16);
      const out = this._matrices;
      out.fill(0);
      const world = [];
      const self = this;
      function worldOf(i) {
        if (world[i]) return world[i];
        const bone = self.skeleton[i];
        if (!bone) return translate(0, 0, 0);
        const parentIndex = bone.parent ? self._names[bone.parent] : -1;
        const parentWorld = parentIndex >= 0 ? worldOf(parentIndex) : null;
        const parentHead = parentIndex >= 0 ? self.skeleton[parentIndex].head || [0, 0, 0] : [0, 0, 0];
        const head = bone.head || [0, 0, 0];
        const restLocal = translate(head[0] - parentHead[0], head[1] - parentHead[1], head[2] - parentHead[2]);
        const offset = pose.p[bone.name] || { x: 0, y: 0, z: 0 };
        const delta = mat4FromQuat(offset, pose.q[bone.name] || Q.identity());
        const local = Mat4.multiply(restLocal, delta);
        world[i] = parentWorld ? Mat4.multiply(parentWorld, local) : local;
        return world[i];
      }
      for (let i = 0; i < count; i++) {
        const skin = Mat4.multiply(worldOf(i), this._invBind[i] || translate(0, 0, 0));
        out.set(skin, i * 16);
      }
      /* Unused bone slots stay as identity so a stale slot can never explode a vertex. */
      for (let i = count; i < BONE_LIMIT; i++) {
        const base = i * 16;
        out[base] = 1; out[base + 5] = 1; out[base + 10] = 1; out[base + 15] = 1;
      }
      return out;
    }
  }
  Animator.typeName = 'Animator';
  Animator.label = 'Animator';
  Animator.props = ['rigName', 'skeleton', 'motion', 'motionName', 'blendMotion', 'blendWeight',
    'blendMode', 'speed', 'loop', 'playing', 'fade', 'preview'];
  UE.Components.Animator = Animator;

  /* --------------------------------------------------------------------- API */
  function attach(object, options) {
    options = options || {};
    if (!object) throw new Error('Auto-rig needs a GameObject');
    const mr = object.getComponent('MeshRenderer');
    if (!mr || !mr.meshId) throw new Error('Auto-rig needs a Mesh Renderer with an imported model');
    const asset = UE.AssetStore && UE.AssetStore.get(mr.meshId);
    if (!asset) throw new Error('The imported mesh asset is missing; re-import the model');
    const rig = autoRig(asset, options);
    let animator = object.getComponent('Animator');
    if (!animator) animator = object.addComponent('Animator');
    animator.rigName = rig.name;
    animator.skeleton = rig.skeleton;
    animator.motion = options.motion === undefined
      ? Library.firstIndex(options.category || 'idle')
      : (Library.resolve(options.motion) || 0);
    const info = motionInfo(animator.motion);
    animator.motionName = info ? info.name : '';
    animator.playing = true;
    animator.loop = info ? info.loop : true;
    animator._resetRuntime();
    clearSkinCache();
    return animator;
  }

  function updateAll(scene, dt, respectPreview) {
    if (!scene) return;
    for (const object of scene.objects) {
      const animator = object.getComponent && object.getComponent('Animator');
      if (!animator) continue;
      /* Preview is an edit-mode preference only: Play always animates. */
      if (respectPreview && animator.preview === false) continue;
      animator.advance(dt);
    }
  }

  UE.Animation = {
    BONE_LIMIT: BONE_LIMIT,
    MAX_MOTIONS: MAX_MOTIONS,
    PER_CATEGORY: PER_CATEGORY,
    CATEGORIES: CATEGORIES,
    Library: Library,
    Animator: Animator,
    autoRig: autoRig,
    attach: attach,
    updateAll: updateAll,
    skinFor: skinFor,
    clearSkinCache: clearSkinCache,
    rigKey: hashRig,
    sample: sampleMotion,
    info: motionInfo
  };

  return UE;
});
