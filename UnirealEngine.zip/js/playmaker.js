/* UnirealEngine — playmaker.js
 * A compact, PlayMaker-style visual state machine: FSMs, states, transitions,
 * variables, actions, event proxies, timers, keyboard input and collision triggers.
 * The FSM is data-driven so it serializes with the scene and is edited in the Inspector. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;
  const Component = UE.Component;
  if (!Component) throw new Error('engine.js must load before playmaker.js');

  /* --------------------------------------------------------------- utilities */
  function finite(v, fallback) {
    const n = typeof v === 'number' ? v : parseFloat(v);
    return Number.isFinite(n) ? n : (fallback || 0);
  }
  function readValue(value, ctx) {
    if (typeof value === 'string') {
      const s = value.trim();
      if (s.charAt(0) === '$') {
        const key = s.slice(1);
        return Object.prototype.hasOwnProperty.call(ctx.vars, key) ? ctx.vars[key] : '';
      }
    }
    return value;
  }
  function readNumber(value, ctx) {
    const v = readValue(value, ctx);
    if (typeof v === 'number') return v;
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : 0;
  }
  function readString(value, ctx) {
    const v = readValue(value, ctx);
    return v === undefined || v === null ? '' : String(v);
  }
  function readBool(value, ctx) {
    const v = readValue(value, ctx);
    if (typeof v === 'string') return v !== '' && v !== 'false' && v !== '0';
    return !!v;
  }
  function targetObject(ctx, name) {
    if (!name || name === 'self') return ctx.self;
    if (name === 'none') return null;
    const text = String(name).trim();
    if (text.indexOf('tag:') === 0) {
      const tag = text.slice(4).trim();
      return ctx.scene.findAllByTag ? ctx.scene.findByTag(tag) : (ctx.scene.objects.find(function (o) { return o.tag === tag; }) || null);
    }
    return ctx.scene.find(text) || null;
  }
  function positionOf(object) {
    return object ? object.transform.worldPosition() : V3.create();
  }
  function colorOr(value, fallback) {
    return /^#[0-9a-f]{6}$/i.test(String(value || '')) ? value : fallback;
  }
  function findFsm(target, name) {
    if (!target) return null;
    const fsms = target.getComponents('PlayMakerFSM');
    if (!fsms.length) return null;
    const wanted = String(name || '').trim();
    if (wanted && wanted !== 'self') {
      const named = fsms.find(function (fsm) { return fsm.name === wanted; });
      if (named) return named;
    }
    return fsms[0];
  }
  function objectsWithTag(scene, tag) {
    const value = String(tag || '').trim();
    if (!value || !scene) return [];
    return (scene.findAllByTag ? scene.findAllByTag(value) : scene.objects.filter(function (o) { return o.tag === value; }));
  }
  function writeVariable(vars, action, ctx) {
    const key = readString(action.name, ctx).trim() || 'value';
    const op = action.operation || 'set';
    const current = readNumber(vars[key], ctx);
    if (op === 'set') {
      const v = readValue(action.value, ctx);
      const n = parseFloat(v);
      vars[key] = Number.isFinite(n) && typeof v !== 'boolean' ? n : v;
    } else if (op === 'add') vars[key] = current + readNumber(action.value, ctx);
    else if (op === 'subtract') vars[key] = current - readNumber(action.value, ctx);
    else if (op === 'multiply') vars[key] = current * readNumber(action.value, ctx);
    else if (op === 'random') {
      const min = readNumber(action.min, ctx), max = readNumber(action.max, ctx);
      vars[key] = min + Math.random() * (max - min);
    }
    return key;
  }

  /* --------------------------------------------------------------- actions */
  const ACTIONS = {};
  function defineAction(type, label, category, params, run, help) {
    ACTIONS[type] = { type: type, label: label, category: category, params: params, run: run, help: help || '' };
  }
  function defaults(params) {
    const out = {};
    for (const p of params) out[p.key] = p.default;
    return out;
  }
  function motion(ctx, action, rt, key, value) {
    const target = targetObject(ctx, action.target);
    if (!target) return true;
    target.transform[key].x += value.x * ctx.dt;
    target.transform[key].y += value.y * ctx.dt;
    target.transform[key].z += value.z * ctx.dt;
    const duration = readNumber(action.duration, ctx);
    if (duration <= 0) return false;
    rt.t = (rt.t || 0) + ctx.dt;
    return rt.t >= duration - 1e-6;
  }

  defineAction('log', 'Log Message', 'Flow', [
    { key: 'message', label: 'Message', type: 'text', default: 'Hello from PlayMaker' }
  ], function (a, ctx) {
    UE.log('info', '[FSM] ' + readString(a.message, ctx));
    return true;
  });

  defineAction('wait', 'Wait', 'Flow', [
    { key: 'seconds', label: 'Seconds', type: 'number', default: 1, min: 0, step: 0.1 }
  ], function (a, ctx, rt) {
    rt.t = (rt.t || 0) + ctx.dt;
    return rt.t >= Math.max(0, readNumber(a.seconds, ctx));
  }, 'Pauses this state for a number of seconds, then continues to the next action.');

  defineAction('setVariable', 'Set Variable', 'Variables', [
    { key: 'name', label: 'Variable', type: 'text', default: 'counter' },
    { key: 'operation', label: 'Operation', type: 'select', default: 'set', options: [
      { value: 'set', label: 'Set' }, { value: 'add', label: 'Add' }, { value: 'subtract', label: 'Subtract' },
      { value: 'multiply', label: 'Multiply' }, { value: 'random', label: 'Random between' }
    ] },
    { key: 'value', label: 'Value', type: 'text', default: '1' },
    { key: 'min', label: 'Random min', type: 'number', default: 0 },
    { key: 'max', label: 'Random max', type: 'number', default: 1 }
  ], function (a, ctx) {
    writeVariable(ctx.vars, a, ctx);
    return true;
  });

  defineAction('sendEvent', 'Send Event', 'Events', [
    { key: 'event', label: 'Event', type: 'text', default: 'FINISHED' },
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const name = readString(a.event, ctx);
    if (target && name) {
      if (target === ctx.self) ctx.send(name);
      else PlayMaker.sendEventToObject(target, name);
    }
    return true;
  });

  defineAction('broadcastEvent', 'Broadcast Event', 'Events', [
    { key: 'event', label: 'Event', type: 'text', default: 'Ping' }
  ], function (a, ctx) {
    PlayMaker.sendEventToScene(ctx.scene, readString(a.event, ctx));
    return true;
  });

  defineAction('randomEvent', 'Random Event', 'Events', [
    { key: 'events', label: 'Events (comma separated)', type: 'text', default: 'A,B,C' }
  ], function (a, ctx) {
    const list = readString(a.events, ctx).split(',').map(s => s.trim()).filter(Boolean);
    if (list.length) ctx.send(list[Math.floor(Math.random() * list.length)]);
    return true;
  });

  /* ------------------------------------------------------------------- FSM */
  defineAction('setFsmVariable', 'Set FSM Variable', 'FSM', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'fsm', label: 'FSM name', type: 'text', default: 'FSM' },
    { key: 'name', label: 'Variable', type: 'text', default: 'counter' },
    { key: 'operation', label: 'Operation', type: 'select', default: 'set', options: [
      { value: 'set', label: 'Set' }, { value: 'add', label: 'Add' }, { value: 'subtract', label: 'Subtract' },
      { value: 'multiply', label: 'Multiply' }, { value: 'random', label: 'Random between' }
    ] },
    { key: 'value', label: 'Value', type: 'text', default: '1' },
    { key: 'min', label: 'Random min', type: 'number', default: 0 },
    { key: 'max', label: 'Random max', type: 'number', default: 1 }
  ], function (a, ctx) {
    const fsm = findFsm(targetObject(ctx, a.target), a.fsm);
    if (fsm) writeVariable(fsm.variables, a, ctx);
    return true;
  }, 'Writes a variable on another FSM (or this one by name), without changing its state.');

  defineAction('sendFsmEvent', 'Send FSM Event', 'FSM', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'fsm', label: 'FSM name', type: 'text', default: 'FSM' },
    { key: 'event', label: 'Event', type: 'text', default: 'FINISHED' }
  ], function (a, ctx) {
    const fsm = findFsm(targetObject(ctx, a.target), a.fsm);
    if (fsm) fsm.queueEvent(readString(a.event, ctx));
    return true;
  });

  defineAction('goToFsmState', 'Go To FSM State', 'FSM', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'fsm', label: 'FSM name', type: 'text', default: 'FSM' },
    { key: 'state', label: 'State', type: 'text', default: 'Idle' }
  ], function (a, ctx) {
    const fsm = findFsm(targetObject(ctx, a.target), a.fsm);
    if (fsm) fsm.enter(readString(a.state, ctx));
    return true;
  });

  defineAction('restartFsm', 'Restart FSM', 'FSM', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'fsm', label: 'FSM name', type: 'text', default: 'FSM' }
  ], function (a, ctx) {
    const fsm = findFsm(targetObject(ctx, a.target), a.fsm);
    if (fsm) fsm.restart();
    return true;
  });

  defineAction('setFsmEnabled', 'Enable / Disable FSM', 'FSM', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'fsm', label: 'FSM name', type: 'text', default: 'FSM' },
    { key: 'enabled', label: 'Enabled', type: 'bool', default: true }
  ], function (a, ctx) {
    const fsm = findFsm(targetObject(ctx, a.target), a.fsm);
    if (fsm) fsm.enabled = readBool(a.enabled, ctx);
    return true;
  });

  defineAction('setPosition', 'Set Position', 'Transform', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X', type: 'number', default: 0 },
    { key: 'y', label: 'Y', type: 'number', default: 0 },
    { key: 'z', label: 'Z', type: 'number', default: 0 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.transform.position = V3.create(readNumber(a.x, ctx), readNumber(a.y, ctx), readNumber(a.z, ctx));
    return true;
  });

  defineAction('translate', 'Translate', 'Transform', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X / sec', type: 'number', default: 0 },
    { key: 'y', label: 'Y / sec', type: 'number', default: 1 },
    { key: 'z', label: 'Z / sec', type: 'number', default: 0 },
    { key: 'duration', label: 'Duration (0 = forever)', type: 'number', default: 0, min: 0 }
  ], function (a, ctx, rt) {
    return motion(ctx, a, rt, 'position', {
      x: readNumber(a.x, ctx), y: readNumber(a.y, ctx), z: readNumber(a.z, ctx)
    });
  });

  defineAction('setRotation', 'Set Rotation', 'Transform', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X', type: 'number', default: 0 },
    { key: 'y', label: 'Y', type: 'number', default: 0 },
    { key: 'z', label: 'Z', type: 'number', default: 0 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.transform.rotation = V3.create(readNumber(a.x, ctx), readNumber(a.y, ctx), readNumber(a.z, ctx));
    return true;
  });

  defineAction('rotate', 'Rotate', 'Transform', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X °/sec', type: 'number', default: 0 },
    { key: 'y', label: 'Y °/sec', type: 'number', default: 90 },
    { key: 'z', label: 'Z °/sec', type: 'number', default: 0 },
    { key: 'duration', label: 'Duration (0 = forever)', type: 'number', default: 0, min: 0 }
  ], function (a, ctx, rt) {
    return motion(ctx, a, rt, 'rotation', {
      x: readNumber(a.x, ctx), y: readNumber(a.y, ctx), z: readNumber(a.z, ctx)
    });
  });

  defineAction('setScale', 'Set Scale', 'Transform', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X', type: 'number', default: 1 },
    { key: 'y', label: 'Y', type: 'number', default: 1 },
    { key: 'z', label: 'Z', type: 'number', default: 1 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.transform.scale = V3.create(readNumber(a.x, ctx), readNumber(a.y, ctx), readNumber(a.z, ctx));
    return true;
  });

  defineAction('moveTowards', 'Move Towards', 'Transform', [
    { key: 'target', label: 'Move', type: 'object', default: 'self' },
    { key: 'x', label: 'Point X', type: 'number', default: 0 },
    { key: 'y', label: 'Point Y', type: 'number', default: 1 },
    { key: 'z', label: 'Point Z', type: 'number', default: 0 },
    { key: 'speed', label: 'Speed', type: 'number', default: 2, min: 0.01, step: 0.1 }
  ], function (a, ctx, rt) {
    const target = targetObject(ctx, a.target);
    if (!target) return true;
    const goal = V3.create(readNumber(a.x, ctx), readNumber(a.y, ctx), readNumber(a.z, ctx));
    const p = target.transform.position;
    const delta = V3.sub(goal, p);
    const distance = V3.length(delta);
    const step = Math.max(0.001, readNumber(a.speed, ctx)) * ctx.dt;
    if (distance <= step) {
      target.transform.position = goal;
      return true;
    }
    target.transform.position = V3.addScaled(p, V3.normalize(delta), step);
    return false;
  });

  defineAction('lookAt', 'Look At', 'Transform', [
    { key: 'target', label: 'Rotate', type: 'object', default: 'self' },
    { key: 'lookAt', label: 'Towards', type: 'object', default: 'none' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const aim = targetObject(ctx, a.lookAt);
    if (!target || !aim || aim === target) return true;
    const d = V3.normalize(V3.sub(positionOf(aim), positionOf(target)));
    target.transform.rotation = V3.create(
      Math.asin(UE.clamp(d.y, -1, 1)) * UE.RAD,
      Math.atan2(-d.x, -d.z) * UE.RAD,
      0
    );
    return true;
  });

  defineAction('setColor', 'Set Color', 'Material', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'color', label: 'Color', type: 'color', default: '#66ccff' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const mr = target && target.getComponent('MeshRenderer');
    if (mr) mr.color = colorOr(readString(a.color, ctx), mr.color);
    return true;
  });

  defineAction('setMaterial', 'Set Material', 'Material', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'color', label: 'Color', type: 'color', default: '#66ccff' },
    { key: 'opacity', label: 'Opacity', type: 'number', default: 1, min: 0.05, max: 1, step: 0.05 },
    { key: 'roughness', label: 'Roughness', type: 'number', default: 0.5, min: 0, max: 1, step: 0.05 },
    { key: 'emissive', label: 'Emissive', type: 'number', default: 0, min: 0, max: 1, step: 0.05 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const mr = target && target.getComponent('MeshRenderer');
    if (mr) {
      mr.color = colorOr(readString(a.color, ctx), mr.color);
      mr.opacity = UE.clamp(readNumber(a.opacity, ctx), 0.05, 1);
      mr.roughness = UE.clamp(readNumber(a.roughness, ctx), 0.02, 1);
      mr.emissive = UE.clamp(readNumber(a.emissive, ctx), 0, 1);
    }
    return true;
  });

  defineAction('editTexture', 'Edit Texture', 'Texture', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'color', label: 'Tint', type: 'color', default: '#ffffff' },
    { key: 'opacity', label: 'Opacity', type: 'number', default: 1, min: 0.05, max: 1, step: 0.05 },
    { key: 'roughness', label: 'Roughness', type: 'number', default: 0.55, min: 0, max: 1, step: 0.05 },
    { key: 'emissive', label: 'Emissive', type: 'number', default: 0, min: 0, max: 1, step: 0.05 },
    { key: 'scaleX', label: 'Tiling X', type: 'number', default: 1, step: 0.1 },
    { key: 'scaleY', label: 'Tiling Y', type: 'number', default: 1, step: 0.1 },
    { key: 'offsetX', label: 'Offset X', type: 'number', default: 0, step: 0.01 },
    { key: 'offsetY', label: 'Offset Y', type: 'number', default: 0, step: 0.01 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const mr = target && target.getComponent('MeshRenderer');
    if (mr) {
      mr.color = colorOr(readString(a.color, ctx), mr.color);
      mr.opacity = UE.clamp(readNumber(a.opacity, ctx), 0.05, 1);
      mr.roughness = UE.clamp(readNumber(a.roughness, ctx), 0.02, 1);
      mr.emissive = UE.clamp(readNumber(a.emissive, ctx), 0, 1);
      mr.uvScale = { x: readNumber(a.scaleX, ctx), y: readNumber(a.scaleY, ctx) };
      mr.uvOffset = { x: readNumber(a.offsetX, ctx), y: readNumber(a.offsetY, ctx) };
    }
    return true;
  }, 'Edits an imported base-color texture: tint, opacity, roughness, emission and UV tiling/offset.');

  defineAction('scrollTexture', 'Scroll Texture', 'Texture', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'U / sec', type: 'number', default: 0.1, step: 0.01 },
    { key: 'y', label: 'V / sec', type: 'number', default: 0, step: 0.01 },
    { key: 'duration', label: 'Duration (0 = forever)', type: 'number', default: 0, min: 0 }
  ], function (a, ctx, rt) {
    const target = targetObject(ctx, a.target);
    const mr = target && target.getComponent('MeshRenderer');
    if (!mr) return true;
    if (!mr.uvOffset) mr.uvOffset = { x: 0, y: 0 };
    mr.uvOffset.x += readNumber(a.x, ctx) * ctx.dt;
    mr.uvOffset.y += readNumber(a.y, ctx) * ctx.dt;
    const duration = readNumber(a.duration, ctx);
    if (duration <= 0) return false;
    rt.t = (rt.t || 0) + ctx.dt;
    return rt.t >= duration - 1e-6;
  }, 'Animates the base-color texture UV offset by scrolling it during Play mode.');

  defineAction('setActive', 'Set Active', 'Game Object', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'active', label: 'Active', type: 'bool', default: true }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.active = readBool(a.active, ctx);
    return true;
  });

  defineAction('activate', 'Activate Game Object', 'Game Object', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.active = true;
    return true;
  });

  defineAction('deactivate', 'Deactivate Game Object', 'Game Object', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.active = false;
    return true;
  });

  defineAction('setTag', 'Set Tag', 'Game Object', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'tag', label: 'Tag', type: 'text', default: 'Player' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) target.tag = readString(a.tag, ctx).trim() || 'Untagged';
    return true;
  }, 'Sets the GameObject tag. Tags are plain strings and serialize with the scene.');

  defineAction('setActiveByTag', 'Activate Objects By Tag', 'Game Object', [
    { key: 'tag', label: 'Tag', type: 'text', default: 'Player' },
    { key: 'active', label: 'Active', type: 'bool', default: true }
  ], function (a, ctx) {
    const tag = readString(a.tag, ctx).trim();
    const active = readBool(a.active, ctx);
    for (const object of objectsWithTag(ctx.scene, tag)) object.active = active;
    return true;
  });

  defineAction('sendEventToTag', 'Send Event To Tag', 'Game Object', [
    { key: 'tag', label: 'Tag', type: 'text', default: 'Player' },
    { key: 'event', label: 'Event', type: 'text', default: 'Ping' }
  ], function (a, ctx) {
    const tag = readString(a.tag, ctx).trim();
    const event = readString(a.event, ctx);
    if (!event) return true;
    for (const object of objectsWithTag(ctx.scene, tag)) {
      if (object.active) PM.sendEventToObject(object, event);
    }
    return true;
  }, 'Queues an event on every active GameObject that shares a tag.');

  defineAction('spawn', 'Spawn Primitive', 'Game Object', [
    { key: 'primitive', label: 'Primitive', type: 'primitive', default: 'cube' },
    { key: 'color', label: 'Color', type: 'color', default: '#ffb86b' },
    { key: 'x', label: 'Offset X', type: 'number', default: 0 },
    { key: 'y', label: 'Offset Y', type: 'number', default: 0.5 },
    { key: 'z', label: 'Offset Z', type: 'number', default: 0 }
  ], function (a, ctx) {
    const p = positionOf(ctx.self);
    const go = UE.createPrimitive('Spawned ' + (ctx.scene.objects.length + 1), a.primitive || 'cube', colorOr(readString(a.color, ctx), '#ffb86b'), {
      x: p.x + readNumber(a.x, ctx), y: p.y + readNumber(a.y, ctx), z: p.z + readNumber(a.z, ctx)
    });
    ctx.scene.add(go);
    return true;
  });

  defineAction('destroy', 'Destroy Object', 'Game Object', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (target) ctx.scene.remove(target);
    return true;
  });

  defineAction('setLight', 'Set Light', 'Rendering', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'color', label: 'Color', type: 'color', default: '#ffd08a' },
    { key: 'intensity', label: 'Intensity', type: 'number', default: 2, min: 0, max: 8, step: 0.1 },
    { key: 'range', label: 'Range', type: 'number', default: 10, min: 0.1, step: 0.5 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const light = target && target.getComponent('Light');
    if (light) {
      light.color = colorOr(readString(a.color, ctx), light.color);
      light.intensity = Math.max(0, readNumber(a.intensity, ctx));
      light.range = Math.max(0.1, readNumber(a.range, ctx));
    }
    return true;
  });

  defineAction('setSun', 'Set Sun', 'Rendering', [
    { key: 'color', label: 'Color', type: 'color', default: '#ffe9c4' },
    { key: 'intensity', label: 'Intensity', type: 'number', default: 1, min: 0, max: 4, step: 0.05 },
    { key: 'ambient', label: 'Ambient', type: 'number', default: 0.3, min: 0, max: 1, step: 0.05 }
  ], function (a, ctx) {
    ctx.scene.sun.color = colorOr(readString(a.color, ctx), ctx.scene.sun.color);
    ctx.scene.sun.intensity = Math.max(0, readNumber(a.intensity, ctx));
    ctx.scene.sun.ambient = UE.clamp(readNumber(a.ambient, ctx), 0, 1);
    return true;
  });

  defineAction('setLightType', 'Set Light Type', 'Rendering', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'type', label: 'Type', type: 'select', default: 'spot', options: UE.LIGHT_TYPES || [
      { value: 'sun', label: 'Sun' }, { value: 'directional', label: 'Directional' },
      { value: 'point', label: 'Point' }, { value: 'spot', label: 'Spot' }
    ] },
    { key: 'color', label: 'Color', type: 'color', default: '#ffd08a' },
    { key: 'intensity', label: 'Intensity', type: 'number', default: 2, min: 0, max: 8, step: 0.1 },
    { key: 'range', label: 'Range', type: 'number', default: 10, min: 0.1, step: 0.5 },
    { key: 'spotAngle', label: 'Outer angle', type: 'number', default: 46, min: 5, max: 120, step: 1 },
    { key: 'innerAngle', label: 'Inner angle', type: 'number', default: 22, min: 1, max: 120, step: 1 },
    { key: 'cookie', label: 'Cookie', type: 'select', default: 'none', options: UE.LIGHT_COOKIES || [
      { value: 'none', label: 'None' }, { value: 'checker', label: 'Checker' }, { value: 'stripes', label: 'Stripes' },
      { value: 'grid', label: 'Grid' }, { value: 'dots', label: 'Dots' }, { value: 'rings', label: 'Rings' }
    ] },
    { key: 'castShadow', label: 'Cast shadow', type: 'bool', default: true }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const light = target && target.getComponent('Light');
    if (light) {
      light.type = String(a.type || 'point');
      light.color = colorOr(readString(a.color, ctx), light.color);
      light.intensity = Math.max(0, readNumber(a.intensity, ctx));
      light.range = Math.max(0.1, readNumber(a.range, ctx));
      light.spotAngle = UE.clamp(readNumber(a.spotAngle, ctx), 5, 120);
      light.innerAngle = UE.clamp(readNumber(a.innerAngle, ctx), 1, light.spotAngle);
      light.cookie = String(a.cookie || 'none');
      light.castShadow = readBool(a.castShadow, ctx);
    }
    return true;
  }, 'Switches between the four light types — Sun, Directional, Point and Spot — and edits their properties.');

  /* --------------------------------------------------------------- animation */
  function ensureAnimator(target) {
    if (!target || !UE.Animation) return null;
    let animator = target.getComponent('Animator');
    if (!animator || !animator.skeleton || !animator.skeleton.length) {
      try { animator = UE.Animation.attach(target); } catch (err) { return null; }
    }
    return animator;
  }
  function motionIndex(value, ctx) {
    if (!UE.Animation) return null;
    return UE.Animation.Library.resolve(readValue(value, ctx));
  }
  const MOTION_LOOP = [
    { value: 'auto', label: 'Motion default' },
    { value: 'on', label: 'Loop' },
    { value: 'off', label: 'One shot' }
  ];
  function loopOption(value, ctx) {
    if (value === 'on') return true;
    if (value === 'off') return false;
    return undefined;
  }

  defineAction('playMotion', 'Play Motion', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'motion', label: 'Motion (name or #)', type: 'text', default: 'idle' },
    { key: 'fade', label: 'Crossfade (s)', type: 'number', default: 0.25, min: 0, step: 0.05 },
    { key: 'loop', label: 'Loop', type: 'select', default: 'auto', options: MOTION_LOOP }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (!animator) return true;
    const index = motionIndex(a.motion, ctx);
    if (index === null) return true;
    animator.play(index, { fade: Math.max(0, readNumber(a.fade, ctx)), loop: loopOption(a.loop, ctx) });
    return true;
  }, 'Plays any motion from the 99,999-motion library by name, category word or index. Auto-rigs a model that has no Animator yet.');

  defineAction('crossFadeMotion', 'Crossfade Motion', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'motion', label: 'Motion (name or #)', type: 'text', default: 'run' },
    { key: 'fade', label: 'Crossfade (s)', type: 'number', default: 0.35, min: 0, step: 0.05 },
    { key: 'loop', label: 'Loop', type: 'select', default: 'auto', options: MOTION_LOOP }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (!animator) return true;
    const index = motionIndex(a.motion, ctx);
    if (index === null) return true;
    animator.crossFadeTo(index, Math.max(0, readNumber(a.fade, ctx)));
    if (a.loop !== 'auto') animator.loop = loopOption(a.loop, ctx);
    return true;
  }, 'Blends from the current clip into another clip over a number of seconds.');

  defineAction('randomMotion', 'Random Motion', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'category', label: 'Category', type: 'select', default: 'all', options: (function () {
      const options = [{ value: 'all', label: 'All 99,999 motions' }];
      for (const category of (UE.Animation ? UE.Animation.CATEGORIES : [])) {
        options.push({ value: category.key, label: category.name });
      }
      return options;
    })() },
    { key: 'fade', label: 'Crossfade (s)', type: 'number', default: 0.25, min: 0, step: 0.05 }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (!animator || !UE.Animation) return true;
    const category = String(a.category || 'all');
    const offset = category === 'all' ? 0 : UE.Animation.Library.firstIndex(category);
    const index = offset + Math.floor(Math.random() * UE.Animation.PER_CATEGORY);
    animator.play(index % UE.Animation.MAX_MOTIONS, { fade: Math.max(0, readNumber(a.fade, ctx)) });
    return true;
  }, 'Plays a random motion, optionally restricted to one of the 25 motion categories.');

  defineAction('blendMotion', 'Blend Motion', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'motion', label: 'Blend motion (name or #)', type: 'text', default: 'walk' },
    { key: 'weight', label: 'Weight', type: 'number', default: 0.5, min: 0, max: 1, step: 0.05 },
    { key: 'mode', label: 'Mode', type: 'select', default: 'mix', options: [
      { value: 'mix', label: 'Mix (cross-blend)' },
      { value: 'additive', label: 'Additive (layer)' }
    ] },
    { key: 'clear', label: 'Clear secondary clip', type: 'bool', default: false }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (!animator) return true;
    if (readBool(a.clear, ctx)) { animator.setBlend(null); animator.blendWeight = 0; return true; }
    const index = motionIndex(a.motion, ctx);
    if (index === null) return true;
    animator.setBlend(index, UE.clamp(readNumber(a.weight, ctx), 0, 1), a.mode === 'additive' ? 'additive' : 'mix');
    return true;
  }, 'Layers a second clip over the current motion. Mix blends poses; Additive adds the clip pose as a delta.');

  defineAction('setMotionSpeed', 'Set Motion Speed', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'speed', label: 'Speed multiplier', type: 'number', default: 1.2, min: 0, max: 8, step: 0.05 }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (animator) animator.speed = Math.max(0, readNumber(a.speed, ctx));
    return true;
  });

  defineAction('setMotionPlaying', 'Set Motion Playing', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'playing', label: 'Playing', type: 'bool', default: true },
    { key: 'rewind', label: 'Rewind when playing', type: 'bool', default: false }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (!animator) return true;
    animator.playing = readBool(a.playing, ctx);
    if (animator.playing && readBool(a.rewind, ctx)) animator._time = 0;
    return true;
  });

  defineAction('stopAnimator', 'Stop Animation', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const animator = ensureAnimator(targetObject(ctx, a.target));
    if (animator) animator.stop();
    return true;
  }, 'Stops playback and rewinds the current motion to the rest pose.');

  defineAction('autoRigAnimator', 'Auto Rig Animator', 'Animation', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'motion', label: 'First motion', type: 'text', default: 'idle' },
    { key: 'fade', label: 'Crossfade (s)', type: 'number', default: 0.25, min: 0, step: 0.05 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    if (!target || !UE.Animation) return true;
    const index = motionIndex(a.motion, ctx);
    const options = { motion: index === null ? undefined : index };
    try {
      const animator = UE.Animation.attach(target, options);
      animator.fade = Math.max(0, readNumber(a.fade, ctx));
      if (index !== null) animator.play(index, { fade: animator.fade });
    } catch (err) {
      UE.log('warn', '[FSM] Auto Rig: ' + err.message);
    }
    return true;
  }, 'Builds a humanoid skeleton and skin weights for an imported model at runtime, then starts a motion.');

  defineAction('waitForInput', 'Wait For Key', 'Input', [
    { key: 'key', label: 'Key', type: 'key', default: 'e' }
  ], function (a, ctx) {
    const key = readString(a.key, ctx).toLowerCase();
    return ctx.keys.has(key);
  }, 'Continues when the key is held down during Play mode.');

  defineAction('setVelocity', 'Set Velocity', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X', type: 'number', default: 0 },
    { key: 'y', label: 'Y', type: 'number', default: 4 },
    { key: 'z', label: 'Z', type: 'number', default: 0 },
    { key: 'mode', label: 'Mode', type: 'select', default: 'set', options: [
      { value: 'set', label: 'Set' }, { value: 'add', label: 'Add impulse' }
    ] }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) {
      const set = a.mode !== 'add';
      rb.velocity.x = set ? readNumber(a.x, ctx) : rb.velocity.x + readNumber(a.x, ctx);
      rb.velocity.y = set ? readNumber(a.y, ctx) : rb.velocity.y + readNumber(a.y, ctx);
      rb.velocity.z = set ? readNumber(a.z, ctx) : rb.velocity.z + readNumber(a.z, ctx);
    }
    return true;
  });

  defineAction('addForce', 'Add Force', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'x', label: 'X', type: 'number', default: 0 },
    { key: 'y', label: 'Y', type: 'number', default: 3 },
    { key: 'z', label: 'Z', type: 'number', default: 0 },
    { key: 'mode', label: 'Mode', type: 'select', default: 'impulse', options: [
      { value: 'impulse', label: 'Impulse (instant velocity)' },
      { value: 'force', label: 'Force (per second)' }
    ] }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) {
      const mass = Math.max(0.001, Number(rb.mass) || 1);
      const factor = (a.mode === 'force' ? ctx.dt : 1) / mass;
      rb.velocity.x += readNumber(a.x, ctx) * factor;
      rb.velocity.y += readNumber(a.y, ctx) * factor;
      rb.velocity.z += readNumber(a.z, ctx) * factor;
    }
    return true;
  });

  defineAction('setUseGravity', 'Set Use Gravity', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'enabled', label: 'Gravity', type: 'bool', default: true }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) rb.useGravity = readBool(a.enabled, ctx);
    return true;
  });

  defineAction('setKinematic', 'Set Kinematic', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'enabled', label: 'Kinematic', type: 'bool', default: true },
    { key: 'stop', label: 'Stop motion', type: 'bool', default: true }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) {
      rb.isKinematic = readBool(a.enabled, ctx);
      if (rb.isKinematic && readBool(a.stop, ctx)) rb.velocity = V3.create();
    }
    return true;
  });

  defineAction('configureRigidbody', 'Configure Rigidbody', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'mass', label: 'Mass', type: 'number', default: 1, min: 0.001, step: 0.1 },
    { key: 'drag', label: 'Drag', type: 'number', default: 0, min: 0, step: 0.05 },
    { key: 'restitution', label: 'Bounce', type: 'number', default: 0.3, min: 0, max: 1, step: 0.05 }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) {
      rb.mass = Math.max(0.001, readNumber(a.mass, ctx));
      rb.drag = Math.max(0, readNumber(a.drag, ctx));
      rb.restitution = UE.clamp(readNumber(a.restitution, ctx), 0, 1);
    }
    return true;
  });

  defineAction('stopMotion', 'Stop Motion', 'Physics', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const rb = target && target.getComponent('Rigidbody');
    if (rb) rb.velocity = V3.create();
    return true;
  });

  defineAction('startTimer', 'Start Timer', 'Timers', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' },
    { key: 'seconds', label: 'Seconds', type: 'number', default: 1, min: 0.05, step: 0.1 },
    { key: 'repeat', label: 'Repeat', type: 'bool', default: true }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const timer = target && target.getComponent('PlayMakerTimer');
    if (timer) timer.start(readNumber(a.seconds, ctx), readBool(a.repeat, ctx));
    return true;
  }, 'Starts or restarts a PlayMaker Timer with an optional new period.');

  defineAction('stopTimer', 'Stop Timer', 'Timers', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const timer = target && target.getComponent('PlayMakerTimer');
    if (timer) timer.stop();
    return true;
  }, 'Stops a PlayMaker Timer. Start Timer resumes it from zero.');

  defineAction('resetTimer', 'Reset Timer', 'Timers', [
    { key: 'target', label: 'Target', type: 'object', default: 'self' }
  ], function (a, ctx) {
    const target = targetObject(ctx, a.target);
    const timer = target && target.getComponent('PlayMakerTimer');
    if (timer) timer.start(timer.seconds, timer.repeat);
    return true;
  });

  /* ------------------------------------------------------------ web / PHP */
  defineAction('openLink', 'Open Link', 'Web', [
    { key: 'url', label: 'URL', type: 'text', default: 'https://example.com/' },
    { key: 'newTab', label: 'New tab', type: 'bool', default: true }
  ], function (a, ctx) {
    const url = readString(a.url, ctx).trim();
    if (!url) return true;
    try {
      if (typeof window !== 'undefined' && window.open) {
        window.open(url, readBool(a.newTab, ctx) ? '_blank' : '_self', 'noopener');
      } else {
        UE.log('warn', '[FSM] Open Link is only available in a browser');
      }
    } catch (err) {
      UE.log('warn', '[FSM] Open Link failed: ' + err.message);
    }
    return true;
  }, 'Opens a URL in a new tab or the current tab. Use it for links, downloads or a PHP page.');

  defineAction('phpRequest', 'PHP Request', 'Web', [
    { key: 'url', label: 'PHP URL', type: 'text', default: 'https://example.com/api.php' },
    { key: 'method', label: 'Method', type: 'select', default: 'GET', options: [
      { value: 'GET', label: 'GET' }, { value: 'POST', label: 'POST' }
    ] },
    { key: 'body', label: 'POST body', type: 'text', default: '' },
    { key: 'contentType', label: 'Body type', type: 'select', default: 'application/x-www-form-urlencoded', options: [
      { value: 'application/x-www-form-urlencoded', label: 'Form URL encoded' },
      { value: 'application/json', label: 'JSON' },
      { value: 'text/plain', label: 'Plain text' }
    ] },
    { key: 'parseJSON', label: 'Parse JSON reply', type: 'bool', default: false },
    { key: 'replyKey', label: 'Reply key', type: 'text', default: 'phpReply' },
    { key: 'replyVariable', label: 'Reply variable', type: 'text', default: 'phpReply' },
    { key: 'replyEvent', label: 'On reply event', type: 'text', default: 'PHP_REPLY' },
    { key: 'errorEvent', label: 'On error event', type: 'text', default: 'PHP_ERROR' },
    { key: 'target', label: 'Event target', type: 'object', default: 'self' }
  ], function (a, ctx, rt) {
    if (rt.done) return true;
    if (rt.started) return false;
    const url = readString(a.url, ctx).trim();
    if (!url) {
      UE.log('warn', '[FSM] PHP Request needs a URL');
      rt.done = true;
      return true;
    }
    const fetcher = PM.web && PM.web.fetch;
    if (typeof fetcher !== 'function') {
      UE.log('warn', '[FSM] PHP Request is not available in this browser');
      rt.done = true;
      return true;
    }
    rt.started = true;
    const key = readString(a.replyKey, ctx).trim() || 'phpReply';
    const varName = readString(a.replyVariable, ctx).trim() || key;
    const target = targetObject(ctx, a.target);
    const method = String(a.method || 'GET').toUpperCase();
    const options = { method: method, headers: {} };
    if (method !== 'GET' && method !== 'HEAD') {
      options.body = readString(a.body, ctx);
      options.headers['Content-Type'] = a.contentType || 'application/x-www-form-urlencoded';
    }
    const finish = function (ok, value, status) {
      PM.web.storeReply(key, value, status);
      ctx.vars[varName] = value;
      const event = readString(ok ? a.replyEvent : a.errorEvent, ctx).trim();
      if (event && target) PM.sendEventToObject(target, event);
      rt.done = true;
    };
    try {
      Promise.resolve(fetcher(url, options)).then(function (response) {
        if (response && typeof response.text === 'function') {
          return response.text().then(function (text) {
            return { text: text, status: response.status || 0 };
          });
        }
        return { text: String(response === undefined ? '' : response), status: 0 };
      }).then(function (result) {
        let value = result.text;
        if (readBool(a.parseJSON, ctx)) {
          try { value = JSON.parse(value); }
          catch (err) { UE.log('warn', '[FSM] PHP reply was not valid JSON: ' + err.message); }
        }
        finish(true, value, result.status);
      }).catch(function (err) {
        UE.log('warn', '[FSM] PHP Request failed: ' + (err && err.message ? err.message : err));
        finish(false, '', 0);
      });
    } catch (err) {
      UE.log('warn', '[FSM] PHP Request failed: ' + err.message);
      finish(false, '', 0);
    }
    return false;
  }, 'Sends a GET/POST request to a PHP (or any HTTP) endpoint. The reply is stored and an event is queued when it arrives. The endpoint must allow CORS for cross-origin browser requests.');

  defineAction('phpReply', 'PHP Reply Receive', 'Web', [
    { key: 'replyKey', label: 'Reply key', type: 'text', default: 'phpReply' },
    { key: 'variable', label: 'Store in variable', type: 'text', default: 'phpReply' },
    { key: 'event', label: 'On receive event', type: 'text', default: 'PHP_REPLY' },
    { key: 'target', label: 'Event target', type: 'object', default: 'self' },
    { key: 'consume', label: 'Consume reply', type: 'bool', default: true },
    { key: 'timeout', label: 'Timeout seconds (0 = wait)', type: 'number', default: 0, min: 0, step: 0.5 }
  ], function (a, ctx, rt) {
    const key = readString(a.replyKey, ctx).trim() || 'phpReply';
    const reply = PM.web && PM.web.replies ? PM.web.replies[key] : null;
    if (!reply) {
      const timeout = readNumber(a.timeout, ctx);
      if (timeout > 0) {
        rt.t = (rt.t || 0) + ctx.dt;
        if (rt.t >= timeout) {
          UE.log('warn', '[FSM] PHP Reply Receive timed out waiting for "' + key + '"');
          return true;
        }
      }
      return false;
    }
    const varName = readString(a.variable, ctx).trim() || key;
    ctx.vars[varName] = reply.value;
    const event = readString(a.event, ctx).trim();
    if (event) {
      const target = targetObject(ctx, a.target);
      if (target) PM.sendEventToObject(target, event);
    }
    if (readBool(a.consume, ctx)) delete PM.web.replies[key];
    return true;
  }, 'Waits for, or immediately reads, a reply stored by PHP Request. Useful for chaining requests in different FSMs.');

  /* --------------------------------------------------------------- components */
  const PM = UE.PlayMaker = {
    keys: new Set(),
    onStateChange: null,
    events: ['START', 'FINISHED', 'UPDATE']
  };
  PM.actions = ACTIONS;
  PM.catalog = Object.keys(ACTIONS).map(k => ACTIONS[k]);
  PM.categories = ['Flow', 'FSM', 'Variables', 'Events', 'Transform', 'Material', 'Texture',
    'Game Object', 'Rendering', 'Animation', 'Physics', 'Timers', 'Web', 'Input'];
  PM.action = function (type) {
    const def = ACTIONS[type] || ACTIONS.log;
    return Object.assign({ type: def.type, enabled: true }, defaults(def.params));
  };
  PM.defaults = defaults;
  PM.web = {
    replies: {},
    storeReply: function (key, value, status) {
      const reply = { key: String(key || 'phpReply'), value: value, status: Number(status) || 0, time: Date.now() };
      this.replies[reply.key] = reply;
      return reply;
    },
    clear: function () {
      for (const key of Object.keys(this.replies)) delete this.replies[key];
    },
    fetch: function (url, options) {
      if (typeof fetch === 'function') return fetch(url, options);
      return Promise.reject(new Error('HTTP requests are not available in this browser'));
    }
  };

  class PlayMakerFSM extends Component {
    constructor(object) {
      super(object);
      this.name = 'FSM';
      this.start = 'Idle';
      this.variables = {};
      this.states = [{ name: 'Idle', actions: [], transitions: [] }];
      this.enabled = true;
      this._resetRuntime();
    }
    props() { return ['name', 'start', 'variables', 'states']; }
    _resetRuntime() {
      this._started = false;
      this._current = null;
      this._actionIndex = 0;
      this._runtimes = [];
      this._queue = [];
      this._finished = false;
      this._stateTime = 0;
    }
    applyJSON(props) {
      if (!props) return;
      for (const k of ['name', 'start', 'variables', 'states']) {
        if (props[k] !== undefined) this[k] = UE.clone(props[k]);
      }
      if (!Array.isArray(this.states) || !this.states.length) {
        this.states = [{ name: 'Idle', actions: [], transitions: [] }];
      }
      for (const state of this.states) {
        if (!Array.isArray(state.actions)) state.actions = [];
        if (!Array.isArray(state.transitions)) state.transitions = [];
        state.actions = state.actions.map(a => Object.assign(PM.action(a.type), a));
      }
      if (!this.variables || typeof this.variables !== 'object' || Array.isArray(this.variables)) this.variables = {};
      if (!this.states.some(s => s.name === this.start)) this.start = this.states[0].name;
      this._resetRuntime();
    }
    serializeProps() {
      return { name: this.name, start: this.start, variables: UE.clone(this.variables), states: UE.clone(this.states) };
    }
    state() { return this.states.find(s => s.name === this._current) || null; }
    queueEvent(name) {
      if (!name) return;
      this._queue.push(String(name));
    }
    enter(name) {
      if (!this.states.some(s => s.name === name)) return false;
      this._current = name;
      this._actionIndex = 0;
      this._runtimes = [];
      this._stateTime = 0;
      this._finished = false;
      if (typeof PM.onStateChange === 'function') PM.onStateChange(this, name);
      return true;
    }
    transition(event) {
      const state = this.state();
      if (!state) return false;
      const t = (state.transitions || []).find(x => x.event === event);
      if (!t) return false;
      return this.enter(t.to);
    }
    restart() {
      this.enabled = true;
      this._resetRuntime();
      this._started = true;
      this.enter(this.states.some(s => s.name === this.start) ? this.start : this.states[0].name);
      this._queue.push('START');
      return true;
    }
    update(scene, dt, time) {
      if (this.enabled === false) return;
      if (!this._started) {
        this._started = true;
        this.enter(this.states.some(s => s.name === this.start) ? this.start : this.states[0].name);
        this._queue.push('START');
      }
      this._stateTime += dt;
      const ctx = {
        self: this.object, scene: scene, dt: dt, time: time,
        fsm: this, vars: this.variables, keys: PM.keys,
        send: event => this.queueEvent(event)
      };
      let guard = 0;
      while (guard++ < 64) {
        if (this.enabled === false) return;
        if (!this._current) return;
        if (this._queue.length) {
          const event = this._queue.shift();
          if (this.transition(event)) continue;
        }
        const state = this.state();
        if (!state) return;
        if (this._actionIndex >= state.actions.length) {
          if (!this._finished) {
            this._finished = true;
            this._queue.push('FINISHED');
            continue;
          }
          return;
        }
        const action = state.actions[this._actionIndex];
        if (!action || action.enabled === false) {
          this._actionIndex++;
          continue;
        }
        const def = ACTIONS[action.type];
        if (!def) {
          this._actionIndex++;
          continue;
        }
        const rt = this._runtimes[this._actionIndex] || (this._runtimes[this._actionIndex] = {});
        let done = false;
        try {
          done = def.run(action, ctx, rt);
        } catch (err) {
          UE.log('error', '[FSM] ' + this.object.name + ' / ' + def.label + ': ' + err.message);
          done = true;
        }
        if (this._queue.length) continue;
        if (done) this._actionIndex++;
        else return;
      }
    }
  }
  PlayMakerFSM.typeName = 'PlayMakerFSM';
  PlayMakerFSM.label = 'PlayMaker FSM';
  PlayMakerFSM.props = ['name', 'start', 'variables', 'states'];

  class PlayMakerTrigger extends Component {
    constructor(object) {
      super(object);
      this.enterEvent = 'OnCollisionEnter';
      this.exitEvent = 'OnCollisionExit';
      this.target = 'self';
    }
    dispatch(kind, other) {
      const name = kind === 'enter' ? this.enterEvent : this.exitEvent;
      if (!name) return;
      const target = targetObject({ self: this.object, scene: this.object.scene }, this.target);
      if (target) PM.sendEventToObject(target, name, other);
    }
  }
  PlayMakerTrigger.typeName = 'PlayMakerTrigger';
  PlayMakerTrigger.label = 'PlayMaker Trigger';
  PlayMakerTrigger.props = ['enterEvent', 'exitEvent', 'target'];

  class PlayMakerTimer extends Component {
    constructor(object) {
      super(object);
      this.eventName = 'Timer';
      this.seconds = 1;
      this.repeat = true;
      this.target = 'self';
      this.running = true;
      this._t = 0;
      this._done = false;
    }
    start(seconds, repeat) {
      const period = Number(seconds);
      if (Number.isFinite(period)) this.seconds = Math.max(0.05, period);
      if (repeat !== undefined) this.repeat = !!repeat;
      this.running = true;
      this._done = false;
      this._t = 0;
      return this;
    }
    stop() {
      this.running = false;
      this._done = true;
      return this;
    }
    update(scene, dt) {
      if (!this.running || this._done) return;
      this._t = (this._t || 0) + dt;
      const period = Math.max(0.05, Number(this.seconds) || 1);
      if (this._t >= period) {
        this._t = 0;
        const target = targetObject({ self: this.object, scene: scene }, this.target);
        if (target) PM.sendEventToObject(target, this.eventName);
        if (!this.repeat) this._done = true;
      }
    }
  }
  PlayMakerTimer.typeName = 'PlayMakerTimer';
  PlayMakerTimer.label = 'PlayMaker Timer';
  PlayMakerTimer.props = ['eventName', 'seconds', 'repeat', 'target'];

  class PlayMakerInput extends Component {
    constructor(object) {
      super(object);
      this.eventName = 'Input';
      this.key = 'e';
      this.mode = 'down';
      this.target = 'self';
    }
    update(scene) {
      const key = String(this.key || '').toLowerCase();
      const down = PM.keys.has(key);
      if ((this.mode === 'up' && this._wasDown && !down) || (this.mode !== 'up' && down && !this._wasDown)) {
        const target = targetObject({ self: this.object, scene: scene }, this.target);
        if (target) PM.sendEventToObject(target, this.eventName);
      }
      this._wasDown = down;
    }
  }
  PlayMakerInput.typeName = 'PlayMakerInput';
  PlayMakerInput.label = 'PlayMaker Input';
  PlayMakerInput.props = ['eventName', 'key', 'mode', 'target'];

  class PlayMakerEventProxy extends Component {
    constructor(object) {
      super(object);
      this.eventName = 'Event';
      this.trigger = 'start';
      this.seconds = 1;
      this.key = 'e';
      this.target = 'self';
    }
    update(scene, dt) {
      if (this._done) return;
      let fire = false;
      if (this.trigger === 'start') {
        fire = true;
        this._done = true;
      } else if (this.trigger === 'timer') {
        this._t = (this._t || 0) + dt;
        if (this._t >= Math.max(0.05, Number(this.seconds) || 1)) { this._t = 0; fire = true; }
      } else if (this.trigger === 'key') {
        const key = String(this.key || '').toLowerCase();
        const down = PM.keys.has(key);
        fire = down && !this._wasDown;
        this._wasDown = down;
      }
      if (fire) {
        const target = targetObject({ self: this.object, scene: scene }, this.target);
        if (target) PM.sendEventToObject(target, this.eventName);
      }
    }
  }
  PlayMakerEventProxy.typeName = 'PlayMakerEventProxy';
  PlayMakerEventProxy.label = 'PlayMaker Event Proxy';
  PlayMakerEventProxy.props = ['eventName', 'trigger', 'seconds', 'key', 'target'];

  for (const C of [PlayMakerFSM, PlayMakerTrigger, PlayMakerTimer, PlayMakerInput, PlayMakerEventProxy]) {
    UE.Components[C.typeName] = C;
  }

  /* --------------------------------------------------------------- runtime */
  PM.sendEventToObject = function (object, event, other) {
    if (!object || !event) return false;
    let sent = false;
    for (const fsm of object.getComponents('PlayMakerFSM')) {
      fsm.queueEvent(event);
      fsm.lastEventObject = other || null;
      sent = true;
    }
    return sent;
  };
  PM.sendEventToScene = function (scene, event) {
    for (const object of scene.objects) {
      if (object.active) PM.sendEventToObject(object, event);
    }
  };
  PM.update = function (scene, dt, time) {
    for (const object of scene.objects) {
      if (!object.active) continue;
      for (const comp of object.components) {
        if (comp instanceof PlayMakerTimer || comp instanceof PlayMakerInput || comp instanceof PlayMakerEventProxy) {
          comp.update(scene, dt, time);
        }
      }
    }
    for (const object of scene.objects) {
      if (!object.active) continue;
      for (const comp of object.getComponents('PlayMakerFSM')) comp.update(scene, dt, time);
    }
  };
  PM.handleContacts = function (scene, contacts) {
    const previous = scene._pmContacts;
    scene._pmContacts = contacts;
    if (!previous) return;
    const added = [], removed = [];
    for (const key of contacts) if (!previous.has(key)) added.push(key);
    for (const key of previous) if (!contacts.has(key)) removed.push(key);
    function notify(pair, kind) {
      const ids = pair.split('|');
      for (let i = 0; i < ids.length; i++) {
        const object = scene.get(ids[i]);
        const other = scene.get(ids[i === 0 ? 1 : 0]);
        if (!object || !object.active) continue;
        for (const trigger of object.getComponents('PlayMakerTrigger')) trigger.dispatch(kind, other);
      }
    }
    for (const pair of added) notify(pair, 'enter');
    for (const pair of removed) notify(pair, 'exit');
  };
  PM.reset = function (scene) {
    PM.keys.clear();
    PM.web.clear();
    if (!scene) return;
    scene._pmContacts = null;
    for (const object of scene.objects) {
      for (const fsm of object.getComponents('PlayMakerFSM')) { fsm.enabled = true; fsm._resetRuntime(); }
      for (const timer of object.getComponents('PlayMakerTimer')) { timer.running = true; timer._t = 0; timer._done = false; }
      for (const input of object.getComponents('PlayMakerInput')) input._wasDown = false;
      for (const proxy of object.getComponents('PlayMakerEventProxy')) { proxy._t = 0; proxy._done = false; proxy._wasDown = false; }
    }
  };
  PM.setKey = function (key, down) {
    key = String(key || '').toLowerCase();
    if (down) PM.keys.add(key); else PM.keys.delete(key);
  };

  return UE;
});
