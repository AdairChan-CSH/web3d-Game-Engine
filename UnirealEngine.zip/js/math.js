/* UnirealEngine — math.js
 * Vectors, quaternions, matrices, rays and AABBs. No dependencies, no DOM.
 * Loads as a global (window.UE) in the browser. */
(function (root, factory) {
  root.UE = root.UE || {};
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';
  UE = UE || {};

  UE.DEG = Math.PI / 180;
  UE.RAD = 180 / Math.PI;
  UE.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  UE.lerp = function (a, b, t) { return a + (b - a) * t; };
  UE.clone = function (v) { return v == null ? v : JSON.parse(JSON.stringify(v)); };
  UE.uuid = function () {
    return 'o' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  };

  /* ------------------------------------------------------------------ Vec3 */
  const V3 = UE.V3 = {
    create: function (x, y, z) { return { x: x === undefined ? 0 : x, y: y === undefined ? 0 : y, z: z === undefined ? 0 : z }; },
    clone: function (a) { return { x: a.x, y: a.y, z: a.z }; },
    copy: function (a, b) { a.x = b.x; a.y = b.y; a.z = b.z; return a; },
    set: function (a, x, y, z) { a.x = x; a.y = y; a.z = z; return a; },
    add: function (a, b) { return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }; },
    sub: function (a, b) { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; },
    scale: function (a, s) { return { x: a.x * s, y: a.y * s, z: a.z * s }; },
    addScaled: function (a, b, s) { return { x: a.x + b.x * s, y: a.y + b.y * s, z: a.z + b.z * s }; },
    dot: function (a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; },
    cross: function (a, b) {
      return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x };
    },
    length: function (a) { return Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z); },
    lengthSq: function (a) { return a.x * a.x + a.y * a.y + a.z * a.z; },
    distance: function (a, b) { return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z); },
    normalize: function (a) {
      const l = Math.hypot(a.x, a.y, a.z);
      return l > 1e-9 ? { x: a.x / l, y: a.y / l, z: a.z / l } : { x: 0, y: 0, z: 0 };
    },
    neg: function (a) { return { x: -a.x, y: -a.y, z: -a.z }; },
    lerp: function (a, b, t) { return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t }; },
    round: function (a, step) {
      if (!step) return a;
      return { x: Math.round(a.x / step) * step, y: Math.round(a.y / step) * step, z: Math.round(a.z / step) * step };
    },
    equals: function (a, b, eps) {
      eps = eps || 1e-6;
      return Math.abs(a.x - b.x) < eps && Math.abs(a.y - b.y) < eps && Math.abs(a.z - b.z) < eps;
    }
  };

  /* ------------------------------------------------------------------ Quat */
  const Q = UE.Q = {
    identity: function () { return { x: 0, y: 0, z: 0, w: 1 }; },
    axisAngle: function (axis, radians) {
      const s = Math.sin(radians / 2);
      return { x: axis.x * s, y: axis.y * s, z: axis.z * s, w: Math.cos(radians / 2) };
    },
    multiply: function (a, b) {
      return {
        x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
      };
    },
    /* Unity's Euler order: ZXY (R = Ry * Rx * Rz). Degrees in, quaternion out. */
    fromEuler: function (e) {
      const rx = e.x * UE.DEG / 2, ry = e.y * UE.DEG / 2, rz = e.z * UE.DEG / 2;
      const qx = { x: Math.sin(rx), y: 0, z: 0, w: Math.cos(rx) };
      const qy = { x: 0, y: Math.sin(ry), z: 0, w: Math.cos(ry) };
      const qz = { x: 0, y: 0, z: Math.sin(rz), w: Math.cos(rz) };
      return Q.multiply(Q.multiply(qy, qx), qz);
    },
    rotate: function (q, v) {
      const ix = q.w * v.x + q.y * v.z - q.z * v.y;
      const iy = q.w * v.y + q.z * v.x - q.x * v.z;
      const iz = q.w * v.z + q.x * v.y - q.y * v.x;
      const iw = -q.x * v.x - q.y * v.y - q.z * v.z;
      return {
        x: ix * q.w + iw * -q.x + iy * -q.z - iz * -q.y,
        y: iy * q.w + iw * -q.y + iz * -q.x - ix * -q.z,
        z: iz * q.w + iw * -q.z + ix * -q.y - iy * -q.x
      };
    }
  };

  /* ------------------------------------------------------------------ Mat4
   * Column-major, identical to the arrays WebGL expects. */
  const M4 = UE.Mat4 = {
    identity: function () {
      return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
    },
    multiply: function (a, b) {
      const o = new Float32Array(16);
      for (let c = 0; c < 4; c++) {
        for (let r = 0; r < 4; r++) {
          o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
        }
      }
      return o;
    },
    compose: function (position, rotationEuler, scale) {
      const q = Q.fromEuler(rotationEuler);
      const x = q.x, y = q.y, z = q.z, w = q.w;
      const x2 = x + x, y2 = y + y, z2 = z + z;
      const xx = x * x2, xy = x * y2, xz = x * z2;
      const yy = y * y2, yz = y * z2, zz = z * z2;
      const wx = w * x2, wy = w * y2, wz = w * z2;
      const sx = scale.x, sy = scale.y, sz = scale.z;
      const m = new Float32Array(16);
      m[0] = (1 - (yy + zz)) * sx; m[1] = (xy + wz) * sx; m[2] = (xz - wy) * sx; m[3] = 0;
      m[4] = (xy - wz) * sy; m[5] = (1 - (xx + zz)) * sy; m[6] = (yz + wx) * sy; m[7] = 0;
      m[8] = (xz + wy) * sz; m[9] = (yz - wx) * sz; m[10] = (1 - (xx + yy)) * sz; m[11] = 0;
      m[12] = position.x; m[13] = position.y; m[14] = position.z; m[15] = 1;
      return m;
    },
    perspective: function (fovDeg, aspect, near, far) {
      const f = 1 / Math.tan(fovDeg * UE.DEG / 2);
      const nf = 1 / (near - far);
      const m = new Float32Array(16);
      m[0] = f / aspect; m[5] = f; m[10] = (far + near) * nf; m[11] = -1;
      m[14] = 2 * far * near * nf;
      return m;
    },
    lookAt: function (eye, target, up) {
      const z = V3.normalize(V3.sub(eye, target));
      let x = V3.cross(up, z);
      if (V3.lengthSq(x) < 1e-8) x = V3.cross(V3.create(0, 0, 1), z);
      x = V3.normalize(x);
      const y = V3.cross(z, x);
      const m = new Float32Array(16);
      m[0] = x.x; m[1] = y.x; m[2] = z.x; m[3] = 0;
      m[4] = x.y; m[5] = y.y; m[6] = z.y; m[7] = 0;
      m[8] = x.z; m[9] = y.z; m[10] = z.z; m[11] = 0;
      m[12] = -V3.dot(x, eye); m[13] = -V3.dot(y, eye); m[14] = -V3.dot(z, eye); m[15] = 1;
      return m;
    },
    transformPoint: function (m, p) {
      const w = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15] || 1;
      return {
        x: (m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12]) / w,
        y: (m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13]) / w,
        z: (m[2] * p.x + m[6] * p.y + m[10] * p.z + m[14]) / w
      };
    },
    transformDirection: function (m, d) {
      return {
        x: m[0] * d.x + m[4] * d.y + m[8] * d.z,
        y: m[1] * d.x + m[5] * d.y + m[9] * d.z,
        z: m[2] * d.x + m[6] * d.y + m[10] * d.z
      };
    },
    /* Inverse-transpose of the upper-left 3x3, column-major (for normals). */
    normalMatrix: function (m) {
      const a = m[0], b = m[1], c = m[2];
      const d = m[4], e = m[5], f = m[6];
      const g = m[8], h = m[9], i = m[10];
      const c00 = e * i - f * h, c01 = -(b * i - c * h), c02 = b * f - c * e;
      const c10 = -(d * i - f * g), c11 = a * i - c * g, c12 = -(a * f - c * d);
      const c20 = d * h - e * g, c21 = -(a * h - b * g), c22 = a * e - b * d;
      let det = a * c00 + b * c01 + c * c02;
      if (Math.abs(det) < 1e-9) det = 1e-9;
      const n = new Float32Array(9);
      n[0] = c00 / det; n[1] = c10 / det; n[2] = c20 / det;
      n[3] = c01 / det; n[4] = c11 / det; n[5] = c21 / det;
      n[6] = c02 / det; n[7] = c12 / det; n[8] = c22 / det;
      return n;
    },
    /* General 4x4 inverse (column-major). */
    invert: function (m) {
      const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3];
      const a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7];
      const a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11];
      const a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15];
      const b00 = a00 * a11 - a01 * a10;
      const b01 = a00 * a12 - a02 * a10;
      const b02 = a00 * a13 - a03 * a10;
      const b03 = a01 * a12 - a02 * a11;
      const b04 = a01 * a13 - a03 * a11;
      const b05 = a02 * a13 - a03 * a12;
      const b06 = a20 * a31 - a21 * a30;
      const b07 = a20 * a32 - a22 * a30;
      const b08 = a20 * a33 - a23 * a30;
      const b09 = a21 * a32 - a22 * a31;
      const b10 = a21 * a33 - a23 * a31;
      const b11 = a22 * a33 - a23 * a32;
      let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
      if (!det) return null;
      det = 1 / det;
      const o = new Float32Array(16);
      o[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det;
      o[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
      o[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det;
      o[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
      o[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det;
      o[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
      o[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det;
      o[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
      o[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det;
      o[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
      o[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det;
      o[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
      o[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det;
      o[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det;
      o[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det;
      o[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
      return o;
    },
    /* World -> screen. Returns null when the point is behind the camera. */
    project: function (m, p, width, height) {
      const x = m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12];
      const y = m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13];
      const z = m[2] * p.x + m[6] * p.y + m[10] * p.z + m[14];
      const w = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15];
      if (w <= 1e-5) return null;
      return {
        x: (x / w * 0.5 + 0.5) * width,
        y: (1 - (y / w * 0.5 + 0.5)) * height,
        ndcZ: z / w
      };
    }
  };

  /* ------------------------------------------------------------------ AABB */
  UE.AABB = {
    fromCenterSize: function (center, size) {
      const hx = Math.abs(size.x) / 2, hy = Math.abs(size.y) / 2, hz = Math.abs(size.z) / 2;
      return { cx: center.x, cy: center.y, cz: center.z, hx: hx, hy: hy, hz: hz };
    },
    min: function (b) { return V3.create(b.cx - b.hx, b.cy - b.hy, b.cz - b.hz); },
    max: function (b) { return V3.create(b.cx + b.hx, b.cy + b.hy, b.cz + b.hz); },
    center: function (b) { return V3.create(b.cx, b.cy, b.cz); },
    overlaps: function (a, b) {
      return Math.abs(a.cx - b.cx) < a.hx + b.hx &&
             Math.abs(a.cy - b.cy) < a.hy + b.hy &&
             Math.abs(a.cz - b.cz) < a.hz + b.hz;
    },
    /* Smallest translation that separates `a` from `b`. */
    separation: function (a, b) {
      const dx = a.cx - b.cx, px = a.hx + b.hx - Math.abs(dx);
      const dy = a.cy - b.cy, py = a.hy + b.hy - Math.abs(dy);
      const dz = a.cz - b.cz, pz = a.hz + b.hz - Math.abs(dz);
      if (px <= 0 || py <= 0 || pz <= 0) return null;
      if (px <= py && px <= pz) return { axis: 'x', pen: px, sign: dx >= 0 ? 1 : -1 };
      if (py <= pz) return { axis: 'y', pen: py, sign: dy >= 0 ? 1 : -1 };
      return { axis: 'z', pen: pz, sign: dz >= 0 ? 1 : -1 };
    }
  };

  /* ------------------------------------------------------------------- Ray */
  const R = UE.Ray = {
    create: function (origin, dir) { return { origin: origin, dir: V3.normalize(dir) }; },
    fromCamera: function (eye, forward, up, fovDeg, aspect, ndcX, ndcY) {
      const f = V3.normalize(forward);
      let right = V3.cross(f, up);
      if (V3.lengthSq(right) < 1e-8) right = V3.cross(f, V3.create(0, 0, 1));
      right = V3.normalize(right);
      const camUp = V3.cross(right, f);
      const tan = Math.tan(fovDeg * UE.DEG / 2);
      const dir = V3.normalize(V3.add(f, V3.add(V3.scale(right, ndcX * tan * aspect), V3.scale(camUp, ndcY * tan))));
      return { origin: V3.clone(eye), dir: dir };
    },
    intersectAABB: function (ro, rd, b) {
      let tmin = -Infinity, tmax = Infinity;
      const lo = [b.cx - b.hx, b.cy - b.hy, b.cz - b.hz];
      const hi = [b.cx + b.hx, b.cy + b.hy, b.cz + b.hz];
      const o = [ro.x, ro.y, ro.z], d = [rd.x, rd.y, rd.z];
      for (let i = 0; i < 3; i++) {
        if (Math.abs(d[i]) < 1e-9) {
          if (o[i] < lo[i] || o[i] > hi[i]) return null;
        } else {
          const inv = 1 / d[i];
          let t1 = (lo[i] - o[i]) * inv, t2 = (hi[i] - o[i]) * inv;
          if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
          tmin = Math.max(tmin, t1);
          tmax = Math.min(tmax, t2);
          if (tmin > tmax) return null;
        }
      }
      if (tmax < 0) return null;
      return tmin >= 0 ? tmin : tmax;
    },
    intersectSphere: function (ro, rd, center, radius) {
      const oc = V3.sub(ro, center);
      const b = V3.dot(oc, rd);
      const c = V3.dot(oc, oc) - radius * radius;
      const disc = b * b - c;
      if (disc < 0) return null;
      const sq = Math.sqrt(disc);
      let t = -b - sq;
      if (t < 0) t = -b + sq;
      return t < 0 ? null : t;
    },
    intersectPlane: function (ro, rd, point, normal) {
      const den = V3.dot(normal, rd);
      if (Math.abs(den) < 1e-6) return null;
      const t = V3.dot(normal, V3.sub(point, ro)) / den;
      return t < 0 ? null : t;
    },
    /* Closest parameter along an infinite axis line to the mouse ray. */
    closestOnAxis: function (ro, rd, origin, axis) {
      const w0 = V3.sub(origin, ro);
      const b = V3.dot(axis, rd);
      const c = V3.dot(axis, w0);
      const e = V3.dot(rd, w0);
      const den = 1 - b * b;
      if (Math.abs(den) < 1e-6) return null;
      return (e * b - c) / den;
    }
  };

  return UE;
});
