/* UnirealEngine — editor.js
 * The editor shell: hierarchy, inspector, viewport navigation, translate/rotate/scale gizmos,
 * play mode, undo history, console and localStorage/JSON persistence. Plain DOM + WebGL. */
(function () {
  'use strict';

  const UE = window.UE;
  const V3 = UE.V3;
  const DEG = UE.DEG;

  const STORAGE_SCENE = 'unirealengine.scene.v1';
  const STORAGE_PREFS = 'unirealengine.prefs.v1';
  const HISTORY_LIMIT = 80;
  const FIXED_DT = 1 / 60;

  /* ------------------------------------------------------------------- state */
  const app = {
    scene: null,
    selected: null,
    viewMode: 'scene',
    tool: 'move',
    playing: false,
    paused: false,
    time: 0,
    acc: 0,
    playJson: null,
    camera: { target: { x: 0, y: 1.1, z: 0 }, yaw: 38, pitch: 24, dist: 15, fov: 50 },
    view: null,
    options: { grid: true, wireframe: false, snap: false },
    history: [],
    redo: [],
    clipboard: null,
    logs: [],
    edit: null,
    drag: null,
    dragId: null,
    collapsed: new Set(),
    gizmoHover: null,
    gameCameraWarned: false,
    fps: 60,
    fpsFrames: 0,
    fpsTime: 0,
    lastStatsUpdate: 0,
    autosaveTimer: null
  };

  const els = {};
  function cacheEls() {
    const ids = ['tree', 'hierSearch', 'hierCount', 'btnAddObject', 'sceneList', 'btnNewScene',
      'stage', 'view', 'stageBadge', 'stageError', 'consoleLog', 'logCount', 'btnClearConsole',
      'chkInfo', 'chkWarn', 'chkError', 'inspector', 'inspectorTitle', 'inspectorSub',
      'btnPlay', 'btnPause', 'btnStep', 'btnStop', 'modePill', 'statFps', 'statTris', 'statObjs',
      'sceneTitle', 'chkSnap', 'chkGrid', 'chkWire', 'btnFocus', 'btnResetCam',
      'helpModal', 'btnHelpClose', 'toasts', 'importScene', 'importModel', 'importCookie',
      'btnImportModel', 'modelList'];
    for (const id of ids) els[id] = document.getElementById(id);
  }

  /* ------------------------------------------------------------------ helpers */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function fmt(n) {
    if (!Number.isFinite(n)) return '0';
    return String(Math.round(n * 1000) / 1000);
  }
  /* History and Play snapshots leave imported geometry out of the JSON: the
     AssetStore already owns it, and full meshes would make every undo entry huge. */
  function currentJson() { return JSON.stringify(app.scene.toJSON({ assets: false })); }
  function fullJson() { return JSON.stringify(app.scene.toJSON()); }
  function selectedObject() { return app.selected ? app.scene.get(app.selected) : null; }
  function normalizeColor(value) {
    if (typeof value !== 'string') return '#cccccc';
    let h = value.trim();
    if (h[0] !== '#') h = '#' + h;
    if (h.length === 4) h = '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
    return /^#[0-9a-fA-F]{6}$/.test(h) ? h : '#cccccc';
  }
  function uniqueName(base) {
    if (!app.scene.find(base)) return base;
    let i = 2;
    while (app.scene.find(base + ' ' + i)) i++;
    return base + ' ' + i;
  }
  function objectKind(obj) {
    if (obj.getComponent('Light')) return 'light';
    if (obj.getComponent('Camera')) return 'camera';
    const mr = obj.getComponent('MeshRenderer');
    if (mr) return mr.meshId ? 'model' : mr.primitive;
    if (obj.getComponent('PlayMakerFSM')) return 'fsm';
    if (obj.getComponent('Script')) return 'script';
    return 'empty';
  }
  function hasPlayMaker(obj) {
    return !!(obj.getComponent('PlayMakerFSM') || obj.getComponent('PlayMakerTrigger') ||
      obj.getComponent('PlayMakerTimer') || obj.getComponent('PlayMakerInput') ||
      obj.getComponent('PlayMakerEventProxy'));
  }
  function objectIcon(obj) {
    return el('span', 'oicon ' + objectKind(obj));
  }
  function objectBounds(obj) {
    const b = UE.Physics.bounds(obj);
    if (b) return b;
    const p = obj.transform.worldPosition();
    return { cx: p.x, cy: p.y, cz: p.z, hx: 0.35, hy: 0.35, hz: 0.35 };
  }

  /* ------------------------------------------------------------------ console */
  function log(level, message) {
    level = level === 'warning' ? 'warn' : level === 'log' ? 'info' : level;
    if (!['info', 'warn', 'error'].includes(level)) level = 'info';
    app.logs.push({ level: level, message: String(message), at: new Date() });
    if (app.logs.length > 400) app.logs.shift();
    renderConsole();
  }
  function renderConsole() {
    const show = { info: els.chkInfo.checked, warn: els.chkWarn.checked, error: els.chkError.checked };
    const nearBottom = els.consoleLog.scrollHeight - els.consoleLog.scrollTop - els.consoleLog.clientHeight < 40;
    els.consoleLog.innerHTML = '';
    for (const entry of app.logs) {
      if (!show[entry.level]) continue;
      const row = el('div', 'logrow ' + entry.level);
      const time = el('span', 'logtime', entry.at.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      const icon = el('span', 'logicon', entry.level === 'error' ? '✕' : entry.level === 'warn' ? '!' : '›');
      const text = el('span', 'logmsg', entry.message);
      row.appendChild(time); row.appendChild(icon); row.appendChild(text);
      els.consoleLog.appendChild(row);
    }
    els.logCount.textContent = String(app.logs.length);
    if (nearBottom) els.consoleLog.scrollTop = els.consoleLog.scrollHeight;
  }
  function toast(message) {
    const node = el('div', 'toast', message);
    els.toasts.appendChild(node);
    setTimeout(() => { node.classList.add('out'); }, 2200);
    setTimeout(() => { node.remove(); }, 2700);
  }

  /* ------------------------------------------------------------------ history */
  function commit(label) {
    app.history.push({ label: label, json: currentJson() });
    if (app.history.length > HISTORY_LIMIT) app.history.shift();
    app.redo.length = 0;
  }
  function beginEdit(label) {
    if (app.edit) return;
    app.edit = { label: label || 'Edit', json: currentJson() };
  }
  function endEdit() {
    if (!app.edit) return;
    const entry = app.edit;
    app.edit = null;
    if (entry.json !== currentJson()) {
      app.history.push(entry);
      if (app.history.length > HISTORY_LIMIT) app.history.shift();
      app.redo.length = 0;
      scheduleAutosave();
    }
  }
  function mutate(label, fn) {
    commit(label);
    fn();
    renderAll();
    scheduleAutosave();
  }
  function restore(json) {
    let data;
    try { data = JSON.parse(json); } catch (err) { log('error', 'Could not restore snapshot: ' + err.message); return; }
    app.scene = UE.Scene.fromJSON(data);
    if (app.selected && !app.scene.get(app.selected)) app.selected = null;
    app.playing = false;
    app.paused = false;
    app.playJson = null;
    app.drag = null;
    if (UE.PlayMaker && UE.PlayMaker.reset) UE.PlayMaker.reset(app.scene);
    renderAll();
    updateTransport();
    scheduleAutosave();
  }
  function undo() {
    if (!app.history.length) { toast('Nothing to undo'); return; }
    const entry = app.history.pop();
    app.redo.push({ label: entry.label, json: currentJson() });
    restore(entry.json);
    log('info', 'Undo: ' + entry.label);
  }
  function redo() {
    if (!app.redo.length) { toast('Nothing to redo'); return; }
    const entry = app.redo.pop();
    app.history.push({ label: entry.label, json: currentJson() });
    restore(entry.json);
    log('info', 'Redo: ' + entry.label);
  }

  /* ------------------------------------------------------------------- camera */
  function sceneEye(camera) {
    const c = camera || app.camera;
    const cp = Math.cos(c.pitch * DEG);
    return {
      x: c.target.x + Math.cos(c.yaw * DEG) * cp * c.dist,
      y: c.target.y + Math.sin(c.pitch * DEG) * c.dist,
      z: c.target.z + Math.sin(c.yaw * DEG) * cp * c.dist
    };
  }
  function lookRotation(from, to) {
    const d = V3.normalize(V3.sub(to, from));
    return {
      x: Math.asin(UE.clamp(d.y, -1, 1)) * UE.RAD,
      y: Math.atan2(-d.x, -d.z) * UE.RAD,
      z: 0
    };
  }
  function getView() {
    const width = Math.max(1, els.stage.clientWidth);
    const height = Math.max(1, els.stage.clientHeight);
    const aspect = width / height;
    let eye, forward, up, fov, near, far;
    const camObject = app.scene.mainCamera();
    if (app.viewMode === 'game' && camObject) {
      const cam = camObject.getComponent('Camera');
      eye = camObject.transform.worldPosition();
      forward = camObject.transform.forward();
      up = camObject.transform.up();
      fov = cam.fov || 60;
      near = cam.near || 0.1;
      far = cam.far || 250;
    } else {
      eye = sceneEye();
      forward = V3.normalize(V3.sub(app.camera.target, eye));
      up = V3.create(0, 1, 0);
      fov = app.camera.fov;
      near = 0.05;
      far = 600;
    }
    const viewMatrix = UE.Mat4.lookAt(eye, V3.add(eye, forward), up);
    const proj = UE.Mat4.perspective(fov, aspect, near, far);
    return {
      eye: eye, forward: forward, up: up, fov: fov, aspect: aspect,
      width: width, height: height, near: near, far: far,
      viewProj: UE.Mat4.multiply(proj, viewMatrix)
    };
  }
  function screenRay(clientX, clientY) {
    const rect = els.view.getBoundingClientRect();
    const ndcX = ((clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1;
    const ndcY = -(((clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1);
    const v = app.view || (app.view = getView());
    return UE.Ray.fromCamera(v.eye, v.forward, v.up, v.fov, v.aspect, ndcX, ndcY);
  }
  function projectPoint(p) {
    const v = app.view || (app.view = getView());
    return UE.Mat4.project(v.viewProj, p, v.width, v.height);
  }
  function localMouse(e) {
    const rect = els.view.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }
  function distToSegment(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay;
    const len = dx * dx + dy * dy;
    let t = len ? ((px - ax) * dx + (py - ay) * dy) / len : 0;
    t = UE.clamp(t, 0, 1);
    const cx = ax + dx * t, cy = ay + dy * t;
    return Math.hypot(px - cx, py - cy);
  }
  function gizmoInfo() {
    const obj = selectedObject();
    if (!obj || app.viewMode !== 'scene') return null;
    if (!app.view) app.view = getView();
    const origin = obj.transform.worldPosition();
    const scale = Math.max(0.25, V3.distance(app.view.eye, origin) * Math.tan(app.view.fov * DEG / 2) * 0.42);
    return { obj: obj, origin: origin, scale: scale, mode: app.tool };
  }
  function hitGizmo(x, y) {
    const g = gizmoInfo();
    if (!g) return null;
    const originS = projectPoint(g.origin);
    if (!originS) return null;
    if (g.mode === 'rotate') {
      const axes = {
        x: [V3.create(0, 1, 0), V3.create(0, 0, 1)],
        y: [V3.create(1, 0, 0), V3.create(0, 0, 1)],
        z: [V3.create(1, 0, 0), V3.create(0, 1, 0)]
      };
      let best = null;
      for (const axis of ['x', 'y', 'z']) {
        const [u1, u2] = axes[axis];
        let prev = null;
        for (let i = 0; i <= 72; i++) {
          const th = i / 72 * Math.PI * 2;
          const p = V3.add(g.origin, V3.add(V3.scale(u1, Math.cos(th) * g.scale), V3.scale(u2, Math.sin(th) * g.scale)));
          const s = projectPoint(p);
          if (prev && s) {
            const d = distToSegment(x, y, prev.x, prev.y, s.x, s.y);
            if (d < 7 && (!best || d < best.d)) best = { axis: axis, d: d };
          }
          prev = s;
        }
      }
      return best;
    }
    const axes = { x: V3.create(1, 0, 0), y: V3.create(0, 1, 0), z: V3.create(0, 0, 1) };
    let best = null;
    for (const axis of ['x', 'y', 'z']) {
      const tip = V3.add(g.origin, V3.scale(axes[axis], g.scale));
      const tipS = projectPoint(tip);
      if (!tipS) continue;
      const d = distToSegment(x, y, originS.x, originS.y, tipS.x, tipS.y);
      if (d < 9 && (!best || d < best.d)) best = { axis: axis, d: d };
    }
    if (g.mode === 'scale' && Math.hypot(x - originS.x, y - originS.y) < 11) best = { axis: 'all', d: 0 };
    return best;
  }
  function setWorldPosition(obj, world) {
    const parent = obj.transform.parent;
    if (!parent) { obj.transform.position = V3.clone(world); return; }
    const inv = UE.Mat4.invert(parent.transform.worldMatrix());
    if (!inv) { obj.transform.position = V3.clone(world); return; }
    const local = UE.Mat4.transformPoint(inv, world);
    obj.transform.position = { x: local.x, y: local.y, z: local.z };
  }
  function startGizmoDrag(e, hit) {
    const obj = selectedObject();
    const info = gizmoInfo();
    if (!obj || !info) return;
    beginEdit(app.tool === 'move' ? 'Move' : app.tool === 'rotate' ? 'Rotate' : 'Scale');
    const ray = screenRay(e.clientX, e.clientY);
    const axes = { x: V3.create(1, 0, 0), y: V3.create(0, 1, 0), z: V3.create(0, 0, 1) };
    const axis = hit.axis === 'all' ? V3.create(1, 0, 0) : axes[hit.axis];
    const drag = {
      kind: 'gizmo',
      mode: app.tool,
      axis: hit.axis,
      origin: info.origin,
      scale: info.scale,
      startWorld: obj.transform.worldPosition(),
      startLocal: V3.clone(obj.transform.position),
      startRotation: V3.clone(obj.transform.rotation),
      startScale: V3.clone(obj.transform.scale),
      startT: null,
      lastAngle: 0,
      angleAcc: 0,
      startMouseY: e.clientY,
      startMouse: localMouse(e)
    };
    if (app.tool === 'rotate') {
      const normal = axis;
      const basis = hit.axis === 'x' ? [V3.create(0, 1, 0), V3.create(0, 0, 1)] :
        hit.axis === 'y' ? [V3.create(1, 0, 0), V3.create(0, 0, 1)] : [V3.create(1, 0, 0), V3.create(0, 1, 0)];
      const t = UE.Ray.intersectPlane(ray.origin, ray.dir, info.origin, normal);
      if (t === null) { endEdit(); return; }
      const p = V3.add(ray.origin, V3.scale(ray.dir, t));
      const v = V3.sub(p, info.origin);
      drag.basis = basis;
      drag.lastAngle = Math.atan2(V3.dot(v, basis[1]), V3.dot(v, basis[0]));
    } else {
      drag.startT = UE.Ray.closestOnAxis(ray.origin, ray.dir, info.origin, axis);
    }
    app.drag = drag;
    els.view.style.cursor = 'grabbing';
  }
  function updateGizmoDrag(e, drag) {
    const obj = selectedObject();
    if (!obj) return;
    const ray = screenRay(e.clientX, e.clientY);
    const snap = app.options.snap || e.ctrlKey || e.metaKey;
    if (drag.mode === 'move') {
      const axis = drag.axis === 'x' ? V3.create(1, 0, 0) : drag.axis === 'y' ? V3.create(0, 1, 0) : V3.create(0, 0, 1);
      const t = UE.Ray.closestOnAxis(ray.origin, ray.dir, drag.origin, axis);
      if (t === null || drag.startT === null) return;
      let delta = t - drag.startT;
      if (snap) delta = Math.round(delta / 0.25) * 0.25;
      const world = V3.addScaled(drag.startWorld, axis, delta);
      setWorldPosition(obj, world);
    } else if (drag.mode === 'rotate') {
      const normal = drag.axis === 'x' ? V3.create(1, 0, 0) : drag.axis === 'y' ? V3.create(0, 1, 0) : V3.create(0, 0, 1);
      const t = UE.Ray.intersectPlane(ray.origin, ray.dir, drag.origin, normal);
      if (t === null) return;
      const p = V3.add(ray.origin, V3.scale(ray.dir, t));
      const v = V3.sub(p, drag.origin);
      let angle = Math.atan2(V3.dot(v, drag.basis[1]), V3.dot(v, drag.basis[0]));
      let d = angle - drag.lastAngle;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      drag.angleAcc += d;
      drag.lastAngle = angle;
      let deg = drag.angleAcc * UE.RAD * (drag.axis === 'y' ? -1 : 1);
      let value = drag.startRotation[drag.axis] + deg;
      if (snap) value = Math.round(value / 15) * 15;
      obj.transform.rotation[drag.axis] = value;
    } else if (drag.mode === 'scale') {
      if (drag.axis === 'all') {
        const factor = Math.max(0.05, 1 - (e.clientY - drag.startMouseY) * 0.01);
        for (const k of ['x', 'y', 'z']) {
          let v = drag.startScale[k] * factor;
          if (snap) v = Math.round(v / 0.1) * 0.1;
          obj.transform.scale[k] = UE.clamp(v, 0.02, 200);
        }
        return;
      }
      const axis = drag.axis === 'x' ? V3.create(1, 0, 0) : drag.axis === 'y' ? V3.create(0, 1, 0) : V3.create(0, 0, 1);
      const t = UE.Ray.closestOnAxis(ray.origin, ray.dir, drag.origin, axis);
      if (t === null || drag.startT === null) return;
      const factor = Math.max(0.04, 1 + (t - drag.startT) / drag.scale);
      let v = drag.startScale[drag.axis] * factor;
      if (snap) v = Math.round(v / 0.1) * 0.1;
      obj.transform.scale[drag.axis] = UE.clamp(v, 0.02, 200);
    }
  }

  /* ------------------------------------------------------------------ picking */
  function pickObject(clientX, clientY) {
    const ray = screenRay(clientX, clientY);
    let best = null;
    for (const obj of app.scene.objects) {
      if (!obj.active) continue;
      if (!obj.getComponent('MeshRenderer') && !obj.getComponent('Collider')) continue;
      const b = objectBounds(obj);
      const t = UE.Ray.intersectAABB(ray.origin, ray.dir, b);
      if (t !== null && t >= 0 && (!best || t < best.t)) best = { t: t, obj: obj };
    }
    return best ? best.obj : null;
  }

  /* -------------------------------------------------------------------- scene */
  function renderAll() {
    document.title = app.scene.name + ' — UnirealEngine';
    els.sceneTitle.textContent = app.scene.name;
    applySky();
    renderHierarchy();
    renderInspector();
    renderSceneList();
    renderModelList();
  }
  function applySky() {
    const sky = app.scene.sky || { top: '#182231', bottom: '#080a0e' };
    els.stage.style.background = 'linear-gradient(180deg, ' + sky.top + ' 0%, ' + sky.bottom + ' 100%)';
  }
  function select(id) {
    app.selected = id || null;
    app.gizmoHover = null;
    renderHierarchy();
    renderInspector();
  }
  function toggleActive(obj) {
    if (!obj) return;
    commit('Toggle active');
    obj.active = !obj.active;
    renderAll();
    scheduleAutosave();
  }
  function focusObject(obj) {
    if (!obj) return;
    const b = objectBounds(obj);
    app.camera.target = { x: b.cx, y: b.cy, z: b.cz };
    const radius = Math.max(b.hx, b.hy, b.hz);
    app.camera.dist = UE.clamp(radius * 4.5, 2.2, 90);
  }
  function resetCamera() {
    app.camera.target = { x: 0, y: 1.1, z: 0 };
    app.camera.yaw = 38;
    app.camera.pitch = 24;
    app.camera.dist = 15;
  }
  function addPrimitive(primitive) {
    mutate('Add ' + UE.primitiveLabel(primitive), function () {
      const label = UE.primitiveLabel(primitive);
      const go = UE.createPrimitive(uniqueName(label), primitive, defaultColor(primitive));
      go.transform.position = {
        x: app.camera.target.x,
        y: primitive === 'plane' ? 0 : 0.5,
        z: app.camera.target.z
      };
      if (primitive === 'plane') {
        go.transform.scale = V3.create(1, 1, 1);
      }
      app.scene.add(go);
      app.selected = go.id;
    });
    log('info', 'Added ' + UE.primitiveLabel(primitive));
  }
  function defaultColor(primitive) {
    return {
      cube: '#c9ced8', sphere: '#62b6cb', cylinder: '#8e7dff',
      cone: '#e06c75', plane: '#3a4250'
    }[primitive] || '#c9ced8';
  }
  function addCameraObject() {
    mutate('Add Camera', function () {
      const eye = sceneEye();
      const cam = UE.createCamera(uniqueName('Camera'), eye);
      cam.transform.rotation = lookRotation(eye, app.camera.target);
      for (const other of app.scene.objects) {
        const c = other.getComponent('Camera');
        if (c) c.main = false;
      }
      app.scene.add(cam);
      app.selected = cam.id;
    });
    log('info', 'Added Camera');
  }
  function addEmpty() {
    mutate('Create Empty', function () {
      const go = UE.createEmpty(uniqueName('GameObject'), { x: app.camera.target.x, y: 0, z: app.camera.target.z });
      app.scene.add(go);
      app.selected = go.id;
    });
  }
  function lightLabel(type) {
    return ({ sun: 'Sun Light', directional: 'Directional Light', point: 'Point Light', spot: 'Spot Light' })[type] || 'Light';
  }
  function addLight(type) {
    mutate('Add ' + lightLabel(type), function () {
      const height = type === 'sun' ? 9 : type === 'directional' ? 7 : type === 'spot' ? 4 : 2.4;
      const side = type === 'point' ? -1.9 : 0;
      const position = { x: app.camera.target.x + side, y: height, z: app.camera.target.z + (type === 'point' ? 1.9 : 0) };
      const rotation = {
        sun: { x: -52, y: 34, z: 0 },
        directional: { x: -42, y: 24, z: 0 },
        point: { x: 0, y: 0, z: 0 },
        spot: { x: -58, y: 0, z: 0 }
      }[type] || { x: 0, y: 0, z: 0 };
      const go = UE.createLight(uniqueName(lightLabel(type)), type, position, rotation);
      app.scene.add(go);
      app.selected = go.id;
    });
    log('info', 'Added ' + lightLabel(type) + ' — drag it in the scene, aim it with Rotate (E)');
  }

  /* --------------------------------------------------------------- model import */
  function readFileBuffer(file) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(new Error('Could not read ' + file.name)); };
      reader.readAsArrayBuffer(file);
    });
  }
  function importModelData(name, buffer, companions) {
    let mesh;
    try {
      mesh = UE.ModelIO.parse(name, buffer, companions);
    } catch (err) {
      log('error', 'Model "' + name + '" failed: ' + err.message);
      toast('Could not import ' + name);
      return null;
    }
    const meshId = UE.AssetStore.add(mesh, mesh.name, { dedupe: true });
    const meta = UE.AssetStore.meta(meshId);
    let object = null;
    mutate('Import ' + meta.name, function () {
      /* Imported primitives carry their own material colors, and base-color
       * textures already contain the model's colors. White keeps both untinted;
       * untextured models without a material fall back to the neutral gray. */
      const color = (meta.hasTexture || mesh.color) ? '#ffffff' : '#b9c6d8';
      object = UE.createModel(uniqueName(meta.name), meshId, { x: app.camera.target.x, y: 0, z: app.camera.target.z }, color);
      app.scene.add(object);
      app.selected = object.id;
    });
    log('info', 'Imported "' + meta.name + '" — ' + meta.triangleCount.toLocaleString() + ' triangles, ' + meta.vertexCount.toLocaleString() + ' vertices' + (meta.hasTexture ? ', base-color texture' : ''));
    return object;
  }
  function importModelFiles(fileList) {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    const modelFiles = files.filter(function (f) { return /\.(obj|stl|glb|gltf)$/i.test(f.name); });
    if (!modelFiles.length) {
      const first = files[0];
      if (/\.json$/i.test(first.name)) importSceneFile(first);
      else { toast('Use an OBJ, STL, GLB or glTF file'); log('warn', 'Unsupported file: ' + first.name); }
      return;
    }
    Promise.all(files.map(function (file) {
      return readFileBuffer(file).then(function (buffer) { return { file: file, buffer: buffer }; });
    })).then(function (items) {
      const companions = {};
      for (const item of items) companions[item.file.name] = item.buffer;
      for (const item of items) {
        if (modelFiles.indexOf(item.file) < 0) continue;
        importModelData(item.file.name, item.buffer, companions);
      }
      renderAll();
    }).catch(function (err) {
      log('error', 'Model import failed: ' + err.message);
      toast('Import failed');
    });
  }
  function importCookieFile(file, light) {
    if (!file || !light) return;
    if (!/^image\//.test(file.type || '')) { toast('Choose an image file'); return; }
    const reader = new FileReader();
    reader.onload = function () {
      light.cookie = 'texture';
      light.cookieTexture = String(reader.result);
      commit('Light cookie');
      renderInspector();
      scheduleAutosave();
      log('info', 'Light cookie set from ' + file.name);
    };
    reader.readAsDataURL(file);
  }
  function renderModelList() {
    if (!els.modelList) return;
    const items = UE.AssetStore ? UE.AssetStore.list() : [];
    els.modelList.innerHTML = '';
    if (!items.length) {
      els.modelList.appendChild(el('p', 'fineprint model-empty', 'No imported models yet. Drop an .obj, .stl, .glb or .gltf file here, or use Import.'));
      return;
    }
    for (const meta of items) {
      const card = el('div', 'model-card');
      card.appendChild(el('span', 'model-thumb'));
      const info = el('span', 'model-meta');
      info.appendChild(el('strong', '', meta.name));
      info.appendChild(el('small', '', meta.triangleCount.toLocaleString() + ' tris · ' + meta.vertexCount.toLocaleString() + ' verts'));
      card.appendChild(info);
      const add = el('button', 'btn tiny ghost model-add', 'Add');
      add.addEventListener('click', function () {
        mutate('Add ' + meta.name, function () {
          const color = (meta.hasTexture || meta.color) ? '#ffffff' : '#b9c6d8';
          const go = UE.createModel(uniqueName(meta.name), meta.id, { x: app.camera.target.x, y: 0, z: app.camera.target.z }, color);
          app.scene.add(go);
          app.selected = go.id;
        });
        log('info', 'Added model instance "' + meta.name + '"');
      });
      card.appendChild(add);
      els.modelList.appendChild(card);
    }
  }
  function deleteSelected() {
    const obj = selectedObject();
    if (!obj) { toast('Select an object first'); return; }
    const name = obj.name;
    mutate('Delete ' + name, function () {
      app.scene.remove(obj);
      app.selected = null;
    });
    log('info', 'Deleted ' + name);
  }
  function serializeSubtree(obj) {
    const list = [];
    (function walk(o) {
      list.push(o.toJSON());
      o.children().forEach(walk);
    })(obj);
    return list;
  }
  function copySelected() {
    const obj = selectedObject();
    if (!obj) { toast('Select an object first'); return; }
    app.clipboard = serializeSubtree(obj);
    toast('Copied ' + obj.name);
  }
  function pasteData(list) {
    if (!list || !list.length) return;
    const idMap = new Map();
    for (const src of list) idMap.set(src.id, UE.uuid());
    const objects = list.map(function (src) {
      const copy = UE.clone(src);
      copy.id = idMap.get(src.id);
      copy.parentId = src.parentId && idMap.has(src.parentId) ? idMap.get(src.parentId) : null;
      return copy;
    });
    objects[0].name = uniqueName(objects[0].name);
    const temp = UE.Scene.fromJSON({ name: 'clipboard', objects: objects });
    for (const obj of temp.objects.slice()) app.scene.add(obj);
    const root = app.scene.get(objects[0].id);
    const originalParent = list[0].parentId ? app.scene.get(list[0].parentId) : null;
    if (root && originalParent) root.setParent(originalParent);
    app.selected = root ? root.id : null;
  }
  function pasteClipboard() {
    if (!app.clipboard) { toast('Clipboard is empty'); return; }
    mutate('Paste', function () { pasteData(app.clipboard); });
    log('info', 'Pasted objects');
  }
  function duplicateSelected() {
    const obj = selectedObject();
    if (!obj) { toast('Select an object first'); return; }
    const list = serializeSubtree(obj);
    mutate('Duplicate ' + obj.name, function () { pasteData(list); });
  }
  function lookAtSelection() {
    const obj = selectedObject();
    if (!obj) return;
    const target = obj.transform.position;
    const d = V3.normalize(V3.sub(target, app.camera.target));
    app.camera.yaw = Math.atan2(d.z, d.x) * UE.RAD + 180;
    app.camera.pitch = Math.asin(UE.clamp(d.y, -1, 1)) * UE.RAD;
  }
  function openSample(id) {
    const entry = UE.Samples.list.find(function (s) { return s.id === id; });
    if (!entry) return;
    commit('Open ' + entry.name);
    app.scene = entry.make();
    app.selected = null;
    app.playing = false;
    app.paused = false;
    app.playJson = null;
    resetCamera();
    renderAll();
    updateTransport();
    scheduleAutosave();
    log('info', 'Opened "' + entry.name + '" — ' + app.scene.objects.length + ' objects');
  }
  function newScene() {
    commit('New Scene');
    app.scene = UE.Samples.create('empty');
    app.scene.name = 'Untitled';
    app.selected = null;
    app.playing = false;
    app.paused = false;
    app.playJson = null;
    resetCamera();
    renderAll();
    updateTransport();
    scheduleAutosave();
    log('info', 'New scene created');
  }

  /* ------------------------------------------------------------------ hierarchy */
  function matches(obj, filter) {
    if (!filter) return true;
    const tagOnly = filter.indexOf('tag:') === 0;
    const text = tagOnly ? filter.slice(4).trim() : filter;
    if (!tagOnly && obj.name.toLowerCase().indexOf(filter) >= 0) return true;
    if (text && String(obj.tag || '').toLowerCase().indexOf(text) >= 0) return true;
    return obj.children().some(function (c) { return matches(c, filter); });
  }
  function buildRow(obj, depth, filter, fragment) {
    if (filter && !matches(obj, filter)) return;
    const row = el('div', 'tree-row' + (obj.id === app.selected ? ' is-selected' : '') + (obj.active ? '' : ' is-off'));
    row.dataset.id = obj.id;
    row.style.paddingLeft = (6 + depth * 14) + 'px';
    row.draggable = true;
    row.setAttribute('role', 'treeitem');

    const hasChildren = obj.transform.children.length > 0;
    if (hasChildren) {
      const collapsed = !filter && app.collapsed.has(obj.id);
      const twist = el('button', 'twist', collapsed ? '▸' : '▾');
      twist.title = collapsed ? 'Expand' : 'Collapse';
      row.appendChild(twist);
    } else {
      row.appendChild(el('span', 'twist-space'));
    }
    row.appendChild(objectIcon(obj));
    row.appendChild(el('span', 'oname', obj.name));
    if (obj.tag && obj.tag !== 'Untagged') row.appendChild(el('span', 'chip tag', obj.tag));
    if (obj.getComponent('Script')) row.appendChild(el('span', 'chip', 'script'));
    if (obj.getComponent('Rigidbody')) row.appendChild(el('span', 'chip phys', 'rb'));
    if (hasPlayMaker(obj)) row.appendChild(el('span', 'chip ai', 'fsm'));
    const eye = el('button', 'eye' + (obj.active ? ' on' : ''), obj.active ? '●' : '○');
    eye.title = obj.active ? 'Disable object' : 'Enable object';
    row.appendChild(eye);
    fragment.appendChild(row);

    if (hasChildren && (filter || !app.collapsed.has(obj.id))) {
      for (const child of obj.children()) buildRow(child, depth + 1, filter, fragment);
    }
  }
  function renderHierarchy() {
    const filter = els.hierSearch.value.trim().toLowerCase();
    const fragment = document.createDocumentFragment();
    for (const root of app.scene.roots()) buildRow(root, 0, filter, fragment);
    els.tree.innerHTML = '';
    els.tree.appendChild(fragment);
    if (!app.scene.objects.length) {
      els.tree.appendChild(el('div', 'tree-empty', 'Scene is empty. Add a primitive from the Project panel.'));
    }
    els.hierCount.textContent = app.scene.objects.length + (app.scene.objects.length === 1 ? ' object' : ' objects');
  }

  /* ------------------------------------------------------------------ inspector */
  function fieldRow(label, control) {
    const row = el('div', 'field-row');
    row.appendChild(el('span', 'field-label', label));
    row.appendChild(control);
    return row;
  }
  function numInput(value, options) {
    options = options || {};
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'num' + (options.cls ? ' ' + options.cls : '');
    input.step = options.step || 0.1;
    if (options.min !== undefined) input.min = options.min;
    if (options.max !== undefined) input.max = options.max;
    input.value = fmt(value);
    const label = options.label || 'Edit';
    input.addEventListener('focus', function () { beginEdit(label); });
    input.addEventListener('input', function () {
      const v = parseFloat(input.value);
      if (Number.isFinite(v)) options.onChange(v);
    });
    input.addEventListener('blur', function () {
      endEdit();
      input.value = fmt(options.get ? options.get() : parseFloat(input.value) || 0);
    });
    return input;
  }
  function vectorEditor(vec, options) {
    options = options || {};
    const wrap = el('div', 'vec');
    for (const axis of ['x', 'y', 'z']) {
      const field = el('label', 'vec-field ' + axis);
      field.appendChild(el('span', 'axis-tag', axis.toUpperCase()));
      field.appendChild(numInput(vec[axis], {
        step: options.step || 0.1,
        min: options.min,
        label: (options.label || 'Vector') + ' ' + axis.toUpperCase(),
        get: function () { return vec[axis]; },
        onChange: function (v) {
          vec[axis] = v;
          if (options.onChange) options.onChange();
        }
      }));
      wrap.appendChild(field);
    }
    return wrap;
  }
  function vector2Editor(vec, options) {
    options = options || {};
    const wrap = el('div', 'vec two');
    for (const axis of ['x', 'y']) {
      const field = el('label', 'vec-field ' + axis);
      field.appendChild(el('span', 'axis-tag', axis.toUpperCase()));
      field.appendChild(numInput(vec[axis], {
        step: options.step || 0.1,
        min: options.min,
        label: (options.label || 'Vector 2') + ' ' + axis.toUpperCase(),
        get: function () { return vec[axis]; },
        onChange: function (v) {
          vec[axis] = v;
          if (options.onChange) options.onChange();
        }
      }));
      wrap.appendChild(field);
    }
    return wrap;
  }
  function checkboxRow(label, checked, onChange) {
    const row = el('label', 'check-row');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = !!checked;
    input.addEventListener('change', function () { onChange(input.checked); });
    row.appendChild(input);
    row.appendChild(el('span', '', label));
    return row;
  }
  function selectRow(label, value, options, onChange) {
    const select = document.createElement('select');
    select.className = 'select';
    for (const opt of options) {
      const option = document.createElement('option');
      option.value = opt.value;
      option.textContent = opt.label;
      if (opt.value === value) option.selected = true;
      select.appendChild(option);
    }
    select.addEventListener('change', function () { onChange(select.value); });
    return fieldRow(label, select);
  }
  function colorRow(label, value, onChange) {
    const wrap = el('div', 'color-row');
    const input = document.createElement('input');
    input.type = 'color';
    input.className = 'color';
    input.value = normalizeColor(value);
    const hex = el('span', 'hexval', normalizeColor(value));
    input.addEventListener('focus', function () { beginEdit(label); });
    input.addEventListener('input', function () {
      hex.textContent = input.value;
      onChange(input.value);
    });
    input.addEventListener('blur', function () { endEdit(); });
    wrap.appendChild(input);
    wrap.appendChild(hex);
    return fieldRow(label, wrap);
  }
  function sliderRow(label, value, min, max, step, onChange, formatter) {
    const wrap = el('div', 'slider-row');
    const input = document.createElement('input');
    input.type = 'range';
    input.min = min; input.max = max; input.step = step;
    input.value = value;
    const out = el('span', 'slider-val', formatter ? formatter(+value) : fmt(+value));
    input.addEventListener('pointerdown', function () { beginEdit(label); });
    input.addEventListener('input', function () {
      const v = parseFloat(input.value);
      out.textContent = formatter ? formatter(v) : fmt(v);
      onChange(v);
    });
    input.addEventListener('change', endEdit);
    input.addEventListener('pointerup', endEdit);
    wrap.appendChild(input);
    wrap.appendChild(out);
    return fieldRow(label, wrap);
  }
  function componentCard(title, onRemove, iconClass) {
    const card = el('div', 'comp');
    const head = el('header', 'comp-head');
    if (iconClass) head.appendChild(el('span', 'comp-icon ' + iconClass));
    head.appendChild(el('span', 'comp-title', title));
    if (onRemove) {
      const btn = el('button', 'iconbtn comp-remove', '×');
      btn.title = 'Remove component';
      btn.addEventListener('click', onRemove);
      head.appendChild(btn);
    }
    card.appendChild(head);
    const body = el('div', 'comp-body');
    card.appendChild(body);
    return { card: card, body: body };
  }
  /* A small canvas preview of a light cookie, drawn with the same patterns the
     renderer bakes into its 512×512 atlas. */
  function drawCookiePreview(canvas, cookie, texture) {
    const ctx = canvas.getContext('2d');
    const s = canvas.width;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, s, s);
    if (cookie === 'texture') {
      if (!texture) {
        ctx.fillStyle = '#1b2129';
        ctx.fillRect(0, 0, s, s);
        ctx.fillStyle = '#6f7b89';
        ctx.font = Math.round(s * 0.2) + 'px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('no image', s / 2, s / 2 + s * 0.07);
        return;
      }
      const img = new Image();
      img.onload = function () {
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, s, s);
        const scale = Math.max(s / img.naturalWidth, s / img.naturalHeight);
        ctx.drawImage(img, (s - img.naturalWidth * scale) / 2, (s - img.naturalHeight * scale) / 2,
          img.naturalWidth * scale, img.naturalHeight * scale);
      };
      img.src = texture;
      return;
    }
    if (cookie === 'checker') {
      const step = s / 8;
      ctx.fillStyle = '#ffffff';
      for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
          if ((row + col) % 2 === 0) ctx.fillRect(col * step, row * step, step, step);
        }
      }
    } else if (cookie === 'stripes') {
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 8; i += 2) ctx.fillRect(i * s / 8, 0, s / 8, s);
    } else if (cookie === 'grid') {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = Math.max(1, s / 42);
      for (let i = 0; i <= 8; i++) {
        const p = i * s / 8;
        ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, s); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(s, p); ctx.stroke();
      }
    } else if (cookie === 'dots') {
      ctx.fillStyle = '#ffffff';
      const step = s / 6;
      for (let row = 0; row < 6; row++) {
        for (let col = 0; col < 6; col++) {
          ctx.beginPath();
          ctx.arc((col + 0.5) * step, (row + 0.5) * step, step * 0.26, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (cookie === 'rings') {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = Math.max(1, s * 0.055);
      for (let r = s * 0.1; r < s * 0.75; r += s * 0.13) {
        ctx.beginPath(); ctx.arc(s / 2, s / 2, r, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(s / 2, s / 2, s * 0.06, 0, Math.PI * 2); ctx.fill();
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, s, s);
    }
  }
  function renderInspector() {
    const obj = selectedObject();
    els.inspector.innerHTML = '';
    if (!obj) {
      els.inspectorTitle.textContent = 'Scene';
      els.inspectorSub.textContent = 'environment';
      renderSceneInspector();
      return;
    }
    els.inspectorTitle.textContent = 'Inspector';
    els.inspectorSub.textContent = obj.name;

    /* object header */
    const head = el('div', 'obj-head');
    const active = document.createElement('input');
    active.type = 'checkbox';
    active.checked = obj.active;
    active.title = 'Active';
    active.addEventListener('change', function () {
      commit('Toggle active');
      obj.active = active.checked;
      renderAll();
      scheduleAutosave();
    });
    head.appendChild(active);
    const name = document.createElement('input');
    name.type = 'text';
    name.className = 'obj-name';
    name.value = obj.name;
    name.spellcheck = false;
    name.addEventListener('focus', function () { beginEdit('Rename'); });
    name.addEventListener('input', function () {
      obj.name = name.value || 'GameObject';
      els.inspectorSub.textContent = obj.name;
      const rowName = els.tree.querySelector('[data-id="' + obj.id + '"] .oname');
      if (rowName) rowName.textContent = obj.name;
    });
    name.addEventListener('blur', function () { endEdit(); renderHierarchy(); });
    head.appendChild(name);
    els.inspector.appendChild(head);

    /* tag */
    const tagWrap = el('div', 'obj-tag');
    const tagInput = document.createElement('input');
    tagInput.type = 'text';
    tagInput.className = 'text';
    tagInput.spellcheck = false;
    tagInput.value = obj.tag || 'Untagged';
    tagInput.setAttribute('list', 'scene-tag-suggestions');
    const tagList = document.createElement('datalist');
    tagList.id = 'scene-tag-suggestions';
    const tagSet = new Set(['Untagged', 'Player', 'Enemy', 'Pickup', 'Light']);
    for (const other of app.scene.objects) if (other.tag) tagSet.add(other.tag);
    for (const tag of tagSet) {
      const option = document.createElement('option');
      option.value = tag;
      tagList.appendChild(option);
    }
    tagInput.title = 'GameObject tag. Search the hierarchy with tag:Name and target it from PlayMaker with tag:Name.';
    tagInput.addEventListener('focus', function () { beginEdit('Tag'); });
    tagInput.addEventListener('input', function () { obj.tag = tagInput.value.trim() || 'Untagged'; });
    tagInput.addEventListener('blur', function () {
      endEdit();
      tagInput.value = obj.tag;
      renderHierarchy();
      scheduleAutosave();
    });
    tagWrap.appendChild(fieldRow('Tag', tagInput));
    tagWrap.appendChild(tagList);
    els.inspector.appendChild(tagWrap);

    /* transform */
    const transform = componentCard('Transform', null, 'transform');
    transform.body.appendChild(fieldRow('Position', vectorEditor(obj.transform.position, { step: 0.1, label: 'Position' })));
    transform.body.appendChild(fieldRow('Rotation', vectorEditor(obj.transform.rotation, { step: 1, label: 'Rotation' })));
    transform.body.appendChild(fieldRow('Scale', vectorEditor(obj.transform.scale, { step: 0.05, min: 0.01, label: 'Scale' })));
    els.inspector.appendChild(transform.card);

    /* components */
    for (const comp of obj.components.slice()) {
      const card = renderComponent(obj, comp);
      if (card) els.inspector.appendChild(card);
    }

    /* add component — grouped by category */
    const addWrap = el('div', 'add-comp');
    const select = document.createElement('select');
    select.className = 'select add-select';
    const labels = {
      MeshRenderer: 'Mesh Renderer', Collider: 'Collider', Rigidbody: 'Rigidbody', Camera: 'Camera',
      Script: 'Script', Light: 'Light', Animator: 'Animator', PlayMakerFSM: 'PlayMaker / FSM',
      PlayMakerTrigger: 'PlayMaker / Trigger', PlayMakerTimer: 'PlayMaker / Timer',
      PlayMakerInput: 'PlayMaker / Input', PlayMakerEventProxy: 'PlayMaker / Event Proxy'
    };
    const groups = [
      { label: 'Rendering', types: ['MeshRenderer', 'Light'] },
      { label: 'Animation', types: ['Animator'] },
      { label: 'Physics', types: ['Collider', 'Rigidbody'] },
      { label: 'PlayMaker', types: ['PlayMakerFSM', 'PlayMakerTrigger', 'PlayMakerTimer', 'PlayMakerInput', 'PlayMakerEventProxy'] },
      { label: 'Other', types: ['Camera', 'Script'] }
    ];
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = 'Add Component…';
    select.appendChild(placeholder);
    for (const group of groups) {
      const og = document.createElement('optgroup');
      og.label = group.label;
      for (const type of group.types) {
        const repeatable = type === 'Script' || type.indexOf('PlayMaker') === 0;
        if (obj.getComponent(type) && !repeatable) continue;
        const option = document.createElement('option');
        option.value = type;
        option.textContent = labels[type];
        og.appendChild(option);
      }
      if (og.children.length) select.appendChild(og);
    }
    select.addEventListener('change', function () {
      const type = select.value;
      if (!type) return;
      addComponentToObject(obj, type);
    });
    addWrap.appendChild(select);
    els.inspector.appendChild(addWrap);
  }
  /* Auto-rig is a scene edit: generate the skeleton once, then expose motion
     playback and blending in the Animator card. */
  function autoRigObject(obj, options) {
    if (!UE.Animation) { toast('The animation module is not loaded'); return null; }
    const mr = obj && obj.getComponent('MeshRenderer');
    if (!mr || !mr.meshId) {
      toast('Import a 3D model first');
      log('warn', 'Auto Rig needs a Mesh Renderer with an imported model');
      return null;
    }
    commit('Auto rig');
    try {
      const animator = UE.Animation.attach(obj, options);
      log('info', 'Auto-rigged "' + obj.name + '" · ' + animator.skeleton.length + ' bones · ' + animator.motionName);
      toast('Auto-rigged · ' + animator.skeleton.length + ' bones');
      renderAll();
      scheduleAutosave();
      return animator;
    } catch (err) {
      log('error', 'Auto rig failed: ' + err.message);
      toast('Auto rig failed');
      return null;
    }
  }
  function addComponentToObject(obj, type) {
    if (!obj || !type) return;
    if (type === 'Animator') { autoRigObject(obj); return; }
    const labels = {
      MeshRenderer: 'Mesh Renderer', Collider: 'Collider', Rigidbody: 'Rigidbody', Camera: 'Camera',
      Script: 'Script', Light: 'Light', Animator: 'Animator', PlayMakerFSM: 'PlayMaker FSM',
      PlayMakerTrigger: 'PlayMaker Trigger', PlayMakerTimer: 'PlayMaker Timer',
      PlayMakerInput: 'PlayMaker Input', PlayMakerEventProxy: 'PlayMaker Event Proxy'
    };
    mutate('Add ' + (labels[type] || type), function () {
      if (type === 'Rigidbody' && !obj.getComponent('Collider')) obj.addComponent('Collider');
      if (type === 'Camera') {
        for (const other of app.scene.objects) {
          const c = other.getComponent('Camera');
          if (c) c.main = false;
        }
      }
      obj.addComponent(type, type === 'MeshRenderer' ? { primitive: 'cube' } : null);
    });
    log('info', 'Added ' + (labels[type] || type) + ' to ' + obj.name);
  }
  function renderComponent(obj, comp) {
    const type = comp.constructor.typeName;
    const remove = function () {
      commit('Remove ' + type);
      obj.removeComponent(comp);
      renderAll();
      scheduleAutosave();
    };
    if (type === 'MeshRenderer') {
      const card = componentCard('Mesh Renderer', remove, 'mesh');
      const modelOptions = [{ value: '', label: '— Built-in primitive —' }];
      if (UE.AssetStore) {
        for (const meta of UE.AssetStore.list()) modelOptions.push({ value: meta.id, label: meta.name });
      }
      card.body.appendChild(selectRow('Mesh', comp.meshId || '', modelOptions, function (v) {
        commit('Mesh asset');
        comp.meshId = v || null;
        const meta = v ? UE.AssetStore.meta(v) : null;
        comp.meshName = meta ? meta.name : '';
        if (v) comp.primitive = 'model';
        renderInspector();
        renderHierarchy();
        scheduleAutosave();
      }));
      card.body.appendChild(selectRow('Primitive', comp.primitive,
        UE.PRIMITIVES.map(function (p) { return { value: p, label: UE.primitiveLabel(p) }; }),
        function (v) {
          commit('Primitive');
          comp.primitive = v;
          comp.meshId = null;
          comp.meshName = '';
          renderInspector();
          renderHierarchy();
          scheduleAutosave();
        }));
      if (comp.meshId) {
        const meta = UE.AssetStore.meta(comp.meshId);
        card.body.appendChild(el('p', 'fineprint', meta
          ? 'Imported mesh · ' + meta.triangleCount.toLocaleString() + ' triangles · ' + meta.vertexCount.toLocaleString() + ' vertices · ' +
            (meta.hasTexture ? 'base-color texture' : 'no texture') + '. Color below tints the imported material.'
          : 'The imported mesh is missing. Re-import the model file.'));
        if (UE.Animation) {
          const rigButton = el('button', 'btn tiny primary', obj.getComponent('Animator') ? 'Re-Auto Rig' : 'Auto Rig & Animate');
          rigButton.title = 'Generate a humanoid skeleton, compute skin weights and start a procedural motion';
          rigButton.addEventListener('click', function () { autoRigObject(obj); });
          card.body.appendChild(rigButton);
        }
      }
      card.body.appendChild(colorRow('Color', comp.color, function (v) { comp.color = v; }));
      card.body.appendChild(sliderRow('Roughness', comp.roughness, 0.02, 1, 0.01, function (v) { comp.roughness = v; }, function (v) { return v.toFixed(2); }));
      card.body.appendChild(sliderRow('Opacity', comp.opacity === undefined ? 1 : comp.opacity, 0.05, 1, 0.01, function (v) { comp.opacity = v; }, function (v) { return Math.round(v * 100) + '%'; }));
      card.body.appendChild(sliderRow('Emissive', comp.emissive || 0, 0, 0.6, 0.01, function (v) { comp.emissive = v; }, function (v) { return v.toFixed(2); }));
      if (!comp.uvScale) comp.uvScale = { x: 1, y: 1 };
      if (!comp.uvOffset) comp.uvOffset = { x: 0, y: 0 };
      card.body.appendChild(fieldRow('UV tiling', vector2Editor(comp.uvScale, {
        step: 0.1, label: 'UV tiling', onChange: scheduleAutosave
      })));
      card.body.appendChild(fieldRow('UV offset', vector2Editor(comp.uvOffset, {
        step: 0.05, label: 'UV offset', onChange: scheduleAutosave
      })));
      const uvReset = el('button', 'btn tiny ghost', 'Reset UV tiling & offset');
      uvReset.addEventListener('click', function () {
        commit('Reset UV');
        comp.uvScale = { x: 1, y: 1 };
        comp.uvOffset = { x: 0, y: 0 };
        renderInspector();
        scheduleAutosave();
      });
      card.body.appendChild(uvReset);
      card.body.appendChild(el('p', 'fineprint', comp.meshId && UE.AssetStore.meta(comp.meshId)
        ? 'UV tiling and offset edit the imported base-color texture. Use Edit Texture or Scroll Texture in PlayMaker to animate them.'
        : 'UV tiling and offset apply to imported base-color textures. Built-in primitives use vertex colors.'));
      card.body.appendChild(checkboxRow('Cast contact shadow', comp.castShadow !== false, function (v) {
        commit('Cast shadow');
        comp.castShadow = v;
      }));
      return card.card;
    }
    if (type === 'Animator') {
      const A = UE.Animation;
      const card = componentCard('Animator', remove, 'anim');
      if (!A || !A.Library) {
        card.body.appendChild(el('p', 'fineprint', 'The animation module is not loaded.'));
        return card.card;
      }
      const lib = A.Library;
      if (!comp.skeleton || !comp.skeleton.length) {
        card.body.appendChild(el('p', 'fineprint', 'This Animator has no skeleton yet. Select a model and press Auto Rig.'));
        const rigNow = el('button', 'btn tiny primary', 'Auto Rig from Mesh');
        rigNow.addEventListener('click', function () { autoRigObject(obj); });
        card.body.appendChild(rigNow);
        return card.card;
      }

      const info = lib.info(comp.motion) || { index: 0, name: 'None', duration: 0, category: '—', loop: true };
      card.body.appendChild(el('p', 'fineprint',
        'Rig: ' + (comp.rigName || 'Auto Humanoid') + ' · ' + comp.skeleton.length + ' bones · GPU linear-blend skinning'));
      card.body.appendChild(el('p', 'anim-now', info.name));
      card.body.appendChild(el('p', 'fineprint',
        'Motion ' + (info.index + 1).toLocaleString() + ' of ' + A.MAX_MOTIONS.toLocaleString() +
        ' · ' + info.duration.toFixed(2) + ' s · ' + info.category + (info.loop ? ' · loops' : ' · one shot')));

      const setMotion = function (index, label, options) {
        const resolved = lib.resolve(index);
        if (resolved === null) { toast('Unknown motion'); return; }
        commit(label || 'Animation motion');
        comp.play(resolved, options);
        renderInspector();
        scheduleAutosave();
      };
      const button = function (label, title, fn, cls) {
        const b = el('button', 'btn tiny' + (cls ? ' ' + cls : ''), label);
        if (title) b.title = title;
        b.addEventListener('click', fn);
        return b;
      };

      const quick = el('div', 'anim-buttons');
      quick.appendChild(button('‹ Prev', 'Previous motion', function () {
        setMotion((comp.motion + A.MAX_MOTIONS - 1) % A.MAX_MOTIONS, 'Previous motion');
      }));
      quick.appendChild(button('Next ›', 'Next motion', function () {
        setMotion((comp.motion + 1) % A.MAX_MOTIONS, 'Next motion');
      }));
      quick.appendChild(button('Random', 'Pick a random motion from all 99,999', function () {
        setMotion(Math.floor(Math.random() * A.MAX_MOTIONS), 'Random motion');
      }));
      quick.appendChild(button(comp.playing ? '❚❚ Pause' : '▶ Play', 'Play or pause the current motion', function () {
        commit('Animation play');
        comp.playing = !comp.playing;
        renderInspector();
        scheduleAutosave();
      }));
      quick.appendChild(button('■ Stop', 'Stop and rewind', function () {
        commit('Animation stop');
        comp.stop();
        renderInspector();
        scheduleAutosave();
      }));
      card.body.appendChild(quick);

      /* library browser: category, free-text search, page of results */
      const resultSelect = document.createElement('select');
      resultSelect.className = 'select';
      let filterCategory = 'all';
      let filterText = '';
      const refresh = function () {
        const offset = filterCategory === 'all' ? 0 : lib.firstIndex(filterCategory);
        const found = lib.list({ category: filterCategory, query: filterText, limit: 80, offset: offset });
        resultSelect.innerHTML = '';
        if (!found.length) {
          const empty = document.createElement('option');
          empty.value = '';
          empty.textContent = 'No matches';
          resultSelect.appendChild(empty);
          return;
        }
        for (const motion of found) {
          const option = document.createElement('option');
          option.value = String(motion.index);
          option.textContent = '#' + (motion.index + 1).toLocaleString() + '  ' + motion.name;
          if (motion.index === comp.motion) option.selected = true;
          resultSelect.appendChild(option);
        }
      };
      refresh();
      resultSelect.addEventListener('change', function () {
        if (resultSelect.value !== '') setMotion(parseInt(resultSelect.value, 10), 'Animation motion');
      });

      const categorySelect = document.createElement('select');
      categorySelect.className = 'select';
      const allOption = document.createElement('option');
      allOption.value = 'all';
      allOption.textContent = 'All · ' + A.MAX_MOTIONS.toLocaleString() + ' motions';
      categorySelect.appendChild(allOption);
      for (const category of A.CATEGORIES) {
        const option = document.createElement('option');
        option.value = category.key;
        option.textContent = category.name + ' · 4,000';
        categorySelect.appendChild(option);
      }
      categorySelect.addEventListener('change', function () { filterCategory = categorySelect.value; refresh(); });
      card.body.appendChild(fieldRow('Category', categorySelect));

      const search = document.createElement('input');
      search.type = 'search';
      search.className = 'text';
      search.placeholder = 'Search motion names, e.g. run, kick, carry';
      search.addEventListener('input', function () { filterText = search.value.trim().toLowerCase(); refresh(); });
      card.body.appendChild(fieldRow('Find motion', search));
      card.body.appendChild(fieldRow('Library', resultSelect));

      const jumpWrap = el('div', 'anim-inline');
      const jump = document.createElement('input');
      jump.type = 'number';
      jump.className = 'num';
      jump.min = '1';
      jump.max = String(A.MAX_MOTIONS);
      jump.step = '1';
      jump.value = String(info.index + 1);
      jumpWrap.appendChild(jump);
      const jumpGo = button('Go', 'Play the motion with this index', function () {
        setMotion(Math.round(Number(jump.value)) - 1, 'Motion index');
      });
      jumpWrap.appendChild(jumpGo);
      card.body.appendChild(fieldRow('Go to #', jumpWrap));

      /* blending */
      const blendLine = el('p', 'fineprint');
      const updateBlendNote = function () {
        if (comp.blendMotion >= 0) {
          const blendInfo = lib.info(comp.blendMotion);
          blendLine.textContent = 'Blending with ' + (blendInfo ? blendInfo.name : '—') +
            ' at ' + Math.round((comp.blendWeight || 0) * 100) + '% (' + comp.blendMode + ').';
        } else {
          blendLine.textContent = 'No secondary clip. Pick a blend motion below to mix or add another clip.';
        }
      };
      updateBlendNote();
      card.body.appendChild(blendLine);

      const blendWrap = el('div', 'anim-inline');
      const blendInput = document.createElement('input');
      blendInput.type = 'number';
      blendInput.className = 'num';
      blendInput.min = '1';
      blendInput.max = String(A.MAX_MOTIONS);
      blendInput.step = '1';
      blendInput.placeholder = 'motion #';
      if (comp.blendMotion >= 0) blendInput.value = String(comp.blendMotion + 1);
      blendWrap.appendChild(blendInput);
      blendWrap.appendChild(button('Set', 'Blend this motion', function () {
        const resolved = lib.resolve(parseInt(blendInput.value, 10) - 1);
        if (resolved === null) { toast('Unknown blend motion'); return; }
        commit('Blend motion');
        comp.setBlend(resolved, comp.blendWeight > 0 ? comp.blendWeight : 0.5, comp.blendMode);
        renderInspector();
        scheduleAutosave();
      }));
      blendWrap.appendChild(button('Random', 'Blend a random motion', function () {
        commit('Blend motion');
        comp.setBlend(Math.floor(Math.random() * A.MAX_MOTIONS), comp.blendWeight > 0 ? comp.blendWeight : 0.5, comp.blendMode);
        renderInspector();
        scheduleAutosave();
      }));
      blendWrap.appendChild(button('Clear', 'Remove the secondary clip', function () {
        commit('Clear blend');
        comp.setBlend(null);
        comp.blendWeight = 0;
        renderInspector();
        scheduleAutosave();
      }));
      card.body.appendChild(fieldRow('Blend #', blendWrap));
      card.body.appendChild(sliderRow('Blend weight', comp.blendWeight || 0, 0, 1, 0.01, function (v) {
        comp.blendWeight = v;
        scheduleAutosave();
      }, function (v) { return Math.round(v * 100) + '%'; }));
      card.body.appendChild(selectRow('Blend mode', comp.blendMode, [
        { value: 'mix', label: 'Mix (cross-blend)' },
        { value: 'additive', label: 'Additive (layer)' }
      ], function (v) {
        commit('Blend mode');
        comp.blendMode = v;
        renderInspector();
        scheduleAutosave();
      }));

      card.body.appendChild(sliderRow('Speed', comp.speed, 0.05, 3, 0.05, function (v) {
        comp.speed = v;
        scheduleAutosave();
      }, function (v) { return v.toFixed(2) + '×'; }));
      card.body.appendChild(sliderRow('Crossfade', comp.fade, 0, 1, 0.01, function (v) {
        comp.fade = v;
        scheduleAutosave();
      }, function (v) { return v.toFixed(2) + ' s'; }));
      card.body.appendChild(checkboxRow('Loop', comp.loop, function (v) {
        commit('Animation loop');
        comp.loop = v;
        scheduleAutosave();
      }));
      card.body.appendChild(checkboxRow('Preview in edit mode', comp.preview !== false, function (v) {
        commit('Animation preview');
        comp.preview = v;
        scheduleAutosave();
      }));
      card.body.appendChild(el('p', 'fineprint',
        'The library is generated lazily, so all 99,999 motions exist without storing 99,999 clips. ' +
        'Use PlayMaker actions to play, crossfade or blend motions at runtime.'));
      return card.card;
    }
    if (type === 'Light') {
      const card = componentCard('Light', remove, 'light');
      card.body.appendChild(selectRow('Type', comp.type, UE.LIGHT_TYPES, function (v) {
        commit('Light type');
        comp.type = v;
        if (v === 'sun' || v === 'directional') comp.range = comp.range || 10;
        renderInspector();
        renderHierarchy();
        scheduleAutosave();
      }));
      card.body.appendChild(colorRow('Color', comp.color, function (v) { comp.color = v; }));
      card.body.appendChild(sliderRow('Intensity', comp.intensity, 0, 8, 0.05, function (v) { comp.intensity = v; }, function (v) { return v.toFixed(2); }));
      if (comp.type === 'point' || comp.type === 'spot') {
        card.body.appendChild(sliderRow('Range', comp.range || 10, 0.2, 40, 0.1, function (v) { comp.range = v; }, function (v) { return v.toFixed(1) + ' m'; }));
        card.body.appendChild(selectRow('Cookie', comp.cookie || 'none', UE.LIGHT_COOKIES, function (v) {
          commit('Light cookie');
          comp.cookie = v;
          if (v !== 'texture') comp.cookieTexture = '';
          renderInspector();
          scheduleAutosave();
        }));
        if (comp.cookie && comp.cookie !== 'none') {
          const preview = el('div', 'cookie-preview-row');
          const canvas = document.createElement('canvas');
          canvas.width = 64; canvas.height = 64;
          canvas.className = 'cookie-preview';
          drawCookiePreview(canvas, comp.cookie, comp.cookieTexture);
          preview.appendChild(canvas);
          const note = el('p', 'fineprint', comp.cookie === 'texture'
            ? 'Projected image cookie. A radial pattern is stretched around the light.'
            : 'Procedural cookie baked into the light atlas.');
          preview.appendChild(note);
          card.body.appendChild(preview);
        }
        if (comp.cookie === 'texture') {
          const upload = el('button', 'btn tiny ghost', 'Upload texture image…');
          upload.addEventListener('click', function () {
            app.cookieTarget = comp;
            els.importCookie.click();
          });
          card.body.appendChild(upload);
        }
      }
      if (comp.type === 'spot') {
        card.body.appendChild(sliderRow('Outer angle', comp.spotAngle, 5, 120, 1, function (v) { comp.spotAngle = v; }, function (v) { return Math.round(v) + '°'; }));
        card.body.appendChild(sliderRow('Inner angle', Math.min(comp.innerAngle, comp.spotAngle), 1, 120, 1, function (v) { comp.innerAngle = v; }, function (v) { return Math.round(v) + '°'; }));
      }
      card.body.appendChild(checkboxRow('Cast shadow (reserved)', comp.castShadow !== false, function (v) {
        commit('Light shadow');
        comp.castShadow = v;
      }));
      const hint = comp.type === 'sun'
        ? 'A Sun light overrides the global Sun & Lighting direction and color. Only the first active Sun is used.'
        : comp.type === 'spot'
          ? 'A spot points along the object\'s −Z axis. Use Rotate (E) to aim it. Cookies are projected through the cone.'
          : comp.type === 'point'
            ? 'Point lights fade over Range and can project a cookie in every direction.'
            : 'Directional lights point along −Z and have no range falloff.';
      card.body.appendChild(el('p', 'fineprint', hint));
      return card.card;
    }
    if (type === 'Collider') {
      const card = componentCard('Collider', remove, 'collider');
      card.body.appendChild(selectRow('Shape', comp.shape, [
        { value: 'box', label: 'Box' }, { value: 'sphere', label: 'Sphere' }
      ], function (v) {
        commit('Collider shape');
        comp.shape = v;
        renderInspector();
        scheduleAutosave();
      }));
      card.body.appendChild(fieldRow('Size', vectorEditor(comp.size, { step: 0.05, min: 0.01, label: 'Collider size' })));
      if (comp.shape === 'sphere') card.body.appendChild(el('p', 'fineprint', 'Sphere uses the X size as its diameter.'));
      card.body.appendChild(fieldRow('Center', vectorEditor(comp.center, { step: 0.05, label: 'Collider center' })));
      return card.card;
    }
    if (type === 'Rigidbody') {
      const card = componentCard('Rigidbody', remove, 'rigidbody');
      card.body.appendChild(checkboxRow('Use gravity', comp.useGravity, function (v) { commit('Use gravity'); comp.useGravity = v; }));
      card.body.appendChild(fieldRow('Mass', numInput(comp.mass, {
        step: 0.1, min: 0.01, label: 'Mass',
        get: function () { return comp.mass; },
        onChange: function (v) { comp.mass = Math.max(0.01, v); }
      })));
      card.body.appendChild(fieldRow('Drag', numInput(comp.drag, {
        step: 0.05, min: 0, label: 'Drag',
        get: function () { return comp.drag; },
        onChange: function (v) { comp.drag = Math.max(0, v); }
      })));
      card.body.appendChild(sliderRow('Bounciness', comp.restitution, 0, 1, 0.01, function (v) { comp.restitution = v; }, function (v) { return v.toFixed(2); }));
      card.body.appendChild(checkboxRow('Is kinematic', comp.isKinematic, function (v) { commit('Kinematic'); comp.isKinematic = v; }));
      card.body.appendChild(el('p', 'fineprint', 'Fixed-step AABB physics. Colliders use world-axis boxes, so rotated boxes are approximated.'));
      return card.card;
    }
    if (type === 'Camera') {
      const card = componentCard('Camera', remove, 'camera');
      card.body.appendChild(fieldRow('Field of view', numInput(comp.fov, {
        step: 1, min: 10, max: 120, label: 'FOV',
        get: function () { return comp.fov; },
        onChange: function (v) { comp.fov = UE.clamp(v, 10, 120); }
      })));
      card.body.appendChild(fieldRow('Near / Far', (function () {
        const wrap = el('div', 'vec two');
        wrap.appendChild(numInput(comp.near, { step: 0.01, min: 0.01, label: 'Near', get: function () { return comp.near; }, onChange: function (v) { comp.near = Math.max(0.01, v); } }));
        wrap.appendChild(numInput(comp.far, { step: 1, min: 1, label: 'Far', get: function () { return comp.far; }, onChange: function (v) { comp.far = Math.max(1, v); } }));
        return wrap;
      })()));
      card.body.appendChild(checkboxRow('Main camera (Game view)', comp.main, function (v) {
        commit('Main camera');
        if (v) {
          for (const other of app.scene.objects) {
            const c = other.getComponent('Camera');
            if (c && c !== comp) c.main = false;
          }
        }
        comp.main = v;
        renderInspector();
        scheduleAutosave();
      }));
      return card.card;
    }
    if (type === 'Script') {
      const card = componentCard('Script', remove, 'script');
      card.body.appendChild(fieldRow('Name', (function () {
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'text';
        input.value = comp.name;
        input.addEventListener('focus', function () { beginEdit('Script name'); });
        input.addEventListener('input', function () { comp.name = input.value; });
        input.addEventListener('blur', function () { endEdit(); renderHierarchy(); });
        return input;
      })()));
      const sampleRow = el('div', 'sample-row');
      sampleRow.appendChild(el('span', 'muted tiny', 'Load example'));
      const sampleSelect = document.createElement('select');
      sampleSelect.className = 'select';
      const placeholder = document.createElement('option');
      placeholder.value = '';
      placeholder.textContent = 'Choose…';
      sampleSelect.appendChild(placeholder);
      for (const key of Object.keys(UE.Samples.scripts)) {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = key;
        sampleSelect.appendChild(option);
      }
      sampleSelect.addEventListener('change', function () {
        const key = sampleSelect.value;
        if (!key) return;
        commit('Script example');
        comp.name = key;
        comp.code = UE.Samples.scripts[key];
        renderInspector();
        renderHierarchy();
        scheduleAutosave();
      });
      sampleRow.appendChild(sampleSelect);
      card.body.appendChild(sampleRow);
      const area = document.createElement('textarea');
      area.className = 'code';
      area.rows = 9;
      area.spellcheck = false;
      area.value = comp.code;
      area.addEventListener('focus', function () { beginEdit('Edit script'); });
      area.addEventListener('input', function () { comp.code = area.value; });
      area.addEventListener('blur', endEdit);
      card.body.appendChild(area);
      card.body.appendChild(el('p', 'fineprint', 'Runs each fixed step during Play. Variables: self, dt, time, scene, UE.'));
      return card.card;
    }
    if (type === 'PlayMakerFSM') return renderFsmCard(obj, comp, remove);
    if (type === 'PlayMakerTrigger') return renderTriggerCard(obj, comp, remove);
    if (type === 'PlayMakerTimer') return renderTimerCard(obj, comp, remove);
    if (type === 'PlayMakerInput') return renderInputCard(obj, comp, remove);
    if (type === 'PlayMakerEventProxy') return renderProxyCard(obj, comp, remove);
    return null;
  }

  /* ------------------------------------------------------------- PlayMaker UI */
  function pmText(value, label, onChange) {
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'text';
    input.value = value === undefined || value === null ? '' : String(value);
    input.spellcheck = false;
    input.addEventListener('focus', function () { beginEdit(label); });
    input.addEventListener('input', function () { onChange(input.value); });
    input.addEventListener('blur', function () { endEdit(); });
    return input;
  }
  function pmCommit(label, fn) {
    commit(label);
    fn();
    scheduleAutosave();
  }
  function pmStateNames(comp) { return comp.states.map(function (s) { return s.name; }); }
  function pmUniqueState(comp, base, current) {
    let name = base || 'State';
    let i = 2;
    while (comp.states.some(function (s) { return s !== current && s.name === name; })) name = base + ' ' + i++;
    return name;
  }
  function pmRenameState(comp, state, name) {
    const old = state.name;
    const next = pmUniqueState(comp, String(name || '').trim() || 'State', state);
    state.name = next;
    if (comp.start === old) comp.start = next;
    for (const s of comp.states) {
      for (const t of s.transitions || []) {
        if (t.to === old) t.to = next;
      }
    }
  }
  function pmObjectRow(label, value, onChange) {
    return fieldRow(label, pmText(value || 'self', label, function (v) { onChange(v); }));
  }
  function pmActionDef(type) {
    return (UE.PlayMaker.catalog || []).find(function (a) { return a.type === type; }) || { label: type, params: [] };
  }
  function pmParamRow(action, param) {
    const value = action[param.key] === undefined ? param.default : action[param.key];
    const label = param.label || param.key;
    if (param.type === 'number') {
      return fieldRow(label, numInput(Number(value) || 0, {
        step: param.step || 0.1,
        min: param.min,
        max: param.max,
        label: label,
        get: function () { return Number(action[param.key]) || 0; },
        onChange: function (v) { action[param.key] = v; }
      }));
    }
    if (param.type === 'bool') {
      return checkboxRow(label, value !== false, function (v) {
        pmCommit('Action value', function () { action[param.key] = v; });
      });
    }
    if (param.type === 'select') {
      return selectRow(label, value, param.options || [], function (v) {
        pmCommit('Action value', function () { action[param.key] = v; });
      });
    }
    if (param.type === 'color') {
      return colorRow(label, value, function (v) { action[param.key] = v; });
    }
    if (param.type === 'primitive') {
      return selectRow(label, value, UE.PRIMITIVES.map(function (p) { return { value: p, label: UE.primitiveLabel(p) }; }), function (v) {
        pmCommit('Action value', function () { action[param.key] = v; });
      });
    }
    return fieldRow(label, pmText(value, label, function (v) { action[param.key] = v; }));
  }
  function pmActionBlock(state, action, index) {
    const def = pmActionDef(action.type);
    const block = el('div', 'fsm-action' + (action.enabled === false ? ' is-off' : ''));
    const head = el('div', 'fsm-action-head');
    head.appendChild(el('span', 'fsm-action-title', def.label || action.type));
    const tools = el('span', 'fsm-tools');
    const enabled = el('button', 'iconbtn fsm-mini', action.enabled === false ? '○' : '●');
    enabled.title = action.enabled === false ? 'Enable action' : 'Disable action';
    enabled.addEventListener('click', function () {
      pmCommit('Toggle action', function () { action.enabled = action.enabled === false; });
      renderInspector();
    });
    tools.appendChild(enabled);
    const up = el('button', 'iconbtn fsm-mini', '↑');
    up.title = 'Move up';
    up.disabled = index === 0;
    up.addEventListener('click', function () {
      pmCommit('Reorder action', function () {
        state.actions.splice(index, 1);
        state.actions.splice(index - 1, 0, action);
      });
      renderInspector();
    });
    tools.appendChild(up);
    const down = el('button', 'iconbtn fsm-mini', '↓');
    down.title = 'Move down';
    down.disabled = index >= state.actions.length - 1;
    down.addEventListener('click', function () {
      pmCommit('Reorder action', function () {
        state.actions.splice(index, 1);
        state.actions.splice(index + 1, 0, action);
      });
      renderInspector();
    });
    tools.appendChild(down);
    const del = el('button', 'iconbtn fsm-mini', '×');
    del.title = 'Remove action';
    del.addEventListener('click', function () {
      pmCommit('Remove action', function () { state.actions.splice(index, 1); });
      renderInspector();
    });
    tools.appendChild(del);
    head.appendChild(tools);
    block.appendChild(head);
    const params = el('div', 'fsm-params');
    for (const param of def.params || []) params.appendChild(pmParamRow(action, param));
    block.appendChild(params);
    return block;
  }
  function renderFsmCard(obj, comp, remove) {
    const card = componentCard('PlayMaker FSM', remove, 'fsm');
    card.body.appendChild(fieldRow('Name', pmText(comp.name, 'FSM name', function (v) { comp.name = v; })));
    card.body.appendChild(selectRow('Start state', comp.start, pmStateNames(comp).map(function (n) { return { value: n, label: n }; }), function (v) {
      pmCommit('FSM start', function () { comp.start = v; });
      renderInspector();
    }));

    /* variables */
    const varsHead = el('div', 'fsm-subhead');
    varsHead.appendChild(el('span', 'fsm-subtitle', 'Variables'));
    const addVar = el('button', 'btn tiny ghost', '+ Variable');
    addVar.addEventListener('click', function () {
      pmCommit('Add variable', function () {
        let name = 'variable', i = 2;
        while (comp.variables[name] !== undefined) name = 'variable' + i++;
        comp.variables[name] = '';
      });
      renderInspector();
    });
    varsHead.appendChild(addVar);
    card.body.appendChild(varsHead);
    const varWrap = el('div', 'fsm-vars');
    const varNames = Object.keys(comp.variables);
    if (!varNames.length) varWrap.appendChild(el('p', 'fineprint', 'No variables. Actions can read and write them by name.'));
    for (const name of varNames) {
      const row = el('div', 'fsm-var');
      row.appendChild(pmText(name, 'Variable name', (function (oldName) {
        return function (v) {
          if (v === oldName || !v.trim()) return;
          if (comp.variables[v] !== undefined) return;
          const value = comp.variables[oldName];
          delete comp.variables[oldName];
          comp.variables[v] = value;
          oldName = v;
        };
      })(name)));
      row.appendChild(pmText(comp.variables[name], 'Variable value', (function (key) {
        return function (v) { comp.variables[key] = v; };
      })(name)));
      const del = el('button', 'iconbtn fsm-mini', '×');
      del.title = 'Remove variable';
      del.addEventListener('click', function () {
        pmCommit('Remove variable', function () { delete comp.variables[name]; });
        renderInspector();
      });
      row.appendChild(del);
      varWrap.appendChild(row);
    }
    card.body.appendChild(varWrap);

    /* states */
    const statesHead = el('div', 'fsm-subhead');
    statesHead.appendChild(el('span', 'fsm-subtitle', 'States'));
    const addState = el('button', 'btn tiny ghost', '+ State');
    addState.addEventListener('click', function () {
      pmCommit('Add state', function () {
        comp.states.push({ name: pmUniqueState(comp, 'State', null), actions: [], transitions: [] });
      });
      renderInspector();
    });
    statesHead.appendChild(addState);
    card.body.appendChild(statesHead);

    comp.states.forEach(function (state, stateIndex) {
      const block = el('div', 'fsm-state' + (state.name === comp.start ? ' is-start' : ''));
      const head = el('div', 'fsm-state-head');
      if (state.name === comp.start) head.appendChild(el('span', 'fsm-startdot', '●'));
      const nameInput = pmText(state.name, 'State name', function () {});
      nameInput.className = 'text fsm-state-name';
      nameInput.addEventListener('change', function () {
        commit('Rename state');
        pmRenameState(comp, state, nameInput.value);
        renderInspector();
        scheduleAutosave();
      });
      head.appendChild(nameInput);
      const setStart = el('button', 'btn tiny ghost', 'Start');
      setStart.disabled = state.name === comp.start;
      setStart.title = 'Make this the start state';
      setStart.addEventListener('click', function () {
        pmCommit('FSM start', function () { comp.start = state.name; });
        renderInspector();
      });
      head.appendChild(setStart);
      const del = el('button', 'iconbtn fsm-mini', '×');
      del.title = 'Remove state';
      del.disabled = comp.states.length <= 1;
      del.addEventListener('click', function () {
        pmCommit('Remove state', function () {
          comp.states.splice(stateIndex, 1);
          if (comp.start === state.name) comp.start = comp.states[0].name;
          for (const s of comp.states) {
            s.transitions = (s.transitions || []).filter(function (t) { return t.to !== state.name; });
          }
        });
        renderInspector();
      });
      head.appendChild(del);
      block.appendChild(head);

      /* actions */
      const actionWrap = el('div', 'fsm-actions');
      if (!state.actions.length) actionWrap.appendChild(el('p', 'fineprint', 'No actions. Add one below.'));
      state.actions.forEach(function (action, actionIndex) {
        actionWrap.appendChild(pmActionBlock(state, action, actionIndex));
      });
      block.appendChild(actionWrap);

      const addRow = el('div', 'fsm-add');
      const select = document.createElement('select');
      select.className = 'select pm-select';
      const placeholder = document.createElement('option');
      placeholder.value = '';
      placeholder.textContent = 'Add action…';
      select.appendChild(placeholder);
      for (const category of UE.PlayMaker.categories) {
        const defs = UE.PlayMaker.catalog.filter(function (a) { return a.category === category; });
        if (!defs.length) continue;
        const og = document.createElement('optgroup');
        og.label = category;
        for (const def of defs) {
          const option = document.createElement('option');
          option.value = def.type;
          option.textContent = def.label;
          og.appendChild(option);
        }
        select.appendChild(og);
      }
      addRow.appendChild(select);
      const add = el('button', 'btn tiny', 'Add');
      add.addEventListener('click', function () {
        if (!select.value) return;
        pmCommit('Add action', function () { state.actions.push(UE.PlayMaker.action(select.value)); });
        renderInspector();
      });
      addRow.appendChild(add);
      block.appendChild(addRow);

      /* transitions */
      const transHead = el('div', 'fsm-subhead narrow');
      transHead.appendChild(el('span', 'fsm-subtitle', 'Transitions'));
      const addTrans = el('button', 'btn tiny ghost', '+ Transition');
      addTrans.addEventListener('click', function () {
        pmCommit('Add transition', function () {
          const other = comp.states.find(function (s) { return s.name !== state.name; }) || state;
          state.transitions.push({ event: 'FINISHED', to: other.name });
        });
        renderInspector();
      });
      transHead.appendChild(addTrans);
      block.appendChild(transHead);
      const transWrap = el('div', 'fsm-transitions');
      for (const transition of state.transitions) {
        const row = el('div', 'fsm-transition');
        row.appendChild(el('span', 'fsm-event-arrow', 'on'));
        row.appendChild(pmText(transition.event, 'Event name', function (v) { transition.event = v; }));
        row.appendChild(el('span', 'fsm-event-arrow', '→'));
        const to = document.createElement('select');
        to.className = 'select';
        for (const other of comp.states) {
          const option = document.createElement('option');
          option.value = other.name;
          option.textContent = other.name;
          if (other.name === transition.to) option.selected = true;
          to.appendChild(option);
        }
        to.addEventListener('change', function () {
          pmCommit('Transition target', function () { transition.to = to.value; });
        });
        row.appendChild(to);
        const del = el('button', 'iconbtn fsm-mini', '×');
        del.title = 'Remove transition';
        del.addEventListener('click', function () {
          pmCommit('Remove transition', function () {
            const i = state.transitions.indexOf(transition);
            if (i >= 0) state.transitions.splice(i, 1);
          });
          renderInspector();
        });
        row.appendChild(del);
        transWrap.appendChild(row);
      }
      block.appendChild(transWrap);
      card.body.appendChild(block);
    });
    card.body.appendChild(el('p', 'fineprint', 'Actions run in order. When a state finishes its actions it receives FINISHED. Events come from transitions, triggers, timers, input and event proxies.'));
    return card.card;
  }
  function renderTriggerCard(obj, comp, remove) {
    const card = componentCard('PlayMaker Trigger', remove, 'fsm');
    card.body.appendChild(fieldRow('On enter', pmText(comp.enterEvent, 'Enter event', function (v) { comp.enterEvent = v; })));
    card.body.appendChild(fieldRow('On exit', pmText(comp.exitEvent, 'Exit event', function (v) { comp.exitEvent = v; })));
    card.body.appendChild(pmObjectRow('Target', comp.target, function (v) { comp.target = v; }));
    card.body.appendChild(el('p', 'fineprint', 'Sends an event when a collider pair enters or leaves contact. Target "self" or an object name / id.'));
    return card.card;
  }
  function renderTimerCard(obj, comp, remove) {
    const card = componentCard('PlayMaker Timer', remove, 'fsm');
    card.body.appendChild(fieldRow('Event', pmText(comp.eventName, 'Timer event', function (v) { comp.eventName = v; })));
    card.body.appendChild(fieldRow('Seconds', numInput(comp.seconds, {
      step: 0.1, min: 0.05, label: 'Timer seconds',
      get: function () { return comp.seconds; },
      onChange: function (v) { comp.seconds = Math.max(0.05, v); }
    })));
    card.body.appendChild(checkboxRow('Repeat', comp.repeat, function (v) { pmCommit('Timer repeat', function () { comp.repeat = v; }); }));
    card.body.appendChild(pmObjectRow('Target', comp.target, function (v) { comp.target = v; }));
    card.body.appendChild(el('p', 'fineprint', 'Fires the event every N seconds while playing.'));
    return card.card;
  }
  function renderInputCard(obj, comp, remove) {
    const card = componentCard('PlayMaker Input', remove, 'fsm');
    card.body.appendChild(fieldRow('Event', pmText(comp.eventName, 'Input event', function (v) { comp.eventName = v; })));
    card.body.appendChild(fieldRow('Key', pmText(comp.key, 'Input key', function (v) { comp.key = v.slice(0, 12); })));
    card.body.appendChild(selectRow('Trigger on', comp.mode, [{ value: 'down', label: 'Key down' }, { value: 'up', label: 'Key up' }], function (v) {
      pmCommit('Input mode', function () { comp.mode = v; });
    }));
    card.body.appendChild(pmObjectRow('Target', comp.target, function (v) { comp.target = v; }));
    card.body.appendChild(el('p', 'fineprint', 'Listens for a keyboard key during Play. Click the viewport first so the page has focus.'));
    return card.card;
  }
  function renderProxyCard(obj, comp, remove) {
    const card = componentCard('PlayMaker Event Proxy', remove, 'fsm');
    card.body.appendChild(fieldRow('Event', pmText(comp.eventName, 'Proxy event', function (v) { comp.eventName = v; })));
    card.body.appendChild(selectRow('When', comp.trigger, [
      { value: 'start', label: 'On start' }, { value: 'timer', label: 'After seconds' }, { value: 'key', label: 'On key' }
    ], function (v) {
      pmCommit('Proxy trigger', function () { comp.trigger = v; });
      renderInspector();
    }));
    if (comp.trigger === 'timer') {
      card.body.appendChild(fieldRow('Seconds', numInput(comp.seconds, {
        step: 0.1, min: 0.05, label: 'Proxy seconds',
        get: function () { return comp.seconds; },
        onChange: function (v) { comp.seconds = Math.max(0.05, v); }
      })));
    }
    if (comp.trigger === 'key') {
      card.body.appendChild(fieldRow('Key', pmText(comp.key, 'Proxy key', function (v) { comp.key = v.slice(0, 12); })));
    }
    card.body.appendChild(pmObjectRow('Target', comp.target, function (v) { comp.target = v; }));
    card.body.appendChild(el('p', 'fineprint', 'Lightweight event sender for an FSM on this object or another one.'));
    return card.card;
  }
  function renderSceneInspector() {
    const sceneCard = componentCard('Scene', null, 'scene');
    sceneCard.body.appendChild(fieldRow('Name', (function () {
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'text';
      input.value = app.scene.name;
      input.addEventListener('focus', function () { beginEdit('Scene name'); });
      input.addEventListener('input', function () {
        app.scene.name = input.value || 'Untitled';
        els.sceneTitle.textContent = app.scene.name;
        document.title = app.scene.name + ' — UnirealEngine';
      });
      input.addEventListener('blur', endEdit);
      return input;
    })()));
    els.inspector.appendChild(sceneCard.card);

    const sun = componentCard('Sun & Lighting', null, 'sun');
    sun.body.appendChild(colorRow('Color', app.scene.sun.color, function (v) {
      app.scene.sun.color = v;
    }));
    sun.body.appendChild(sliderRow('Azimuth', app.scene.sun.azimuth, 0, 360, 1, function (v) { app.scene.sun.azimuth = v; }, function (v) { return Math.round(v) + '°'; }));
    sun.body.appendChild(sliderRow('Elevation', app.scene.sun.elevation, 2, 89, 1, function (v) { app.scene.sun.elevation = v; }, function (v) { return Math.round(v) + '°'; }));
    sun.body.appendChild(sliderRow('Intensity', app.scene.sun.intensity, 0, 2, 0.01, function (v) { app.scene.sun.intensity = v; }, function (v) { return v.toFixed(2); }));
    sun.body.appendChild(sliderRow('Ambient', app.scene.sun.ambient, 0, 1, 0.01, function (v) { app.scene.sun.ambient = v; }, function (v) { return v.toFixed(2); }));
    els.inspector.appendChild(sun.card);

    const sky = componentCard('Sky', null, 'sky');
    sky.body.appendChild(colorRow('Top', app.scene.sky.top, function (v) { app.scene.sky.top = v; applySky(); }));
    sky.body.appendChild(colorRow('Bottom', app.scene.sky.bottom, function (v) { app.scene.sky.bottom = v; applySky(); }));
    els.inspector.appendChild(sky.card);

    const stats = componentCard('Runtime', null, 'stats');
    const grid = el('div', 'stat-list');
    const rows = [
      ['Objects', app.scene.objects.length],
      ['Triangles', renderer.ok ? renderer.stats.triangles.toLocaleString() : '—'],
      ['Draw calls', renderer.ok ? renderer.stats.draws : '—'],
      ['FPS', Math.round(app.fps)]
    ];
    for (const [key, value] of rows) {
      const row = el('div', 'stat');
      row.appendChild(el('span', '', key));
      row.appendChild(el('strong', '', String(value)));
      grid.appendChild(row);
    }
    stats.body.appendChild(grid);
    stats.body.appendChild(el('p', 'fineprint', 'Everything is generated at runtime. Scene state is JSON in memory; localStorage holds a copy. No SQL, no server.'));
    els.inspector.appendChild(stats.card);

    const help = componentCard('Quick controls', null, 'help');
    const list = el('ul', 'mini-keys');
    for (const text of ['RMB orbit · MMB pan · wheel zoom', 'W move · E rotate · R scale', 'F frame · Del delete · Ctrl+D duplicate', 'Ctrl+P play · Esc stop']) {
      list.appendChild(el('li', '', text));
    }
    help.body.appendChild(list);
    els.inspector.appendChild(help.card);
  }

  /* --------------------------------------------------------------- scene list */
  function renderSceneList() {
    els.sceneList.innerHTML = '';
    for (const entry of UE.Samples.list) {
      const card = el('button', 'scene-card');
      card.appendChild(el('span', 'scene-thumb ' + entry.id));
      const meta = el('span', 'scene-meta');
      meta.appendChild(el('strong', '', entry.name));
      meta.appendChild(el('small', '', entry.desc));
      card.appendChild(meta);
      card.addEventListener('click', function () { openSample(entry.id); });
      els.sceneList.appendChild(card);
    }
  }

  /* --------------------------------------------------------------- play mode */
  function updateTransport() {
    const playing = app.playing;
    els.btnPlay.disabled = playing;
    els.btnPause.disabled = !playing || app.paused;
    els.btnStep.disabled = !playing;
    els.btnStop.disabled = !playing;
    els.modePill.textContent = playing ? (app.paused ? 'Paused' : 'Playing') : 'Edit';
    els.modePill.className = 'mode-pill ' + (playing ? (app.paused ? 'paused' : 'playing') : 'edit');
    els.stageBadge.textContent = app.viewMode === 'game' ? 'Game' : 'Scene';
  }
  function play() {
    if (app.playing) return;
    app.playJson = currentJson();
    app.playing = true;
    app.paused = false;
    app.time = 0;
    app.acc = 0;
    if (UE.PlayMaker && UE.PlayMaker.reset) UE.PlayMaker.reset(app.scene);
    updateTransport();
    log('info', 'Play mode started — scripts, PlayMaker FSMs and physics are running');
  }
  function togglePause() {
    if (!app.playing) return;
    app.paused = !app.paused;
    updateTransport();
    log('info', app.paused ? 'Paused' : 'Resumed');
  }
  function stop() {
    if (!app.playing) return;
    const snapshot = app.playJson;
    app.playing = false;
    app.paused = false;
    app.playJson = null;
    if (snapshot) restore(snapshot);
    else { renderAll(); updateTransport(); }
    if (UE.PlayMaker && UE.PlayMaker.reset) UE.PlayMaker.reset(app.scene);
    log('info', 'Stopped — scene restored');
    toast('Play mode stopped');
  }
  function stepFrame() {
    if (!app.playing) {
      app.playJson = currentJson();
      app.playing = true;
      app.paused = true;
      app.time = 0;
      if (UE.PlayMaker && UE.PlayMaker.reset) UE.PlayMaker.reset(app.scene);
    }
    app.paused = true;
    tick(FIXED_DT);
    updateTransport();
  }
  function tick(dt) {
    app.time += dt;
    UE.ScriptSystem.update(app.scene, dt, app.time);
    if (UE.PlayMaker && UE.PlayMaker.update) UE.PlayMaker.update(app.scene, dt, app.time);
    if (UE.Animation && UE.Animation.updateAll) UE.Animation.updateAll(app.scene, dt);
    UE.Physics.step(app.scene, dt);
  }

  /* ------------------------------------------------------------------- saving */
  function scheduleAutosave() {
    if (app.playing) return;
    if (app.autosaveTimer) clearTimeout(app.autosaveTimer);
    app.autosaveTimer = setTimeout(function () {
      app.autosaveTimer = null;
      try {
        localStorage.setItem(STORAGE_SCENE, fullJson());
        savePrefs();
      } catch (err) { /* private mode / file:// with storage disabled — memory still works */ }
    }, 1200);
  }
  function savePrefs() {
    try {
      localStorage.setItem(STORAGE_PREFS, JSON.stringify({
        camera: app.camera, tool: app.tool, viewMode: app.viewMode, options: app.options
      }));
    } catch (err) { /* ignore */ }
  }
  function loadPrefs() {
    try {
      const raw = localStorage.getItem(STORAGE_PREFS);
      if (!raw) return;
      const prefs = JSON.parse(raw);
      if (prefs.camera) app.camera = Object.assign(app.camera, prefs.camera);
      if (prefs.tool) setTool(prefs.tool, true);
      if (prefs.viewMode === 'scene' || prefs.viewMode === 'game') app.viewMode = prefs.viewMode;
      if (prefs.options) app.options = Object.assign(app.options, prefs.options);
    } catch (err) { /* ignore */ }
  }
  function saveSceneLocal() {
    try {
      localStorage.setItem(STORAGE_SCENE, fullJson());
      savePrefs();
      toast('Scene saved to this browser');
      log('info', 'Saved "' + app.scene.name + '" to localStorage');
    } catch (err) {
      log('warn', 'localStorage is unavailable; exporting a file instead');
      exportScene();
    }
  }
  function exportScene() {
    const json = JSON.stringify(app.scene.toJSON(), null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (app.scene.name || 'scene').replace(/[^a-z0-9_-]+/gi, '_') + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    log('info', 'Exported ' + a.download);
    toast('Scene exported');
  }
  function importSceneFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function () {
      try {
        const data = JSON.parse(String(reader.result));
        const scene = UE.Scene.fromJSON(data);
        commit('Import scene');
        app.scene = scene;
        app.selected = null;
        app.playing = false;
        app.paused = false;
        app.playJson = null;
        renderAll();
        updateTransport();
        scheduleAutosave();
        log('info', 'Imported "' + scene.name + '" — ' + scene.objects.length + ' objects');
        toast('Scene imported');
      } catch (err) {
        log('error', 'Import failed: ' + err.message);
        toast('Import failed');
      }
    };
    reader.readAsText(file);
  }

  /* --------------------------------------------------------------------- init */
  const renderer = new UE.Renderer(document.getElementById('view'));

  function setTool(tool, silent) {
    if (!['move', 'rotate', 'scale'].includes(tool)) return;
    app.tool = tool;
    document.querySelectorAll('[data-tool]').forEach(function (btn) {
      btn.classList.toggle('is-active', btn.dataset.tool === tool);
    });
    if (!silent) scheduleAutosave();
  }
  function setViewMode(mode) {
    app.viewMode = mode === 'game' ? 'game' : 'scene';
    document.querySelectorAll('[data-view]').forEach(function (btn) {
      const active = btn.dataset.view === app.viewMode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    if (app.viewMode === 'game' && app.scene && !app.scene.mainCamera() && !app.gameCameraWarned) {
      app.gameCameraWarned = true;
      log('warn', 'Game view has no active Main Camera; showing the scene camera instead.');
    }
    updateTransport();
    scheduleAutosave();
  }
  function openHelp() {
    els.helpModal.hidden = false;
    document.body.classList.add('modal-open');
  }
  function closeHelp() {
    els.helpModal.hidden = true;
    document.body.classList.remove('modal-open');
  }
  function openManual() {
    closeHelp();
    window.open('manual.html', '_blank', 'noopener');
  }

  function bindUi() {
    /* menus */
    document.querySelectorAll('.menu').forEach(function (menu) {
      const btn = menu.querySelector('.menu-btn');
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        const wasOpen = menu.classList.contains('open');
        closeMenus();
        if (!wasOpen) menu.classList.add('open');
      });
    });
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.menu')) closeMenus();
      const cmdBtn = e.target.closest('[data-cmd]');
      if (cmdBtn) {
        closeMenus();
        runCommand(cmdBtn.dataset.cmd);
      }
    });

    /* transport */
    els.btnPlay.addEventListener('click', play);
    els.btnPause.addEventListener('click', togglePause);
    els.btnStep.addEventListener('click', stepFrame);
    els.btnStop.addEventListener('click', stop);

    /* view bar */
    document.querySelectorAll('[data-view]').forEach(function (btn) {
      btn.addEventListener('click', function () { setViewMode(btn.dataset.view); });
    });
    document.querySelectorAll('[data-tool]').forEach(function (btn) {
      btn.addEventListener('click', function () { setTool(btn.dataset.tool); });
    });
    els.chkSnap.addEventListener('change', function () { app.options.snap = els.chkSnap.checked; scheduleAutosave(); });
    els.chkGrid.addEventListener('change', function () { app.options.grid = els.chkGrid.checked; scheduleAutosave(); });
    els.chkWire.addEventListener('change', function () { app.options.wireframe = els.chkWire.checked; scheduleAutosave(); });
    els.btnFocus.addEventListener('click', function () { focusObject(selectedObject()); });
    els.btnResetCam.addEventListener('click', function () { resetCamera(); toast('View reset'); });

    /* project tiles */
    document.querySelectorAll('[data-primitive]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const kind = btn.dataset.primitive;
        if (kind === 'camera') addCameraObject();
        else if (kind === 'importModel') els.importModel.click();
        else addPrimitive(kind);
      });
    });
    document.querySelectorAll('[data-light]').forEach(function (btn) {
      btn.addEventListener('click', function () { addLight(btn.dataset.light); });
    });
    els.btnNewScene.addEventListener('click', newScene);
    els.btnAddObject.addEventListener('click', addEmpty);
    if (els.btnImportModel) els.btnImportModel.addEventListener('click', function () { els.importModel.click(); });

    /* hierarchy */
    els.hierSearch.addEventListener('input', renderHierarchy);
    els.tree.addEventListener('click', function (e) {
      const eye = e.target.closest('.eye');
      const row = e.target.closest('.tree-row');
      if (!row) return;
      if (eye) {
        toggleActive(app.scene.get(row.dataset.id));
        return;
      }
      if (e.target.closest('.twist')) {
        const id = row.dataset.id;
        if (app.collapsed.has(id)) app.collapsed.delete(id);
        else app.collapsed.add(id);
        renderHierarchy();
        return;
      }
      select(row.dataset.id);
    });
    els.tree.addEventListener('dblclick', function (e) {
      const row = e.target.closest('.tree-row');
      if (row) focusObject(app.scene.get(row.dataset.id));
    });
    els.tree.addEventListener('dragstart', function (e) {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      app.dragId = row.dataset.id;
      e.dataTransfer.setData('text/plain', row.dataset.id);
      e.dataTransfer.effectAllowed = 'move';
      row.classList.add('dragging');
    });
    els.tree.addEventListener('dragend', function () {
      app.dragId = null;
      els.tree.querySelectorAll('.dragging,.drop-target').forEach(function (n) { n.classList.remove('dragging', 'drop-target'); });
    });
    els.tree.addEventListener('dragover', function (e) {
      const row = e.target.closest('.tree-row');
      if (!row || !app.dragId || row.dataset.id === app.dragId) return;
      e.preventDefault();
      els.tree.querySelectorAll('.drop-target').forEach(function (n) { n.classList.remove('drop-target'); });
      row.classList.add('drop-target');
    });
    els.tree.addEventListener('dragleave', function (e) {
      const row = e.target.closest('.tree-row');
      if (row) row.classList.remove('drop-target');
    });
    els.tree.addEventListener('drop', function (e) {
      const row = e.target.closest('.tree-row');
      if (!row) return;
      e.preventDefault();
      const dragged = app.scene.get(app.dragId);
      const target = app.scene.get(row.dataset.id);
      if (!dragged || !target || dragged === target) return;
      let p = target.transform.parent;
      while (p) { if (p === dragged) { toast('Cannot parent an object to its own child'); return; } p = p.transform.parent; }
      if (target.transform.parent === dragged) return;
      mutate('Reparent ' + dragged.name, function () { dragged.setParent(target); });
      log('info', dragged.name + ' is now a child of ' + target.name);
    });

    /* console */
    els.btnClearConsole.addEventListener('click', function () { app.logs.length = 0; renderConsole(); });
    [els.chkInfo, els.chkWarn, els.chkError].forEach(function (input) { input.addEventListener('change', renderConsole); });

    /* modal */
    els.btnHelpClose.addEventListener('click', closeHelp);
    els.helpModal.addEventListener('click', function (e) { if (e.target === els.helpModal) closeHelp(); });

    /* file import */
    els.importScene.addEventListener('change', function () {
      importSceneFile(els.importScene.files[0]);
      els.importScene.value = '';
    });
    els.importModel.addEventListener('change', function () {
      importModelFiles(els.importModel.files);
      els.importModel.value = '';
    });
    els.importCookie.addEventListener('change', function () {
      importCookieFile(els.importCookie.files[0], app.cookieTarget);
      els.importCookie.value = '';
    });
    els.stage.addEventListener('dragover', function (e) { e.preventDefault(); });
    els.stage.addEventListener('drop', function (e) {
      e.preventDefault();
      const files = e.dataTransfer.files;
      if (!files || !files.length) return;
      if (Array.from(files).some(function (f) { return /\.(obj|stl|glb|gltf|bin|mtl|png|jpe?g|webp|gif|bmp)$/i.test(f.name); })) importModelFiles(files);
      else importSceneFile(files[0]);
    });

    /* viewport input */
    els.view.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    els.view.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    els.view.addEventListener('wheel', onWheel, { passive: false });

    /* keyboard */
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', function () { if (UE.PlayMaker) UE.PlayMaker.keys.clear(); });

    /* resize */
    if (window.ResizeObserver) {
      new ResizeObserver(function () { resizeViewport(); }).observe(els.stage);
    }
    window.addEventListener('resize', resizeViewport);
  }

  function closeMenus() {
    document.querySelectorAll('.menu.open').forEach(function (m) { m.classList.remove('open'); });
  }
  function resizeViewport() {
    renderer.resize(Math.max(1, els.stage.clientWidth), Math.max(1, els.stage.clientHeight));
  }

  function onMouseDown(e) {
    els.view.focus();
    if (e.button === 2 || (e.button === 0 && e.altKey)) {
      e.preventDefault();
      app.drag = { kind: 'orbit', x: e.clientX, y: e.clientY };
      els.view.style.cursor = 'grabbing';
      return;
    }
    if (e.button === 1) {
      e.preventDefault();
      app.drag = { kind: 'pan', x: e.clientX, y: e.clientY };
      els.view.style.cursor = 'grabbing';
      return;
    }
    if (e.button !== 0) return;
    if (app.viewMode !== 'scene') return;
    const m = localMouse(e);
    const hit = hitGizmo(m.x, m.y);
    if (hit) {
      startGizmoDrag(e, hit);
      return;
    }
    const picked = pickObject(e.clientX, e.clientY);
    select(picked ? picked.id : null);
  }
  function onMouseMove(e) {
    if (app.drag) {
      if (app.drag.kind === 'orbit') {
        const dx = e.clientX - app.drag.x;
        const dy = e.clientY - app.drag.y;
        app.drag.x = e.clientX;
        app.drag.y = e.clientY;
        app.camera.yaw += dx * 0.32;
        app.camera.pitch = UE.clamp(app.camera.pitch + dy * 0.32, -85, 85);
      } else if (app.drag.kind === 'pan') {
        const dx = e.clientX - app.drag.x;
        const dy = e.clientY - app.drag.y;
        app.drag.x = e.clientX;
        app.drag.y = e.clientY;
        const v = app.view;
        const right = V3.normalize(V3.cross(v.forward, v.up));
        const up = V3.cross(right, v.forward);
        const k = 2 * app.camera.dist * Math.tan(app.camera.fov * DEG / 2) / Math.max(1, v.height);
        app.camera.target = V3.add(app.camera.target, V3.add(V3.scale(right, -dx * k), V3.scale(up, dy * k)));
      } else if (app.drag.kind === 'gizmo') {
        updateGizmoDrag(e, app.drag);
      }
      return;
    }
    if (app.viewMode === 'scene') {
      const m = localMouse(e);
      const hit = hitGizmo(m.x, m.y);
      app.gizmoHover = hit ? hit.axis : null;
      els.view.style.cursor = hit ? 'grab' : 'default';
    } else {
      els.view.style.cursor = 'default';
    }
  }
  function onMouseUp() {
    if (app.drag && app.drag.kind === 'gizmo') endEdit();
    if (app.drag) {
      app.drag = null;
      els.view.style.cursor = 'default';
      scheduleAutosave();
    }
  }
  function onWheel(e) {
    if (app.viewMode !== 'scene') return;
    e.preventDefault();
    app.camera.dist = UE.clamp(app.camera.dist * Math.exp(e.deltaY * 0.0012), 1.2, 140);
    scheduleAutosave();
  }
  function onKeyDown(e) {
    const tag = (e.target.tagName || '').toLowerCase();
    const inField = tag === 'input' || tag === 'textarea' || tag === 'select';
    if (inField) {
      if (e.key === 'Escape') e.target.blur();
      return;
    }
    if (app.playing && UE.PlayMaker) UE.PlayMaker.setKey(e.key, true);
    const ctrl = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    if (ctrl && key === 'p') {
      e.preventDefault();
      if (e.shiftKey) togglePause(); else play();
    } else if (ctrl && key === '.') {
      e.preventDefault(); stepFrame();
    } else if (ctrl && key === 'z') {
      e.preventDefault(); if (e.shiftKey) redo(); else undo();
    } else if (ctrl && key === 'y') {
      e.preventDefault(); redo();
    } else if (ctrl && key === 'd') {
      e.preventDefault(); duplicateSelected();
    } else if (ctrl && key === 'c') {
      e.preventDefault(); copySelected();
    } else if (ctrl && key === 'v') {
      e.preventDefault(); pasteClipboard();
    } else if (ctrl && key === 's') {
      e.preventDefault(); saveSceneLocal();
    } else if (ctrl && key === 'n') {
      e.preventDefault(); newScene();
    } else if (key === 'w') { if (!ctrl) setTool('move'); }
    else if (key === 'e') { if (!ctrl) setTool('rotate'); }
    else if (key === 'r') { if (!ctrl) setTool('scale'); }
    else if (key === 'f') { if (!ctrl) focusObject(selectedObject()); }
    else if (key === 'delete' || key === 'backspace') { e.preventDefault(); deleteSelected(); }
    else if (key === 'escape') {
      if (app.playing) stop();
      else if (els.helpModal.hidden === false) closeHelp();
      else select(null);
    } else if (key === 'f1') {
      e.preventDefault();
      if (e.shiftKey && (e.ctrlKey || e.metaKey)) openManual();
      else openHelp();
    }
  }

  function onKeyUp(e) {
    if (UE.PlayMaker) UE.PlayMaker.setKey(e.key, false);
  }
  function runCommand(command) {
    switch (command) {
      case 'newScene': newScene(); break;
      case 'saveScene': saveSceneLocal(); break;
      case 'downloadScene': exportScene(); break;
      case 'importScene': els.importScene.click(); break;
      case 'importModel': els.importModel.click(); break;
      case 'loadStarter': openSample('starter'); break;
      case 'loadPhysics': openSample('physics'); break;
      case 'loadGallery': openSample('gallery'); break;
      case 'loadPlaymaker': openSample('lights'); break;
      case 'undo': undo(); break;
      case 'redo': redo(); break;
      case 'duplicate': duplicateSelected(); break;
      case 'copy': copySelected(); break;
      case 'paste': pasteClipboard(); break;
      case 'delete': deleteSelected(); break;
      case 'deselect': select(null); break;
      case 'clearConsole': app.logs.length = 0; renderConsole(); break;
      case 'empty': addEmpty(); break;
      case 'cube': addPrimitive('cube'); break;
      case 'sphere': addPrimitive('sphere'); break;
      case 'cylinder': addPrimitive('cylinder'); break;
      case 'cone': addPrimitive('cone'); break;
      case 'plane': addPrimitive('plane'); break;
      case 'camera': addCameraObject(); break;
      case 'lightSun': addLight('sun'); break;
      case 'lightDirectional': addLight('directional'); break;
      case 'lightPoint': addLight('point'); break;
      case 'lightSpot': addLight('spot'); break;
      case 'lightRig': addSampleScript(); break;
      case 'addScript': addComponentToSelection('Script'); break;
      case 'addRigidbody': addComponentToSelection('Rigidbody'); break;
      case 'addCollider': addComponentToSelection('Collider'); break;
      case 'addCamera': addComponentToSelection('Camera'); break;
      case 'addLight': addComponentToSelection('Light'); break;
      case 'addAnimator': addComponentToSelection('Animator'); break;
      case 'autoRig':
        if (!selectedObject()) toast('Select an imported model first');
        else autoRigObject(selectedObject());
        break;
      case 'addFSM': addComponentToSelection('PlayMakerFSM'); break;
      case 'addTrigger': addComponentToSelection('PlayMakerTrigger'); break;
      case 'addTimer': addComponentToSelection('PlayMakerTimer'); break;
      case 'addInput': addComponentToSelection('PlayMakerInput'); break;
      case 'addProxy': addComponentToSelection('PlayMakerEventProxy'); break;
      case 'help':
      case 'about': openHelp(); break;
      case 'manual': openManual(); break;
      case 'resetLayout': resetCamera(); toast('View reset'); break;
      default: log('warn', 'Unknown command: ' + command);
    }
  }
  function addComponentToSelection(type) {
    const obj = selectedObject();
    if (!obj) { toast('Select an object first'); return; }
    addComponentToObject(obj, type);
  }
  function addSampleScript() {
    const obj = selectedObject();
    if (!obj) { toast('Select an object first'); return; }
    mutate('Add script', function () {
      const key = 'spin';
      obj.addComponent('Script', { name: key, code: UE.Samples.scripts[key] });
    });
    log('info', 'Added the "' + 'spin' + '" example script to ' + obj.name);
  }

  /* --------------------------------------------------------------------- loop */
  let lastFrame = performance.now();
  function frame(now) {
    const realDt = Math.min(0.1, (now - lastFrame) / 1000);
    lastFrame = now;
    if (app.playing && !app.paused) {
      app.acc = Math.min(0.25, app.acc + realDt);
      let guard = 0;
      while (app.acc >= FIXED_DT && guard++ < 8) {
        tick(FIXED_DT);
        app.acc -= FIXED_DT;
      }
    } else if (!app.playing && UE.Animation && UE.Animation.updateAll) {
      /* Edit-mode preview: auto-rigged models animate in the viewport. */
      UE.Animation.updateAll(app.scene, realDt, true);
    }
    app.view = getView();
    if (renderer.ok) {
      const gizmo = gizmoInfo();
      renderer.render(app.scene, app.view, {
        grid: app.options.grid,
        wireframe: app.options.wireframe,
        shadows: true,
        selection: app.selected ? [app.selected] : [],
        lightIcons: app.viewMode !== 'game',
        gizmo: gizmo ? { origin: gizmo.origin, scale: gizmo.scale, mode: gizmo.mode, hover: app.gizmoHover } : null
      });
    }
    /* fps + stats */
    app.fpsFrames++;
    app.fpsTime += realDt;
    if (app.fpsTime >= 0.4) {
      app.fps = app.fpsFrames / app.fpsTime;
      app.fpsFrames = 0;
      app.fpsTime = 0;
      els.statFps.textContent = Math.round(app.fps) + ' fps';
      els.statTris.textContent = (renderer.ok ? renderer.stats.triangles.toLocaleString() : '0') + ' tris';
      els.statObjs.textContent = app.scene.objects.length + ' objects';
    }
    requestAnimationFrame(frame);
  }

  /* --------------------------------------------------------------------- boot */
  function boot() {
    cacheEls();
    UE.onLog = log;
    window.addEventListener('error', function (e) { log('error', e.message); });
    window.addEventListener('unhandledrejection', function (e) {
      log('error', 'Unhandled promise rejection: ' + (e.reason && e.reason.message ? e.reason.message : e.reason));
    });

    bindUi();
    loadPrefs();
    els.chkGrid.checked = app.options.grid;
    els.chkWire.checked = app.options.wireframe;
    els.chkSnap.checked = app.options.snap;
    setTool(app.tool, true);
    setViewMode(app.viewMode);

    if (!renderer.ok) {
      els.stageError.hidden = false;
      els.stageError.textContent = 'WebGL is not available, so the 3D viewport cannot render. The Hierarchy and Inspector still work.';
    }

    let loaded = false;
    try {
      const raw = localStorage.getItem(STORAGE_SCENE);
      if (raw) {
        app.scene = UE.Scene.fromJSON(JSON.parse(raw));
        loaded = true;
      }
    } catch (err) { /* ignore corrupt storage */ }
    if (!loaded) app.scene = UE.Samples.create('starter');
    if (app.viewMode === 'game') setViewMode('game');

    resizeViewport();
    renderAll();
    renderConsole();
    updateTransport();
    log('info', 'UnirealEngine ready — plain HTML, CSS and JavaScript. No SQL, no build step.');
    if (loaded) log('info', 'Restored "' + app.scene.name + '" from localStorage');
    log('info', 'Scene has ' + app.scene.objects.length + ' objects. Press Ctrl+P to play.');

    window.addEventListener('beforeunload', function () {
      if (!app.playing) {
        try { localStorage.setItem(STORAGE_SCENE, fullJson()); } catch (err) { /* ignore */ }
      }
    });
    requestAnimationFrame(frame);

    /* Small automation surface: handy from the devtools console and for tests. */
    window.UnirealEngine = {
      app: app,
      renderer: renderer,
      play: play,
      stop: stop,
      undo: undo,
      redo: redo,
      select: select,
      addPrimitive: addPrimitive,
      addLight: addLight,
      importModel: importModelData,
      importModelFiles: importModelFiles,
      addComponent: addComponentToSelection,
      exportScene: exportScene,
      getView: getView,
      pickObject: pickObject,
      setViewMode: setViewMode,
      setTool: setTool,
      openSample: openSample,
      newScene: newScene,
      saveScene: saveSceneLocal,
      togglePause: togglePause,
      stepFrame: stepFrame,
      toast: toast,
      assets: UE.AssetStore,
      modelIO: UE.ModelIO,
      animation: UE.Animation,
      autoRig: autoRigObject,
      playmaker: UE.PlayMaker
    };
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
