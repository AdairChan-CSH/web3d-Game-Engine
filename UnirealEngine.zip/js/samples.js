/* UnirealEngine — samples.js
 * Ready-to-use scenes and example scripts. All of it is procedural JSON-friendly data. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;

  const scripts = UE.Samples = UE.Samples || {};
  scripts.scripts = {
    spin: '// Spin around Y every frame.\nself.transform.rotation.y += 90 * dt;\n',
    bob: '// Float up and down. self.data is persistent per-object state.\nif (self.data.baseY === undefined) self.data.baseY = self.transform.position.y;\nself.transform.position.y = self.data.baseY + Math.sin(time * 2) * 0.3;\n',
    orbit: '// Orbit the world origin at a fixed radius.\nif (self.data.radius === undefined) {\n  self.data.radius = Math.hypot(self.transform.position.x, self.transform.position.z);\n  self.data.height = self.transform.position.y;\n}\nself.transform.position.x = Math.cos(time * 0.8) * self.data.radius;\nself.transform.position.z = Math.sin(time * 0.8) * self.data.radius;\nself.transform.position.y = self.data.height + Math.sin(time * 1.6) * 0.25;\n',
    pulse: '// Breathe in and out.\nconst k = 1 + Math.sin(time * 3) * 0.14;\nself.transform.scale.x = k;\nself.transform.scale.y = k;\nself.transform.scale.z = k;\n',
    lookAtOrigin: '// Turn to face the world origin.\nconst p = self.transform.position;\nconst yaw = Math.atan2(p.x, p.z) * 180 / Math.PI;\nself.transform.rotation.y = yaw + 180;\n'
  };

  function add(scene, name, primitive, color, position, opts) {
    opts = opts || {};
    const go = UE.createPrimitive(name, primitive, color, position);
    if (opts.scale) go.transform.scale = V3.clone(opts.scale);
    if (opts.rotation) go.transform.rotation = V3.clone(opts.rotation);
    if (opts.rb) go.addComponent('Rigidbody', opts.rb);
    if (opts.script) {
      go.addComponent('Script', {
        name: opts.script,
        code: scripts.scripts[opts.script] || '// empty script'
      });
    }
    if (opts.mr) {
      const mr = go.getComponent('MeshRenderer');
      Object.assign(mr, opts.mr);
    }
    scene.add(go);
    return go;
  }

  function ground(scene, size, color) {
    const g = add(scene, 'Ground', 'plane', color || '#242a35', { x: 0, y: 0, z: 0 });
    g.transform.scale = V3.create(size || 3, 1, size || 3);
    g.getComponent('MeshRenderer').castShadow = false;
    g.getComponent('Collider').size = { x: 10, y: 0.1, z: 10 };
    return g;
  }

  function cameraAt(scene, position, target) {
    const cam = UE.createCamera('Main Camera', position);
    const d = V3.normalize(V3.sub(target || V3.create(0, 1, 0), position));
    cam.transform.rotation = V3.create(
      Math.asin(UE.clamp(d.y, -1, 1)) * UE.RAD,
      Math.atan2(-d.x, -d.z) * UE.RAD,
      0
    );
    scene.add(cam);
    return cam;
  }

  function starter() {
    const scene = new UE.Scene('Starter Scene');
    scene.sun = { azimuth: 42, elevation: 52, color: '#ffe7c2', intensity: 1.15, ambient: 0.38 };
    scene.sky = { top: '#20304a', bottom: '#080b11' };
    ground(scene, 3.2);
    add(scene, 'Platform', 'cube', '#39424f', { x: 0, y: 0.25, z: -1 }, { scale: { x: 4.6, y: 0.5, z: 3.4 } });
    add(scene, 'Crate A', 'cube', '#e0a458', { x: -1.15, y: 1.55, z: 0.1 }, { rb: { restitution: 0.28 } });
    add(scene, 'Crate B', 'cube', '#d98b48', { x: -1.15, y: 2.7, z: 0.1 }, { rb: { restitution: 0.28 } });
    add(scene, 'Ball', 'sphere', '#62b6cb', { x: 0.7, y: 2.1, z: 0.5 }, { rb: { restitution: 0.68 } });
    add(scene, 'Pillar', 'cylinder', '#8e7dff', { x: 2.3, y: 1.05, z: -0.7 }, { scale: { x: 0.9, y: 2.1, z: 0.9 } });
    add(scene, 'Cone', 'cone', '#e06c75', { x: -2.6, y: 0.9, z: 1.5 }, { rotation: { x: 0, y: 20, z: 0 } });
    add(scene, 'Spinner', 'cube', '#7ee787', { x: 3.1, y: 2.1, z: -2.3 }, {
      scale: { x: 0.7, y: 0.7, z: 0.7 },
      script: 'spin'
    });
    add(scene, 'Orbiter', 'sphere', '#ffb86b', { x: 0, y: 3.1, z: -4.2 }, {
      scale: { x: 0.55, y: 0.55, z: 0.55 },
      script: 'orbit'
    });
    cameraAt(scene, { x: 7.4, y: 5.6, z: 8.8 }, { x: 0, y: 1.2, z: 0 });
    return scene;
  }

  function physicsLab() {
    const scene = new UE.Scene('Physics Lab');
    scene.sun = { azimuth: 15, elevation: 62, color: '#fff3dd', intensity: 1.3, ambient: 0.3 };
    scene.sky = { top: '#2b1f1a', bottom: '#0b0908' };
    ground(scene, 4, '#2a2622');
    for (let i = 0; i < 6; i++) {
      add(scene, 'Tower ' + (i + 1), 'cube', i % 2 ? '#e0a458' : '#c98b4b', { x: 0, y: 0.55 + i * 1.02, z: 0 }, {
        rotation: { x: 0, y: (i % 2 ? 6 : -5), z: 0 },
        rb: { restitution: 0.2, mass: 1 }
      });
    }
    for (let i = 0; i < 5; i++) {
      add(scene, 'Ball ' + (i + 1), 'sphere', ['#62b6cb', '#8e7dff', '#7ee787', '#ffb86b', '#e06c75'][i], {
        x: -5.5 + i * 0.1,
        y: 4.5 + i * 1.1,
        z: 2.2
      }, { scale: { x: 0.7, y: 0.7, z: 0.7 }, rb: { restitution: 0.78 } });
    }
    add(scene, 'Pedestal', 'cylinder', '#4c5668', { x: 3.6, y: 0.6, z: -1.5 }, { scale: { x: 1.4, y: 1.2, z: 1.4 } });
    add(scene, 'Bowling Ball', 'sphere', '#ff5b5b', { x: 3.6, y: 3.2, z: -1.5 }, {
      scale: { x: 1.2, y: 1.2, z: 1.2 },
      rb: { restitution: 0.35, mass: 4 }
    });
    add(scene, 'Hover', 'cube', '#5aa9ff', { x: -3, y: 2.4, z: -2.2 }, {
      scale: { x: 0.8, y: 0.8, z: 0.8 },
      script: 'bob'
    });
    cameraAt(scene, { x: 9.5, y: 6.4, z: 11 }, { x: 0, y: 2.2, z: 0 });
    return scene;
  }

  function gallery() {
    const scene = new UE.Scene('Material Gallery');
    scene.sun = { azimuth: 120, elevation: 46, color: '#ffffff', intensity: 1.05, ambient: 0.42 };
    scene.sky = { top: '#1b2735', bottom: '#090a0c' };
    ground(scene, 2.2);
    const colors = ['#e06c75', '#e0a458', '#e5e58a', '#7ee787', '#62b6cb', '#8e7dff', '#ff8fd8'];
    colors.forEach((color, i) => {
      const sphere = add(scene, 'Sphere ' + (i + 1), 'sphere', color, { x: -4.5 + i * 1.5, y: 0.75, z: 0 }, {
        scale: { x: 1.1, y: 1.1, z: 1.1 },
        mr: { roughness: 0.08 + i * 0.12, castShadow: true }
      });
      sphere.addComponent('Script', { name: 'pulse', code: scripts.scripts.pulse });
    });
    add(scene, 'Backdrop', 'cube', '#202633', { x: 0, y: 2.4, z: -6 }, { scale: { x: 16, y: 5, z: 0.3 } });
    cameraAt(scene, { x: 0, y: 3.4, z: 9 }, { x: 0, y: 1.2, z: 0 });
    return scene;
  }

  function empty() {
    const scene = new UE.Scene('Untitled');
    scene.sun = { azimuth: 38, elevation: 54, color: '#ffe9c4', intensity: 1.05, ambient: 0.34 };
    ground(scene, 3);
    cameraAt(scene, { x: 6, y: 4.5, z: 8 }, { x: 0, y: 0.8, z: 0 });
    return scene;
  }

  function lightsAndPlayMaker() {
    const scene = new UE.Scene('Lights & PlayMaker');
    scene.sun = { azimuth: 38, elevation: 54, color: '#ffe9c4', intensity: 0.4, ambient: 0.16 };
    scene.sky = { top: '#101827', bottom: '#04060a' };
    ground(scene, 3.6, '#1b212a');

    /* A Sun component overrides the global sun entirely. */
    const sun = UE.createLight('Sun Light', 'sun', { x: -7, y: 9, z: 7 }, { x: -54, y: 36, z: 0 });
    Object.assign(sun.getComponent('Light'), { color: '#ffdfae', intensity: 1.5 });
    scene.add(sun);

    add(scene, 'Pedestal', 'cylinder', '#3d4757', { x: 0, y: 0.35, z: 0 }, { scale: { x: 2.4, y: 0.7, z: 2.4 } });
    add(scene, 'Backdrop', 'cube', '#171d26', { x: 0, y: 2.6, z: -5.5 }, { scale: { x: 14, y: 5.4, z: 0.4 } });

    /* PlayMaker orb: Idle → Patrol → Return, and a Boost state on the E key. */
    const orb = add(scene, 'PlayMaker Orb', 'sphere', '#62b6cb', { x: 0, y: 1.45, z: 1.4 }, { scale: { x: 0.8, y: 0.8, z: 0.8 } });
    orb.addComponent('PlayMakerInput', { eventName: 'Boost', key: 'e', mode: 'down', target: 'self' });
    orb.addComponent('PlayMakerFSM', {
      name: 'Orb FSM',
      start: 'Idle',
      variables: { laps: 0 },
      states: [
        {
          name: 'Idle',
          actions: [
            { type: 'wait', seconds: 0.8 },
            { type: 'setColor', target: 'self', color: '#62b6cb' }
          ],
          transitions: [{ event: 'FINISHED', to: 'Patrol' }, { event: 'Boost', to: 'Spin' }]
        },
        {
          name: 'Patrol',
          actions: [
            { type: 'setColor', target: 'self', color: '#7ee787' },
            { type: 'moveTowards', target: 'self', x: 2.2, y: 1.45, z: 1.4, speed: 2.2 }
          ],
          transitions: [{ event: 'FINISHED', to: 'Return' }, { event: 'Boost', to: 'Spin' }]
        },
        {
          name: 'Return',
          actions: [
            { type: 'setColor', target: 'self', color: '#ffb86b' },
            { type: 'moveTowards', target: 'self', x: 0, y: 1.45, z: 1.4, speed: 2.2 }
          ],
          transitions: [{ event: 'FINISHED', to: 'Idle' }, { event: 'Boost', to: 'Spin' }]
        },
        {
          name: 'Spin',
          actions: [
            { type: 'setColor', target: 'self', color: '#e06c75' },
            { type: 'rotate', target: 'self', x: 0, y: 720, z: 0, duration: 1.1 }
          ],
          transitions: [{ event: 'FINISHED', to: 'Idle' }]
        }
      ]
    });

    /* Point light with a rings cookie, pulsed warm/cool by a Timer. */
    const point = UE.createLight('Point Light', 'point', { x: 0, y: 3.4, z: 0 });
    Object.assign(point.getComponent('Light'), { color: '#ffcf8a', intensity: 3.2, range: 9, cookie: 'rings' });
    point.addComponent('PlayMakerTimer', { eventName: 'Timer', seconds: 1.4, repeat: true, target: 'self' });
    point.addComponent('PlayMakerFSM', {
      name: 'Light Pulse',
      start: 'Warm',
      states: [
        {
          name: 'Warm',
          actions: [{ type: 'setLight', target: 'self', color: '#ffb86b', intensity: 2.4, range: 9 }],
          transitions: [{ event: 'Timer', to: 'Cool' }]
        },
        {
          name: 'Cool',
          actions: [{ type: 'setLight', target: 'self', color: '#7ecbff', intensity: 4.0, range: 9 }],
          transitions: [{ event: 'Timer', to: 'Warm' }]
        }
      ]
    });
    scene.add(point);

    /* Spot light with a grid cookie; Event Proxy opens it on start. */
    const spot = UE.createLight('Spot Light', 'spot', { x: 3.2, y: 5, z: 5.5 }, { x: -33, y: 30, z: 0 });
    Object.assign(spot.getComponent('Light'), {
      color: '#cfe8ff', intensity: 4.2, range: 16, spotAngle: 42, innerAngle: 18, cookie: 'grid'
    });
    spot.addComponent('PlayMakerEventProxy', { eventName: 'Open', trigger: 'start', target: 'self' });
    spot.addComponent('PlayMakerFSM', {
      name: 'Spot Gate',
      start: 'Closed',
      states: [
        {
          name: 'Closed',
          actions: [{ type: 'setLight', target: 'self', color: '#cfe8ff', intensity: 0.25, range: 16 }],
          transitions: [{ event: 'Open', to: 'Open' }]
        },
        {
          name: 'Open',
          actions: [{ type: 'setLight', target: 'self', color: '#cfe8ff', intensity: 4.2, range: 16 }],
          transitions: []
        }
      ]
    });
    scene.add(spot);

    add(scene, 'Spot Target', 'cube', '#8e7dff', { x: 0.2, y: 0.45, z: 0.3 }, {
      scale: { x: 1.1, y: 0.9, z: 1.1 },
      mr: { emissive: 0.22, roughness: 0.25 }
    });

    cameraAt(scene, { x: 7.2, y: 5.8, z: 9.4 }, { x: 0.4, y: 1.4, z: 0 });
    return scene;
  }

  scripts.list = [
    { id: 'starter', name: 'Starter Scene', desc: 'Crates, a bouncy ball, and two animated objects.', make: starter },
    { id: 'physics', name: 'Physics Lab', desc: 'A tower to knock down and a heavy ball drop.', make: physicsLab },
    { id: 'gallery', name: 'Material Gallery', desc: 'Seven pulsing spheres, different roughness.', make: gallery },
    { id: 'lights', name: 'Lights & PlayMaker', desc: 'Sun, point and spot cookies with FSM states.', make: lightsAndPlayMaker },
    { id: 'empty', name: 'Empty Scene', desc: 'Ground and a main camera.', make: empty }
  ];

  scripts.create = function (id) {
    const entry = scripts.list.find(s => s.id === id) || scripts.list[0];
    return entry.make();
  };

  return UE;
});
