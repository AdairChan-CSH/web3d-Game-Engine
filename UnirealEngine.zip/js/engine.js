/* UnirealEngine — engine.js
 * Scene graph, components, serialization, a small fixed-step physics solver and the script runtime.
 * No DOM, no database: everything lives in plain objects and serializes to JSON. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;

  /* ------------------------------------------------------------------ logging */
  UE.onLog = null;
  UE.log = function (level, message) {
    if (typeof UE.onLog === 'function') UE.onLog(level, message);
    else if (typeof console !== 'undefined') (console[level] || console.log)(message);
  };

  /* ---------------------------------------------------------------- Transform */
  class Transform {
    constructor(object) {
      this.object = object;
      this.parent = null;
      this.children = [];
      this.position = V3.create();
      this.rotation = V3.create();       // Euler degrees, Unity ZXY order
      this.scale = V3.create(1, 1, 1);
    }
    localMatrix() {
      return UE.Mat4.compose(this.position, this.rotation, this.scale);
    }
    worldMatrix() {
      const local = this.localMatrix();
      return this.parent ? UE.Mat4.multiply(this.parent.transform.worldMatrix(), local) : local;
    }
    worldPosition() {
      const m = this.worldMatrix();
      return { x: m[12], y: m[13], z: m[14] };
    }
    worldScale() {
      const out = V3.create(1, 1, 1);
      let t = this;
      while (t) {
        out.x *= t.scale.x; out.y *= t.scale.y; out.z *= t.scale.z;
        t = t.parent ? t.parent.transform : null;
      }
      return out;
    }
    forward() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(0, 0, -1)); }
    right() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(1, 0, 0)); }
    up() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(0, 1, 0)); }
  }

  /* ---------------------------------------------------------------- components */
  const COMPONENTS = UE.Components = {};

  class Component {
    constructor(object) { this.object = object; }
    get transform() { return this.object.transform; }
    applyJSON(props) {
      if (!props) return;
      for (const k of this.constructor.props) {
        if (props[k] !== undefined) this[k] = UE.clone(props[k]);
      }
    }
    serialize() {
      const out = {};
      for (const k of this.constructor.props) out[k] = UE.clone(this[k]);
      return out;
    }
  }
  UE.Component = Component;

  class MeshRenderer extends Component {
    constructor(object) {
      super(object);
      this.primitive = 'cube';
      this.meshId = null;                 // imported model asset (see UE.AssetStore)
      this.meshName = '';
      this.color = '#c9ced8';
      this.roughness = 0.55;
      this.emissive = 0;
      this.opacity = 1;
      this.uvScale = { x: 1, y: 1 };       // base-color texture tiling
      this.uvOffset = { x: 0, y: 0 };      // base-color texture scroll/offset
      this.castShadow = true;
    }
  }
  MeshRenderer.typeName = 'MeshRenderer';
  MeshRenderer.label = 'Mesh Renderer';
  MeshRenderer.props = ['primitive', 'meshId', 'meshName', 'color', 'roughness', 'emissive', 'opacity', 'uvScale', 'uvOffset', 'castShadow'];

  class Collider extends Component {
    constructor(object) {
      super(object);
      this.shape = 'box';
      this.size = V3.create(1, 1, 1);
      this.center = V3.create(0, 0, 0);
    }
  }
  Collider.typeName = 'Collider';
  Collider.label = 'Collider';
  Collider.props = ['shape', 'size', 'center'];

  class Rigidbody extends Component {
    constructor(object) {
      super(object);
      this.useGravity = true;
      this.mass = 1;
      this.drag = 0;
      this.restitution = 0.3;
      this.isKinematic = false;
      this.velocity = V3.create();       // runtime only, not serialized
    }
  }
  Rigidbody.typeName = 'Rigidbody';
  Rigidbody.label = 'Rigidbody';
  Rigidbody.props = ['useGravity', 'mass', 'drag', 'restitution', 'isKinematic'];

  class Camera extends Component {
    constructor(object) {
      super(object);
      this.fov = 60;
      this.near = 0.1;
      this.far = 250;
      this.main = true;
    }
  }
  Camera.typeName = 'Camera';
  Camera.label = 'Camera';
  Camera.props = ['fov', 'near', 'far', 'main'];

  class Light extends Component {
    constructor(object) {
      super(object);
      this.type = 'point';                // directional | point | spot
      this.color = '#ffe0b0';
      this.intensity = 1.4;
      this.range = 10;
      this.spotAngle = 48;                // full outer cone angle in degrees
      this.innerAngle = 26;               // full inner cone angle in degrees
      this.cookie = 'none';               // none | checker | stripes | grid | dots | rings | texture
      this.cookieTexture = null;          // data URL for an uploaded light cookie
      this.castShadow = true;             // reserved for shadow-map support
    }
  }
  Light.typeName = 'Light';
  Light.label = 'Light';
  Light.props = ['type', 'color', 'intensity', 'range', 'spotAngle', 'innerAngle', 'cookie', 'cookieTexture', 'castShadow'];

  UE.LIGHT_TYPES = [
    { value: 'directional', label: 'Directional' },
    { value: 'sun', label: 'Sun (primary light)' },
    { value: 'point', label: 'Point' },
    { value: 'spot', label: 'Spot' }
  ];
  UE.LIGHT_COOKIES = [
    { value: 'none', label: 'None' },
    { value: 'checker', label: 'Checker' },
    { value: 'stripes', label: 'Stripes' },
    { value: 'grid', label: 'Grid' },
    { value: 'dots', label: 'Dots' },
    { value: 'rings', label: 'Rings' },
    { value: 'texture', label: 'Uploaded texture' }
  ];
  UE.lightCookieLabel = function (value) {
    const found = UE.LIGHT_COOKIES.find(c => c.value === value);
    return found ? found.label : 'None';
  };

  class Script extends Component {
    constructor(object) {
      super(object);
      this.name = 'New Script';
      this.code = '// Runs every frame. Available: self, dt, time, scene, UE\nself.transform.rotation.y += 45 * dt;';
    }
    run(dt, time, scene) {
      if (this._compiledFrom !== this.code) {
        this._compiledFrom = this.code;
        this._fn = null;
        this._error = null;
        try {
          this._fn = new Function('self', 'dt', 'time', 'scene', 'UE', '"use strict";\n' + this.code);
        } catch (err) {
          this._error = err.message;
          UE.log('error', 'Script "' + this.name + '" on ' + this.object.name + ' failed to compile: ' + err.message);
        }
      }
      if (!this._fn) return;
      try {
        this._fn(this.object, dt, time, scene, UE);
        this._lastThrown = null;
      } catch (err) {
        if (this._lastThrown !== err.message) {
          this._lastThrown = err.message;
          UE.log('error', 'Script "' + this.name + '" on ' + this.object.name + ': ' + err.message);
        }
      }
    }
  }
  Script.typeName = 'Script';
  Script.label = 'Script';
  Script.props = ['name', 'code'];

  for (const C of [MeshRenderer, Collider, Rigidbody, Camera, Light, Script]) {
    COMPONENTS[C.typeName] = C;
  }

  UE.componentLabel = function (type) {
    const C = COMPONENTS[type];
    return (C && C.label) || type;
  };

  /* --------------------------------------------------------------- GameObject */
  class GameObject {
    constructor(name) {
      this.id = UE.uuid();
      this.name = name || 'GameObject';
      this.active = true;
      this.tag = 'Untagged';
      this.transform = new Transform(this);
      this.components = [];
      this.scene = null;
      this._scriptData = null;
    }
    get data() { return this._scriptData || (this._scriptData = {}); }
    getComponent(type) {
      for (const c of this.components) if (c.constructor.typeName === type) return c;
      return null;
    }
    getComponents(type) {
      return this.components.filter(c => !type || c.constructor.typeName === type);
    }
    addComponent(type, props) {
      const C = COMPONENTS[type];
      if (!C) throw new Error('Unknown component type: ' + type);
      const existing = this.getComponent(type);
      if (existing && type !== 'Script' && type !== 'PlayMakerFSM') return existing;
      const comp = new C(this);
      if (props) comp.applyJSON(props);
      this.components.push(comp);
      return comp;
    }
    removeComponent(comp) {
      const i = this.components.indexOf(comp);
      if (i >= 0) this.components.splice(i, 1);
      return i >= 0;
    }
    children() { return this.transform.children.map(c => c.object); }
    setParent(parent) {
      if (parent === this || (parent && parent.transform === this.transform)) return;
      if (this.transform.parent) {
        const old = this.transform.parent.transform.children;
        const i = old.indexOf(this.transform);
        if (i >= 0) old.splice(i, 1);
      }
      this.transform.parent = parent || null;
      if (parent) parent.transform.children.push(this.transform);
    }
    destroy() {
      if (this.scene) this.scene.remove(this);
    }
    toJSON() {
      return {
        id: this.id,
        name: this.name,
        active: this.active,
        tag: this.tag,
        parentId: this.transform.parent ? this.transform.parent.id : null,
        transform: {
          position: UE.clone(this.transform.position),
          rotation: UE.clone(this.transform.rotation),
          scale: UE.clone(this.transform.scale)
        },
        components: this.components.map(c => ({ type: c.constructor.typeName, props: c.serialize() }))
      };
    }
  }
  UE.GameObject = GameObject;

  /* --------------------------------------------------------------- asset store
   * Imported meshes are immutable assets. Geometry is stored as base64 Float32
   * positions/normals and Uint16 or Uint32 indices, so a scene JSON stays
   * compact and no binary files live outside the browser. Assets are shared by
   * reference. */
  const BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function bytesToBase64(bytes) {
    if (typeof btoa === 'function') {
      let out = '';
      /* Every chunk except the last must be a multiple of three bytes or btoa
       * inserts padding mid-stream and the concatenated string becomes invalid. */
      const chunk = 0x8000 - (0x8000 % 3);
      for (let i = 0; i < bytes.length; i += chunk) {
        out += btoa(String.fromCharCode.apply(null, bytes.subarray(i, i + chunk)));
      }
      return out;
    }
    let out = '';
    for (let i = 0; i < bytes.length; i += 3) {
      const a = bytes[i], b = bytes[i + 1], c = bytes[i + 2];
      out += BASE64_CHARS[a >> 2] + BASE64_CHARS[((a & 3) << 4) | ((b || 0) >> 4)] +
        (b === undefined ? '=' : BASE64_CHARS[((b & 15) << 2) | ((c || 0) >> 6)]) +
        (c === undefined ? '=' : BASE64_CHARS[c & 63]);
    }
    return out;
  }
  function base64ToBytes(text) {
    if (typeof atob === 'function') {
      const raw = atob(text);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      return bytes;
    }
    const bytes = [];
    let buffer = 0, bits = 0;
    for (const ch of text) {
      if (ch === '=') break;
      const v = BASE64_CHARS.indexOf(ch);
      if (v < 0) continue;
      buffer = (buffer << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; bytes.push((buffer >> bits) & 255); }
    }
    return new Uint8Array(bytes);
  }
  function encodeFloat32(list) {
    const f = list instanceof Float32Array ? list : new Float32Array(list);
    return bytesToBase64(new Uint8Array(f.buffer, f.byteOffset, f.byteLength));
  }
  function encodeUint16(list) {
    const u = list instanceof Uint16Array ? list : new Uint16Array(list);
    return bytesToBase64(new Uint8Array(u.buffer, u.byteOffset, u.byteLength));
  }
  function encodeUint32(list) {
    const u = list instanceof Uint32Array ? list : new Uint32Array(list);
    return bytesToBase64(new Uint8Array(u.buffer, u.byteOffset, u.byteLength));
  }
  function decodeFloat32(text) {
    const bytes = base64ToBytes(text);
    const out = new Float32Array(bytes.length >> 2);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getFloat32(i * 4, true);
    return out;
  }
  function decodeUint16(text) {
    const bytes = base64ToBytes(text);
    const out = new Uint16Array(bytes.length >> 1);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getUint16(i * 2, true);
    return out;
  }
  function decodeUint32(text) {
    const bytes = base64ToBytes(text);
    const out = new Uint32Array(bytes.length >> 2);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getUint32(i * 4, true);
    return out;
  }
  function maxIndex(indices) {
    let max = 0;
    for (let i = 0; i < indices.length; i++) if (indices[i] > max) max = indices[i];
    return max;
  }

  /* ------------------------------------------------------------- asset helpers
   * Assets store one or more primitives. Each primitive keeps base64 buffers
   * for positions, normals, UVs and indices, plus an optional base-color
   * material whose texture is stored as compressed image bytes (base64 in
   * scene JSON). The renderer decodes the image on the GPU asynchronously. */
  function encodeUtf8(text) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(text);
    const bytes = [];
    for (let i = 0; i < text.length; i++) {
      let code = text.charCodeAt(i);
      if (code >= 0xD800 && code <= 0xDBFF && i + 1 < text.length) {
        const next = text.charCodeAt(i + 1);
        if (next >= 0xDC00 && next <= 0xDFFF) {
          code = 0x10000 + ((code - 0xD800) << 10) + (next - 0xDC00);
          i++;
        }
      }
      if (code < 0x80) bytes.push(code);
      else if (code < 0x800) bytes.push(0xC0 | (code >> 6), 0x80 | (code & 0x3F));
      else if (code < 0x10000) bytes.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 0x3F), 0x80 | (code & 0x3F));
      else bytes.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 0x3F), 0x80 | ((code >> 6) & 0x3F), 0x80 | (code & 0x3F));
    }
    return new Uint8Array(bytes);
  }
  function bytesOf(data) {
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (data && data.buffer instanceof ArrayBuffer) return new Uint8Array(data.buffer, data.byteOffset || 0, data.byteLength);
    if (typeof data === 'string') return encodeUtf8(data);
    return new Uint8Array(0);
  }
  function positionsBounds(positions) {
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i], y = positions[i + 1], z = positions[i + 2];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    return { min: [minX, minY, minZ], max: [maxX, maxY, maxZ] };
  }
  function primsBounds(prims) {
    let bounds = null;
    for (const prim of prims) {
      if (!prim.positions || !prim.positions.length) continue;
      const b = positionsBounds(prim.positions);
      if (!bounds) bounds = b;
      else {
        for (let k = 0; k < 3; k++) {
          bounds.min[k] = Math.min(bounds.min[k], b.min[k]);
          bounds.max[k] = Math.max(bounds.max[k], b.max[k]);
        }
      }
    }
    return bounds;
  }
  function materialToJSON(material) {
    if (!material) return null;
    const tex = material.texture;
    return {
      color: material.color || null,
      texture: tex && tex.bytes && tex.bytes.length
        ? { mime: tex.mime || 'image/png', name: tex.name || '', t: bytesToBase64(bytesOf(tex.bytes)) }
        : null
    };
  }
  function materialFromJSON(material) {
    if (!material) return null;
    const tex = material.texture;
    return {
      color: material.color || null,
      texture: tex && tex.t
        ? { mime: tex.mime || 'image/png', name: tex.name || '', bytes: base64ToBytes(tex.t) }
        : null
    };
  }
  function encodePrimitive(prim) {
    const positions = prim.positions;
    const vertexCount = positions.length / 3;
    const normals = prim.normals && prim.normals.length === positions.length ? prim.normals : new Array(positions.length).fill(0);
    const uvs = prim.uvs && prim.uvs.length === vertexCount * 2 ? prim.uvs : new Array(vertexCount * 2).fill(0);
    const indices = prim.indices;
    const wide = maxIndex(indices) > 65535;
    return {
      p: encodeFloat32(positions),
      n: encodeFloat32(normals),
      u: encodeFloat32(uvs),
      i: wide ? encodeUint32(indices) : encodeUint16(indices),
      indexType: wide ? 32 : 16,
      material: materialToJSON(prim.material)
    };
  }
  function decodePrimitive(src) {
    const positions = decodeFloat32(src.p);
    const normals = decodeFloat32(src.n);
    const vertexCount = positions.length / 3;
    const uvs = src.u ? decodeFloat32(src.u) : new Float32Array(vertexCount * 2);
    const wide = src.indexType === 32 || src.indexType === 'uint32';
    const indices = wide ? decodeUint32(src.i) : decodeUint16(src.i);
    const data = new Float32Array(vertexCount * 8);
    for (let i = 0; i < vertexCount; i++) {
      const o = i * 8, p = i * 3, uv = i * 2;
      data[o] = positions[p];
      data[o + 1] = positions[p + 1];
      data[o + 2] = positions[p + 2];
      data[o + 3] = normals[p];
      data[o + 4] = normals[p + 1];
      data[o + 5] = normals[p + 2];
      data[o + 6] = uvs[uv] || 0;
      data[o + 7] = uvs[uv + 1] || 0;
    }
    return {
      positions: positions,
      normals: normals,
      uvs: uvs,
      indices: indices,
      indexType: wide ? 32 : 16,
      material: materialFromJSON(src.material),
      data: data,
      triangles: indices.length / 3
    };
  }

  const AssetStore = UE.AssetStore = {
    items: {},
    decoded: {},
    add: function (mesh, name, options) {
      options = options || {};
      if (!mesh) throw new Error('Mesh is empty');
      let source;
      if (Array.isArray(mesh.primitives) && mesh.primitives.length) {
        source = mesh.primitives;
      } else if (mesh.positions && mesh.indices) {
        source = [{
          positions: mesh.positions, normals: mesh.normals, uvs: mesh.uvs, indices: mesh.indices,
          material: mesh.material || (mesh.color ? { color: mesh.color } : null)
        }];
      } else {
        throw new Error('Mesh needs positions and indices');
      }

      let vertexCount = 0, triangleCount = 0;
      let hasTexture = false, color = null;
      const encoded = [];
      for (const src of source) {
        if (!src.positions || !src.positions.length) throw new Error('Mesh is empty');
        const pc = src.positions.length / 3;
        if (src.positions.length % 3) throw new Error('Mesh has an incomplete vertex');
        let indices = src.indices;
        if (!indices || !indices.length) {
          indices = [];
          for (let i = 0; i < pc; i++) indices.push(i);
        }
        if (indices.length % 3) throw new Error('Mesh has an incomplete triangle');
        for (let i = 0; i < indices.length; i++) {
          if (!Number.isFinite(indices[i]) || indices[i] < 0 || indices[i] >= pc) throw new Error('Mesh has an invalid triangle index');
        }
        vertexCount += pc;
        triangleCount += indices.length / 3;
        encoded.push(encodePrimitive({
          positions: src.positions, normals: src.normals, uvs: src.uvs, indices: indices, material: src.material || null
        }));
        if (src.material) {
          if (!color && src.material.color) color = src.material.color;
          if (src.material.texture && src.material.texture.bytes && src.material.texture.bytes.length) hasTexture = true;
        }
      }
      if (!vertexCount || !triangleCount) throw new Error('Mesh is empty');
      const limits = UE.MODEL_LIMITS || { maxVertices: 65535 * 99, maxTriangles: 80000 * 99 };
      if (vertexCount > limits.maxVertices) throw new Error('Mesh has ' + vertexCount.toLocaleString() + ' vertices; the import limit is ' + limits.maxVertices.toLocaleString());
      if (triangleCount > limits.maxTriangles) throw new Error('Mesh has ' + triangleCount.toLocaleString() + ' triangles; the import limit is ' + limits.maxTriangles.toLocaleString());

      const cleanName = String(name || mesh.name || 'Model');
      const textureChars = encoded.reduce(function (n, p) {
        return n + (p.material && p.material.texture ? p.material.texture.t.length : 0);
      }, 0);
      const signature = cleanName + '|' + vertexCount + '|' + triangleCount + '|' + textureChars;
      if (options.dedupe !== false) {
        for (const id of Object.keys(this.items)) {
          if (this.items[id].signature === signature) return id;
        }
      }
      const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      const bounds = mesh.bounds || primsBounds(source);
      this.items[id] = {
        id: id,
        name: cleanName,
        vertexCount: vertexCount,
        triangleCount: triangleCount,
        bounds: bounds,
        signature: signature,
        hasTexture: hasTexture,
        color: color,
        prims: encoded
      };
      return id;
    },
    has: function (id) { return !!this.items[id]; },
    get: function (id) {
      const a = this.items[id];
      if (!a) return null;
      let d = this.decoded[id];
      if (!d) {
        const prims = (a.prims || []).map(decodePrimitive);
        d = {
          prims: prims,
          bounds: a.bounds,
          triangles: a.triangleCount,
          vertexCount: a.vertexCount,
          color: a.color || null,
          hasTexture: !!a.hasTexture
        };
        if (prims.length === 1) {
          d.positions = prims[0].positions;
          d.normals = prims[0].normals;
          d.uvs = prims[0].uvs;
          d.indices = prims[0].indices;
          d.data = prims[0].data;
          d.material = prims[0].material;
        }
        this.decoded[id] = d;
      }
      return d;
    },
    meta: function (id) {
      const a = this.items[id];
      if (!a) return null;
      return {
        id: a.id, name: a.name, vertexCount: a.vertexCount, triangleCount: a.triangleCount,
        bounds: a.bounds, hasTexture: !!a.hasTexture, color: a.color || null,
        primitives: (a.prims || []).length
      };
    },
    list: function () { return Object.keys(this.items).map(id => this.meta(id)); },
    findByName: function (name) {
      for (const id of Object.keys(this.items)) if (this.items[id].name === name) return id;
      return null;
    },
    toJSON: function (ids) {
      const out = {};
      const wanted = ids ? new Set(ids) : null;
      for (const id of Object.keys(this.items)) {
        if (wanted && !wanted.has(id)) continue;
        out[id] = UE.clone(this.items[id]);
      }
      return out;
    },
    fromJSON: function (assets) {
      if (!assets || typeof assets !== 'object') return;
      for (const id of Object.keys(assets)) {
        const src = assets[id];
        if (!src) continue;
        let prims;
        if (Array.isArray(src.prims) && src.prims.length) {
          prims = src.prims.map(function (p) {
            return {
              p: p.p,
              n: p.n || encodeFloat32([]),
              u: p.u || null,
              i: p.i,
              indexType: p.indexType || 16,
              material: p.material || null
            };
          });
        } else if (src.p && src.i) {
          /* Older scenes stored one flat primitive per asset. */
          prims = [{
            p: src.p, n: src.n || encodeFloat32([]), u: null, i: src.i,
            indexType: src.indexType || (src.vertexCount > 65535 ? 32 : 16),
            material: src.color ? { color: src.color, texture: null } : null
          }];
        } else {
          continue;
        }
        this.items[id] = {
          id: id,
          name: src.name || 'Model',
          vertexCount: src.vertexCount || 0,
          triangleCount: src.triangleCount || 0,
          bounds: src.bounds || null,
          signature: src.signature || null,
          hasTexture: !!src.hasTexture || prims.some(function (p) { return !!(p.material && p.material.texture); }),
          color: src.color || null,
          prims: prims
        };
        delete this.decoded[id];
      }
    },
    clear: function () { this.items = {}; this.decoded = {}; }
  };

  /* -------------------------------------------------------------------- Scene */
  const DEFAULT_SUN = { azimuth: 38, elevation: 54, color: '#ffe9c4', intensity: 1.05, ambient: 0.34 };
  const DEFAULT_SKY = { top: '#182231', bottom: '#080a0e' };

  class Scene {
    constructor(name) {
      this.name = name || 'Untitled';
      this.objects = [];
      this.sun = UE.clone(DEFAULT_SUN);
      this.sky = UE.clone(DEFAULT_SKY);
    }
    add(object, parent) {
      if (!object) return null;
      if (object.scene && object.scene !== this) object.scene.remove(object);
      if (!this.objects.includes(object)) this.objects.push(object);
      object.scene = this;
      if (parent) object.setParent(parent);
      return object;
    }
    remove(object) {
      if (!object) return;
      for (const child of object.transform.children.slice()) this.remove(child.object);
      const i = this.objects.indexOf(object);
      if (i >= 0) this.objects.splice(i, 1);
      if (object.transform.parent) {
        const siblings = object.transform.parent.transform.children;
        const j = siblings.indexOf(object.transform);
        if (j >= 0) siblings.splice(j, 1);
      }
      object.transform.parent = null;
      object.scene = null;
    }
    roots() { return this.objects.filter(o => !o.transform.parent); }
    get(id) { return this.objects.find(o => o.id === id) || null; }
    find(name) { return this.objects.find(o => o.name === name) || null; }
    findByTag(tag) { return this.objects.find(o => o.tag === tag) || null; }
    findAllByTag(tag) { return this.objects.filter(o => o.tag === tag); }
    mainCamera() {
      for (const o of this.objects) {
        if (!o.active) continue;
        const c = o.getComponent('Camera');
        if (c && c.main) return o;
      }
      return null;
    }
    clear() {
      for (const o of this.objects.slice()) o.scene = null;
      this.objects.length = 0;
    }
    toJSON(options) {
      const includeAssets = !(options === false || (options && options.assets === false));
      const out = {
        format: 'unirealengine.scene',
        version: 2,
        name: this.name,
        sun: UE.clone(this.sun),
        sky: UE.clone(this.sky),
        objects: this.objects.map(o => o.toJSON())
      };
      if (includeAssets) {
        const ids = [];
        for (const object of this.objects) {
          const mr = object.getComponent('MeshRenderer');
          if (mr && mr.meshId && !ids.includes(mr.meshId)) ids.push(mr.meshId);
        }
        const assets = UE.AssetStore.toJSON(ids);
        if (Object.keys(assets).length) out.assets = assets;
      }
      return out;
    }
    clone() { return Scene.fromJSON(this.toJSON()); }
    static fromJSON(data) {
      if (!data || !Array.isArray(data.objects)) throw new Error('Not a UnirealEngine scene file');
      if (data.assets) UE.AssetStore.fromJSON(data.assets);
      const scene = new Scene(data.name || 'Untitled');
      if (data.sun) scene.sun = Object.assign(UE.clone(DEFAULT_SUN), data.sun);
      if (data.sky) scene.sky = Object.assign(UE.clone(DEFAULT_SKY), data.sky);
      const map = new Map();
      const objects = data.objects || [];
      for (const src of objects) {
        const go = new GameObject(src.name || 'GameObject');
        if (src.id) go.id = src.id;
        go.active = src.active !== false;
        go.tag = src.tag || 'Untagged';
        const t = src.transform || {};
        if (t.position) go.transform.position = { x: +t.position.x || 0, y: +t.position.y || 0, z: +t.position.z || 0 };
        if (t.rotation) go.transform.rotation = { x: +t.rotation.x || 0, y: +t.rotation.y || 0, z: +t.rotation.z || 0 };
        if (t.scale) go.transform.scale = { x: t.scale.x === undefined ? 1 : +t.scale.x, y: t.scale.y === undefined ? 1 : +t.scale.y, z: t.scale.z === undefined ? 1 : +t.scale.z };
        for (const c of src.components || []) {
          try { go.addComponent(c.type, c.props); }
          catch (err) { UE.log('warn', 'Skipped component ' + c.type + ' on ' + go.name + ': ' + err.message); }
        }
        scene.add(go);
        map.set(go.id, go);
      }
      for (const src of objects) {
        if (!src.parentId) continue;
        const child = map.get(src.id), parent = map.get(src.parentId);
        if (child && parent) child.setParent(parent);
      }
      return scene;
    }
  }
  UE.Scene = Scene;

  /* ------------------------------------------------------------ primitive info */
  UE.primitiveSize = function (primitive) {
    if (primitive === 'plane') return { x: 10, y: 0.1, z: 10 };
    return { x: 1, y: 1, z: 1 };
  };
  UE.primitiveLabel = function (primitive) {
    return ({ cube: 'Cube', sphere: 'Sphere', cylinder: 'Cylinder', cone: 'Cone', plane: 'Plane', model: 'Model' })[primitive] || 'Mesh';
  };
  UE.PRIMITIVES = ['cube', 'sphere', 'cylinder', 'cone', 'plane'];

  /* World-space AABB of an imported mesh, using the asset's local bounds. */
  UE.objectMeshBounds = function (object) {
    const mr = object && object.getComponent ? object.getComponent('MeshRenderer') : null;
    if (!mr || !mr.meshId) return null;
    const asset = UE.AssetStore.get(mr.meshId);
    if (!asset) return null;
    let bounds = asset.bounds;
    if (!bounds) {
      const p = asset.positions;
      let min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < p.length; i += 3) {
        for (let k = 0; k < 3; k++) {
          if (p[i + k] < min[k]) min[k] = p[i + k];
          if (p[i + k] > max[k]) max[k] = p[i + k];
        }
      }
      bounds = { min: min, max: max };
    }
    const m = object.transform.worldMatrix();
    const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < 8; i++) {
      const local = {
        x: (i & 1) ? bounds.max[0] : bounds.min[0],
        y: (i & 2) ? bounds.max[1] : bounds.min[1],
        z: (i & 4) ? bounds.max[2] : bounds.min[2]
      };
      const w = UE.Mat4.transformPoint(m, local);
      lo[0] = Math.min(lo[0], w.x); lo[1] = Math.min(lo[1], w.y); lo[2] = Math.min(lo[2], w.z);
      hi[0] = Math.max(hi[0], w.x); hi[1] = Math.max(hi[1], w.y); hi[2] = Math.max(hi[2], w.z);
    }
    return {
      cx: (lo[0] + hi[0]) / 2, cy: (lo[1] + hi[1]) / 2, cz: (lo[2] + hi[2]) / 2,
      hx: Math.max(0.01, (hi[0] - lo[0]) / 2),
      hy: Math.max(0.01, (hi[1] - lo[1]) / 2),
      hz: Math.max(0.01, (hi[2] - lo[2]) / 2)
    };
  };

  /* ------------------------------------------------------------------ physics */
  const Physics = UE.Physics = {
    gravity: -9.81,
    /* World-space AABB of an object's collider. Rotation is intentionally ignored:
       the solver is a fast, stable AABB solver, not a full 3D rigid-body engine. */
    bounds: function (object) {
      const c = object.getComponent('Collider');
      if (!c) return null;
      const p = object.transform.worldPosition();
      const s = object.transform.worldScale();
      if (c.shape === 'sphere') {
        const r = Math.max(0.02, Math.abs(c.size.x) * Math.abs(s.x) * 0.5);
        return { cx: p.x + c.center.x * s.x, cy: p.y + c.center.y * s.y, cz: p.z + c.center.z * s.z, hx: r, hy: r, hz: r };
      }
      return {
        cx: p.x + c.center.x * s.x,
        cy: p.y + c.center.y * s.y,
        cz: p.z + c.center.z * s.z,
        hx: Math.max(0.01, Math.abs(c.size.x) * Math.abs(s.x)) / 2,
        hy: Math.max(0.01, Math.abs(c.size.y) * Math.abs(s.y)) / 2,
        hz: Math.max(0.01, Math.abs(c.size.z) * Math.abs(s.z)) / 2
      };
    },
    step: function (scene, dt) {
      const bodies = [], statics = [], contacts = new Set();
      for (const object of scene.objects) {
        if (!object.active) continue;
        if (!object.getComponent('Collider')) continue;
        const b = this.bounds(object);
        if (!b) continue;
        const rb = object.getComponent('Rigidbody');
        b.object = object;
        b.rb = rb;
        if (rb && !rb.isKinematic) bodies.push(b);
        else statics.push(b);
      }

      /* integrate */
      for (const b of bodies) {
        const rb = b.rb;
        if (rb.useGravity) rb.velocity.y += this.gravity * dt;
        const damp = 1 / (1 + Math.max(0, rb.drag) * dt);
        rb.velocity.x *= damp; rb.velocity.y *= damp; rb.velocity.z *= damp;
        const t = b.object.transform;
        t.position.x += rb.velocity.x * dt;
        t.position.y += rb.velocity.y * dt;
        t.position.z += rb.velocity.z * dt;
        b.cx += rb.velocity.x * dt;
        b.cy += rb.velocity.y * dt;
        b.cz += rb.velocity.z * dt;
      }

      /* Resolve contacts in a few passes. The extra passes matter for stacks:
         pushing a lower box down into the ground is corrected again in the next
         pass, which walks the separation up the stack instead of leaving the
         boxes interpenetrating. */
      for (let iteration = 0; iteration < 3; iteration++) {
        /* dynamic vs static */
        for (const b of bodies) {
          for (const s of statics) {
            if (!UE.AABB.overlaps(b, s)) continue;
            const pair = b.object.id < s.object.id ? b.object.id + '|' + s.object.id : s.object.id + '|' + b.object.id;
            contacts.add(pair);
            const sep = UE.AABB.separation(b, s);
            if (sep) this._correct(b, sep, b.rb.restitution, 0.82);
          }
          /* infinite ground plane at y = 0 */
          if (b.cy - b.hy < 0) {
            this._correct(b, { axis: 'y', pen: -(b.cy - b.hy), sign: 1 }, b.rb.restitution, 0.82);
          }
        }

        /* dynamic vs dynamic */
        for (let i = 0; i < bodies.length; i++) {
          for (let j = i + 1; j < bodies.length; j++) {
            const a = bodies[i], b = bodies[j];
            if (!UE.AABB.overlaps(a, b)) continue;
            const pair = a.object.id < b.object.id ? a.object.id + '|' + b.object.id : b.object.id + '|' + a.object.id;
            contacts.add(pair);
            const sep = UE.AABB.separation(a, b);
            if (!sep) continue;
            const half = sep.pen / 2;
            a.object.transform.position[sep.axis] += sep.sign * half;
            b.object.transform.position[sep.axis] -= sep.sign * half;
            const va = a.rb.velocity[sep.axis], vb = b.rb.velocity[sep.axis];
            const rel = va - vb;
            if (rel * sep.sign < 0) {
              const e = Math.max(a.rb.restitution, b.rb.restitution);
              const avg = (va + vb) / 2, dv = (vb - va) / 2;
              a.rb.velocity[sep.axis] = avg - e * dv;
              b.rb.velocity[sep.axis] = avg + e * dv;
            }
            Object.assign(a, this.bounds(a.object));
            Object.assign(b, this.bounds(b.object));
          }
        }
      }

      /* settle micro-jitter */
      for (const b of bodies) {
        const v = b.rb.velocity;
        if (Math.abs(v.x) < 0.02) v.x = 0;
        if (Math.abs(v.z) < 0.02) v.z = 0;
        if (b.cy - b.hy <= 0.002 && Math.abs(v.y) < 0.25) v.y = 0;
      }

      /* PlayMaker trigger components listen for enter/exit pairs. */
      if (UE.PlayMaker && UE.PlayMaker.handleContacts) UE.PlayMaker.handleContacts(scene, contacts);
    },
    _correct: function (b, sep, restitution, friction) {
      const t = b.object.transform;
      const v = b.rb.velocity;
      t.position[sep.axis] += sep.sign * sep.pen;
      b['c' + sep.axis] += sep.sign * sep.pen;
      const along = v[sep.axis];
      if (along * sep.sign < 0) {
        v[sep.axis] = -along * restitution;
        const others = sep.axis === 'x' ? ['y', 'z'] : sep.axis === 'y' ? ['x', 'z'] : ['x', 'y'];
        for (const k of others) v[k] *= friction;
      }
      if (sep.axis === 'y' && sep.sign > 0 && Math.abs(v.y) < 0.9) v.y = 0;
    },
    /* Used by the editor to let a scripted/physics body sit on a surface without sinking. */
    raycastDown: function (scene, origin, maxDist) {
      const ray = { origin: origin, dir: { x: 0, y: -1, z: 0 } };
      let best = null;
      for (const object of scene.objects) {
        const b = this.bounds(object);
        if (!b) continue;
        const t = UE.Ray.intersectAABB(ray.origin, ray.dir, b);
        if (t !== null && t >= 0 && t <= maxDist && (best === null || t < best.t)) best = { t: t, object: object };
      }
      return best;
    }
  };

  /* ------------------------------------------------------------- script system */
  const ScriptSystem = UE.ScriptSystem = {
    update: function (scene, dt, time) {
      for (const object of scene.objects) {
        if (!object.active) continue;
        for (const component of object.components) {
          if (component instanceof Script) component.run(dt, time, scene);
        }
      }
    }
  };

  /* ------------------------------------------------------------ scene helpers */
  UE.createPrimitive = function (name, primitive, color, position, parent) {
    const go = new GameObject(name || UE.primitiveLabel(primitive));
    go.transform.position = V3.create(position ? position.x : 0, position ? position.y : 0, position ? position.z : 0);
    go.addComponent('MeshRenderer', {
      primitive: primitive,
      color: color || '#c9ced8'
    });
    go.addComponent('Collider', {
      shape: primitive === 'sphere' ? 'sphere' : 'box',
      size: UE.primitiveSize(primitive)
    });
    if (parent) go.setParent(parent);
    return go;
  };

  UE.createEmpty = function (name, position) {
    const go = new GameObject(name || 'GameObject');
    if (position) go.transform.position = V3.clone(position);
    return go;
  };

  UE.createCamera = function (name, position, rotation) {
    const go = new GameObject(name || 'Main Camera');
    if (position) go.transform.position = V3.clone(position);
    if (rotation) go.transform.rotation = V3.clone(rotation);
    go.addComponent('Camera', { fov: 60, near: 0.1, far: 250, main: true });
    return go;
  };

  UE.createModel = function (name, meshId, position, color) {
    const meta = UE.AssetStore.meta(meshId);
    const go = new GameObject(name || (meta ? meta.name : 'Model'));
    if (position) go.transform.position = V3.clone(position);
    go.addComponent('MeshRenderer', {
      primitive: 'model',
      meshId: meshId,
      meshName: meta ? meta.name : '',
      color: color || '#b9c6d8'
    });
    if (meta && meta.bounds) {
      const b = meta.bounds;
      const size = { x: b.max[0] - b.min[0], y: b.max[1] - b.min[1], z: b.max[2] - b.min[2] };
      go.addComponent('Collider', {
        shape: 'box',
        size: { x: Math.max(0.05, size.x), y: Math.max(0.05, size.y), z: Math.max(0.05, size.z) },
        center: { x: (b.min[0] + b.max[0]) / 2, y: (b.min[1] + b.max[1]) / 2, z: (b.min[2] + b.max[2]) / 2 }
      });
    }
    return go;
  };

  UE.createLight = function (name, type, position, rotation, props) {
    type = type || 'point';
    const labels = { sun: 'Sun Light', directional: 'Directional Light', spot: 'Spot Light', point: 'Point Light' };
    const go = new GameObject(name || labels[type] || 'Light');
    if (position) go.transform.position = V3.clone(position);
    if (rotation) go.transform.rotation = V3.clone(rotation);
    const defaults = {
      sun: { type: 'sun', color: '#ffe2b0', intensity: 1.7, castShadow: true },
      directional: { type: 'directional', color: '#fff3d6', intensity: 1.0, castShadow: true },
      point: { type: 'point', color: '#ffd3a1', intensity: 2.6, range: 9 },
      spot: { type: 'spot', color: '#ffd9a0', intensity: 3.4, range: 14, spotAngle: 46, innerAngle: 22 }
    };
    const light = go.addComponent('Light', defaults[type] || defaults.point);
    if (props) light.applyJSON(props);
    return go;
  };

  return UE;
});
