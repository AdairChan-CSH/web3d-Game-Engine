/* UnirealEngine — models.js
 * Dependency-free importers for OBJ, STL, GLB and glTF.
 *
 * Every importer produces a model made of one or more primitives. A primitive
 * carries positions/normals/UVs/indices plus a base-color material:
 *   { positions, normals, uvs, indices, material: { color, texture } }
 * where texture is { mime, name, bytes: Uint8Array }. glTF baseColorTexture
 * (including GLB bufferViews, data URIs and external images) and OBJ MTL
 * map_Kd files are supported. Textures are kept as compressed bytes here and
 * decoded to GPU textures by the renderer.
 *
 * Imports are auto-fitted to a 2-unit footprint and stored in UE.AssetStore.
 * No SQL, no external runtime, no build step. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const MAX_VERTICES = 65535 * 99;      // 6,487,965 vertices per model
  const MAX_TRIANGLES = 80000 * 99;     // 7,920,000 triangles per model
  UE.MODEL_LIMITS = { maxVertices: MAX_VERTICES, maxTriangles: MAX_TRIANGLES };

  /* ------------------------------------------------------------------ helpers */
  function baseName(file) {
    return String(file || 'Model').replace(/^.*[\\/]/, '');
  }
  function stem(file) {
    return baseName(file).replace(/\.[^.]+$/, '') || 'Model';
  }
  function ext(file) {
    const m = /\.([^.]+)$/.exec(String(file || '').toLowerCase());
    return m ? m[1] : '';
  }
  function decodeUtf8(data) {
    const bytes = data instanceof ArrayBuffer
      ? new Uint8Array(data)
      : new Uint8Array(data.buffer, data.byteOffset || 0, data.byteLength);
    let out = '';
    for (let i = 0; i < bytes.length;) {
      const first = bytes[i++];
      let code;
      if (first < 0x80) code = first;
      else if (first < 0xE0 && i < bytes.length) code = ((first & 0x1F) << 6) | (bytes[i++] & 0x3F);
      else if (first < 0xF0 && i + 1 < bytes.length) code = ((first & 0x0F) << 12) | ((bytes[i++] & 0x3F) << 6) | (bytes[i++] & 0x3F);
      else if (i + 2 < bytes.length) {
        code = ((first & 0x07) << 18) | ((bytes[i++] & 0x3F) << 12) | ((bytes[i++] & 0x3F) << 6) | (bytes[i++] & 0x3F);
      } else code = 0xFFFD;
      if (code < 0x10000) out += String.fromCharCode(code);
      else {
        code -= 0x10000;
        out += String.fromCharCode(0xD800 + (code >> 10), 0xDC00 + (code & 0x3FF));
      }
    }
    return out;
  }
  function toText(data) {
    if (typeof data === 'string') return data;
    if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(data);
    return decodeUtf8(data);
  }
  /* Accept an ArrayBuffer, any typed array or DataView. Some browsers hand us
   * a view into a larger buffer, so respect byteOffset/byteLength instead of
   * assuming the whole backing store. */
  function toArrayBuffer(data) {
    if (data instanceof ArrayBuffer) return data;
    if (data && data.buffer instanceof ArrayBuffer) {
      if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength) return data.buffer;
      return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
    }
    if (typeof data === 'string') return new TextEncoder().encode(data).buffer;
    throw new Error('Expected binary model data');
  }
  function toBytes(data) {
    if (data instanceof Uint8Array) return data;
    if (data && data.buffer instanceof ArrayBuffer) return new Uint8Array(data.buffer, data.byteOffset || 0, data.byteLength);
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (typeof data === 'string') return new TextEncoder().encode(data);
    return new Uint8Array(0);
  }
  /* Copy the exact byte range so a texture does not keep the whole .glb alive. */
  function sliceBytes(bytes) {
    const view = toBytes(bytes);
    const out = new Uint8Array(view.length);
    out.set(view);
    return out;
  }
  function mimeFromBytes(bytes) {
    const b = bytes;
    if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47) return 'image/png';
    if (b.length >= 3 && b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return 'image/jpeg';
    if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
        b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
    if (b.length >= 4 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return 'image/gif';
    if (b.length >= 2 && b[0] === 0x42 && b[1] === 0x4D) return 'image/bmp';
    return 'application/octet-stream';
  }
  function mimeFromURI(uri) {
    const m = /^data:([^;,]+)/i.exec(String(uri || ''));
    if (m) return m[1].toLowerCase();
    const e = ext(String(uri || '').split(/[?#]/)[0]);
    if (e === 'png') return 'image/png';
    if (e === 'jpg' || e === 'jpeg') return 'image/jpeg';
    if (e === 'webp') return 'image/webp';
    if (e === 'gif') return 'image/gif';
    if (e === 'bmp') return 'image/bmp';
    return 'application/octet-stream';
  }
  function decodeBase64(text) {
    if (typeof atob === 'function') return atob(text);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let out = '';
    let buffer = 0;
    let bits = 0;
    for (const ch of String(text).replace(/[^A-Za-z0-9+/]/g, '')) {
      buffer = (buffer << 6) | chars.indexOf(ch);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out += String.fromCharCode((buffer >> bits) & 0xFF);
      }
    }
    return out;
  }
  function decodeDataURI(uri) {
    const comma = uri.indexOf(',');
    if (comma < 0) throw new Error('Malformed data URI');
    const meta = uri.slice(0, comma);
    const raw = uri.slice(comma + 1);
    if (/;base64/i.test(meta)) {
      const bin = decodeBase64(raw);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return bytes;
    }
    const text = decodeURIComponent(raw);
    const bytes = new Uint8Array(text.length);
    for (let i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i);
    return bytes;
  }
  function companionNames(companions) {
    const map = {};
    for (const name of Object.keys(companions || {})) {
      map[baseName(decodeURIComponent(name)).toLowerCase()] = companions[name];
      map[decodeURIComponent(name).toLowerCase()] = companions[name];
    }
    return map;
  }
  function findCompanion(map, uri) {
    if (!uri) return null;
    let clean = String(uri).split(/[?#]/)[0];
    try { clean = decodeURIComponent(clean); } catch (err) { /* keep raw */ }
    return map[baseName(clean).toLowerCase()] || map[clean.toLowerCase()] || null;
  }
  function colorFromFactor(factor) {
    if (!factor || factor.length < 3) return null;
    return '#' + [0, 1, 2].map(function (k) {
      return Math.round(Math.pow(UE.clamp(factor[k], 0, 1), 1 / 2.2) * 255).toString(16).padStart(2, '0');
    }).join('');
  }

  /* ------------------------------------------------------------- mesh helpers */
  function meshBounds(positions) {
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i], y = positions[i + 1], z = positions[i + 2];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    return { min: [minX, minY, minZ], max: [maxX, maxY, maxZ] };
  }

  function smoothNormals(positions, indices) {
    const normals = new Array(positions.length).fill(0);
    for (let i = 0; i < indices.length; i += 3) {
      const ia = indices[i] * 3, ib = indices[i + 1] * 3, ic = indices[i + 2] * 3;
      const ax = positions[ib] - positions[ia], ay = positions[ib + 1] - positions[ia + 1], az = positions[ib + 2] - positions[ia + 2];
      const bx = positions[ic] - positions[ia], by = positions[ic + 1] - positions[ia + 1], bz = positions[ic + 2] - positions[ia + 2];
      const nx = ay * bz - az * by;
      const ny = az * bx - ax * bz;
      const nz = ax * by - ay * bx;
      normals[ia] += nx; normals[ia + 1] += ny; normals[ia + 2] += nz;
      normals[ib] += nx; normals[ib + 1] += ny; normals[ib + 2] += nz;
      normals[ic] += nx; normals[ic + 1] += ny; normals[ic + 2] += nz;
    }
    for (let i = 0; i < normals.length; i += 3) {
      const l = Math.hypot(normals[i], normals[i + 1], normals[i + 2]);
      if (l > 1e-9) {
        normals[i] /= l; normals[i + 1] /= l; normals[i + 2] /= l;
      } else {
        normals[i] = 0; normals[i + 1] = 1; normals[i + 2] = 0;
      }
    }
    return normals;
  }

  function cloneMaterial(material) {
    if (!material) return null;
    const texture = material.texture;
    return {
      color: material.color || null,
      texture: texture && texture.bytes && texture.bytes.length
        ? { mime: texture.mime || mimeFromBytes(texture.bytes), name: texture.name || '', bytes: texture.bytes }
        : null
    };
  }

  /* Accept either the new primitive form or the old flat mesh form and return
   * a validated, normalized model. The flat positions/normals/indices stay on
   * the result for backwards compatibility with callers that want one array. */
  function normalizeMesh(mesh) {
    const source = Array.isArray(mesh.primitives) && mesh.primitives.length
      ? mesh.primitives
      : [{
        positions: mesh.positions,
        normals: mesh.normals,
        uvs: mesh.uvs,
        indices: mesh.indices,
        material: mesh.material || (mesh.color ? { color: mesh.color } : null)
      }];

    let vertexCount = 0, triangleCount = 0;
    const prims = [];
    for (const src of source) {
      const positions = src.positions;
      if (!positions || !positions.length) throw new Error('The model contains no vertices');
      let indices = src.indices;
      if (!indices || !indices.length) {
        indices = [];
        for (let i = 0; i < positions.length / 3; i++) indices.push(i);
      }
      const pc = positions.length / 3;
      if (positions.length % 3 !== 0) throw new Error('The model has an incomplete vertex');
      if (indices.length % 3 !== 0) throw new Error('The model has an incomplete triangle');
      for (let i = 0; i < positions.length; i++) {
        if (!Number.isFinite(positions[i])) throw new Error('Model contains a non-finite vertex');
      }
      for (let i = 0; i < indices.length; i++) {
        if (!Number.isFinite(indices[i]) || indices[i] < 0 || indices[i] >= pc) {
          throw new Error('Model has an invalid triangle index');
        }
      }
      vertexCount += pc;
      triangleCount += indices.length / 3;
      prims.push({
        positions: positions,
        normals: src.normals && src.normals.length === positions.length ? src.normals : null,
        uvs: src.uvs && src.uvs.length === pc * 2 ? src.uvs : null,
        indices: indices,
        material: cloneMaterial(src.material)
      });
    }
    if (vertexCount > MAX_VERTICES) throw new Error('Model has ' + vertexCount.toLocaleString() + ' vertices; the limit is ' + MAX_VERTICES.toLocaleString());
    if (triangleCount > MAX_TRIANGLES) throw new Error('Model has ' + triangleCount.toLocaleString() + ' triangles; the limit is ' + MAX_TRIANGLES.toLocaleString());

    /* Fit the whole model, not each primitive, so materials stay aligned. */
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (const prim of prims) {
      const b = meshBounds(prim.positions);
      if (b.min[0] < minX) minX = b.min[0]; if (b.max[0] > maxX) maxX = b.max[0];
      if (b.min[1] < minY) minY = b.min[1]; if (b.max[1] > maxY) maxY = b.max[1];
      if (b.min[2] < minZ) minZ = b.min[2]; if (b.max[2] > maxZ) maxZ = b.max[2];
    }
    const sizeX = maxX - minX, sizeY = maxY - minY, sizeZ = maxZ - minZ;
    const maxExtent = Math.max(sizeX, sizeY, sizeZ);
    const scale = maxExtent > 1e-9 ? 2 / maxExtent : 1;
    const cx = (minX + maxX) / 2;
    const cz = (minZ + maxZ) / 2;
    for (const prim of prims) {
      const p = prim.positions;
      for (let i = 0; i < p.length; i += 3) {
        p[i] = (p[i] - cx) * scale;
        p[i + 1] = (p[i + 1] - minY) * scale;
        p[i + 2] = (p[i + 2] - cz) * scale;
      }
      const n = prim.normals || smoothNormals(p, prim.indices);
      for (let i = 0; i < n.length; i += 3) {
        const l = Math.hypot(n[i], n[i + 1], n[i + 2]);
        if (l > 1e-9) {
          n[i] /= l; n[i + 1] /= l; n[i + 2] /= l;
        } else {
          n[i] = 0; n[i + 1] = 1; n[i + 2] = 0;
        }
      }
      prim.normals = n;
      if (!prim.uvs) prim.uvs = new Array((p.length / 3) * 2).fill(0);
    }

    const positions = [], normals = [], uvs = [], indices = [];
    let offset = 0;
    for (const prim of prims) {
      for (let i = 0; i < prim.positions.length; i++) positions.push(prim.positions[i]);
      for (let i = 0; i < prim.normals.length; i++) normals.push(prim.normals[i]);
      for (let i = 0; i < prim.uvs.length; i++) uvs.push(prim.uvs[i]);
      for (let i = 0; i < prim.indices.length; i++) indices.push(prim.indices[i] + offset);
      offset += prim.positions.length / 3;
    }

    const bounds = meshBounds(positions);
    let color = null, texture = null;
    for (const prim of prims) {
      if (!prim.material) continue;
      if (!color && prim.material.color) color = prim.material.color;
      if (!texture && prim.material.texture) texture = prim.material.texture;
    }
    return {
      name: stem(mesh.name),
      primitives: prims,
      positions: positions,
      normals: normals,
      uvs: uvs,
      indices: indices,
      bounds: bounds,
      triangles: triangleCount,
      vertexCount: vertexCount,
      color: color,
      texture: texture,
      hasTexture: !!texture,
      source: mesh.source || '',
      warnings: mesh.warnings || []
    };
  }

  /* --------------------------------------------------------------------- OBJ */
  function parseOBJ(text, filename, companions) {
    const rawV = [], rawVT = [], rawN = [];
    const groups = new Map();
    const groupOrder = [];
    let current = '';
    let mtlLibs = [];

    function groupFor(name) {
      if (!groups.has(name)) { groups.set(name, []); groupOrder.push(name); }
      return groups.get(name);
    }

    for (const rawLine of String(text).split(/\r?\n/)) {
      const line = rawLine.replace(/#.*$/, '').trim();
      if (!line) continue;
      const parts = line.split(/\s+/);
      const key = parts[0];
      if (key === 'v') {
        rawV.push([parseFloat(parts[1]), parseFloat(parts[2]), parseFloat(parts[3])]);
      } else if (key === 'vt') {
        rawVT.push([parseFloat(parts[1]) || 0, parseFloat(parts[2]) || 0]);
      } else if (key === 'vn') {
        rawN.push([parseFloat(parts[1]), parseFloat(parts[2]), parseFloat(parts[3])]);
      } else if (key === 'usemtl') {
        current = parts.slice(1).join(' ') || '';
      } else if (key === 'mtllib') {
        const lib = line.slice(6).trim();
        if (lib) mtlLibs.push(lib);
      } else if (key === 'f') {
        const corners = [];
        for (let i = 1; i < parts.length; i++) {
          const bits = parts[i].split('/');
          let vi = parseInt(bits[0], 10);
          let ti = bits.length > 1 && bits[1] !== '' ? parseInt(bits[1], 10) : null;
          let ni = bits.length > 2 && bits[2] !== '' ? parseInt(bits[2], 10) : null;
          if (!Number.isFinite(vi) || vi === 0) continue;
          vi = vi < 0 ? rawV.length + vi : vi - 1;
          if (ti !== null && Number.isFinite(ti) && ti !== 0) ti = ti < 0 ? rawVT.length + ti : ti - 1;
          else ti = null;
          if (ni !== null && Number.isFinite(ni) && ni !== 0) ni = ni < 0 ? rawN.length + ni : ni - 1;
          else ni = null;
          if (vi >= 0 && vi < rawV.length) corners.push({ vi: vi, ti: ti, ni: ni });
        }
        if (corners.length >= 3) {
          const group = groupFor(current);
          for (let i = 1; i < corners.length - 1; i++) group.push([corners[0], corners[i], corners[i + 1]]);
        }
      }
    }
    if (!rawV.length || !groups.size) throw new Error('OBJ contains no triangles');

    /* Material libraries and their map_Kd textures (optional). */
    const names = companionNames(companions);
    const materials = {};
    for (const lib of mtlLibs) {
      const found = findCompanion(names, lib);
      if (!found) continue;
      const parsed = parseMTL(toText(found), companions);
      for (const name of Object.keys(parsed)) materials[name] = parsed[name];
    }

    const prims = [];
    const warnings = [];
    for (const name of groupOrder) {
      const faces = groups.get(name);
      if (!faces.length) continue;
      const allNormals = faces.every(function (face) {
        return face.every(function (c) { return c.ni !== null && c.ni >= 0 && c.ni < rawN.length; });
      });
      const allUVs = faces.every(function (face) {
        return face.every(function (c) { return c.ti !== null && c.ti >= 0 && c.ti < rawVT.length; });
      });
      const positions = [], normals = [], uvs = [], indices = [];
      const map = new Map();
      for (const face of faces) {
        for (const corner of face) {
          const mapKey = corner.vi + '/' + (allUVs ? corner.ti : '') + '/' + (allNormals ? corner.ni : '');
          let index = map.get(mapKey);
          if (index === undefined) {
            index = positions.length / 3;
            map.set(mapKey, index);
            positions.push(rawV[corner.vi][0], rawV[corner.vi][1], rawV[corner.vi][2]);
            if (allNormals) {
              const n = rawN[corner.ni];
              normals.push(n[0], n[1], n[2]);
            }
            if (allUVs) {
              const t = rawVT[corner.ti];
              /* OBJ UVs use a bottom-left origin; WebGL samples from the top. */
              uvs.push(t[0], 1 - t[1]);
            }
          }
          indices.push(index);
        }
      }

      const def = materials[name] || (!name ? materials[Object.keys(materials)[0]] : null);
      let material = null;
      if (def) {
        /* map_Kd already paints the surface; tinting it with Kd as well darkens
         * the result, so textured OBJ materials use a white base color. */
        material = { color: def.texture ? '#ffffff' : (def.color || null), texture: def.texture || null };
      }
      if (name && !materials[name] && Object.keys(materials).length) {
        warnings.push('Material "' + name + '" was not found in the MTL file; the group uses the default material color');
      }
      prims.push({
        positions: positions,
        normals: allNormals ? normals : null,
        uvs: allUVs ? uvs : null,
        indices: indices,
        material: material
      });
    }
    if (!prims.length) throw new Error('OBJ contains no triangles');
    if (Object.keys(materials).length === 0 && mtlLibs.length) {
      warnings.push('MTL material file was not provided; the OBJ uses the default material color');
    }
    return { name: filename, primitives: prims, source: 'obj', warnings: warnings };
  }

  function parseMTL(text, companions) {
    const out = {};
    let current = null;
    for (const rawLine of String(text).split(/\r?\n/)) {
      const line = rawLine.replace(/#.*$/, '').trim();
      if (!line) continue;
      const parts = line.split(/\s+/);
      const key = parts[0];
      if (key === 'newmtl') {
        current = { color: null, texture: null, textureFile: null, opacity: 1 };
        out[parts.slice(1).join(' ') || 'Material'] = current;
      } else if (!current) {
        continue;
      } else if (key === 'Kd') {
        const r = Math.round(UE.clamp(parseFloat(parts[1]) || 0, 0, 1) * 255);
        const g = Math.round(UE.clamp(parseFloat(parts[2]) || 0, 0, 1) * 255);
        const b = Math.round(UE.clamp(parseFloat(parts[3]) || 0, 0, 1) * 255);
        current.color = '#' + [r, g, b].map(function (v) { return v.toString(16).padStart(2, '0'); }).join('');
      } else if (key === 'd' || key === 'Tr') {
        current.opacity = UE.clamp(parseFloat(parts[1]) || 0, 0, 1);
      } else if (key === 'map_Kd' || key === 'map_kd' || key === 'map_Ka') {
        const rest = line.slice(key.length).trim();
        const file = rest.split(/\s+/).pop();
        if (file) current.textureFile = file;
      }
    }
    if (companions) {
      const names = companionNames(companions);
      for (const name of Object.keys(out)) {
        const def = out[name];
        if (!def.textureFile) continue;
        const found = findCompanion(names, def.textureFile);
        if (!found) continue;
        const bytes = sliceBytes(found);
        if (!bytes.length) continue;
        def.texture = { mime: mimeFromBytes(bytes), name: baseName(def.textureFile), bytes: bytes };
      }
    }
    return out;
  }

  /* --------------------------------------------------------------------- STL */
  function parseSTL(data, filename) {
    if (typeof data === 'string') return parseAsciiSTL(data, filename);
    const buffer = toArrayBuffer(data);
    if (looksLikeAsciiSTL(buffer)) return parseAsciiSTL(toText(buffer), filename);
    return parseBinarySTL(buffer, filename);
  }
  function looksLikeAsciiSTL(buffer) {
    const bytes = new Uint8Array(buffer);
    const preview = new TextDecoder('utf-8').decode(bytes.subarray(0, Math.min(256, bytes.length)));
    return /^\s*solid\b/i.test(preview) && /facet\s+normal/i.test(preview);
  }
  function parseBinarySTL(buffer, filename) {
    const dv = new DataView(buffer);
    if (buffer.byteLength < 84) throw new Error('STL file is too small');
    const count = dv.getUint32(80, true);
    if (count < 1) throw new Error('STL contains no triangles');
    if (count > MAX_TRIANGLES) throw new Error('STL contains ' + count.toLocaleString() + ' triangles; the limit is ' + MAX_TRIANGLES.toLocaleString());
    if (84 + count * 50 > buffer.byteLength) throw new Error('STL file is truncated');
    const positions = new Float32Array(count * 9);
    const normals = new Float32Array(count * 9);
    let p = 0;
    for (let i = 0; i < count; i++) {
      const off = 84 + i * 50;
      let nx = dv.getFloat32(off, true), ny = dv.getFloat32(off + 4, true), nz = dv.getFloat32(off + 8, true);
      const v = [];
      for (let k = 0; k < 3; k++) {
        v.push([
          dv.getFloat32(off + 12 + k * 12, true),
          dv.getFloat32(off + 16 + k * 12, true),
          dv.getFloat32(off + 20 + k * 12, true)
        ]);
      }
      if (!Number.isFinite(nx) || !Number.isFinite(ny) || !Number.isFinite(nz) || (nx === 0 && ny === 0 && nz === 0)) {
        const ab = [v[1][0] - v[0][0], v[1][1] - v[0][1], v[1][2] - v[0][2]];
        const ac = [v[2][0] - v[0][0], v[2][1] - v[0][1], v[2][2] - v[0][2]];
        nx = ab[1] * ac[2] - ab[2] * ac[1];
        ny = ab[2] * ac[0] - ab[0] * ac[2];
        nz = ab[0] * ac[1] - ab[1] * ac[0];
        const l = Math.hypot(nx, ny, nz) || 1;
        nx /= l; ny /= l; nz /= l;
      }
      for (let k = 0; k < 3; k++) {
        positions[p] = v[k][0]; positions[p + 1] = v[k][1]; positions[p + 2] = v[k][2];
        normals[p] = nx; normals[p + 1] = ny; normals[p + 2] = nz;
        p += 3;
      }
    }
    const indices = new Array(count * 3);
    for (let i = 0; i < indices.length; i++) indices[i] = i;
    return {
      name: filename,
      primitives: [{ positions: Array.from(positions), normals: Array.from(normals), uvs: null, indices: indices, material: null }],
      source: 'stl'
    };
  }
  function parseAsciiSTL(text, filename) {
    const lines = String(text).split(/\r?\n/);
    const positions = [], normals = [], indices = [];
    let normal = [0, 1, 0];
    let vertices = [];
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (/^facet\s+normal/i.test(line)) {
        const p = line.split(/\s+/);
        normal = [parseFloat(p[2]) || 0, parseFloat(p[3]) || 0, parseFloat(p[4]) || 0];
        vertices = [];
      } else if (/^vertex\b/i.test(line)) {
        const p = line.split(/\s+/);
        vertices.push([parseFloat(p[1]) || 0, parseFloat(p[2]) || 0, parseFloat(p[3]) || 0]);
      } else if (/^endfacet/i.test(line) && vertices.length === 3) {
        for (const v of vertices) {
          indices.push(positions.length / 3);
          positions.push(v[0], v[1], v[2]);
          normals.push(normal[0], normal[1], normal[2]);
        }
      }
    }
    if (!indices.length) throw new Error('ASCII STL contains no triangles');
    return {
      name: filename,
      primitives: [{ positions: positions, normals: normals, uvs: null, indices: indices, material: null }],
      source: 'stl'
    };
  }

  /* --------------------------------------------------------------- GLB/glTF */
  const COMPONENT_SIZE = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
  const TYPE_COUNT = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };
  function readAccessor(json, buffers, index) {
    const acc = json.accessors[index];
    if (!acc) throw new Error('glTF accessor ' + index + ' is missing');
    const n = TYPE_COUNT[acc.type] || 1;
    const out = new Float32Array((acc.count || 0) * n);
    if (acc.bufferView === undefined) return out;
    const bv = json.bufferViews[acc.bufferView];
    if (!bv) throw new Error('glTF bufferView ' + acc.bufferView + ' is missing');
    const buffer = buffers[bv.buffer];
    if (!buffer) throw new Error('glTF buffer ' + bv.buffer + ' is missing');
    const dv = new DataView(toArrayBuffer(buffer));
    const compSize = COMPONENT_SIZE[acc.componentType];
    if (!compSize) throw new Error('glTF accessor ' + index + ' uses an unsupported component type');
    const stride = bv.byteStride || compSize * n;
    let offset = (bv.byteOffset || 0) + (acc.byteOffset || 0);
    const norm = !!acc.normalized;
    const signed = acc.componentType === 5120 || acc.componentType === 5122;
    const maxVal = acc.componentType === 5120 ? 127 : acc.componentType === 5121 ? 255 :
      acc.componentType === 5122 ? 32767 : acc.componentType === 5123 ? 65535 : 4294967295;
    for (let i = 0; i < acc.count; i++) {
      for (let c = 0; c < n; c++) {
        const at = offset + c * compSize;
        let value = 0;
        if (acc.componentType === 5126) value = dv.getFloat32(at, true);
        else if (acc.componentType === 5120) value = dv.getInt8(at);
        else if (acc.componentType === 5121) value = dv.getUint8(at);
        else if (acc.componentType === 5122) value = dv.getInt16(at, true);
        else if (acc.componentType === 5123) value = dv.getUint16(at, true);
        else if (acc.componentType === 5125) value = dv.getUint32(at, true);
        if (norm) value = signed ? Math.max(value / maxVal, -1) : value / maxVal;
        out[i * n + c] = value;
      }
      offset += stride;
    }
    return out;
  }
  function quatMatrix(q, t, s) {
    const rot = q && q.length >= 4 ? q : [0, 0, 0, 1];
    let x = rot[0] || 0, y = rot[1] || 0, z = rot[2] || 0;
    let w = rot[3] === undefined ? 1 : rot[3];
    const ql = Math.hypot(x, y, z, w);
    if (ql > 1e-9) { x /= ql; y /= ql; z /= ql; w /= ql; } else { x = y = z = 0; w = 1; }
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = w * x2, wy = w * y2, wz = w * z2;
    const sx = s && s[0] !== undefined ? s[0] : 1;
    const sy = s && s[1] !== undefined ? s[1] : 1;
    const sz = s && s[2] !== undefined ? s[2] : 1;
    const m = new Float32Array(16);
    m[0] = (1 - (yy + zz)) * sx; m[1] = (xy + wz) * sx; m[2] = (xz - wy) * sx; m[3] = 0;
    m[4] = (xy - wz) * sy; m[5] = (1 - (xx + zz)) * sy; m[6] = (yz + wx) * sy; m[7] = 0;
    m[8] = (xz + wy) * sz; m[9] = (yz - wx) * sz; m[10] = (1 - (xx + yy)) * sz; m[11] = 0;
    m[12] = t && t[0] !== undefined ? t[0] : 0;
    m[13] = t && t[1] !== undefined ? t[1] : 0;
    m[14] = t && t[2] !== undefined ? t[2] : 0;
    m[15] = 1;
    return m;
  }
  function nodeMatrix(node) {
    if (node.matrix && node.matrix.length >= 16) return new Float32Array(node.matrix);
    return quatMatrix(node.rotation, node.translation, node.scale);
  }
  /* glTF node matrices may contain a mirror; reversing triangle winding keeps
   * the visible faces pointing outwards after the reflection. */
  function matrixDeterminant(m) {
    const a = m[0], b = m[1], c = m[2];
    const d = m[4], e = m[5], f = m[6];
    const g = m[8], h = m[9], i = m[10];
    return a * (e * i - f * h) - d * (b * i - c * h) + g * (b * f - c * e);
  }
  function transformNormal(nm, x, y, z) {
    return {
      x: nm[0] * x + nm[3] * y + nm[6] * z,
      y: nm[1] * x + nm[4] * y + nm[7] * z,
      z: nm[2] * x + nm[5] * y + nm[8] * z
    };
  }
  function trianglesFor(indices, mode) {
    if (mode === undefined || mode === 4) return indices;
    const out = [];
    if (mode === 5) {
      for (let i = 2; i < indices.length; i++) {
        if (i % 2 === 0) out.push(indices[i - 2], indices[i - 1], indices[i]);
        else out.push(indices[i - 1], indices[i - 2], indices[i]);
      }
      return out;
    }
    if (mode === 6) {
      for (let i = 1; i < indices.length - 1; i++) out.push(indices[0], indices[i], indices[i + 1]);
      return out;
    }
    throw new Error('glTF primitive mode ' + mode + ' is not supported (only triangles, strips and fans)');
  }
  const COMPRESSION_EXTENSIONS = {
    KHR_draco_mesh_compression: 'Draco mesh compression',
    EXT_meshopt_compression: 'meshoptimizer (meshopt) compression',
    KHR_mesh_quantization: null
  };
  function compressionError(json) {
    const used = [].concat(json.extensionsRequired || [], json.extensionsUsed || []);
    for (const name of Object.keys(COMPRESSION_EXTENSIONS)) {
      if (!COMPRESSION_EXTENSIONS[name]) continue;
      if (used.indexOf(name) >= 0) {
        return new Error('This glTF uses ' + COMPRESSION_EXTENSIONS[name] +
          ' (' + name + '), which is not supported. Re-export the model with compression disabled.');
      }
    }
    const meshes = json.meshes || [];
    for (const mesh of meshes) {
      for (const prim of mesh.primitives || []) {
        const ext = prim.extensions || {};
        if (ext.KHR_draco_mesh_compression) {
          return new Error('This glTF uses Draco mesh compression, which is not supported. Re-export the model with compression disabled.');
        }
      }
    }
    for (const bv of json.bufferViews || []) {
      if (bv.extensions && bv.extensions.EXT_meshopt_compression) {
        return new Error('This glTF uses meshoptimizer (meshopt) compression, which is not supported. Re-export the model with compression disabled.');
      }
    }
    return null;
  }

  /* Resolve a glTF texture index to compressed image bytes. Supports bufferView
   * images (the usual GLB layout), data URIs and external companion files. */
  function resolveGLTFTexture(json, buffers, index, names, cache, warnings) {
    if (index === undefined || index === null) return null;
    if (cache.has(index)) return cache.get(index);
    const def = (json.textures || [])[index];
    if (!def) { cache.set(index, null); return null; }
    if (def.source === undefined) {
      const ext = def.extensions || {};
      if (ext.KHR_texture_basisu || ext.EXT_texture_webp || ext.MSFT_texture_dds) {
        warnings.push('Texture ' + index + ' uses a compressed container that is not supported; using its base color instead');
      }
      cache.set(index, null);
      return null;
    }
    const image = (json.images || [])[def.source];
    if (!image) { cache.set(index, null); return null; }
    let bytes = null;
    let mime = image.mimeType || null;
    if (image.bufferView !== undefined) {
      const bv = (json.bufferViews || [])[image.bufferView];
      const buffer = bv && buffers[bv.buffer];
      if (bv && buffer) {
        const view = new Uint8Array(toArrayBuffer(buffer), bv.byteOffset || 0, bv.byteLength);
        bytes = sliceBytes(view);
      }
    } else if (image.uri && /^data:/i.test(image.uri)) {
      bytes = decodeDataURI(image.uri);
      mime = mime || mimeFromURI(image.uri);
    } else if (image.uri) {
      const found = findCompanion(names, image.uri);
      if (found) bytes = sliceBytes(found);
      else warnings.push('Missing texture file "' + image.uri + '"; the model keeps its base color');
      mime = mime || mimeFromURI(image.uri);
    }
    if (!bytes || !bytes.length) { cache.set(index, null); return null; }
    if (!mime || mime === 'application/octet-stream') mime = mimeFromBytes(bytes);
    const texture = { mime: mime, name: image.name || baseName(image.uri || ('texture' + index)), bytes: bytes };
    cache.set(index, texture);
    return texture;
  }

  function primitiveMaterial(json, prim, buffers, names, textureCache, warnings) {
    if (prim.material === undefined) return null;
    const mat = (json.materials || [])[prim.material];
    if (!mat) return { color: '#ffffff', texture: null };
    const pbr = mat.pbrMetallicRoughness || {};
    const specGloss = (mat.extensions && mat.extensions.KHR_materials_pbrSpecularGlossiness) || {};
    const factor = pbr.baseColorFactor || specGloss.diffuseFactor || null;
    const info = pbr.baseColorTexture || specGloss.diffuseTexture || null;
    const texture = info ? resolveGLTFTexture(json, buffers, info.index, names, textureCache, warnings) : null;
    const color = colorFromFactor(factor) || (texture ? '#ffffff' : '#ffffff');
    return { color: color, texture: texture };
  }

  function parseGLTF(json, companions, filename, glbBin) {
    if (!json || !Array.isArray(json.meshes)) throw new Error('glTF contains no meshes');
    const compression = compressionError(json);
    if (compression) throw compression;
    const names = companionNames(companions);
    const buffers = [];
    for (let i = 0; i < (json.buffers || []).length; i++) {
      const b = json.buffers[i];
      if (!b.uri) {
        if (glbBin) buffers[i] = glbBin;
        else throw new Error('glTF buffer ' + i + ' has no data (drop the matching .bin file too)');
      } else if (/^data:/i.test(b.uri)) {
        const bytes = decodeDataURI(b.uri);
        buffers[i] = bytes.buffer.slice(bytes.byteOffset || 0, (bytes.byteOffset || 0) + bytes.byteLength);
      } else {
        const found = findCompanion(names, b.uri);
        if (!found) throw new Error('Missing companion file: ' + b.uri);
        buffers[i] = typeof found === 'string' ? new TextEncoder().encode(found).buffer : toArrayBuffer(found);
      }
    }

    const primitives = [];
    const warnings = [];
    const textureCache = new Map();
    const visited = new Set();

    function addNode(nodeIndex, parentMatrix) {
      if (visited.has(nodeIndex)) return;
      visited.add(nodeIndex);
      const node = (json.nodes || [])[nodeIndex];
      if (!node) return;
      const world = UE.Mat4.multiply(parentMatrix, nodeMatrix(node));
      const mirrored = matrixDeterminant(world) < 0;
      if (node.mesh !== undefined) {
        const mesh = json.meshes[node.mesh];
        if (mesh && Array.isArray(mesh.primitives)) {
          for (const prim of mesh.primitives) {
            const attributes = prim.attributes || {};
            if (attributes.POSITION === undefined) continue;
            const pos = readAccessor(json, buffers, attributes.POSITION);
            const nor = attributes.NORMAL !== undefined ? readAccessor(json, buffers, attributes.NORMAL) : null;
            const uvData = attributes.TEXCOORD_0 !== undefined ? readAccessor(json, buffers, attributes.TEXCOORD_0) : null;
            let idx;
            if (prim.indices !== undefined) {
              const raw = readAccessor(json, buffers, prim.indices);
              idx = Array.from(raw, function (v) { return v | 0; });
            } else {
              idx = [];
              for (let i = 0; i < pos.length / 3; i++) idx.push(i);
            }
            idx = trianglesFor(idx, prim.mode);
            if (!idx.length) continue;

            const positions = [];
            const normals = [];
            const uvs = [];
            const nm = UE.Mat4.normalMatrix(world);
            for (let i = 0; i < pos.length; i += 3) {
              const p = UE.Mat4.transformPoint(world, { x: pos[i], y: pos[i + 1], z: pos[i + 2] });
              positions.push(p.x, p.y, p.z);
              if (nor && nor.length === pos.length) {
                const n = transformNormal(nm, nor[i], nor[i + 1], nor[i + 2]);
                const l = Math.hypot(n.x, n.y, n.z) || 1;
                normals.push(n.x / l, n.y / l, n.z / l);
              }
            }
            if (uvData && uvData.length >= pos.length / 3 * 2) {
              for (let i = 0; i < uvData.length; i += 2) uvs.push(uvData[i], uvData[i + 1]);
            }
            const indices = [];
            if (mirrored) {
              for (let i = 0; i + 2 < idx.length; i += 3) indices.push(idx[i], idx[i + 2], idx[i + 1]);
            } else {
              for (const v of idx) indices.push(v);
            }
            primitives.push({
              positions: positions,
              normals: normals.length === positions.length ? normals : null,
              uvs: uvs.length === positions.length / 3 * 2 ? uvs : null,
              indices: indices,
              material: primitiveMaterial(json, prim, buffers, names, textureCache, warnings)
            });
          }
        }
      }
      for (const child of node.children || []) addNode(child, world);
    }

    const sceneIndex = json.scene === undefined ? 0 : json.scene;
    const scene = (json.scenes || [])[sceneIndex];
    if (scene && Array.isArray(scene.nodes) && scene.nodes.length) {
      for (const nodeIndex of scene.nodes) addNode(nodeIndex, UE.Mat4.identity());
    } else {
      const childSet = new Set();
      for (const node of json.nodes || []) for (const child of node.children || []) childSet.add(child);
      for (let i = 0; i < (json.nodes || []).length; i++) {
        if (!childSet.has(i)) addNode(i, UE.Mat4.identity());
      }
    }
    if (!primitives.length) throw new Error('glTF contains no triangle geometry');
    return { name: filename, primitives: primitives, source: 'gltf', warnings: warnings };
  }
  function parseJSONText(text, label) {
    try {
      return JSON.parse(String(text).replace(/^\uFEFF/, '').replace(/[\u0000\u0020]+$/g, ''));
    } catch (err) {
      throw new Error((label || 'JSON') + ' is invalid: ' + err.message);
    }
  }
  function parseGLB(data, filename) {
    const buffer = toArrayBuffer(data);
    if (buffer.byteLength < 20) throw new Error('Not a valid GLB file (it is too small)');
    const dv = new DataView(buffer);
    if (dv.getUint32(0, true) !== 0x46546C67) throw new Error('Not a valid GLB file (bad magic number)');
    const version = dv.getUint32(4, true);
    if (version !== 2) throw new Error('Unsupported GLB version ' + version + '; only glTF 2.0 binary files are supported');
    const declared = dv.getUint32(8, true);
    const length = declared > 0 && declared <= buffer.byteLength ? declared : buffer.byteLength;
    let offset = 12, json = null, bin = null;
    while (offset + 8 <= length) {
      const chunkLength = dv.getUint32(offset, true);
      const chunkType = dv.getUint32(offset + 4, true);
      const start = offset + 8;
      if (start + chunkLength > buffer.byteLength) throw new Error('GLB is truncated (a chunk extends past the end of the file)');
      if (chunkType === 0x4E4F534A) {
        const text = new TextDecoder('utf-8').decode(new Uint8Array(buffer, start, chunkLength));
        json = parseJSONText(text, 'GLB JSON chunk');
      } else if (chunkType === 0x004E4942 && bin === null) {
        bin = buffer.slice(start, start + chunkLength);
      }
      offset = start + chunkLength;
    }
    if (!json) throw new Error('GLB has no JSON chunk');
    return parseGLTF(json, {}, filename, bin);
  }

  /* ------------------------------------------------------------------- public */
  const ModelIO = UE.ModelIO = {
    extensions: ['obj', 'stl', 'glb', 'gltf'],
    accept: '.obj,.stl,.glb,.gltf,.bin,.mtl,.png,.jpg,.jpeg,.webp',
    parse: function (filename, data, companions) {
      const extension = ext(filename);
      let mesh;
      if (extension === 'obj') mesh = parseOBJ(toText(data), filename, companions || {});
      else if (extension === 'stl') mesh = parseSTL(data, filename);
      else if (extension === 'glb') mesh = parseGLB(data, filename);
      else if (extension === 'gltf') mesh = parseGLTF(parseJSONText(toText(data), 'glTF JSON'), companions || {}, filename, null);
      else throw new Error('Unsupported model type ".' + extension + '". Use OBJ, STL, GLB or glTF.');
      return normalizeMesh(mesh);
    },
    parseMTL: parseMTL,
    normalizeMesh: normalizeMesh,
    smoothNormals: smoothNormals,
    meshBounds: meshBounds
  };

  return UE;
});
