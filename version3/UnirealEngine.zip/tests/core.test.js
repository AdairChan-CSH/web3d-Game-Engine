/* UnirealEngine — browser test suite
 * Open tests/index.html in any modern browser. Plain JavaScript only: the file
 * runs the engine source directly, with no package manager, build step,
 * command line or server-side code involved. */
(function () {
  'use strict';

  const UE = window.UE;
  const results = [];
  const groups = [];
  let running = false;
  let logCapture = null;

  /* ----------------------------------------------------------------- asserts */
  function preview(value, seen) {
    if (ArrayBuffer.isView(value)) return '[' + Array.prototype.join.call(value, ', ') + ']';
    if (Array.isArray(value)) return '[' + value.map(function (v) { return preview(v, seen); }).join(', ') + ']';
    if (value && typeof value === 'object') {
      seen = seen || [];
      if (seen.indexOf(value) >= 0) return '[Circular]';
      seen = seen.concat([value]);
      return '{' + Object.keys(value).sort().map(function (k) { return k + ': ' + preview(value[k], seen); }).join(', ') + '}';
    }
    return String(value);
  }
  function equal(a, b) {
    if (a === b) return true;
    if (typeof a === 'number' && typeof b === 'number') return a === b || (Number.isNaN(a) && Number.isNaN(b));
    const aArray = Array.isArray(a) || ArrayBuffer.isView(a);
    const bArray = Array.isArray(b) || ArrayBuffer.isView(b);
    if (aArray || bArray) {
      if (!aArray || !bArray || a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) if (!equal(a[i], b[i])) return false;
      return true;
    }
    if (a && b && typeof a === 'object' && typeof b === 'object') {
      const ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
      if (ka.length !== kb.length) return false;
      for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i] || !equal(a[ka[i]], b[ka[i]])) return false;
      return true;
    }
    return false;
  }
  const assert = {
    ok: function (value, message) {
      if (!value) throw new Error(message || 'expected a truthy value, got ' + preview(value));
    },
    strictEqual: function (actual, expected, message) {
      if (actual !== expected) throw new Error((message || 'not equal') + ': expected ' + preview(expected) + ', got ' + preview(actual));
    },
    notStrictEqual: function (actual, expected, message) {
      if (actual === expected) throw new Error((message || 'expected different values') + ': both are ' + preview(actual));
    },
    deepStrictEqual: function (actual, expected, message) {
      if (!equal(actual, expected)) throw new Error((message || 'deep compare failed') + ': expected ' + preview(expected) + ', got ' + preview(actual));
    },
    near: function (actual, expected, epsilon, message) {
      const eps = epsilon === undefined ? 1e-6 : epsilon;
      if (!Number.isFinite(actual) || Math.abs(actual - expected) > eps) {
        throw new Error((message || 'not close enough') + ': expected ' + expected + ' +/- ' + eps + ', got ' + actual);
      }
    },
    throws: function (fn, pattern, message) {
      let error = null;
      try { fn(); } catch (err) { error = err; }
      if (!error) throw new Error(message || 'expected the call to throw');
      if (pattern && !pattern.test(String(error.message))) {
        throw new Error((message || 'wrong error') + ': expected /' + pattern.source + '/, got "' + error.message + '"');
      }
    }
  };

  async function execute(name, fn) {
    const result = { name: name, ok: true, message: '' };
    try {
      await fn();
    } catch (err) {
      result.ok = false;
      result.message = err && err.message ? err.message : String(err);
    }
    results.push(result);
  }

  /* Groups are collected when the file loads and executed by run(). */
  function test(name, fn) {
    if (running) execute(name, fn);
    else groups.push({ name: name, fn: fn });
  }

  test('Suite loaded the engine globals', function () {
    assert.ok(UE && UE.V3 && UE.Scene && UE.ModelIO && UE.PlayMaker,
      'math, engine, model and PlayMaker scripts loaded in order');
    assert.ok(UE.Extras && UE.Textures && UE.Input && UE.cameraView,
      'extras, texture tools, input and camera helpers loaded');
    assert.ok(UE.Media && UE.Audio && UE.Video && UE.Components.AudioSource && UE.Components.VideoPlayer,
      'media helpers, audio/video runtimes and media components loaded');
  });

  /* ------------------------------------------------------------- binary helpers */
  function bytesFromBase64(text) {
    const raw = atob(text);
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  function base64FromBytes(bytes) {
    let text = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      text += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(text);
  }
  function float32Bytes(list) {
    const view = new Float32Array(list);
    return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
  }
  function uint16Bytes(list) {
    const view = new Uint16Array(list);
    return new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
  }
  function makeGLB(json, binary, version) {
    let jsonBytes = new TextEncoder().encode(JSON.stringify(json));
    const jsonPad = (4 - (jsonBytes.length % 4)) % 4;
    if (jsonPad) {
      const padded = new Uint8Array(jsonBytes.length + jsonPad);
      padded.set(jsonBytes);
      padded.fill(0x20, jsonBytes.length);
      jsonBytes = padded;
    }
    const source = binary || new Uint8Array(0);
    const binPad = (4 - (source.length % 4)) % 4;
    const bin = new Uint8Array(source.length + binPad);
    bin.set(source);
    const hasBin = source.length > 0;
    const total = 12 + 8 + jsonBytes.length + (hasBin ? 8 + bin.length : 0);
    const out = new Uint8Array(total);
    const dv = new DataView(out.buffer);
    dv.setUint32(0, 0x46546C67, true);
    dv.setUint32(4, version || 2, true);
    dv.setUint32(8, total, true);
    dv.setUint32(12, jsonBytes.length, true);
    dv.setUint32(16, 0x4E4F534A, true);
    out.set(jsonBytes, 20);
    if (hasBin) {
      const at = 20 + jsonBytes.length;
      dv.setUint32(at, bin.length, true);
      dv.setUint32(at + 4, 0x004E4942, true);
      out.set(bin, at + 8);
    }
    return out;
  }

  /* 1 x 1 opaque green PNG, used unchanged as the texture payload. */
  const PNG_1PX = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  function pngBytes() { return bytesFromBase64(PNG_1PX); }

  function wavBytes(seconds, channels, sampleRate, bits) {
    seconds = seconds || 0.5; channels = channels || 1; sampleRate = sampleRate || 8000; bits = bits || 16;
    const dataSize = Math.max(1, Math.floor(seconds * sampleRate * channels * (bits / 8)));
    const bytes = new Uint8Array(44 + dataSize);
    const dv = new DataView(bytes.buffer);
    function tag(at, text) { for (let i = 0; i < text.length; i++) bytes[at + i] = text.charCodeAt(i); }
    tag(0, 'RIFF'); dv.setUint32(4, 36 + dataSize, true); tag(8, 'WAVE');
    tag(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true);
    dv.setUint16(22, channels, true); dv.setUint32(24, sampleRate, true);
    dv.setUint32(28, sampleRate * channels * bits / 8, true);
    dv.setUint16(32, channels * bits / 8, true); dv.setUint16(34, bits, true);
    tag(36, 'data'); dv.setUint32(40, dataSize, true);
    bytes.fill(128, 44);
    return bytes;
  }
  function mp4Bytes() { return new Uint8Array([0, 0, 0, 0x18, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6F, 0x6D]); }
  function fakeParam() { return { value: 0, setValueAtTime: function (v) { this.value = v; } }; }
  function fakeNode(extra) {
    return Object.assign({
      connect: function (target) { return target; },
      disconnect: function () {}
    }, extra || {});
  }
  function fakeAudioContext() {
    const calls = { decode: [], start: 0, stop: 0, panners: [], ctx: null };
    function Ctor() {
      const self = this;
      calls.ctx = this;
      this.currentTime = 0;
      this.state = 'running';
      this.destination = fakeNode();
      this.listener = {
        positionX: fakeParam(), positionY: fakeParam(), positionZ: fakeParam(),
        forwardX: fakeParam(), forwardY: fakeParam(), forwardZ: fakeParam(),
        upX: fakeParam(), upY: fakeParam(), upZ: fakeParam()
      };
      this.decodeAudioData = function (buffer, ok) {
        calls.decode.push(buffer);
        const decoded = { duration: 0.5, sampleRate: 8000 };
        if (ok) ok(decoded);
        return Promise.resolve(decoded);
      };
      this.createBufferSource = function () {
        const node = fakeNode({
          buffer: null, loop: false, playbackRate: fakeParam(), onended: null,
          start: function () { calls.start++; },
          stop: function () { calls.stop++; if (node.onended) node.onended(); }
        });
        return node;
      };
      this.createGain = function () { return fakeNode({ gain: fakeParam() }); };
      this.createPanner = function () {
        const panner = fakeNode({
          refDistance: 1, maxDistance: 1, rolloffFactor: 1,
          panningModel: '', distanceModel: '',
          positionX: fakeParam(), positionY: fakeParam(), positionZ: fakeParam()
        });
        calls.panners.push(panner);
        return panner;
      };
      this.createMediaElementSource = function (element) { return fakeNode({ element: element }); };
      this.resume = function () { self.state = 'running'; return Promise.resolve(); };
      this.suspend = function () { self.state = 'suspended'; return Promise.resolve(); };
    }
    Ctor.calls = calls;
    return Ctor;
  }
  function fakeVideo() {
    return {
      src: '', preload: '', playsInline: false, loop: false, muted: false, volume: 1,
      playbackRate: 1, currentTime: 0, paused: true, readyState: 0,
      videoWidth: 0, videoHeight: 0, duration: 0, listeners: {},
      addEventListener: function (name, fn) {
        (this.listeners[name] = this.listeners[name] || []).push(fn);
      },
      fire: function (name) {
        for (const fn of this.listeners[name] || []) fn();
      },
      load: function () {
        this.readyState = 2; this.videoWidth = 320; this.videoHeight = 180; this.duration = 1;
        this.fire('loadedmetadata'); this.fire('loadeddata');
      },
      play: function () { this.paused = false; return Promise.resolve(); },
      pause: function () { this.paused = true; },
      removeAttribute: function () { this.src = ''; }
    };
  }

  /*
   * One triangle in a 104-byte buffer (80 bytes without UVs):
   *   positions 0..35, normals 36..71, indices 72..77, UVs 80..103, image 104..
   */
  function triangleBinary(png, withUV) {
    const size = withUV ? 104 + (png ? png.length : 0) : 80;
    const bin = new Uint8Array(size);
    bin.set(float32Bytes([0, 0, 0, 1, 0, 0, 0, 1, 0]), 0);
    bin.set(float32Bytes([0, 0, 1, 0, 0, 1, 0, 0, 1]), 36);
    bin.set(uint16Bytes([0, 1, 2]), 72);
    if (withUV) {
      bin.set(float32Bytes([0, 0, 1, 0, 0, 1]), 80);
      if (png) bin.set(png, 104);
    }
    return bin;
  }
  function triangleJSON(png) {
    const json = {
      asset: { version: '2.0' },
      scene: 0,
      scenes: [{ nodes: [0] }],
      nodes: [{ mesh: 0, name: 'Triangle' }],
      meshes: [{ primitives: [{ attributes: { POSITION: 0, NORMAL: 1 }, indices: 2 }] }],
      accessors: [
        { bufferView: 0, componentType: 5126, count: 3, type: 'VEC3' },
        { bufferView: 1, componentType: 5126, count: 3, type: 'VEC3' },
        { bufferView: 2, componentType: 5123, count: 3, type: 'SCALAR' }
      ],
      bufferViews: [
        { buffer: 0, byteOffset: 0, byteLength: 36 },
        { buffer: 0, byteOffset: 36, byteLength: 36 },
        { buffer: 0, byteOffset: 72, byteLength: 6 }
      ],
      buffers: [{ byteLength: 80 }]
    };
    if (png) {
      json.meshes[0].primitives[0].attributes.TEXCOORD_0 = 3;
      json.meshes[0].primitives[0].material = 0;
      json.accessors.push({ bufferView: 3, componentType: 5126, count: 3, type: 'VEC2' });
      json.bufferViews.push({ buffer: 0, byteOffset: 80, byteLength: 24 });
      json.bufferViews.push({ buffer: 0, byteOffset: 104, byteLength: png.length });
      json.buffers[0].byteLength = 104 + png.length;
      json.images = [{ bufferView: 4, mimeType: 'image/png' }];
      json.textures = [{ source: 0 }];
      json.materials = [{
        name: 'Painted',
        pbrMetallicRoughness: {
          baseColorFactor: [1, 1, 1, 1],
          baseColorTexture: { index: 0 }
        }
      }];
    }
    return json;
  }
  function texturedTriangleGLB(png) {
    return makeGLB(triangleJSON(png), triangleBinary(png, true));
  }

  /* ------------------------------------------------------------------- math */
  test('Vec3 arithmetic and normalization', function () {
    const a = UE.V3.create(1, 2, 3);
    const b = UE.V3.create(-4, 5, 6);
    assert.deepStrictEqual(UE.V3.add(a, b), { x: -3, y: 7, z: 9 });
    assert.deepStrictEqual(UE.V3.sub(a, b), { x: 5, y: -3, z: -3 });
    assert.deepStrictEqual(UE.V3.scale(a, 2), { x: 2, y: 4, z: 6 });
    assert.strictEqual(UE.V3.dot(a, b), 24);
    assert.deepStrictEqual(UE.V3.cross(UE.V3.create(1, 0, 0), UE.V3.create(0, 1, 0)), { x: 0, y: 0, z: 1 });
    assert.near(UE.V3.length(UE.V3.create(3, 4, 0)), 5);
    const n = UE.V3.normalize(UE.V3.create(0, 5, 0));
    assert.near(n.y, 1);
    assert.near(UE.V3.length(n), 1);
    assert.deepStrictEqual(UE.V3.normalize(UE.V3.create(0, 0, 0)), { x: 0, y: 0, z: 0 });
  });

  test('Mat4 compose, transformPoint and invert round-trip', function () {
    const position = UE.V3.create(1, 2, 3);
    const rotation = UE.V3.create(0, 90, 0);
    const scale = UE.V3.create(2, 2, 2);
    const m = UE.Mat4.compose(position, rotation, scale);
    const forward = UE.Mat4.transformPoint(m, UE.V3.create(0, 0, -1));
    assert.near(forward.x, -1, 1e-5);
    assert.near(forward.y, 2, 1e-5);
    assert.near(forward.z, 3, 1e-5);

    const p = UE.V3.create(0.5, -1.2, 2);
    const world = UE.Mat4.transformPoint(m, p);
    const back = UE.Mat4.transformPoint(UE.Mat4.invert(m), world);
    assert.near(back.x, p.x, 1e-5);
    assert.near(back.y, p.y, 1e-5);
    assert.near(back.z, p.z, 1e-5);
  });

  test('Mat4 project centers the view and rejects points behind it', function () {
    const view = UE.Mat4.lookAt(UE.V3.create(0, 0, 5), UE.V3.create(0, 0, 0), UE.V3.create(0, 1, 0));
    const proj = UE.Mat4.perspective(60, 1.5, 0.1, 100);
    const vp = UE.Mat4.multiply(proj, view);
    const center = UE.Mat4.project(vp, UE.V3.create(0, 0, 0), 800, 600);
    assert.ok(center, 'the origin is in front of the camera');
    assert.near(center.x, 400, 0.5);
    assert.near(center.y, 300, 0.5);
    assert.strictEqual(UE.Mat4.project(vp, UE.V3.create(0, 0, 10), 800, 600), null);
  });

  test('Euler rotation follows Unity ZXY order', function () {
    const q = UE.Q.fromEuler(UE.V3.create(0, 90, 0));
    const forward = UE.Q.rotate(q, UE.V3.create(0, 0, -1));
    assert.near(forward.x, -1, 1e-6);
    assert.near(forward.y, 0, 1e-6);
    assert.near(forward.z, 0, 1e-6);
    const pitch = UE.Q.rotate(UE.Q.fromEuler(UE.V3.create(90, 0, 0)), UE.V3.create(0, 0, -1));
    assert.near(pitch.y, 1, 1e-6, 'a +X pitch rotates the -Z forward vector toward +Y');
  });

  test('Ray/AABB intersection and camera ray', function () {
    const box = UE.AABB.fromCenterSize(UE.V3.create(0, 1, 0), UE.V3.create(2, 2, 2));
    const hit = UE.Ray.intersectAABB(UE.V3.create(0, 1, 5), UE.V3.create(0, 0, -1), box);
    assert.near(hit, 4);
    assert.strictEqual(UE.Ray.intersectAABB(UE.V3.create(5, 5, 5), UE.V3.create(0, 0, -1), box), null);
    const ray = UE.Ray.fromCamera(UE.V3.create(0, 0, 5), UE.V3.create(0, 0, -1), UE.V3.create(0, 1, 0), 60, 1, 0, 0);
    assert.near(ray.dir.x, 0, 1e-6);
    assert.near(ray.dir.y, 0, 1e-6);
    assert.near(ray.dir.z, -1, 1e-6);
  });

  test('AABB overlap and minimum separation', function () {
    const a = UE.AABB.fromCenterSize(UE.V3.create(0, 0, 0), UE.V3.create(2, 2, 2));
    const b = UE.AABB.fromCenterSize(UE.V3.create(1.5, 0, 0), UE.V3.create(2, 2, 2));
    assert.strictEqual(UE.AABB.overlaps(a, b), true);
    const sep = UE.AABB.separation(a, b);
    assert.strictEqual(sep.axis, 'x');
    assert.near(sep.pen, 0.5);
    assert.strictEqual(sep.sign, -1);
    const far = UE.AABB.fromCenterSize(UE.V3.create(4, 0, 0), UE.V3.create(2, 2, 2));
    assert.strictEqual(UE.AABB.overlaps(a, far), false);
    assert.strictEqual(UE.AABB.separation(a, far), null);
  });

  /* ------------------------------------------------------------------ scene */
  test('GameObject components are unique except Script', function () {
    const go = new UE.GameObject('Thing');
    const first = go.addComponent('MeshRenderer');
    const second = go.addComponent('MeshRenderer');
    assert.strictEqual(first, second, 'one renderer per object');
    assert.strictEqual(go.getComponents('MeshRenderer').length, 1);
    const s1 = go.addComponent('Script');
    const s2 = go.addComponent('Script');
    assert.notStrictEqual(s1, s2, 'scripts stack');
    assert.strictEqual(go.getComponents('Script').length, 2);
    assert.strictEqual(UE.componentLabel('MeshRenderer'), 'Mesh Renderer');
    assert.throws(function () { go.addComponent('Nope'); }, /Unknown component type/);
  });

  test('Parenting keeps world transforms consistent', function () {
    const parent = UE.createEmpty('Parent', { x: 10, y: 0, z: 0 });
    const child = UE.createEmpty('Child', { x: 1, y: 2, z: 3 });
    child.setParent(parent);
    assert.strictEqual(child.transform.parent, parent);
    assert.deepStrictEqual(child.transform.worldPosition(), { x: 11, y: 2, z: 3 });
    assert.strictEqual(parent.children().length, 1);
    child.setParent(null);
    assert.deepStrictEqual(child.transform.worldPosition(), { x: 1, y: 2, z: 3 });
    assert.strictEqual(parent.children().length, 0);
  });

  test('Primitive helper creates mesh + collider of the right size', function () {
    const cube = UE.createPrimitive('Crate', 'cube', '#ff0000', { x: 1, y: 2, z: 3 });
    const mr = cube.getComponent('MeshRenderer');
    const collider = cube.getComponent('Collider');
    assert.strictEqual(mr.primitive, 'cube');
    assert.strictEqual(mr.color, '#ff0000');
    assert.deepStrictEqual(collider.size, { x: 1, y: 1, z: 1 });
    assert.deepStrictEqual(cube.transform.position, { x: 1, y: 2, z: 3 });
    const plane = UE.createPrimitive('Floor', 'plane');
    assert.deepStrictEqual(plane.getComponent('Collider').size, { x: 10, y: 0.1, z: 10 });
    const sphere = UE.createPrimitive('Ball', 'sphere');
    assert.strictEqual(sphere.getComponent('Collider').shape, 'sphere');
    assert.strictEqual(UE.primitiveLabel('cone'), 'Cone');
  });

  test('Scene JSON round-trips ids, components and hierarchy', function () {
    const scene = new UE.Scene('Round Trip');
    const parent = UE.createPrimitive('Parent', 'cube', '#112233', { x: 1, y: 0, z: 0 });
    const child = UE.createPrimitive('Child', 'sphere', '#445566', { x: 2, y: 0, z: 0 });
    scene.add(parent);
    scene.add(child);
    child.setParent(parent);
    child.addComponent('Script', { name: 'spin', code: 'self.transform.rotation.y += 90 * dt;' });
    const light = UE.createLight('Sun Light', 'sun');
    scene.add(light);

    const json = JSON.parse(JSON.stringify(scene.toJSON()));
    const restored = UE.Scene.fromJSON(json);
    assert.strictEqual(restored.name, 'Round Trip');
    assert.strictEqual(restored.objects.length, 3);
    const restoredParent = restored.find('Parent');
    const restoredChild = restored.find('Child');
    assert.strictEqual(restoredParent.id, parent.id);
    assert.strictEqual(restoredChild.transform.parent, restoredParent);
    assert.deepStrictEqual(restoredChild.transform.worldPosition(), { x: 3, y: 0, z: 0 });
    assert.strictEqual(restoredChild.getComponent('Script').code, 'self.transform.rotation.y += 90 * dt;');
    assert.strictEqual(restored.find('Sun Light').getComponent('Light').type, 'sun');
    assert.deepStrictEqual(restored.sun, scene.sun);
    assert.deepStrictEqual(restored.sky, scene.sky);
  });

  test('Scene.fromJSON survives missing optional fields', function () {
    const scene = UE.Scene.fromJSON({ objects: [{ name: 'Bare' }, { name: 'Other', id: 'fixed', active: false }] });
    assert.strictEqual(scene.name, 'Untitled');
    const bare = scene.find('Bare');
    assert.strictEqual(bare.active, true);
    assert.strictEqual(bare.tag, 'Untagged');
    assert.deepStrictEqual(bare.transform.position, { x: 0, y: 0, z: 0 });
    assert.deepStrictEqual(bare.transform.scale, { x: 1, y: 1, z: 1 });
    assert.strictEqual(scene.get('fixed').active, false);
    assert.throws(function () { UE.Scene.fromJSON(null); }, /Not a UnirealEngine scene file/);
  });

  /* ---------------------------------------------------------------- physics */
  test('A dynamic box falls and settles on the ground plane', function () {
    const scene = new UE.Scene('Fall');
    const box = UE.createPrimitive('Box', 'cube');
    box.transform.position.y = 3;
    const rb = box.addComponent('Rigidbody', { restitution: 0 });
    assert.strictEqual(rb.useGravity, true);
    scene.add(box);
    for (let i = 0; i < 180; i++) UE.Physics.step(scene, 1 / 60);
    assert.near(box.transform.position.y, 0.5, 0.02);
    assert.near(rb.velocity.y, 0, 1e-6);
  });

  test('A dynamic box rests on a static platform', function () {
    const scene = new UE.Scene('Platform');
    const platform = UE.createPrimitive('Platform', 'cube');
    platform.transform.position.y = 1;
    scene.add(platform);
    const box = UE.createPrimitive('Box', 'cube');
    box.transform.position.y = 3;
    box.addComponent('Rigidbody', { restitution: 0 });
    scene.add(box);
    for (let i = 0; i < 240; i++) UE.Physics.step(scene, 1 / 60);
    assert.near(box.transform.position.y, 2, 0.03);
  });

  test('Kinematic bodies are not moved by gravity', function () {
    const scene = new UE.Scene('Kinematic');
    const box = UE.createPrimitive('Box', 'cube');
    box.transform.position.y = 5;
    box.addComponent('Rigidbody', { isKinematic: true });
    scene.add(box);
    for (let i = 0; i < 60; i++) UE.Physics.step(scene, 1 / 60);
    assert.strictEqual(box.transform.position.y, 5);
  });

  test('Two falling boxes end up separated', function () {
    const scene = new UE.Scene('Stack');
    const a = UE.createPrimitive('A', 'cube');
    a.transform.position = { x: -0.2, y: 0.6, z: 0 };
    a.addComponent('Rigidbody', { restitution: 0 });
    const b = UE.createPrimitive('B', 'cube');
    b.transform.position = { x: 0.2, y: 2, z: 0 };
    b.addComponent('Rigidbody', { restitution: 0 });
    scene.add(a);
    scene.add(b);
    for (let i = 0; i < 300; i++) UE.Physics.step(scene, 1 / 60);
    const ba = UE.Physics.bounds(a), bb = UE.Physics.bounds(b);
    assert.strictEqual(UE.AABB.overlaps(ba, bb), false, 'the solver pushes overlapping boxes apart');
    const spacing = Math.max(Math.abs(ba.cx - bb.cx), Math.abs(ba.cy - bb.cy), Math.abs(ba.cz - bb.cz));
    assert.ok(spacing >= 0.95, 'their centres end up at least one box apart on some axis');
  });

  test('Mass-weighted contacts move the lighter body farther', function () {
    const scene = new UE.Scene('Mass');
    const light = UE.createPrimitive('Light', 'cube');
    light.transform.position = { x: -0.4, y: 1, z: 0 };
    light.addComponent('Rigidbody', { useGravity: false, mass: 1, restitution: 0 });
    const heavy = UE.createPrimitive('Heavy', 'cube');
    heavy.transform.position = { x: 0.4, y: 1, z: 0 };
    heavy.addComponent('Rigidbody', { useGravity: false, mass: 4, restitution: 0 });
    scene.add(light);
    scene.add(heavy);
    const lightStart = light.transform.position.x, heavyStart = heavy.transform.position.x;
    UE.Physics.step(scene, 1 / 60);
    const lightMove = Math.abs(light.transform.position.x - lightStart);
    const heavyMove = Math.abs(heavy.transform.position.x - heavyStart);
    assert.ok(lightMove > 0 && heavyMove > 0, 'both bodies are pushed apart');
    assert.near(lightMove / heavyMove, 4, 0.05, 'positional correction follows inverse mass');
  });

  test('Trigger colliders report contacts but do not push bodies apart', function () {
    const scene = new UE.Scene('Trigger');
    const pad = UE.createPrimitive('Pad', 'cube');
    pad.transform.position = { x: 0, y: 1, z: 0 };
    scene.add(pad);
    const sensor = UE.createPrimitive('Sensor', 'cube');
    sensor.transform.position = { x: 0, y: 1, z: 0 };
    sensor.getComponent('Collider').isTrigger = true;
    sensor.addComponent('Rigidbody', { useGravity: false, restitution: 0 });
    scene.add(sensor);
    const start = sensor.transform.position.y;
    for (let i = 0; i < 10; i++) UE.Physics.step(scene, 1 / 60);
    assert.strictEqual(sensor.transform.position.y, start, 'the trigger is not separated from the pad');
    assert.ok(scene._pmContacts && scene._pmContacts.size === 1, 'the contact pair is still reported to PlayMaker');
  });

  test('Gravity scale and freeze-position constraints are honoured', function () {
    const scene = new UE.Scene('Constraints');
    const frozen = UE.createPrimitive('Frozen', 'cube');
    frozen.transform.position = { x: 0, y: 4, z: 0 };
    const rb = frozen.addComponent('Rigidbody', {
      useGravity: true,
      freezePosition: { x: false, y: true, z: false }
    });
    scene.add(frozen);
    for (let i = 0; i < 60; i++) UE.Physics.step(scene, 1 / 60);
    assert.strictEqual(frozen.transform.position.y, 4);
    assert.strictEqual(rb.velocity.y, 0);

    const floating = UE.createPrimitive('Floating', 'cube');
    floating.transform.position = { x: 4, y: 4, z: 0 };
    const frb = floating.addComponent('Rigidbody', { useGravity: true, gravityScale: 0 });
    scene.add(floating);
    for (let i = 0; i < 30; i++) UE.Physics.step(scene, 1 / 60);
    assert.strictEqual(floating.transform.position.y, 4);
    assert.strictEqual(frb.velocity.y, 0);
  });

  test('Collider friction slows a sliding body', function () {
    function slide(friction) {
      const scene = new UE.Scene('Friction');
      const box = UE.createPrimitive('Slider', 'cube');
      box.transform.position = { x: 0, y: 0.5, z: 0 };
      box.getComponent('Collider').friction = friction;
      const rb = box.addComponent('Rigidbody', { useGravity: true, restitution: 0, drag: 0 });
      rb.velocity.x = 4;
      scene.add(box);
      for (let i = 0; i < 90; i++) UE.Physics.step(scene, 1 / 60);
      return box.transform.position.x;
    }
    const ice = slide(0);
    const grip = slide(1);
    assert.ok(ice > grip + 3, 'high friction stops the body much sooner than frictionless ice');
    assert.ok(grip >= 0 && grip < ice, 'the gripping body still moves forward');
  });

  test('Tag helpers list built-ins, custom tags and usage counts', function () {
    const scene = new UE.Scene('Tag helper');
    const player = UE.createEmpty('Player');
    player.tag = 'Player';
    const bossA = UE.createEmpty('Boss A');
    bossA.tag = 'Boss';
    const bossB = UE.createEmpty('Boss B');
    bossB.tag = 'Boss';
    scene.add(player);
    scene.add(bossA);
    scene.add(bossB);
    assert.deepStrictEqual(UE.Tags.list(scene), ['Untagged', 'Player', 'Enemy', 'Pickup', 'Light', 'Boss']);
    assert.strictEqual(UE.Tags.normalize('  Boss  '), 'Boss');
    assert.strictEqual(UE.Tags.normalize(''), 'Untagged');
    assert.strictEqual(UE.Tags.counts(scene).Boss, 2);
    assert.strictEqual(UE.Tags.counts(scene).Player, 1);
  });

  test('Unity-style physics fields serialize with the scene', function () {
    const scene = new UE.Scene('Physics fields');
    const body = UE.createPrimitive('Body', 'cube');
    scene.add(body);
    const collider = body.getComponent('Collider');
    collider.isTrigger = true;
    collider.friction = 0.12;
    body.addComponent('Rigidbody', {
      gravityScale: 0.5,
      freezePosition: { x: true, y: false, z: false }
    });
    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    const rc = restored.find('Body').getComponent('Collider');
    const rr = restored.find('Body').getComponent('Rigidbody');
    assert.strictEqual(rc.isTrigger, true);
    assert.near(rc.friction, 0.12);
    assert.near(rr.gravityScale, 0.5);
    assert.strictEqual(rr.freezePosition.x, true);
    assert.strictEqual(rr.freezePosition.y, false);
  });

  /* ---------------------------------------------------------------- scripts */
  test('ScriptSystem runs scripts and keeps self.data between frames', function () {
    const scene = new UE.Scene('Scripts');
    const go = UE.createEmpty('Runner');
    go.addComponent('Script', {
      name: 'counter',
      code: 'self.data.n = (self.data.n || 0) + 1;\nself.transform.position.x = self.data.n;'
    });
    scene.add(go);
    for (let i = 0; i < 3; i++) UE.ScriptSystem.update(scene, 1 / 60, i / 60);
    assert.strictEqual(go.data.n, 3);
    assert.strictEqual(go.transform.position.x, 3);
  });

  test('A broken script logs an error instead of throwing', function () {
    const scene = new UE.Scene('Broken');
    const go = UE.createEmpty('Broken Runner');
    go.addComponent('Script', { name: 'broken', code: 'throw new Error("boom");' });
    scene.add(go);
    logCapture = [];
    UE.ScriptSystem.update(scene, 1 / 60, 0);
    assert.ok(logCapture.some(function (m) { return /boom/.test(m); }), 'the thrown message reaches the log');

    const compile = UE.createEmpty('Compile Error');
    compile.addComponent('Script', { name: 'bad', code: 'this is not javascript' });
    scene.add(compile);
    UE.ScriptSystem.update(scene, 1 / 60, 1 / 60);
    assert.ok(logCapture.some(function (m) { return /failed to compile/.test(m); }), 'compile errors are logged once');
  });

  test('Inactive objects skip scripts and physics', function () {
    const scene = new UE.Scene('Inactive');
    const go = UE.createEmpty('Sleeping');
    go.active = false;
    go.transform.position.y = 4;
    go.addComponent('Rigidbody', { restitution: 0 });
    go.addComponent('Script', { name: 'count', code: 'self.data.n = (self.data.n || 0) + 1;' });
    scene.add(go);
    for (let i = 0; i < 60; i++) UE.Physics.step(scene, 1 / 60);
    UE.ScriptSystem.update(scene, 1 / 60, 0);
    assert.strictEqual(go.transform.position.y, 4);
    assert.strictEqual(go.data.n, undefined);
  });

  /* ----------------------------------------------------------------- models */
  test('OBJ import reads MTL colors and normalizes the mesh', function () {
    const obj = [
      'mtllib crate.mtl',
      'usemtl Paint',
      'v 0 0 0',
      'v 4 0 0',
      'v 4 3 0',
      'v 0 3 0',
      'vn 0 0 1',
      'f 1//1 2//1 3//1',
      'f 1//1 3//1 4//1'
    ].join('\n');
    const mtl = 'newmtl Paint\nKd 0.2 0.6 1.0\n';
    const mesh = UE.ModelIO.parse('crate.obj', obj, { 'crate.mtl': mtl });
    assert.strictEqual(mesh.name, 'crate');
    assert.strictEqual(mesh.triangles, 2);
    assert.strictEqual(mesh.vertexCount, 4);
    assert.strictEqual(mesh.color, '#3399ff', 'MTL Kd becomes a hex material color');
    assert.strictEqual(mesh.positions.length, 12, 'two triangles reuse four unique corners');
    assert.strictEqual(mesh.normals.length, mesh.positions.length);
    const bounds = mesh.bounds;
    assert.near(bounds.min[1], 0, 1e-6, 'the model sits on y = 0');
    assert.near(Math.max(bounds.max[0] - bounds.min[0], bounds.max[1] - bounds.min[1]), 2, 1e-5);
  });

  test('ASCII STL import builds triangles and valid normals', function () {
    const stl = [
      'solid tri',
      'facet normal 0 0 1',
      'outer loop',
      'vertex 0 0 0',
      'vertex 2 0 0',
      'vertex 0 2 0',
      'endloop',
      'endfacet',
      'endsolid tri'
    ].join('\n');
    const mesh = UE.ModelIO.parse('tri.stl', stl);
    assert.strictEqual(mesh.triangles, 1);
    assert.strictEqual(mesh.vertexCount, 3);
    assert.strictEqual(mesh.positions.length, 9);
    assert.strictEqual(mesh.normals.length, 9);
    assert.near(mesh.normals[2], 1, 1e-6);
    assert.strictEqual(mesh.primitives.length, 1);
  });

  test('GLB import accepts buffers/views and nodes without a transform', function () {
    const glb = makeGLB(triangleJSON(null), triangleBinary(null, false));
    const mesh = UE.ModelIO.parse('triangle.glb', glb);
    assert.strictEqual(mesh.name, 'triangle');
    assert.strictEqual(mesh.triangles, 1);
    assert.strictEqual(mesh.vertexCount, 3);
    assert.strictEqual(mesh.primitives.length, 1);
    assert.near(mesh.bounds.min[1], 0, 1e-6);
    assert.near(mesh.bounds.max[0] - mesh.bounds.min[0], 2, 1e-5);
  });

  test('glTF import reads data URIs and external .bin companions', function () {
    const bin = triangleBinary(null, false);
    const json = triangleJSON(null);

    const dataJSON = JSON.parse(JSON.stringify(json));
    dataJSON.buffers[0] = { uri: 'data:application/octet-stream;base64,' + base64FromBytes(bin), byteLength: bin.length };
    const viaData = UE.ModelIO.parse('data-triangle.gltf', JSON.stringify(dataJSON));
    assert.strictEqual(viaData.triangles, 1);

    const fileJSON = JSON.parse(JSON.stringify(json));
    fileJSON.buffers[0] = { uri: 'tri.bin', byteLength: bin.length };
    const viaFile = UE.ModelIO.parse('external.gltf', JSON.stringify(fileJSON), { 'tri.bin': bin });
    assert.strictEqual(viaFile.triangles, 1);
    assert.throws(function () {
      UE.ModelIO.parse('external.gltf', JSON.stringify(fileJSON), {});
    }, /Missing companion file: tri\.bin/);
  });

  test('Draco and meshopt compression are rejected clearly', function () {
    const bin = triangleBinary(null, false);
    const draco = triangleJSON(null);
    draco.extensionsRequired = ['KHR_draco_mesh_compression'];
    assert.throws(function () {
      UE.ModelIO.parse('compressed.glb', makeGLB(draco, bin));
    }, /Draco mesh compression.*not supported/);
    const meshopt = triangleJSON(null);
    meshopt.extensionsUsed = ['EXT_meshopt_compression'];
    assert.throws(function () {
      UE.ModelIO.parse('compressed.gltf', JSON.stringify(meshopt));
    }, /meshoptimizer.*not supported/);
  });

  test('GLB version 1 and unknown extensions are rejected', function () {
    const glb = makeGLB(triangleJSON(null), triangleBinary(null, false), 1);
    assert.throws(function () { UE.ModelIO.parse('old.glb', glb); }, /Unsupported GLB version 1/);
    assert.throws(function () { UE.ModelIO.parse('model.fbx', 'nope'); }, /Unsupported model type "\.fbx"/);
  });

  test('GLB import resolves base-color textures and TEXCOORD_0', function () {
    const png = pngBytes();
    const mesh = UE.ModelIO.parse('textured.glb', texturedTriangleGLB(png));
    assert.strictEqual(mesh.primitives.length, 1);
    assert.strictEqual(mesh.hasTexture, true);
    const prim = mesh.primitives[0];
    assert.ok(prim.material.texture, 'the material carries the embedded image');
    assert.strictEqual(prim.material.texture.mime, 'image/png');
    assert.deepStrictEqual(Array.from(prim.material.texture.bytes), Array.from(png), 'image bytes are preserved exactly');
    assert.strictEqual(prim.material.color, '#ffffff', 'the texture is not tinted by the base-color factor');
    assert.deepStrictEqual(Array.from(prim.uvs), [0, 0, 1, 0, 0, 1]);
    assert.strictEqual(mesh.uvs.length, 6);
  });

  test('glTF resolves data-URI and external base-color textures', function () {
    const png = pngBytes();
    const bin = triangleBinary(png, true);

    const dataJSON = triangleJSON(png);
    dataJSON.buffers[0] = { uri: 'data:application/octet-stream;base64,' + base64FromBytes(bin), byteLength: bin.length };
    dataJSON.images = [{ uri: 'data:image/png;base64,' + PNG_1PX }];
    const viaData = UE.ModelIO.parse('data-texture.gltf', JSON.stringify(dataJSON));
    assert.strictEqual(viaData.primitives[0].material.texture.mime, 'image/png');
    assert.deepStrictEqual(Array.from(viaData.primitives[0].material.texture.bytes), Array.from(png));

    const fileJSON = triangleJSON(png);
    fileJSON.buffers[0] = { uri: 'scene.bin', byteLength: bin.length };
    fileJSON.images = [{ uri: 'textures/albedo.png' }];
    const viaFile = UE.ModelIO.parse('external-texture.gltf', JSON.stringify(fileJSON), {
      'scene.bin': bin,
      'albedo.png': png
    });
    assert.strictEqual(viaFile.primitives[0].material.texture.name, 'albedo.png');
    assert.deepStrictEqual(Array.from(viaFile.primitives[0].material.texture.bytes), Array.from(png));

    const missing = UE.ModelIO.parse('missing-texture.gltf', JSON.stringify(fileJSON), { 'scene.bin': bin });
    assert.strictEqual(missing.hasTexture, false);
    assert.ok(missing.warnings.some(function (w) { return /Missing texture file/.test(w); }));
  });

  test('OBJ import loads map_Kd textures and flips OBJ UVs', function () {
    const png = pngBytes();
    const obj = [
      'mtllib crate.mtl',
      'usemtl Paint',
      'v 0 0 0',
      'v 2 0 0',
      'v 2 2 0',
      'v 0 2 0',
      'vt 0 0',
      'vt 1 0',
      'vt 1 1',
      'vt 0 1',
      'f 1/1 2/2 3/3',
      'f 1/1 3/3 4/4'
    ].join('\n');
    const mtl = 'newmtl Paint\nKd 0.9 0.1 0.1\nmap_Kd crate.png\n';
    const mesh = UE.ModelIO.parse('crate.obj', obj, { 'crate.mtl': mtl, 'crate.png': png });
    assert.strictEqual(mesh.hasTexture, true);
    assert.strictEqual(mesh.primitives.length, 1);
    const prim = mesh.primitives[0];
    assert.strictEqual(prim.material.texture.mime, 'image/png');
    assert.strictEqual(prim.material.texture.name, 'crate.png');
    assert.strictEqual(prim.material.color, '#ffffff', 'the texture is not darkened by Kd');
    assert.deepStrictEqual(prim.uvs.slice(0, 4), [0, 1, 1, 1], 'OBJ V is flipped for WebGL');
    assert.deepStrictEqual(prim.uvs.slice(4, 6), [1, 0]);
    assert.strictEqual(mesh.uvs.length, 8, 'flat UVs are concatenated for compatibility');

    const untextured = UE.ModelIO.parse('crate.obj', obj, { 'crate.mtl': 'newmtl Paint\nKd 0.9 0.1 0.1\n' });
    assert.strictEqual(untextured.hasTexture, false);
    assert.strictEqual(untextured.color, '#e61a1a');
  });

  test('multi-material OBJ imports one primitive per usemtl group', function () {
    const obj = [
      'mtllib two.mtl',
      'v 0 0 0',
      'v 1 0 0',
      'v 1 1 0',
      'v 3 0 0',
      'v 4 0 0',
      'v 4 1 0',
      'usemtl Red',
      'f 1 2 3',
      'usemtl Blue',
      'f 4 5 6'
    ].join('\n');
    const mtl = 'newmtl Red\nKd 1 0 0\n\nnewmtl Blue\nKd 0 0 1\n';
    const mesh = UE.ModelIO.parse('two.obj', obj, { 'two.mtl': mtl });
    assert.strictEqual(mesh.primitives.length, 2);
    assert.strictEqual(mesh.triangles, 2);
    assert.deepStrictEqual(mesh.primitives.map(function (p) { return p.material.color; }), ['#ff0000', '#0000ff']);
    assert.near(mesh.bounds.max[0] - mesh.bounds.min[0], 2, 1e-5, 'the whole model is fitted, not each primitive');
  });

  test('Model limits are raised 99 times', function () {
    assert.strictEqual(UE.MODEL_LIMITS.maxVertices, 65535 * 99);
    assert.strictEqual(UE.MODEL_LIMITS.maxTriangles, 80000 * 99);
    assert.strictEqual(UE.MODEL_LIMITS.maxVertices, 6487965);
    assert.strictEqual(UE.MODEL_LIMITS.maxTriangles, 7920000);
  });

  /* -------------------------------------------------------------- asset store */
  test('AssetStore encodes meshes to base64 and decodes them back', function () {
    const positions = [0, 0, 0, 1, 0, 0, 0, 1, 0];
    const normals = [0, 0, 1, 0, 0, 1, 0, 0, 1];
    const uvs = [0, 0, 1, 0, 0, 1];
    const indices = [0, 1, 2];
    const id = UE.AssetStore.add({
      positions: positions, normals: normals, uvs: uvs, indices: indices,
      bounds: { min: [0, 0, 0], max: [1, 1, 0] }
    }, 'Base64 Triangle ' + Math.random().toString(36).slice(2));
    const meta = UE.AssetStore.meta(id);
    assert.strictEqual(meta.vertexCount, 3);
    assert.strictEqual(meta.triangleCount, 1);
    assert.strictEqual(meta.hasTexture, false);
    assert.strictEqual(meta.primitives, 1);
    const decoded = UE.AssetStore.get(id);
    assert.strictEqual(decoded.prims.length, 1);
    for (let i = 0; i < positions.length; i++) assert.near(decoded.positions[i], positions[i]);
    for (let i = 0; i < normals.length; i++) assert.near(decoded.normals[i], normals[i]);
    assert.deepStrictEqual(Array.from(decoded.uvs), uvs);
    assert.deepStrictEqual(Array.from(decoded.indices), indices);
    assert.strictEqual(decoded.data.length, 24, 'interleaved position + normal + UV buffer');
    delete UE.AssetStore.items[id];
    delete UE.AssetStore.decoded[id];
  });

  test('AssetStore round-trips primitives and base-color textures', function () {
    const png = pngBytes();
    const positions = [0, 0, 0, 1, 0, 0, 0, 1, 0];
    const normals = [0, 0, 1, 0, 0, 1, 0, 0, 1];
    const uvs = [0, 0, 1, 0, 0, 1];
    const name = 'Textured Primitives ' + Math.random().toString(36).slice(2);
    const id = UE.AssetStore.add({
      name: name,
      primitives: [
        {
          positions: positions, normals: normals, uvs: uvs, indices: [0, 1, 2],
          material: { color: '#ffffff', texture: { mime: 'image/png', name: 'albedo.png', bytes: png } }
        },
        {
          positions: [2, 0, 0, 3, 0, 0, 2, 1, 0], normals: normals, uvs: uvs, indices: [0, 1, 2],
          material: { color: '#ff8800', texture: null }
        }
      ]
    }, name);
    const meta = UE.AssetStore.meta(id);
    assert.strictEqual(meta.primitives, 2);
    assert.strictEqual(meta.hasTexture, true);
    assert.strictEqual(meta.color, '#ffffff');
    assert.strictEqual(meta.vertexCount, 6);
    assert.strictEqual(meta.triangleCount, 2);

    const decoded = UE.AssetStore.get(id);
    assert.strictEqual(decoded.prims.length, 2);
    assert.strictEqual(decoded.prims[0].data.length, 24);
    assert.deepStrictEqual(Array.from(decoded.prims[0].uvs), uvs);
    assert.strictEqual(decoded.prims[0].material.texture.mime, 'image/png');
    assert.deepStrictEqual(Array.from(decoded.prims[0].material.texture.bytes), Array.from(png));
    assert.strictEqual(decoded.prims[1].material.color, '#ff8800');
    assert.strictEqual(decoded.prims[1].material.texture, null);

    const json = UE.AssetStore.toJSON([id]);
    const savedItems = UE.AssetStore.items;
    const savedDecoded = UE.AssetStore.decoded;
    UE.AssetStore.items = {};
    UE.AssetStore.decoded = {};
    try {
      assert.ok(typeof json[id].prims[0].p === 'string');
      assert.ok(typeof json[id].prims[0].i === 'string');
      assert.ok(typeof json[id].prims[0].material.texture.t === 'string');
      UE.AssetStore.fromJSON(JSON.parse(JSON.stringify(json)));
      const again = UE.AssetStore.get(id);
      assert.strictEqual(again.prims.length, 2);
      assert.deepStrictEqual(Array.from(again.prims[0].material.texture.bytes), Array.from(png));
      assert.strictEqual(again.prims[0].material.color, '#ffffff');
    } finally {
      UE.AssetStore.items = savedItems;
      UE.AssetStore.decoded = savedDecoded;
    }
  });

  test('AssetStore migrates flat legacy assets to primitives', function () {
    const legacy = {
      name: 'Legacy Triangle',
      vertexCount: 3,
      triangleCount: 1,
      bounds: { min: [0, 0, 0], max: [1, 1, 0] },
      p: base64FromBytes(float32Bytes([0, 0, 0, 1, 0, 0, 0, 1, 0])),
      n: base64FromBytes(float32Bytes([0, 0, 1, 0, 0, 1, 0, 0, 1])),
      i: base64FromBytes(uint16Bytes([0, 1, 2])),
      indexType: 16,
      color: '#112233'
    };
    const savedItems = UE.AssetStore.items;
    const savedDecoded = UE.AssetStore.decoded;
    UE.AssetStore.items = {};
    UE.AssetStore.decoded = {};
    try {
      UE.AssetStore.fromJSON({ legacy: legacy });
      const meta = UE.AssetStore.meta('legacy');
      assert.strictEqual(meta.name, 'Legacy Triangle');
      assert.strictEqual(meta.primitives, 1);
      const decoded = UE.AssetStore.get('legacy');
      assert.strictEqual(decoded.prims.length, 1);
      assert.deepStrictEqual(Array.from(decoded.indices), [0, 1, 2]);
      assert.deepStrictEqual(Array.from(decoded.uvs), [0, 0, 0, 0, 0, 0], 'legacy meshes get zero UVs');
      assert.strictEqual(decoded.prims[0].material.color, '#112233');
    } finally {
      UE.AssetStore.items = savedItems;
      UE.AssetStore.decoded = savedDecoded;
    }
  });

  test('Scene JSON embeds referenced meshes and omits unreferenced ones', function () {
    const positions = [0, 0, 0, 1, 0, 0, 0, 1, 0];
    const normals = [0, 0, 1, 0, 0, 1, 0, 0, 1];
    const used = UE.AssetStore.add({
      positions: positions, normals: normals, indices: [0, 1, 2],
      bounds: { min: [0, 0, 0], max: [1, 1, 0] }
    }, 'Used Mesh ' + Math.random().toString(36).slice(2));
    const unused = UE.AssetStore.add({
      positions: positions, normals: normals, indices: [0, 1, 2],
      bounds: { min: [0, 0, 0], max: [1, 1, 0] }
    }, 'Unused Mesh ' + Math.random().toString(36).slice(2));
    const scene = new UE.Scene('Assets');
    const model = UE.createModel('Model', used, { x: 0, y: 0, z: 0 }, '#ffffff');
    scene.add(model);
    try {
      const full = scene.toJSON();
      assert.ok(full.assets[used], 'the referenced mesh is embedded');
      assert.strictEqual(full.assets[unused], undefined, 'unused meshes stay out of the file');
      assert.ok(full.assets[used].prims && full.assets[used].prims.length === 1, 'primitives are embedded');
      assert.ok(typeof full.assets[used].prims[0].p === 'string' && typeof full.assets[used].prims[0].i === 'string');
      assert.strictEqual(scene.toJSON({ assets: false }).assets, undefined);
      assert.strictEqual(scene.toJSON(false).assets, undefined);

      const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(full)));
      const mr = restored.objects[0].getComponent('MeshRenderer');
      assert.strictEqual(mr.meshId, used);
      assert.ok(restored.objects[0].getComponent('Collider'), 'imported models get a bounds collider');
      assert.deepStrictEqual(restored.objects[0].transform.position, { x: 0, y: 0, z: 0 });
    } finally {
      delete UE.AssetStore.items[used];
      delete UE.AssetStore.items[unused];
      delete UE.AssetStore.decoded[used];
      delete UE.AssetStore.decoded[unused];
    }
  });

  /* ------------------------------------------------------------------ lights */
  test('Light components use per-type defaults and serialize every property', function () {
    assert.strictEqual(UE.lightCookieLabel('rings'), 'Rings');
    assert.strictEqual(UE.lightCookieLabel('nope'), 'None');
    const scene = new UE.Scene('Lights');
    const sun = UE.createLight('Sun Light', 'sun');
    const spot = UE.createLight('Spot Light', 'spot', { x: 2, y: 4, z: 1 }, { x: -30, y: 20, z: 0 });
    scene.add(sun);
    scene.add(spot);
    const light = spot.getComponent('Light');
    assert.strictEqual(light.type, 'spot');
    assert.strictEqual(light.intensity, 3.4);
    assert.strictEqual(light.spotAngle, 46);
    assert.strictEqual(light.innerAngle, 22);
    assert.strictEqual(sun.getComponent('Light').intensity, 1.7);

    light.cookie = 'checker';
    light.range = 18;
    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    const restoredSpot = restored.find('Spot Light').getComponent('Light');
    assert.strictEqual(restoredSpot.type, 'spot');
    assert.strictEqual(restoredSpot.cookie, 'checker');
    assert.strictEqual(restoredSpot.range, 18);
    assert.strictEqual(restoredSpot.spotAngle, 46);
    assert.strictEqual(restored.find('Sun Light').getComponent('Light').type, 'sun');
  });

  /* --------------------------------------------------------------- playmaker */
  test('PlayMaker FSM transitions on an event proxy and persists variables', function () {
    const scene = new UE.Scene('FSM');
    const go = UE.createEmpty('Orb');
    go.addComponent('PlayMakerEventProxy', { eventName: 'Ping', trigger: 'start', target: 'self' });
    const fsm = go.addComponent('PlayMakerFSM', {
      name: 'Orb FSM',
      start: 'Idle',
      variables: {},
      states: [
        {
          name: 'Idle',
          actions: [{ type: 'setVariable', name: 'idle', operation: 'add', value: '1' }],
          transitions: [{ event: 'Ping', to: 'Done' }]
        },
        {
          name: 'Done',
          actions: [{ type: 'setVariable', name: 'done', operation: 'set', value: '1' }],
          transitions: []
        }
      ]
    });
    scene.add(go);
    try {
      UE.PlayMaker.update(scene, 1 / 60, 0);
      assert.strictEqual(fsm.state().name, 'Done', 'the START proxy event moved the FSM');
      assert.strictEqual(fsm.variables.done, 1);
      assert.strictEqual(go.transform.position.x, 0);
      UE.PlayMaker.reset(scene);
      assert.strictEqual(fsm.state(), null, 'reset clears the runtime state');
    } finally {
      UE.PlayMaker.reset();
    }
  });

  test('PlayMaker FSM actions and variables survive scene serialization', function () {
    const scene = new UE.Scene('FSM Save');
    const go = UE.createEmpty('Machine');
    go.addComponent('PlayMakerFSM', {
      name: 'Saved FSM',
      start: 'Glow',
      variables: { counter: 5, label: 'hello' },
      states: [
        { name: 'Glow', actions: [{ type: 'wait', seconds: 0.5 }], transitions: [{ event: 'FINISHED', to: 'Done' }] },
        { name: 'Done', actions: [{ type: 'log', message: 'done' }], transitions: [] }
      ]
    });
    scene.add(go);
    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    const fsm = restored.find('Machine').getComponent('PlayMakerFSM');
    assert.strictEqual(fsm.name, 'Saved FSM');
    assert.strictEqual(fsm.start, 'Glow');
    assert.deepStrictEqual(fsm.variables, { counter: 5, label: 'hello' });
    assert.strictEqual(fsm.states.length, 2);
    assert.strictEqual(fsm.states[0].actions[0].type, 'wait');
    assert.near(fsm.states[0].actions[0].seconds, 0.5);
    assert.deepStrictEqual(fsm.states[0].transitions, [{ event: 'FINISHED', to: 'Done' }]);
  });

  /* --------------------------------------------------- extended PlayMaker */
  function actionContext(scene, self, vars) {
    const ctx = {
      self: self, scene: scene, dt: 1 / 60, time: 0, vars: vars || {}, keys: UE.PlayMaker.keys,
      send: function (event) { UE.PlayMaker.sendEventToObject(self, event); }
    };
    return ctx;
  }
  function runAction(type, params, ctx, rt) {
    const action = Object.assign(UE.PlayMaker.action(type), params || {});
    return UE.PlayMaker.actions[type].run(action, ctx, rt || {});
  }

  test('Tags find objects, serialize and drive GameObject tag actions', function () {
    const scene = new UE.Scene('Tags');
    const player = UE.createEmpty('Player');
    const friend = UE.createEmpty('Friend');
    player.tag = 'Player';
    friend.tag = 'Ally';
    scene.add(player);
    scene.add(friend);
    assert.strictEqual(scene.findByTag('Player'), player);
    assert.deepStrictEqual(scene.findAllByTag('Ally'), [friend]);
    assert.deepStrictEqual(scene.findAllByTag('Missing'), []);

    const ctx = actionContext(scene, player);
    runAction('setTag', { target: 'tag:Ally', tag: 'Friend' }, ctx);
    assert.strictEqual(friend.tag, 'Friend');
    assert.strictEqual(scene.findByTag('Ally'), null);

    runAction('setActiveByTag', { tag: 'Friend', active: false }, ctx);
    assert.strictEqual(friend.active, false);
    runAction('activate', { target: 'tag:Friend' }, ctx);
    assert.strictEqual(friend.active, true);
    runAction('deactivate', { target: 'Player' }, ctx);
    assert.strictEqual(player.active, false);
    runAction('activate', { target: 'Player' }, ctx);
    assert.strictEqual(player.active, true);

    const listener = UE.createEmpty('Listener');
    listener.tag = 'Listeners';
    scene.add(listener);
    const fsm = listener.addComponent('PlayMakerFSM', {
      start: 'Idle',
      states: [
        { name: 'Idle', actions: [], transitions: [{ event: 'Ping', to: 'Done' }] },
        { name: 'Done', actions: [{ type: 'setVariable', name: 'heard', operation: 'set', value: '1' }], transitions: [] }
      ]
    });
    runAction('sendEventToTag', { tag: 'Listeners', event: 'Ping' }, ctx);
    fsm.update(scene, 1 / 60, 0);
    assert.strictEqual(fsm.state().name, 'Done', 'tag event reached the listener FSM');
    assert.strictEqual(fsm.variables.heard, 1);

    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    assert.strictEqual(restored.find('Player').tag, 'Player');
    assert.strictEqual(restored.find('Friend').tag, 'Friend');
  });

  test('FSM actions control variables, events, states, restart and enable', function () {
    const scene = new UE.Scene('FSM actions');
    const go = UE.createEmpty('Controller');
    scene.add(go);
    const target = go.addComponent('PlayMakerFSM', {
      name: 'Target FSM',
      start: 'Idle',
      variables: { counter: 5 },
      states: [
        { name: 'Idle', actions: [], transitions: [{ event: 'Ping', to: 'Done' }] },
        { name: 'Done', actions: [{ type: 'setVariable', name: 'done', operation: 'set', value: '1' }], transitions: [] }
      ]
    });
    const ctx = actionContext(scene, go, { counter: 99 });
    runAction('setFsmVariable', { target: 'self', fsm: 'Target FSM', name: 'counter', operation: 'add', value: '2' }, ctx);
    assert.strictEqual(target.variables.counter, 7);

    runAction('sendFsmEvent', { target: 'self', fsm: 'Target FSM', event: 'Ping' }, ctx);
    target.update(scene, 1 / 60, 0);
    assert.strictEqual(target.state().name, 'Done');
    assert.strictEqual(target.variables.done, 1);

    runAction('goToFsmState', { target: 'self', fsm: 'Target FSM', state: 'Idle' }, ctx);
    assert.strictEqual(target.state().name, 'Idle');
    runAction('setFsmEnabled', { target: 'self', fsm: 'Target FSM', enabled: false }, ctx);
    assert.strictEqual(target.enabled, false);
    target.update(scene, 1 / 60, 0);
    assert.strictEqual(target.state().name, 'Idle', 'a disabled FSM skips updates');
    runAction('restartFsm', { target: 'self', fsm: 'Target FSM' }, ctx);
    assert.strictEqual(target.enabled, true);
    assert.strictEqual(target.state().name, 'Idle');
  });

  test('Texture actions edit material tint, UV tiling and scrolling', function () {
    const scene = new UE.Scene('Texture');
    const go = UE.createPrimitive('Panel', 'cube', '#ffffff');
    scene.add(go);
    const mr = go.getComponent('MeshRenderer');
    assert.deepStrictEqual(mr.uvScale, { x: 1, y: 1 });
    assert.deepStrictEqual(mr.uvOffset, { x: 0, y: 0 });

    const ctx = actionContext(scene, go);
    runAction('editTexture', {
      target: 'self', color: '#3366ff', opacity: 0.5, roughness: 0.25, emissive: 0.2,
      scaleX: 2, scaleY: 3, offsetX: 0.1, offsetY: 0.2
    }, ctx);
    assert.strictEqual(mr.color, '#3366ff');
    assert.near(mr.opacity, 0.5);
    assert.near(mr.roughness, 0.25);
    assert.near(mr.emissive, 0.2);
    assert.deepStrictEqual(mr.uvScale, { x: 2, y: 3 });
    assert.deepStrictEqual(mr.uvOffset, { x: 0.1, y: 0.2 });

    const rt = {};
    for (let i = 0; i < 10; i++) runAction('scrollTexture', { x: 0.5, y: 0.25, duration: 0 }, ctx, rt);
    assert.near(mr.uvOffset.x, 0.1 + 0.5 * 10 / 60, 1e-9);
    assert.near(mr.uvOffset.y, 0.2 + 0.25 * 10 / 60, 1e-9);

    const durationRt = {};
    let done = false;
    for (let i = 0; i < 70; i++) done = runAction('scrollTexture', { x: 0, y: 0, duration: 0.25 }, ctx, durationRt);
    assert.strictEqual(done, true, 'scroll completes after its duration');

    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    const restoredMr = restored.find('Panel').getComponent('MeshRenderer');
    assert.deepStrictEqual(restoredMr.uvScale, { x: 2, y: 3 });
    assert.near(restoredMr.uvOffset.x, mr.uvOffset.x);
    assert.near(restoredMr.uvOffset.y, mr.uvOffset.y);
  });

  test('Physics actions apply force, gravity, kinematic and body settings', function () {
    const scene = new UE.Scene('Physics actions');
    const go = UE.createPrimitive('Body', 'cube', '#ffffff');
    scene.add(go);
    const rb = go.addComponent('Rigidbody');
    rb.velocity = UE.V3.create(0, 0, 0);
    const ctx = actionContext(scene, go);

    runAction('addForce', { x: 1, y: 2, z: -1, mode: 'impulse' }, ctx);
    assert.deepStrictEqual(rb.velocity, { x: 1, y: 2, z: -1 });
    runAction('addForce', { x: 2, y: 0, z: 0, mode: 'force' }, ctx);
    assert.near(rb.velocity.x, 1 + 2 / 60, 1e-9);

    runAction('setUseGravity', { enabled: false }, ctx);
    assert.strictEqual(rb.useGravity, false);
    runAction('configureRigidbody', { mass: 4, drag: 0.5, restitution: 0.8 }, ctx);
    assert.strictEqual(rb.mass, 4);
    assert.strictEqual(rb.drag, 0.5);
    assert.strictEqual(rb.restitution, 0.8);

    runAction('setKinematic', { enabled: true, stop: true }, ctx);
    assert.strictEqual(rb.isKinematic, true);
    assert.deepStrictEqual(rb.velocity, { x: 0, y: 0, z: 0 });
    runAction('setKinematic', { enabled: false, stop: false }, ctx);
    assert.strictEqual(rb.isKinematic, false);

    rb.velocity = UE.V3.create(3, 3, 3);
    runAction('stopMotion', {}, ctx);
    assert.deepStrictEqual(rb.velocity, { x: 0, y: 0, z: 0 });
  });

  test('Set Light Type switches all four light types and edits properties', function () {
    const scene = new UE.Scene('Light types');
    const go = UE.createLight('Beacon', 'point');
    scene.add(go);
    const light = go.getComponent('Light');
    const ctx = actionContext(scene, go);
    for (const type of ['sun', 'directional', 'point', 'spot']) {
      runAction('setLightType', {
        type: type, color: '#aabbcc', intensity: 2.5, range: 12, spotAngle: 70, innerAngle: 30,
        cookie: 'grid', castShadow: false
      }, ctx);
      assert.strictEqual(light.type, type);
      assert.strictEqual(light.color, '#aabbcc');
      assert.strictEqual(light.intensity, 2.5);
      assert.strictEqual(light.range, 12);
      assert.strictEqual(light.spotAngle, 70);
      assert.strictEqual(light.innerAngle, 30);
      assert.strictEqual(light.cookie, 'grid');
      assert.strictEqual(light.castShadow, false);
    }
    runAction('setLightType', { type: 'spot', spotAngle: 20, innerAngle: 80, cookie: 'none', castShadow: true }, ctx);
    assert.strictEqual(light.type, 'spot');
    assert.strictEqual(light.innerAngle, 20, 'inner cone is clamped to the outer cone');

    const restored = UE.Scene.fromJSON(JSON.parse(JSON.stringify(scene.toJSON())));
    const restoredLight = restored.find('Beacon').getComponent('Light');
    assert.strictEqual(restoredLight.type, 'spot');
    assert.strictEqual(restoredLight.cookie, 'none');
    assert.strictEqual(restoredLight.castShadow, true);
  });

  test('Timers start, stop, reset and dispatch their event', function () {
    const scene = new UE.Scene('Timers');
    const go = UE.createEmpty('Ticker');
    scene.add(go);
    const timer = go.addComponent('PlayMakerTimer', { eventName: 'Tick', seconds: 1, repeat: true, target: 'self' });
    const fsm = go.addComponent('PlayMakerFSM', {
      start: 'Idle',
      states: [
        { name: 'Idle', actions: [], transitions: [{ event: 'Tick', to: 'Woke' }] },
        { name: 'Woke', actions: [{ type: 'setVariable', name: 'ticks', operation: 'set', value: '1' }], transitions: [] }
      ]
    });
    const ctx = actionContext(scene, go);
    runAction('startTimer', { seconds: 0.25, repeat: true }, ctx);
    assert.strictEqual(timer.running, true);
    assert.strictEqual(timer.seconds, 0.25);
    assert.strictEqual(timer.repeat, true);
    assert.strictEqual(timer._t, 0);

    UE.PlayMaker.update(scene, 0.3, 0);
    assert.strictEqual(fsm.state().name, 'Woke', 'the timer event reached the FSM');
    assert.strictEqual(fsm.variables.ticks, 1);

    runAction('stopTimer', {}, ctx);
    assert.strictEqual(timer.running, false);
    assert.strictEqual(timer._done, true);
    UE.PlayMaker.update(scene, 1, 1);
    assert.strictEqual(timer._t, 0, 'a stopped timer does not accumulate time');

    runAction('resetTimer', {}, ctx);
    assert.strictEqual(timer.running, true);
    assert.strictEqual(timer._t, 0);
    assert.strictEqual(timer._done, false);
  });

  test('Web actions store PHP replies, receive events and open links', function () {
    const scene = new UE.Scene('Web');
    const go = UE.createEmpty('Net');
    scene.add(go);
    const fsm = go.addComponent('PlayMakerFSM', {
      start: 'Idle',
      states: [
        { name: 'Idle', actions: [], transitions: [{ event: 'PHP_REPLY', to: 'Got' }] },
        { name: 'Got', actions: [], transitions: [] }
      ]
    });
    const ctx = actionContext(scene, go, {});
    UE.PlayMaker.web.clear();
    UE.PlayMaker.web.storeReply('chat', 'hello', 200);
    assert.strictEqual(UE.PlayMaker.web.replies.chat.value, 'hello');
    assert.strictEqual(UE.PlayMaker.web.replies.chat.status, 200);

    const progressed = runAction('phpReply', {
      replyKey: 'chat', variable: 'answer', event: 'PHP_REPLY', consume: true, timeout: 0
    }, ctx);
    assert.strictEqual(progressed, true);
    assert.strictEqual(ctx.vars.answer, 'hello');
    assert.strictEqual(UE.PlayMaker.web.replies.chat, undefined, 'reply is consumed');
    fsm.update(scene, 1 / 60, 0);
    assert.strictEqual(fsm.state().name, 'Got');

    assert.strictEqual(runAction('phpReply', { replyKey: 'missing', timeout: 0 }, ctx), false);
    const timeoutRt = {};
    let timedOut = false;
    for (let i = 0; i < 7; i++) {
      timedOut = runAction('phpReply', { replyKey: 'missing', timeout: 0.1 }, ctx, timeoutRt);
    }
    assert.strictEqual(timedOut, true, 'PHP Reply Receive can time out');

    let opened = null;
    const originalOpen = window.open;
    window.open = function (url, target) { opened = { url: url, target: target }; return null; };
    try {
      runAction('openLink', { url: 'https://example.com/api.php', newTab: true }, ctx);
    } finally {
      window.open = originalOpen;
    }
    assert.deepStrictEqual(opened, { url: 'https://example.com/api.php', target: '_blank' });
    assert.strictEqual(UE.PlayMaker.actions.phpRequest.category, 'Web');
    assert.strictEqual(UE.PlayMaker.actions.phpReply.category, 'Web');

    UE.PlayMaker.web.storeReply('stale', 'old', 200);
    UE.PlayMaker.reset(scene);
    assert.strictEqual(UE.PlayMaker.web.replies.stale, undefined, 'stopping Play clears stored replies');
  });

  test('PlayMaker catalog exposes the new action families', function () {
    const expected = {
      setFsmVariable: 'FSM', sendFsmEvent: 'FSM', goToFsmState: 'FSM', restartFsm: 'FSM', setFsmEnabled: 'FSM',
      editTexture: 'Texture', scrollTexture: 'Texture',
      activate: 'Game Object', deactivate: 'Game Object', setTag: 'Game Object', setActiveByTag: 'Game Object',
      sendEventToTag: 'Game Object', setLightType: 'Rendering',
      addForce: 'Physics', setUseGravity: 'Physics', setKinematic: 'Physics', configureRigidbody: 'Physics',
      stopMotion: 'Physics',
      startTimer: 'Timers', stopTimer: 'Timers', resetTimer: 'Timers',
      openLink: 'Web', phpRequest: 'Web', phpReply: 'Web'
    };
    for (const type of Object.keys(expected)) {
      const def = UE.PlayMaker.actions[type];
      assert.ok(def, 'action ' + type + ' exists');
      assert.strictEqual(def.category, expected[type], type + ' category');
      assert.ok(def.params.length > 0, type + ' has editor parameters');
    }
    for (const category of ['FSM', 'Texture', 'Timers', 'Web']) {
      assert.ok(UE.PlayMaker.categories.indexOf(category) >= 0, category + ' category is listed');
    }
    assert.ok(UE.PlayMaker.catalog.length >= 46, 'catalog contains at least 46 actions');
    const action = UE.PlayMaker.action('editTexture');
    assert.strictEqual(action.type, 'editTexture');
    assert.strictEqual(action.scaleX, 1);
    assert.strictEqual(action.offsetY, 0);
  });

  test('PlayMaker supports custom actions and a scene changer action', function () {
    const PM = UE.PlayMaker;
    assert.ok(typeof PM.defineAction === 'function', 'custom actions can be registered');
    assert.ok(typeof PM.undefineAction === 'function', 'custom actions can be removed');
    assert.ok(PM.actions.changeScene, 'changeScene action exists');
    assert.strictEqual(PM.actions.changeScene.category, 'Flow');
    assert.ok(PM.catalog.some(function (def) { return def.type === 'changeScene'; }), 'catalog lists changeScene');

    let seen = null;
    PM.defineAction('_testSceneAction', 'Test Scene Action', 'Flow', [
      { key: 'id', label: 'Scene', type: 'text', default: 'starter' }
    ], function (a) { seen = a.id; return true; }, 'Test-only action');
    assert.ok(PM.actions._testSceneAction, 'defineAction registers the definition');
    assert.ok(PM.catalog.some(function (def) { return def.type === '_testSceneAction'; }), 'defineAction updates the catalog');
    const custom = PM.action('_testSceneAction');
    assert.strictEqual(custom.id, 'starter');
    PM.actions._testSceneAction.run(custom, { self: null, vars: {}, dt: 1 / 60, time: 0 });
    assert.strictEqual(seen, 'starter', 'custom action run body executes');
    assert.strictEqual(PM.undefineAction('_testSceneAction'), true);
    assert.strictEqual(PM.actions._testSceneAction, undefined);
    assert.ok(!PM.catalog.some(function (def) { return def.type === '_testSceneAction'; }), 'catalog is restored');

    let requested = null;
    const previous = PM.sceneChanger;
    PM.sceneChanger = function (id) { requested = id; return true; };
    const change = PM.action('changeScene');
    change.scene = 'physics';
    PM.actions.changeScene.run(change, { self: null, vars: {}, dt: 1 / 60, time: 0 });
    assert.strictEqual(requested, 'physics', 'changeScene calls the editor scene changer with the scene id');
    PM.sceneChanger = previous;
  });

  /* ------------------------------------------------------------- animation */
  function animationBoxAsset() {
    const min = [-0.35, 0, -0.2], max = [0.35, 2, 0.2];
    const positions = [], normals = [], uvs = [], indices = [];
    for (let i = 0; i < 8; i++) {
      const x = (i & 1) ? max[0] : min[0];
      const y = (i & 2) ? max[1] : min[1];
      const z = (i & 4) ? max[2] : min[2];
      positions.push(x, y, z);
      const len = Math.hypot(x, y, z) || 1;
      normals.push(x / len, y / len, z / len);
      uvs.push(0, 0);
    }
    const faces = [
      [0, 1, 3, 2], [4, 6, 7, 5], [0, 4, 5, 1],
      [2, 3, 7, 6], [0, 2, 6, 4], [1, 5, 7, 3]
    ];
    for (const f of faces) {
      indices.push(f[0], f[1], f[2], f[0], f[2], f[3]);
    }
    const name = 'Rig Box ' + Math.random().toString(36).slice(2);
    const id = UE.AssetStore.add({
      positions: positions, normals: normals, uvs: uvs, indices: indices,
      bounds: { min: min, max: max }
    }, name);
    return { id: id, name: name };
  }

  test('Animation library exposes exactly 99,999 deterministic motions', function () {
    assert.ok(UE.Animation, 'animation.js loaded');
    assert.strictEqual(UE.Animation.MAX_MOTIONS, 99999);
    assert.strictEqual(UE.Animation.PER_CATEGORY, 4000);
    assert.strictEqual(UE.Animation.CATEGORIES.length, 25);
    assert.strictEqual(UE.Animation.Library.capacity, 99999);
    assert.strictEqual(UE.Animation.Library.info(0).name, 'Idle 1');
    assert.strictEqual(UE.Animation.Library.info(0).category, 'Idle');
    assert.strictEqual(UE.Animation.Library.info(4000).category, 'Walk');
    assert.strictEqual(UE.Animation.Library.info(99998).index, 99998);
    assert.strictEqual(UE.Animation.Library.info(99999), null);
    assert.strictEqual(UE.Animation.Library.info(-1), null);
    const a = UE.Animation.Library.info(54321);
    const b = UE.Animation.Library.info(54321);
    assert.deepStrictEqual(a, b, 'info is deterministic');
    assert.ok(a.duration > 0);
    assert.ok(a.name.indexOf(a.category) === 0);

    const poseA = UE.Animation.Library.sample(12345, 0.7);
    const poseB = UE.Animation.Library.sample(12345, 0.7);
    assert.deepStrictEqual(poseA, poseB, 'sampling is deterministic');
    assert.ok(Object.keys(poseA.rot).length > 3, 'the clip drives several bones');
    const poseC = UE.Animation.Library.sample(12345, 1.4);
    assert.ok(JSON.stringify(poseA.rot) !== JSON.stringify(poseC.rot), 'time changes the pose');
  });

  test('Motion library pages, searches and resolves names or indexes', function () {
    const lib = UE.Animation.Library;
    assert.strictEqual(lib.firstIndex('idle'), 0);
    assert.strictEqual(lib.firstIndex('run'), 8000);
    assert.strictEqual(lib.firstIndex('carry'), 96000);
    assert.strictEqual(lib.resolve(4000), 4000);
    assert.strictEqual(lib.resolve('4000'), 4000);
    assert.strictEqual(lib.resolve('motion:8000'), 8000);
    assert.strictEqual(lib.resolve('Run 1'), 8000);
    assert.strictEqual(lib.resolve('carry'), 96000);
    assert.strictEqual(lib.resolve(99999), null);
    assert.strictEqual(lib.resolve('not a motion'), null);
    const walk = lib.list({ category: 'walk', limit: 6 });
    assert.strictEqual(walk.length, 6);
    for (const motion of walk) assert.strictEqual(motion.key, 'walk');
    assert.strictEqual(walk[0].index, 4000);
    const found = lib.list({ query: 'kick', limit: 4 });
    assert.ok(found.length >= 4);
    assert.strictEqual(found[0].key, 'kick');
    assert.strictEqual(lib.count({ category: 'dance' }), 4000);
    assert.ok(lib.count({ query: 'zzzz-no-such-motion' }) === 0);
  });

  test('Auto Rig builds a complete humanoid skeleton from mesh bounds', function () {
    const asset = UE.AssetStore.get(animationBoxAsset().id);
    const rig = UE.Animation.autoRig(asset, { name: 'Test Humanoid' });
    assert.strictEqual(rig.name, 'Test Humanoid');
    assert.strictEqual(rig.skeleton.length, 20);
    assert.ok(rig.skeleton.length <= UE.Animation.BONE_LIMIT);
    const names = rig.skeleton.map(function (bone) { return bone.name; });
    for (const name of ['Root', 'Hips', 'Spine', 'Chest', 'Neck', 'Head',
      'Shoulder.L', 'UpperArm.L', 'Forearm.L', 'Hand.L',
      'Shoulder.R', 'UpperArm.R', 'Forearm.R', 'Hand.R',
      'Thigh.L', 'Shin.L', 'Foot.L', 'Thigh.R', 'Shin.R', 'Foot.R']) {
      assert.ok(names.indexOf(name) >= 0, name + ' bone exists');
    }
    assert.strictEqual(new Set(names).size, names.length, 'bone names are unique');
    for (const bone of rig.skeleton) {
      if (!bone.parent) continue;
      assert.ok(names.indexOf(bone.parent) >= 0, bone.name + ' has a real parent');
    }
    assert.near(rig.height, 2, 1e-4, 'rig records the mesh height');
    assert.ok(rig.skeleton[0].head[1] < rig.skeleton[5].head[1], 'head sits above the root');
    const tall = { prims: asset.prims, bounds: { min: [-0.5, 0, -0.5], max: [0.5, 4, 0.5] } };
    const tallRig = UE.Animation.autoRig(tall);
    assert.ok(tallRig.height > rig.height, 'rig scales with the model');
  });

  test('Skin weights are normalized, in range and cached per rig', function () {
    const assetId = animationBoxAsset().id;
    const asset = UE.AssetStore.get(assetId);
    const rig = UE.Animation.autoRig(asset);
    const skin = UE.Animation.skinFor(assetId, rig.skeleton);
    assert.ok(Array.isArray(skin), 'skinning data returned');
    assert.strictEqual(skin.length, asset.prims.length);
    const positions = asset.prims[0].positions;
    const count = positions.length / 3;
    assert.strictEqual(skin[0].joints.length, count * 4);
    assert.strictEqual(skin[0].weights.length, count * 4);
    for (let v = 0; v < count; v++) {
      let sum = 0;
      for (let k = 0; k < 4; k++) {
        const weight = skin[0].weights[v * 4 + k];
        const joint = skin[0].joints[v * 4 + k];
        assert.ok(weight >= 0 && weight <= 1, 'weight in range');
        assert.ok(Number.isInteger(joint) && joint >= 0 && joint < rig.skeleton.length, 'joint in range');
        sum += weight;
      }
      assert.near(sum, 1, 1e-4, 'vertex ' + v + ' weights sum to one');
    }
    assert.strictEqual(UE.Animation.skinFor(assetId, rig.skeleton), skin, 'matching rigs reuse the cache');
    UE.Animation.clearSkinCache();
    assert.notStrictEqual(UE.Animation.skinFor(assetId, rig.skeleton), skin, 'cache can be cleared');
  });

  test('Animator plays, crossfades and blends clips without NaN poses', function () {
    const assetId = animationBoxAsset().id;
    const scene = new UE.Scene('Animation');
    const model = UE.createModel('Dancer', assetId, { x: 0, y: 0, z: 0 }, '#c9ced8');
    scene.add(model);
    const animator = UE.Animation.attach(model, { motion: 'idle' });
    assert.ok(animator instanceof UE.Animation.Animator);
    assert.strictEqual(animator.skeleton.length, 20);
    assert.strictEqual(animator.motion, 0);
    assert.strictEqual(animator.playing, true);
    assert.ok(animator.loop, 'idle loops');

    const first = animator.boneMatrices();
    assert.strictEqual(first.length, UE.Animation.BONE_LIMIT * 16);
    for (let i = 0; i < first.length; i++) assert.ok(Number.isFinite(first[i]), 'bone matrix value ' + i);
    assert.strictEqual(first[20 * 16 + 15], 1, 'unused bone slots stay identity');

    const before = Array.from(first);
    animator.advance(0.6);
    assert.ok(animator._time > 0);
    const after = Array.from(animator.boneMatrices());
    assert.notStrictEqual(JSON.stringify(before), JSON.stringify(after), 'advancing changes the skin matrices');

    assert.strictEqual(animator.crossFadeTo(8000, 0.3), true);
    assert.strictEqual(animator.motion, 8000);
    assert.strictEqual(animator._fromMotion, 0, 'crossfade remembers the previous clip');
    animator.advance(0.1);
    const blended = animator.samplePose();
    assert.ok(Object.keys(blended.q).length === 20);
    for (const name of Object.keys(blended.q)) {
      const q = blended.q[name];
      assert.ok(Number.isFinite(q.x) && Number.isFinite(q.y) && Number.isFinite(q.z) && Number.isFinite(q.w));
    }

    animator.setBlend(4000, 0.5, 'additive');
    assert.strictEqual(animator.blendMotion, 4000);
    assert.strictEqual(animator.blendWeight, 0.5);
    assert.strictEqual(animator.blendMode, 'additive');
    animator.advance(0.2);
    const mixed = animator.samplePose();
    for (const name of Object.keys(mixed.q)) assert.ok(Number.isFinite(mixed.q[name].w));
    animator.setBlend(null);
    assert.strictEqual(animator.blendMotion, -1);

    animator.setBlend(4000, 0.4, 'mix');
    animator.speed = 1.5;
    animator.advance(0.2);
    assert.ok(animator._time >= 0);

    /* The preview toggle freezes edit-mode sampling but never Play mode. */
    animator.playing = true;
    animator.preview = false;
    const previewTime = animator._time;
    UE.Animation.updateAll(scene, 0.5, true);
    assert.strictEqual(animator._time, previewTime, 'edit-mode preview respects the toggle');
    UE.Animation.updateAll(scene, 0.5);
    assert.notStrictEqual(animator._time, previewTime, 'play mode ignores the preview toggle');
    animator.preview = true;

    animator.stop();
    assert.strictEqual(animator.playing, false);
    assert.strictEqual(animator._time, 0);
  });

  test('Animator state survives a scene round trip and keeps skinning', function () {
    const assetId = animationBoxAsset().id;
    const scene = new UE.Scene('Animation Round Trip');
    const model = UE.createModel('Rigged', assetId);
    scene.add(model);
    const animator = UE.Animation.attach(model, { motion: 12000 });
    animator.blendMotion = 8000;
    animator.blendWeight = 0.35;
    animator.blendMode = 'additive';
    animator.speed = 1.25;
    animator.loop = false;
    animator.fade = 0.4;
    const json = JSON.parse(JSON.stringify(scene.toJSON()));
    const restored = UE.Scene.fromJSON(json);
    const restoredModel = restored.find('Rigged');
    assert.ok(restoredModel, 'model restored');
    const restoredAnimator = restoredModel.getComponent('Animator');
    assert.ok(restoredAnimator, 'Animator restored');
    assert.strictEqual(restoredAnimator.motion, 12000);
    assert.strictEqual(restoredAnimator.blendMotion, 8000);
    assert.near(restoredAnimator.blendWeight, 0.35);
    assert.strictEqual(restoredAnimator.blendMode, 'additive');
    assert.strictEqual(restoredAnimator.speed, 1.25);
    assert.strictEqual(restoredAnimator.loop, false);
    assert.strictEqual(restoredAnimator.skeleton.length, 20);
    const matrices = restoredAnimator.boneMatrices();
    for (let i = 0; i < matrices.length; i++) assert.ok(Number.isFinite(matrices[i]));
    assert.deepStrictEqual(Array.from(restoredAnimator.skeleton), Array.from(animator.skeleton));
  });

  test('PlayMaker animation actions drive playback, blending and auto-rig', function () {
    const scene = new UE.Scene('Animation Actions');
    const model = UE.createModel('Actor', animationBoxAsset().id);
    scene.add(model);
    const ctx = actionContext(scene, model);

    const expected = ['playMotion', 'crossFadeMotion', 'blendMotion', 'randomMotion',
      'setMotionSpeed', 'setMotionPlaying', 'stopAnimator', 'autoRigAnimator'];
    for (const type of expected) {
      const def = UE.PlayMaker.actions[type];
      assert.ok(def, 'animation action ' + type + ' exists');
      assert.strictEqual(def.category, 'Animation');
    }
    assert.ok(UE.PlayMaker.categories.indexOf('Animation') >= 0, 'Animation category listed');
    assert.ok(UE.PlayMaker.catalog.length >= 54, 'catalog grew with animation actions');

    runAction('autoRigAnimator', { target: 'self', motion: 'idle', fade: 0.2 }, ctx);
    const animator = model.getComponent('Animator');
    assert.ok(animator, 'auto rig action added an Animator');
    assert.strictEqual(animator.skeleton.length, 20);
    assert.strictEqual(animator.fade, 0.2);

    assert.strictEqual(runAction('playMotion', { target: 'self', motion: 'run', fade: 0 }, ctx), true);
    assert.strictEqual(animator.motion, 8000);
    assert.strictEqual(animator.motionName, 'Run 1');

    ctx.vars.clip = 'kick';
    runAction('playMotion', { target: 'self', motion: '$clip', fade: 0 }, ctx);
    assert.strictEqual(animator.motion, UE.Animation.Library.firstIndex('kick'));

    runAction('crossFadeMotion', { target: 'self', motion: 12345, fade: 0.5 }, ctx);
    assert.strictEqual(animator.motion, 12345);
    assert.strictEqual(animator._fadeDuration, 0.5);

    runAction('blendMotion', { target: 'self', motion: 'walk', weight: 0.4, mode: 'additive' }, ctx);
    assert.strictEqual(animator.blendMotion, 4000);
    assert.near(animator.blendWeight, 0.4);
    assert.strictEqual(animator.blendMode, 'additive');
    runAction('blendMotion', { target: 'self', clear: true }, ctx);
    assert.strictEqual(animator.blendMotion, -1);

    runAction('setMotionSpeed', { target: 'self', speed: 2 }, ctx);
    assert.strictEqual(animator.speed, 2);
    runAction('setMotionPlaying', { target: 'self', playing: false }, ctx);
    assert.strictEqual(animator.playing, false);

    runAction('randomMotion', { target: 'self', category: 'dance', fade: 0 }, ctx);
    assert.ok(animator.motion >= 32000 && animator.motion < 36000, 'random dance motion is in the dance block');

    animator.playing = true;
    animator.advance(0.5);
    runAction('stopAnimator', { target: 'self' }, ctx);
    assert.strictEqual(animator.playing, false);
    assert.strictEqual(animator._time, 0);
  });

  test('Samples build scenes with a main camera and PlayMaker content', function () {
    assert.strictEqual(UE.Samples.list.length, 5);
    for (const entry of UE.Samples.list) {
      const scene = entry.make();
      assert.ok(scene instanceof UE.Scene, entry.id + ' returns a scene');
      assert.ok(scene.objects.length >= 2, entry.id + ' has objects');
      assert.ok(scene.mainCamera(), entry.id + ' has a main camera');
      assert.ok(scene.find('Ground'), entry.id + ' has ground');
    }
    const lights = UE.Samples.create('lights');
    assert.ok(lights.objects.some(function (o) { return o.getComponent('PlayMakerFSM'); }), 'PlayMaker FSM present');
    assert.ok(lights.objects.some(function (o) { return o.getComponent('Light'); }), 'lights present');
    const fallback = UE.Samples.create('does-not-exist');
    assert.strictEqual(fallback.name, UE.Samples.list[0].make().name, 'unknown ids fall back to the first sample');
  });

  /* ------------------------------------------------------------------ network */
  test('NetworkObject serializes identity and sync flags, but not runtime ownership', function () {
    const scene = new UE.Scene('Network Serialization');
    const cube = UE.createPrimitive('Replicated Cube', 'cube', '#66d9c0', { x: 1, y: 2, z: 3 });
    scene.add(cube);
    const comp = cube.addComponent('NetworkObject', {
      networkId: 'net-fixed-id',
      syncTransform: true,
      syncMesh: false,
      syncTag: true,
      syncActive: false,
      sendRate: 24,
      interpolation: 6
    });
    comp.owner = 'peer-owner';
    comp._netClock = 3;
    assert.strictEqual(comp.ensureId(), 'net-fixed-id');
    assert.strictEqual(cube.getComponent('NetworkObject'), comp, 'one NetworkObject per object');

    const json = JSON.parse(JSON.stringify(scene.toJSON()));
    const entry = json.objects.find(function (o) { return o.name === 'Replicated Cube'; });
    const saved = entry.components.find(function (c) { return c.type === 'NetworkObject'; });
    assert.ok(saved, 'NetworkObject is written to the scene');
    assert.strictEqual(saved.props.networkId, 'net-fixed-id');
    assert.strictEqual(saved.props.syncMesh, false);
    assert.strictEqual(saved.props.syncActive, false);
    assert.strictEqual(saved.props.sendRate, 24);
    assert.strictEqual(saved.props.interpolation, 6);
    assert.strictEqual(saved.props.owner, undefined, 'owner is runtime-only');

    const restored = UE.Scene.fromJSON(json);
    const restoredComp = restored.find('Replicated Cube').getComponent('NetworkObject');
    assert.strictEqual(restoredComp.networkId, 'net-fixed-id');
    assert.strictEqual(restoredComp.syncMesh, false);
    assert.strictEqual(restoredComp.owner, '', 'restored owner is unclaimed');
    assert.strictEqual(restoredComp.ensureId(), 'net-fixed-id', 'stable id survives a round trip');
  });

  test('Network room names are sanitized to safe channel ids', function () {
    assert.strictEqual(UE.Network.sanitizeRoom(' My Room! '), 'My-Room');
    assert.strictEqual(UE.Network.sanitizeRoom('team_a.1'), 'team_a.1');
    assert.strictEqual(UE.Network.sanitizeRoom(''), 'lobby');
    assert.strictEqual(UE.Network.sanitizeRoom('///'), 'lobby');
    assert.strictEqual(UE.Network.PROTOCOL, 'unirealengine.network.v1');
    assert.strictEqual(typeof UE.Network.memoryBus, 'function');
  });

  test('NetworkManager replicates spawn, transform, mesh, tag, active state and ownership', function () {
    const bus = UE.Network.memoryBus();
    const host = UE.Network.create({ bus: bus, peerId: 'peer-host', peerName: 'Host' });
    const client = UE.Network.create({ bus: bus, peerId: 'peer-client', peerName: 'Client' });

    const hostScene = new UE.Scene('Host Scene');
    const source = UE.createPrimitive('Replicated', 'cube', '#66d9c0', { x: 0, y: 0, z: 0 });
    hostScene.add(source);
    source.addComponent('NetworkObject', { networkId: 'net-replicated' });
    const clientScene = new UE.Scene('Client Scene');

    host.attachScene(hostScene);
    client.attachScene(clientScene);
    host.setPlaying(true);
    client.setPlaying(true);
    assert.strictEqual(host.host('replication'), true, 'host joined the room');
    assert.strictEqual(client.join('replication'), true, 'client joined the room');
    bus.flush();

    assert.ok(host.isHost, 'host role');
    assert.ok(!client.isHost, 'client role');
    assert.strictEqual(client.peers['peer-host'].name, 'Host', 'client discovered the host');
    const spawned = clientScene.find('Replicated');
    assert.ok(spawned, 'client received the spawn');
    assert.strictEqual(spawned.id, source.id, 'stable object id replicated');
    const spawnedComp = spawned.getComponent('NetworkObject');
    assert.ok(spawnedComp, 'spawned object has a NetworkObject');
    assert.strictEqual(spawnedComp.networkId, 'net-replicated');
    assert.strictEqual(spawnedComp.owner, 'peer-host', 'host owns the source object');

    const hostComp = source.getComponent('NetworkObject');
    assert.strictEqual(hostComp.owner, 'peer-host', 'host claimed its network object');
    hostComp.interpolation = 0;
    spawnedComp.interpolation = 0;
    source.transform.position = { x: 4, y: 2, z: -1 };
    source.transform.rotation = { x: 0, y: 45, z: 0 };
    source.transform.scale = { x: 2, y: 2, z: 2 };
    source.tag = 'Enemy';
    source.active = false;
    const mr = source.getComponent('MeshRenderer');
    mr.color = '#ff0000';
    mr.roughness = 0.2;
    host.update(1 / 15);
    bus.flush();
    client.update(0.5);

    assert.near(spawned.transform.position.x, 4, 1e-3, 'x replicated');
    assert.near(spawned.transform.position.y, 2, 1e-3, 'y replicated');
    assert.near(spawned.transform.position.z, -1, 1e-3, 'z replicated');
    assert.near(spawned.transform.rotation.y, 45, 1e-2, 'rotation replicated');
    assert.near(spawned.transform.scale.x, 2, 1e-3, 'scale replicated');
    assert.strictEqual(spawned.tag, 'Enemy', 'tag replicated');
    assert.strictEqual(spawned.active, false, 'active state replicated');
    assert.strictEqual(spawned.getComponent('MeshRenderer').color, '#ff0000', 'material color replicated');
    assert.near(spawned.getComponent('MeshRenderer').roughness, 0.2, 1e-6, 'material roughness replicated');
    assert.strictEqual(host.status().sent > 0, true, 'host counted sent messages');
    assert.strictEqual(client.status().received > 0, true, 'client counted received messages');

    client.claim(spawned);
    bus.flush();
    assert.strictEqual(hostComp.owner, 'peer-client', 'ownership transferred to the client');
    spawned.transform.position.x = -3;
    client.update(1 / 15);
    bus.flush();
    host.update(0.5);
    assert.near(source.transform.position.x, -3, 1e-3, 'client-owned state moved the host copy');

    let received = null;
    const originalSend = UE.PlayMaker.sendEventToObject;
    UE.PlayMaker.sendEventToObject = function (object, event) {
      received = { id: object.id, event: event };
      return true;
    };
    try {
      client.sendEvent(spawned, 'PING');
      bus.flush();
    } finally {
      UE.PlayMaker.sendEventToObject = originalSend;
    }
    assert.ok(received, 'network event was delivered');
    assert.strictEqual(received.id, source.id, 'event targeted the same object');
    assert.strictEqual(received.event, 'PING', 'event name replicated');

    host.leave();
    client.leave();
    bus.close();
    assert.strictEqual(host.active, false);
    assert.strictEqual(client.active, false);
  });

  test('A client that joins before Play requests a snapshot when Play starts', function () {
    const bus = UE.Network.memoryBus();
    const host = UE.Network.create({ bus: bus, peerId: 'peer-early-host', peerName: 'Host' });
    const client = UE.Network.create({ bus: bus, peerId: 'peer-late-client', peerName: 'Client' });
    const hostScene = new UE.Scene('Late Host');
    const source = UE.createPrimitive('Late Object', 'cube', '#66d9c0', { x: 0, y: 0, z: 0 });
    hostScene.add(source);
    source.addComponent('NetworkObject', { networkId: 'net-late' });
    const clientScene = new UE.Scene('Late Client');
    host.attachScene(hostScene);
    client.attachScene(clientScene);
    host.host('late-room');
    client.join('late-room');
    bus.flush();
    assert.strictEqual(clientScene.objects.length, 0, 'spawns are ignored before Play');

    client.setPlaying(true);
    bus.flush();
    assert.ok(clientScene.find('Late Object'), 'Play requested and received the host snapshot');
    assert.strictEqual(clientScene.find('Late Object').getComponent('NetworkObject').networkId, 'net-late');
    host.leave();
    client.leave();
    bus.close();
  });

  test('PlayMaker network actions spawn, claim and broadcast', function () {
    const scene = new UE.Scene('Network Actions');
    const anchor = UE.createPrimitive('Anchor', 'cube', '#ffffff', { x: 2, y: 1, z: 0 });
    scene.add(anchor);
    const ctx = actionContext(scene, anchor);
    const expected = ['networkSpawn', 'networkClaim', 'networkSendEvent', 'networkBroadcast'];
    for (const type of expected) {
      const def = UE.PlayMaker.actions[type];
      assert.ok(def, 'network action ' + type + ' exists');
      assert.strictEqual(def.category, 'Network');
    }
    assert.ok(UE.PlayMaker.categories.indexOf('Network') >= 0, 'Network category listed');
    assert.ok(UE.PlayMaker.catalog.length >= 58, 'catalog includes the network actions');

    UE.Network.attachScene(scene);
    const before = scene.objects.length;
    runAction('networkSpawn', { name: 'FSM Spawn', primitive: 'sphere', tag: 'Player', target: 'self' }, ctx);
    assert.strictEqual(scene.objects.length, before + 1, 'spawn action added an object');
    const spawned = scene.find('FSM Spawn');
    assert.ok(spawned, 'spawn action named the object');
    assert.ok(spawned.getComponent('NetworkObject'), 'spawn action added a NetworkObject');
    assert.strictEqual(spawned.tag, 'Player');
    assert.near(spawned.transform.position.x, 2, 1e-6, 'spawned at the target x');
    assert.near(spawned.transform.position.y, 1.5, 1e-6, 'spawned above the target y');

    runAction('networkClaim', { target: 'self' }, ctx);
    const anchorComp = anchor.getComponent('NetworkObject');
    assert.ok(anchorComp, 'claim action added a NetworkObject');
    assert.strictEqual(anchorComp.owner, UE.Network.peerId, 'claim action took ownership');
    assert.strictEqual(runAction('networkBroadcast', {}, ctx), true);
    assert.strictEqual(runAction('networkSendEvent', { event: 'START', target: 'self' }, ctx), true);
    UE.Network.leave();
  });

  /* ------------------------------------------------------------------ extras */
  test('Extras module exposes presets, templates, roles, textures and input', function () {
    assert.ok(UE.Extras && UE.Textures && UE.Input, 'extras module loaded after PlayMaker');
    assert.strictEqual(UE.Extras.objectPresets.length, 12, 'twelve object presets');
    assert.strictEqual(UE.Extras.fsmTemplates.length, 9, 'nine FSM templates');
    assert.deepStrictEqual(UE.NETWORK_ROLE_IDS, ['player', 'npc', 'pickup', 'projectile']);
    assert.strictEqual(UE.Extras.gamepadButtons.length, 16, 'standard gamepad button map');
    assert.strictEqual(UE.Input.bindings.play.key, 'p');
    assert.strictEqual(UE.Extras.defaultBindings.secondCamera.key, 'c');
    assert.strictEqual(typeof UE.createPreset, 'function');
    assert.strictEqual(typeof UE.applyFsmTemplate, 'function');
  });

  test('Object presets build role-ready objects', function () {
    const ids = UE.Extras.objectPresets.map(function (p) { return p.id; });
    const objects = ids.map(function (id) {
      return UE.createPreset(id, { name: 'Preset ' + id, position: { x: 2, y: 3, z: 4 } });
    });
    assert.strictEqual(objects.length, 12);
    const byId = {};
    ids.forEach(function (id, i) {
      assert.ok(objects[i], 'preset ' + id + ' created an object');
      assert.strictEqual(objects[i].name, 'Preset ' + id);
      assert.near(objects[i].transform.position.x, 2);
      assert.near(objects[i].transform.position.y, 3);
      assert.near(objects[i].transform.position.z, 4);
      byId[id] = objects[i];
    });

    assert.strictEqual(byId.player.getComponent('Rigidbody').mass, 2);
    assert.strictEqual(byId.player.getComponent('NetworkObject').role, 'player');
    assert.strictEqual(byId.player.tag, 'Player');
    assert.strictEqual(byId.enemy.getComponent('NetworkObject').role, 'npc');
    assert.strictEqual(byId.enemy.tag, 'Enemy');
    assert.strictEqual(byId.pickup.tag, 'Pickup');
    assert.strictEqual(byId.pickup.getComponent('Collider').isTrigger, true);
    assert.strictEqual(byId.projectile.tag, 'Projectile');
    assert.strictEqual(byId.projectile.getComponent('Rigidbody').useGravity, false);
    assert.strictEqual(byId.pickup.getComponent('NetworkObject').syncMesh, true);
    assert.strictEqual(byId.projectile.getComponent('NetworkObject').syncMesh, false);
    assert.strictEqual(byId.camera.getComponent('Camera').main, true);
    assert.strictEqual(byId.pipCamera.getComponent('Camera').main, false);
    assert.strictEqual(byId.pipCamera.getComponent('Camera').pip, true);
    assert.strictEqual(byId.sun.getComponent('Light').type, 'sun');
    assert.strictEqual(byId.platform.tag, 'Ground');
    assert.strictEqual(UE.createPreset('missing'), null);
  });

  test('Four network roles apply their defaults and survive replication', function () {
    const scene = new UE.Scene('Role Defaults');
    const target = UE.createPrimitive('Role Target', 'cube', '#ffffff', { x: 0, y: 0, z: 0 });
    scene.add(target);
    for (const role of UE.NETWORK_ROLE_IDS) {
      const preset = UE.NETWORK_ROLES[role];
      const comp = UE.applyNetworkRole(target, role);
      assert.strictEqual(comp.role, role, role + ' role stored on the component');
      assert.strictEqual(target.tag, preset.tag, role + ' tag applied');
      assert.near(target.transform.scale.x, preset.scale.x);
      assert.near(target.transform.scale.y, preset.scale.y);
      assert.strictEqual(comp.syncMesh, preset.sync.mesh, role + ' mesh sync default');
      assert.strictEqual(comp.syncTag, preset.sync.tag, role + ' tag sync default');
      assert.strictEqual(comp.syncActive, preset.sync.active, role + ' active sync default');
    }
    assert.strictEqual(UE.applyNetworkRole(target, 'unknown').role, 'player', 'unknown roles fall back to player');

    const bus = UE.Network.memoryBus();
    const host = UE.Network.create({ bus: bus, peerId: 'peer-role-host', peerName: 'Role Host' });
    const client = UE.Network.create({ bus: bus, peerId: 'peer-role-client', peerName: 'Role Client' });
    const hostScene = new UE.Scene('Role Host');
    const clientScene = new UE.Scene('Role Client');
    host.attachScene(hostScene);
    client.attachScene(clientScene);
    host.setPlaying(true);
    client.setPlaying(true);
    host.host('role-replication');
    client.join('role-replication');
    bus.flush();

    const sources = UE.NETWORK_ROLE_IDS.map(function (role, i) {
      return host.spawn({ role: role, position: { x: i, y: 0.5, z: 0 } });
    });
    for (let i = 0; i < sources.length; i++) {
      const comp = sources[i].getComponent('NetworkObject');
      assert.strictEqual(comp.role, UE.NETWORK_ROLE_IDS[i], 'host spawned with the requested role');
    }
    bus.flush();
    assert.strictEqual(clientScene.objects.length, 4, 'all four role objects replicated');
    for (let i = 0; i < UE.NETWORK_ROLE_IDS.length; i++) {
      const role = UE.NETWORK_ROLE_IDS[i];
      const ghost = clientScene.objects[i];
      const comp = ghost.getComponent('NetworkObject');
      assert.ok(comp, role + ' has a NetworkObject on the client');
      assert.strictEqual(comp.role, role, role + ' replicated');
      assert.near(ghost.transform.position.x, i, 1e-3, role + ' position replicated');
      assert.near(ghost.transform.scale.x, UE.NETWORK_ROLES[role].scale.x, 1e-3, role + ' scale replicated');
      if (UE.NETWORK_ROLES[role].sync.tag) assert.strictEqual(ghost.tag, UE.NETWORK_ROLES[role].tag);
    }
    host.leave();
    client.leave();
    bus.close();
  });

  test('FSM templates build editable state machines', function () {
    const scene = new UE.Scene('Templates');
    const object = UE.createEmpty('Template Host');
    scene.add(object);
    assert.strictEqual(UE.Extras.fsmTemplates.length, 9);
    for (const template of UE.Extras.fsmTemplates) {
      const fsm = UE.applyFsmTemplate(object, template.id, { replace: true });
      assert.ok(fsm, template.id + ' produced an FSM');
      assert.strictEqual(fsm.start, template.fsm.start);
      assert.strictEqual(fsm.states.length, template.fsm.states.length);
      const names = fsm.states.map(function (s) { return s.name; });
      for (const state of fsm.states) {
        for (const action of state.actions) {
          assert.ok(UE.PlayMaker.actions[action.type], template.id + ' uses known action ' + action.type);
          assert.strictEqual(action.enabled, true, 'template actions are enabled by default');
        }
        for (const transition of state.transitions) {
          assert.ok(names.indexOf(transition.to) >= 0, template.id + ' transition targets a real state');
        }
      }
    }

    const patrol = UE.applyFsmTemplate(object, 'patrol', { replace: true });
    assert.strictEqual(patrol.variables.fromX, 0);
    patrol.variables.fromX = 99;
    assert.strictEqual(UE.Extras.fsmTemplates.find(function (t) { return t.id === 'patrol'; }).fsm.variables.fromX, 0,
      'template data is cloned, not shared');
    const extra = UE.applyFsmTemplate(object, 'idle', { replace: false });
    assert.ok(extra, 'replace: false adds another FSM');
    assert.strictEqual(object.getComponents('PlayMakerFSM').length, 2, 'replace: false keeps existing FSMs');
    UE.applyFsmTemplate(object, 'spin', { replace: true });
    assert.strictEqual(object.getComponents('PlayMakerFSM').length, 1, 'replace removes old FSMs');
    assert.notStrictEqual(object.getComponent('PlayMakerFSM'), extra, 'the old FSM instance was replaced');
    assert.strictEqual(UE.applyFsmTemplate(object, 'missing'), null);
  });

  test('PlayMaker input actions read gamepad state and #gamepad tokens', function () {
    for (const type of ['waitForInput', 'gamepadButton', 'gamepadAxis', 'gamepadMove']) {
      assert.ok(UE.PlayMaker.actions[type], type + ' action exists');
      assert.strictEqual(UE.PlayMaker.actions[type].category, 'Input');
    }
    assert.ok(UE.PlayMaker.categories.indexOf('Input') >= 0, 'Input category listed');

    const pad = {
      buttons: [], axes: [0.8, 0.1, 0, 0]
    };
    for (let i = 0; i < 16; i++) pad.buttons.push({ pressed: i === 0, value: i === 0 ? 1 : 0 });
    const descriptor = Object.getOwnPropertyDescriptor(navigator, 'getGamepads');
    const saved = {
      deadzone: UE.Input.deadzone,
      bindings: UE.clone(UE.Input.bindings),
      axes: UE.Input.axes.slice(),
      buttons: Object.assign({}, UE.Input.buttons)
    };
    Object.defineProperty(navigator, 'getGamepads', {
      configurable: true,
      value: function () { return [pad, null, null, null]; }
    });
    try {
      UE.Input.reset();
      UE.Input.deadzone = 0.25;
      assert.strictEqual(UE.Input.poll(), 1, 'one gamepad polled');
      assert.strictEqual(UE.Input.button('a'), true);
      assert.near(UE.Input.axis(0), 0.8, 1e-6);
      assert.strictEqual(UE.Input.axis(1), 0, 'small axis value falls inside the deadzone');
      assert.ok(UE.PlayMaker.keys.has('gamepad.a'), 'button press is published to PlayMaker');
      assert.strictEqual(UE.Input.value('gamepad.button.a'), 1);

      const scene = new UE.Scene('Input Actions');
      const object = UE.createEmpty('Input Host');
      scene.add(object);
      const vars = { source: '#gamepad.axes.0' };
      const ctx = actionContext(scene, object, vars);
      runAction('copyVariable', { from: 'source', to: 'copied' }, ctx);
      assert.near(vars.copied, 0.8, 1e-6, '#gamepad.axes.0 token resolved through readValue');

      let event = null;
      const originalSend = UE.PlayMaker.sendEventToObject;
      UE.PlayMaker.sendEventToObject = function (target, name) { event = name; return true; };
      try {
        const runtime = {};
        runAction('gamepadButton', { button: 'a', event: 'JUMP' }, ctx, runtime);
        assert.strictEqual(event, 'JUMP', 'button edge sends the event once');
        event = null;
        runAction('gamepadButton', { button: 'a', event: 'JUMP' }, ctx, runtime);
        assert.strictEqual(event, null, 'holding the button does not repeat the event');
      } finally {
        UE.PlayMaker.sendEventToObject = originalSend;
      }

      const before = object.transform.position.x;
      runAction('gamepadMove', { speed: 1 }, ctx);
      assert.near(object.transform.position.x, before + 0.8 / 60, 1e-6, 'axis drives movement');
      runAction('gamepadAxis', { axis: 0, name: 'filtered', threshold: 0.9 }, ctx);
      assert.strictEqual(vars.filtered, 0, 'threshold zeroes a small axis reading');
    } finally {
      if (descriptor) Object.defineProperty(navigator, 'getGamepads', descriptor);
      else delete navigator.getGamepads;
      UE.Input.deadzone = saved.deadzone;
      UE.Input.bindings = saved.bindings;
      UE.Input.axes = saved.axes;
      UE.Input.buttons = saved.buttons;
      for (const name of UE.Extras.gamepadButtons) UE.PlayMaker.keys.delete('gamepad.' + name);
    }
  });

  test('Texture editor lists, encodes and commits base-color texture edits', function () {
    const png = pngBytes();
    const positions = [0, 0, 0, 1, 0, 0, 0, 1, 0];
    const normals = [0, 0, 1, 0, 0, 1, 0, 0, 1];
    const uvs = [0, 0, 1, 0, 0, 1];
    const name = 'Texture Editor ' + Math.random().toString(36).slice(2);
    const id = UE.AssetStore.add({
      name: name,
      primitives: [{
        positions: positions, normals: normals, uvs: uvs, indices: [0, 1, 2],
        material: { color: '#ffffff', texture: { mime: 'image/png', name: 'albedo.png', bytes: png } }
      }]
    }, name);
    try {
      const scene = new UE.Scene('Texture Editor');
      scene.add(UE.createModel('Painted Triangle', id));
      const entries = UE.Textures.list(scene);
      assert.strictEqual(entries.length, 1, 'one textured primitive listed');
      assert.strictEqual(entries[0].assetId, id);
      assert.strictEqual(entries[0].primIndex, 0);
      assert.strictEqual(entries[0].assetName, name);

      const canvas = document.createElement('canvas');
      canvas.width = 4;
      canvas.height = 4;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ff0000';
      ctx.fillRect(0, 0, 4, 4);
      const encoded = UE.Textures.encode(canvas);
      assert.strictEqual(encoded[0], 137, 'encoded canvas is a PNG');
      const roundTrip = UE.Textures.bytesFromDataUrl(UE.Textures.dataUrlFromBytes(encoded, 'image/png'));
      assert.deepStrictEqual(Array.from(roundTrip), Array.from(encoded), 'data URL helpers round-trip bytes');

      assert.strictEqual(UE.Textures.commit(entries[0], canvas), true);
      const asset = UE.AssetStore.items[id];
      const stored = asset.prims[0].material.texture;
      assert.ok(stored.t.length > 0, 'encoded image written back to the stored asset');
      assert.strictEqual(stored.mime, 'image/png');
      assert.ok(UE.Textures.dataUrl(stored).indexOf('data:image/png;base64,') === 0);
      delete UE.AssetStore.decoded[id];
      const reloaded = UE.AssetStore.get(id).prims[0].material.texture;
      assert.deepStrictEqual(Array.from(reloaded.bytes), Array.from(encoded), 'edited bytes survive a cache reload');
      assert.strictEqual(UE.Textures.list(scene)[0].texture, reloaded, 'the editor sees the committed texture');
    } finally {
      delete UE.AssetStore.items[id];
      delete UE.AssetStore.decoded[id];
    }
  });

  test('Camera PiP views serialize and build a matching projection', function () {
    const scene = new UE.Scene('PiP');
    const main = UE.createCamera('Main Camera', { x: 0, y: 2, z: 8 });
    const pip = UE.createCamera('Second Camera', { x: 6, y: 4, z: 6 });
    pip.getComponent('Camera').main = false;
    pip.getComponent('Camera').pip = true;
    pip.transform.rotation = { x: 0, y: 35, z: 0 };
    scene.add(main);
    scene.add(pip);

    const json = JSON.parse(JSON.stringify(scene.toJSON()));
    const restored = UE.Scene.fromJSON(json);
    const restoredPip = restored.find('Second Camera').getComponent('Camera');
    assert.strictEqual(restoredPip.main, false);
    assert.strictEqual(restoredPip.pip, true, 'PiP flag survives scene JSON');
    assert.strictEqual(restored.mainCamera().name, 'Main Camera');

    const view = UE.cameraView(restored.find('Second Camera'), 4 / 3, { width: 320, height: 240 });
    assert.ok(view && view.viewProj, 'cameraView builds a view-projection matrix');
    assert.near(view.aspect, 4 / 3);
    assert.strictEqual(view.width, 320);
    assert.strictEqual(view.height, 240);
    assert.near(view.eye.x, 6, 1e-6);
    assert.strictEqual(UE.cameraView(null, 1), null);
  });

  /* -------------------------------------------------------------- media tests */
  test('Media format detection and WAV header parsing', function () {
    const wav = wavBytes(0.5, 2, 8000, 16);
    assert.strictEqual(UE.Media.format(wav, 'tone.wav'), 'wav');
    assert.strictEqual(UE.Media.format(new Uint8Array([0x49, 0x44, 0x33, 4]), 'song.mp3'), 'mp3');
    assert.strictEqual(UE.Media.format(new Uint8Array([0x4F, 0x67, 0x67, 0x53]), 'clip.ogv'), 'ogv');
    assert.strictEqual(UE.Media.format(mp4Bytes(), 'clip.mp4'), 'mp4');
    assert.strictEqual(UE.Media.format(new Uint8Array([0x1A, 0x45, 0xDF, 0xA3]), 'clip.webm'), 'webm');
    const info = UE.Media.wavInfo(wav);
    assert.ok(info, 'WAV header parsed without an AudioContext');
    assert.strictEqual(info.sampleRate, 8000);
    assert.strictEqual(info.channels, 2);
    assert.strictEqual(info.bitsPerSample, 16);
    assert.near(info.duration, 0.5, 1e-6);
    assert.strictEqual(UE.Media.wavInfo(new Uint8Array([1, 2, 3])), null);
    assert.strictEqual(UE.Media.mime('wav'), 'audio/wav');
  });

  test('Audio and video assets serialize without losing bytes', function () {
    const store = UE.AssetStore;
    const snap = {
      a: store.audioItems, ad: store.audioDecoded,
      v: store.videoItems, vd: store.videoDecoded
    };
    try {
      store.audioItems = {}; store.audioDecoded = {};
      store.videoItems = {}; store.videoDecoded = {};
      const wav = wavBytes(0.25, 1, 8000, 16);
      const aid = store.addAudio(wav, 'beep.wav');
      assert.strictEqual(aid[0], 'a', 'audio ids are namespaced');
      assert.near(store.audioMeta(aid).duration, 0.25, 1e-6);
      assert.strictEqual(store.addAudio(wav, 'beep.wav'), aid, 'identical audio dedupes');
      const dataUrl = 'data:audio/wav;base64,' + base64FromBytes(wav);
      const urlId = store.addAudio(dataUrl, 'from-url.wav', { dedupe: false });
      assert.deepStrictEqual(Array.from(store.getAudio(urlId)), Array.from(wav));
      const vid = store.addVideo(mp4Bytes(), 'clip.mp4');
      assert.strictEqual(vid[0], 'v', 'video ids are namespaced');
      const json = JSON.parse(JSON.stringify({
        audio: store.toAudioJSON([aid, urlId]), video: store.toVideoJSON([vid])
      }));
      store.audioItems = {}; store.videoItems = {};
      store.audioDecoded = {}; store.videoDecoded = {};
      assert.strictEqual(store.getAudio(aid), null);
      store.fromAudioJSON(json.audio); store.fromVideoJSON(json.video);
      assert.deepStrictEqual(Array.from(store.getAudio(aid)), Array.from(wav));
      assert.strictEqual(store.audioDataUrl(aid).indexOf('data:audio/wav;base64,'), 0);
      assert.deepStrictEqual(Array.from(store.getVideo(vid)), Array.from(mp4Bytes()));
      assert.strictEqual(store.listAudio().length, 2);
      assert.strictEqual(store.listVideo().length, 1);
      assert.strictEqual(store.findAudioByName('beep.wav'), aid);
      assert.throws(function () { store.addAudio(new Uint8Array([1, 2, 3]), 'bad.txt'); }, /Unsupported audio format/);
      store.clear();
      assert.strictEqual(store.listAudio().length, 0);
      assert.strictEqual(store.listVideo().length, 0);
    } finally {
      store.audioItems = snap.a; store.audioDecoded = snap.ad;
      store.videoItems = snap.v; store.videoDecoded = snap.vd;
    }
  });

  test('Media components serialize settings but not runtime objects', function () {
    const object = UE.createEmpty('Media Object');
    const audio = object.addComponent('AudioSource', { clipId: 'a-demo', volume: 0.6, loop: true });
    const video = object.addComponent('VideoPlayer', { clipId: 'v-demo', muted: true, playbackRate: 1.5 });
    audio._runtime = { fake: true };
    video._video = { fake: true };
    const props = {};
    for (const entry of object.toJSON().components) props[entry.type] = entry.props;
    assert.strictEqual(props.AudioSource.clipId, 'a-demo');
    assert.strictEqual(props.AudioSource.volume, 0.6);
    assert.strictEqual(props.AudioSource.loop, true);
    assert.ok(!('_runtime' in props.AudioSource), 'WebAudio nodes stay out of JSON');
    assert.strictEqual(props.VideoPlayer.clipId, 'v-demo');
    assert.strictEqual(props.VideoPlayer.playbackRate, 1.5);
    assert.ok(!('_video' in props.VideoPlayer), 'video elements stay out of JSON');
    const restored = UE.createEmpty('Restored');
    const audioAgain = restored.addComponent('AudioSource', props.AudioSource);
    assert.strictEqual(audioAgain.volume, 0.6);
    assert.strictEqual(audioAgain.clipId, 'a-demo');
  });

  test('Scene JSON embeds only referenced audio and video clips', function () {
    const store = UE.AssetStore;
    const snap = {
      a: store.audioItems, ad: store.audioDecoded,
      v: store.videoItems, vd: store.videoDecoded
    };
    try {
      store.audioItems = {}; store.audioDecoded = {};
      store.videoItems = {}; store.videoDecoded = {};
      const aid = store.addAudio(wavBytes(0.2, 1, 8000, 16), 'voice.wav');
      const vid = store.addVideo(mp4Bytes(), 'screen.mp4');
      const unused = store.addAudio(wavBytes(0.1, 1, 8000, 16), 'unused.wav', { dedupe: false });
      const scene = new UE.Scene('Media Scene');
      const speaker = UE.createEmpty('Speaker');
      speaker.addComponent('AudioSource', { clipId: aid, volume: 0.7, spatial: false });
      const screen = UE.createEmpty('Screen');
      screen.addComponent('VideoPlayer', { clipId: vid, loop: true });
      scene.add(speaker); scene.add(screen);
      const json = JSON.parse(JSON.stringify(scene.toJSON()));
      assert.ok(json.audioAssets[aid], 'referenced audio is embedded');
      assert.strictEqual(json.audioAssets[unused], undefined, 'unused audio stays out');
      assert.ok(json.videoAssets[vid], 'referenced video is embedded');
      assert.strictEqual(scene.toJSON({ assets: false }).audioAssets, undefined);
      store.audioItems = {}; store.videoItems = {};
      store.audioDecoded = {}; store.videoDecoded = {};
      const restored = UE.Scene.fromJSON(json);
      const audio = restored.find('Speaker').getComponent('AudioSource');
      assert.strictEqual(audio.clipId, aid);
      assert.near(audio.volume, 0.7);
      assert.strictEqual(restored.find('Screen').getComponent('VideoPlayer').clipId, vid);
      assert.ok(store.getAudio(aid) && store.getVideo(vid), 'clip bytes restored from scene JSON');
    } finally {
      store.audioItems = snap.a; store.audioDecoded = snap.ad;
      store.videoItems = snap.v; store.videoDecoded = snap.vd;
    }
  });

  test('AudioSource decodes natively through a positional WebAudio graph', async function () {
    const oldCtx = window.AudioContext;
    window.AudioContext = fakeAudioContext();
    try {
      UE.Audio.reset();
      const store = UE.AssetStore;
      const aid = store.addAudio(wavBytes(0.2, 1, 8000, 16), 'runtime.wav', { dedupe: false });
      try {
        const scene = new UE.Scene('Sound');
        const speaker = UE.createEmpty('Speaker');
        speaker.transform.position = { x: 3, y: 1, z: -2 };
        scene.add(speaker);
        const comp = speaker.addComponent('AudioSource',
          { clipId: aid, volume: 0.5, pitch: 1.2, spatial: true });
        assert.strictEqual(await UE.Audio.play(comp), true);
        assert.strictEqual(window.AudioContext.calls.decode.length, 1, 'native decode used once');
        assert.strictEqual(window.AudioContext.calls.start, 1);
        const rt = comp._runtime;
        assert.ok(rt && rt.panner, 'spatial source has a panner');
        assert.near(rt.gain.gain.value, 0.5);
        assert.near(rt.source.playbackRate.value, 1.2);
        UE.Audio.updateListener({
          eye: { x: 0, y: 0, z: 0 }, forward: { x: 0, y: 0, z: -1 }, up: { x: 0, y: 1, z: 0 }
        });
        assert.near(window.AudioContext.calls.ctx.listener.forwardZ.value, -1);
        comp.volume = 0.25; comp.pitch = 1;
        UE.Audio.updateSources(scene);
        assert.near(rt.gain.gain.value, 0.25);
        assert.near(rt.source.playbackRate.value, 1);
        assert.near(rt.panner.positionX.value, 3, 'panner follows the GameObject');
        UE.Audio.pause(comp);
        assert.strictEqual(UE.Audio.status(comp), 'paused');
        assert.strictEqual(await UE.Audio.resume(comp), true);
        assert.strictEqual(window.AudioContext.calls.start, 2);
        UE.Audio.stop(comp);
        assert.strictEqual(UE.Audio.status(comp), 'idle');
      } finally {
        delete store.audioItems[aid]; delete store.audioDecoded[aid];
      }
    } finally {
      UE.Audio.reset();
      window.AudioContext = oldCtx;
    }
  });

  test('VideoPlayer yields a video texture and optional spatial audio', async function () {
    const oldCreate = document.createElement;
    const oldCtx = window.AudioContext;
    window.AudioContext = fakeAudioContext();
    document.createElement = function (tag) {
      return tag === 'video' ? fakeVideo() : oldCreate.call(document, tag);
    };
    try {
      UE.Audio.reset();
      const store = UE.AssetStore;
      const vid = store.addVideo(mp4Bytes(), 'runtime.mp4', { dedupe: false });
      try {
        const scene = new UE.Scene('Video');
        const screen = UE.createEmpty('Screen');
        scene.add(screen);
        const comp = screen.addComponent('VideoPlayer',
          { clipId: vid, spatial: true, autoPlay: true, volume: 0.4 });
        assert.strictEqual(UE.Video.textureFor(screen), null, 'no texture before prepare');
        assert.strictEqual(await UE.Video.play(comp), true);
        const video = comp._video;
        assert.ok(video, 'video element created');
        assert.strictEqual(video.paused, false);
        assert.strictEqual(UE.Video.textureFor(screen), video, 'decoded frames become a texture source');
        assert.ok(comp._audioHandle && comp._audioHandle.panner, 'spatial audio attached');
        assert.near(video.volume, 1, 'graph gain owns volume while spatial');
        comp.spatial = false;
        UE.Video.updateSources(scene);
        assert.strictEqual(comp._audioHandle, null, 'disabling spatial restores element audio');
        assert.near(video.volume, 0.4);
        UE.Video.pause(comp);
        assert.strictEqual(UE.Video.status(comp), 'paused');
        UE.Video.stop(comp);
        assert.strictEqual(video.currentTime, 0);
        UE.Video.release(comp);
        assert.strictEqual(comp._video, null);
      } finally {
        delete store.videoItems[vid]; delete store.videoDecoded[vid];
      }
    } finally {
      document.createElement = oldCreate;
      UE.Audio.reset();
      window.AudioContext = oldCtx;
    }
  });

  /* ------------------------------------------------------------------ runner */
  function render() {
    const passed = results.filter(function (r) { return r.ok; }).length;
    const failed = results.length - passed;
    const summary = document.getElementById('summary');
    summary.textContent = passed + ' / ' + results.length + ' test groups passed' + (failed ? ' - ' + failed + ' failed' : '');
    summary.className = failed ? 'fail' : 'pass';
    const list = document.getElementById('results');
    list.textContent = '';
    for (const result of results) {
      const row = document.createElement('li');
      row.className = result.ok ? 'pass' : 'fail';
      const mark = document.createElement('span');
      mark.className = 'mark';
      mark.textContent = result.ok ? '✓' : '✕';
      const body = document.createElement('div');
      const name = document.createElement('div');
      name.textContent = result.name;
      body.appendChild(name);
      if (!result.ok) {
        const detail = document.createElement('div');
        detail.className = 'detail';
        detail.textContent = result.message;
        body.appendChild(detail);
      }
      row.appendChild(mark);
      row.appendChild(body);
      list.appendChild(row);
    }
    document.title = (failed ? '✕ ' + failed + ' failed' : '✓ all passed') + ' - UnirealEngine tests';
    if (failed) console.error('UnirealEngine tests: ' + failed + ' group(s) failed');
  }

  async function run() {
    results.length = 0;
    UE.onLog = function (level, message) {
      if (logCapture) logCapture.push(message);
    };
    running = true;
    for (const group of groups) await execute(group.name, group.fn);
    running = false;
    UE.onLog = null;
    logCapture = null;
    render();
    return results.slice();
  }

  window.UnirealEngineTests = { results: results, groups: groups, run: run };
  document.getElementById('run').addEventListener('click', function () { run(); });
  run();
})();
