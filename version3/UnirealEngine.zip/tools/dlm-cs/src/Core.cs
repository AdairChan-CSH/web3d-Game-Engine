using System.Globalization;
using System.Net;
using System.Text.RegularExpressions;

namespace Dlm;

// --------------------------------------------------------------------------- //
// Errors
// --------------------------------------------------------------------------- //

public class DownloadException : Exception
{
    public DownloadException(string message) : base(message) { }
    public DownloadException(string message, Exception inner) : base(message, inner) { }
}

public sealed class RangeNotSupportedException : DownloadException
{
    public RangeNotSupportedException(string message) : base(message) { }
}

public sealed class RemoteChangedException : DownloadException
{
    public RemoteChangedException(string message) : base(message) { }
}

public sealed class ChecksumMismatchException : DownloadException
{
    public ChecksumMismatchException(string message) : base(message) { }
}

public sealed class DownloadCancelledException : DownloadException
{
    public DownloadCancelledException(string message) : base(message) { }
}

// --------------------------------------------------------------------------- //
// Models
// --------------------------------------------------------------------------- //

public sealed record RemoteInfo
{
    public string Url { get; init; } = "";
    public string FinalUrl { get; init; } = "";
    public long? Size { get; init; }
    public bool Ranges { get; init; }
    public string? ETag { get; init; }
    public string? LastModified { get; init; }
    public string? FileName { get; init; }
    public string? ContentType { get; init; }
}

public sealed class Chunk
{
    public int Index;
    public long Start;
    public long End; // inclusive
    public long Done;

    public long Length => End - Start + 1;
    public bool Finished => Volatile.Read(ref Done) >= Length;
}

public readonly record struct DownloadProgress(
    long Done,
    long? Total,
    double Speed,
    double? Eta,
    int Connections,
    string Phase = "downloading")
{
    public double? Percent => Total is long total && total > 0
        ? Math.Min(100.0, Done * 100.0 / total)
        : null;
}

public sealed record DownloadResult(
    string Path,
    long Size,
    string? Sha256,
    TimeSpan Elapsed,
    bool Resumed,
    int Connections)
{
    public double AverageSpeed => Elapsed.TotalSeconds > 0 ? Size / Elapsed.TotalSeconds : 0;
}

public sealed record DownloadOptions
{
    public string Url { get; init; } = "";
    public string? Output { get; init; }
    public string? Directory { get; init; }
    public int Connections { get; init; } = 8;
    public long ChunkSize { get; init; } = 8L << 20;
    public TimeSpan Timeout { get; init; } = TimeSpan.FromSeconds(30);
    public int Retries { get; init; } = 5;
    public Dictionary<string, string> Headers { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    public string UserAgent { get; init; } = "dlm/1.0 (resumable segmented downloader)";
    public bool Insecure { get; init; }
    public bool Force { get; init; }
    public bool Restart { get; init; }
    public string? VerifySha256 { get; init; }
    public string? StatePath { get; init; }
    public Action<DownloadProgress>? OnProgress { get; init; }
    public Action<string>? OnLog { get; init; }
}

// --------------------------------------------------------------------------- //
// Probe + helpers
// --------------------------------------------------------------------------- //

public static class HttpProbe
{
    public const int MinChunkSize = 64 * 1024;
    public const int MaxChunks = 20_000;

    private static readonly Regex SizePattern = new(
        @"^(\d+(?:\.\d+)?)\s*([KMGT]?)(?:i?B)?$",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex BadFileNameChars = new(
        @"[<>:""/\\|?*\x00-\x1f]",
        RegexOptions.Compiled);

    public static HttpClient CreateClient(DownloadOptions options)
    {
        // .NET Framework defaults to whatever the OS negotiated; ask for TLS 1.2
        // explicitly so HTTPS works on older Windows builds too.
        ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
        ServicePointManager.Expect100Continue = false;
        ServicePointManager.DefaultConnectionLimit = Math.Max(
            ServicePointManager.DefaultConnectionLimit,
            Math.Max(8, options.Connections));

        var handler = new HttpClientHandler
        {
            AllowAutoRedirect = true,
            AutomaticDecompression = DecompressionMethods.None,
            MaxConnectionsPerServer = Math.Max(8, options.Connections),
        };
        if (options.Insecure)
        {
            handler.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
        }

        var client = new HttpClient(handler)
        {
            Timeout = Timeout.InfiniteTimeSpan,
        };
        if (!client.DefaultRequestHeaders.UserAgent.TryParseAdd(options.UserAgent))
        {
            client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", options.UserAgent);
        }
        return client;
    }

    public static async Task<RemoteInfo> ProbeAsync(
        HttpClient client,
        DownloadOptions options,
        CancellationToken cancellationToken)
    {
        using (var request = new HttpRequestMessage(HttpMethod.Get, options.Url))
        {
            request.Headers.TryAddWithoutValidation("Range", "bytes=0-0");
            request.Headers.TryAddWithoutValidation("Accept-Encoding", "identity");
            foreach (var header in options.Headers)
            {
                request.Headers.TryAddWithoutValidation(header.Key, header.Value);
            }

            using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
            {
                timeout.CancelAfter(options.Timeout);

                HttpResponseMessage response;
                try
                {
                    response = await client
                        .SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token)
                        .ConfigureAwait(false);
                }
                catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
                {
                    throw new DownloadException(
                        $"timed out after {options.Timeout.TotalSeconds:0}s probing {options.Url}");
                }
                catch (HttpRequestException ex)
                {
                    throw new DownloadException($"cannot reach {options.Url}: {ex.Message}", ex);
                }

                using (response)
                {
                    int status = (int)response.StatusCode;
                    string finalUrl = response.RequestMessage?.RequestUri?.ToString() ?? options.Url;
                    string? etag = response.Headers.ETag?.ToString();
                    string? lastModified = response.Content.Headers.LastModified?.ToString(
                        "R", CultureInfo.InvariantCulture);
                    string? contentType = response.Content.Headers.ContentType?.ToString();
                    string? fileName = FileNameFromHeaders(response) ?? FileNameFromUrl(finalUrl);

                    long? size;
                    bool ranges;

                    if (status == 206)
                    {
                        var range = response.Content.Headers.ContentRange;
                        if (range is null)
                        {
                            throw new DownloadException(
                                "server sent 206 without a usable Content-Range header");
                        }
                        size = range.Length;
                        ranges = true;
                    }
                    else if (status == 200)
                    {
                        size = response.Content.Headers.ContentLength;
                        ranges = false;
                    }
                    else if (status == 416)
                    {
                        size = response.Content.Headers.ContentRange?.Length;
                        ranges = true;
                    }
                    else
                    {
                        throw new DownloadException($"HTTP {status} {response.ReasonPhrase} for {options.Url}");
                    }

                    return new RemoteInfo
                    {
                        Url = options.Url,
                        FinalUrl = finalUrl,
                        Size = size,
                        Ranges = ranges,
                        ETag = etag,
                        LastModified = lastModified,
                        FileName = fileName,
                        ContentType = contentType,
                    };
                }
            }
        }
    }

    private static string? FileNameFromHeaders(HttpResponseMessage response)
    {
        var disposition = response.Content.Headers.ContentDisposition;
        string? name = disposition?.FileNameStar ?? disposition?.FileName;
        if (string.IsNullOrWhiteSpace(name))
        {
            return null;
        }
        name = name!.Trim().Trim('"');
        name = name.Replace('\\', '/');
        int slash = name.LastIndexOf('/');
        return slash >= 0 ? name.Substring(slash + 1) : name;
    }

    public static string? FileNameFromUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            return null;
        }
        string path = uri.AbsolutePath.TrimEnd('/');
        int slash = path.LastIndexOf('/');
        string name = Uri.UnescapeDataString(slash >= 0 ? path.Substring(slash + 1) : path);
        return string.IsNullOrWhiteSpace(name) ? null : name;
    }

    public static string SafeFileName(string name)
    {
        name = BadFileNameChars.Replace(name, "_").Trim().TrimEnd('.', ' ');
        if (name.Length == 0 || name == "." || name == "..")
        {
            return "download";
        }
        return name.Length > 200 ? name.Substring(0, 200) : name;
    }

    public static long ParseSize(string text)
    {
        var match = SizePattern.Match(text.Trim());
        if (!match.Success)
        {
            throw new FormatException($"invalid size: {text}");
        }
        double value = double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
        long multiplier = match.Groups[2].Value.ToUpperInvariant() switch
        {
            "" => 1L,
            "K" => 1L << 10,
            "M" => 1L << 20,
            "G" => 1L << 30,
            "T" => 1L << 40,
            _ => 1L,
        };
        return (long)(value * multiplier);
    }

    public static List<Chunk> SplitChunks(long size, long chunkSize)
    {
        chunkSize = Math.Max(MinChunkSize, chunkSize);
        while (size > 0 && (size + chunkSize - 1) / chunkSize > MaxChunks)
        {
            chunkSize *= 2;
        }

        var chunks = new List<Chunk>();
        long start = 0;
        int index = 0;
        while (start < size)
        {
            long end = Math.Min(start + chunkSize, size) - 1;
            chunks.Add(new Chunk { Index = index++, Start = start, End = end });
            start = end + 1;
        }
        return chunks;
    }

    public static string ExpandHome(string path)
    {
        if (path == "~")
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        }
        if (path.StartsWith("~/", StringComparison.Ordinal)
            || path.StartsWith("~\\", StringComparison.Ordinal))
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                path.Substring(2));
        }
        return path;
    }

    public static string FormatBytes(long? value)
    {
        if (!value.HasValue)
        {
            return "?";
        }
        long bytes = value.Value;
        string[] units = { "B", "KiB", "MiB", "GiB", "TiB", "PiB" };
        double size = bytes;
        int unit = 0;
        while (size >= 1024 && unit < units.Length - 1)
        {
            size /= 1024;
            unit++;
        }
        return unit == 0
            ? bytes.ToString(CultureInfo.InvariantCulture) + " B"
            : FormattableString.Invariant($"{size:0.0} {units[unit]}");
    }

    public static string FormatTime(double? seconds)
    {
        if (!seconds.HasValue)
        {
            return "--:--";
        }
        double value = seconds.Value;
        if (double.IsNaN(value) || double.IsInfinity(value))
        {
            return "--:--";
        }
        long total = (long)Math.Max(0, value);
        long hours = total / 3600;
        long minutes = total % 3600 / 60;
        long secs = total % 60;
        return hours > 0
            ? FormattableString.Invariant($"{hours}:{minutes:00}:{secs:00}")
            : FormattableString.Invariant($"{minutes:00}:{secs:00}");
    }
}
