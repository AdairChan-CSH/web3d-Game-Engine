using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;

namespace Dlm;

/// <summary>
/// A single resumable, segmented HTTP(S) download.
/// </summary>
public sealed class Downloader : IDisposable
{
    private sealed class StateDto
    {
        public int Version { get; set; }
        public string Url { get; set; } = "";
        public string? FinalUrl { get; set; }
        public long? Size { get; set; }
        public string? ETag { get; set; }
        public string? LastModified { get; set; }
        public string Mode { get; set; } = "single";
        public List<long[]> Chunks { get; set; } = new List<long[]>();
    }

    private const int StateVersion = 1;
    private const int ReadBlock = 256 * 1024;

    private readonly DownloadOptions _options;
    private readonly HttpClient _client;
    private readonly object _saveLock = new object();
    private readonly object _progressLock = new object();

    private ConcurrentQueue<Chunk> _queue = new ConcurrentQueue<Chunk>();
    private CancellationTokenSource _cts = new CancellationTokenSource();
    private Task[] _workers = Array.Empty<Task>();
    private Exception? _fatal;

    private string _mode = "single";
    private long? _size;
    private bool _ranges;
    private List<Chunk> _chunks = new List<Chunk>();
    private string _partPath = "";
    private string? _statePath;
    private string _finalUrl = "";
    private string? _etag;
    private string? _lastModified;

    private long _singleDone;
    private long _resumedBytes;
    private double _speed;
    private long _lastDone;
    private long _lastTick;
    private long _lastSave;
    private long _started;

    public Downloader(DownloadOptions options)
    {
        _options = options;
        _client = HttpProbe.CreateClient(options);
    }

    public string OutputPath { get; private set; } = "";

    public void Cancel() => _cts.Cancel();

    public void Dispose() => _client.Dispose();

    public async Task<DownloadResult> RunAsync(CancellationToken cancellationToken = default)
    {
        _started = Stopwatch.GetTimestamp();
        _lastTick = _started;
        _lastDone = 0;
        _speed = 0;
        _lastSave = 0;
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        Log($"probing {_options.Url}");
        var info = await HttpProbe.ProbeAsync(_client, _options, _cts.Token).ConfigureAwait(false);
        _finalUrl = info.FinalUrl;
        _etag = info.ETag;
        _lastModified = info.LastModified;
        _ranges = info.Ranges;

        OutputPath = ResolveOutput(info);
        _partPath = OutputPath + ".part";
        _statePath = _options.StatePath ?? _partPath + ".dlmstate";

        string? parent = Path.GetDirectoryName(OutputPath);
        if (!string.IsNullOrEmpty(parent))
        {
            Directory.CreateDirectory(parent);
        }

        if (File.Exists(OutputPath) && !_options.Force)
        {
            throw new DownloadException(
                $"refusing to overwrite {OutputPath} (pass --force)");
        }

        if (_options.Restart)
        {
            ClearState();
        }

        bool resumed = Restore(info);
        if (resumed)
        {
            _resumedBytes = _mode == "chunked"
                ? _chunks.Sum(c => Volatile.Read(ref c.Done))
                : 0;
        }
        else
        {
            Plan(info);
            _resumedBytes = 0;
        }

        PreparePart();

        Log(
            $"{(resumed ? "resuming" : "downloading")} " +
            $"{(_size.HasValue ? _size.Value.ToString(CultureInfo.InvariantCulture) : "unknown")} " +
            $"bytes in {_mode} mode");

        try
        {
            if (_mode == "chunked")
            {
                await RunChunkedAsync().ConfigureAwait(false);
            }
            else
            {
                await RunSingleAsync().ConfigureAwait(false);
            }
        }
        catch (DownloadCancelledException)
        {
            SaveState();
            throw;
        }
        catch (OperationCanceledException) when (_cts.IsCancellationRequested)
        {
            SaveState();
            throw new DownloadCancelledException("cancelled");
        }
        catch
        {
            SaveState();
            throw;
        }

        long size = _size ?? new FileInfo(_partPath).Length;
        string? digest = await VerifyAsync(size).ConfigureAwait(false);

        Compat.MoveOverwrite(_partPath, OutputPath);
        ClearState(removePart: false);

        Log($"saved {size} bytes to {OutputPath}");
        return new DownloadResult(
            OutputPath,
            size,
            digest,
            Compat.Elapsed(_started),
            resumed && _resumedBytes > 0,
            WorkerCount);
    }

    // -- planning / state --------------------------------------------------- //

    private string ResolveOutput(RemoteInfo info)
    {
        string name = HttpProbe.SafeFileName(info.FileName ?? "download");

        string? rawOutput = _options.Output;
        if (!string.IsNullOrEmpty(rawOutput))
        {
            string output = Path.GetFullPath(
                HttpProbe.ExpandHome(Environment.ExpandEnvironmentVariables(rawOutput)));
            bool isDirectory = Directory.Exists(output)
                || rawOutput!.EndsWith("/", StringComparison.Ordinal)
                || rawOutput!.EndsWith("\\", StringComparison.Ordinal);
            return isDirectory ? Path.Combine(output, name) : output;
        }

        string directory = Path.GetFullPath(
            HttpProbe.ExpandHome(Environment.ExpandEnvironmentVariables(
                _options.Directory ?? Environment.CurrentDirectory)));
        return Path.Combine(directory, name);
    }

    private void Plan(RemoteInfo info)
    {
        if (!info.Size.HasValue)
        {
            _mode = "single";
            _size = null;
            _chunks = new List<Chunk>();
            return;
        }

        _size = info.Size.Value;
        if (info.Ranges && info.Size.Value > 0)
        {
            _mode = "chunked";
            _chunks = HttpProbe.SplitChunks(info.Size.Value, _options.ChunkSize);
        }
        else
        {
            _mode = "single";
            _chunks = new List<Chunk>();
        }
    }

    private bool Restore(RemoteInfo info)
    {
        string? statePath = _statePath;
        if (string.IsNullOrEmpty(statePath) || !File.Exists(statePath))
        {
            return false;
        }

        StateDto? state;
        try
        {
            state = ParseState(File.ReadAllText(statePath));
        }
        catch (Exception ex) when (ex is IOException || ex is FormatException || ex is ArgumentException)
        {
            Log("resume state is unreadable; starting over");
            ClearState();
            return false;
        }

        if (state is null || !StateMatches(state, info))
        {
            Log("remote file changed or state does not match; starting over");
            ClearState();
            return false;
        }

        var chunks = new List<Chunk>();
        foreach (long[] item in state.Chunks)
        {
            if (item.Length != 3)
            {
                ClearState();
                return false;
            }
            long length = item[1] - item[0] + 1;
            chunks.Add(new Chunk
            {
                Index = chunks.Count,
                Start = item[0],
                End = item[1],
                Done = Compat.Clamp(item[2], 0, length),
            });
        }

        if (chunks.Count == 0)
        {
            ClearState();
            return false;
        }

        _mode = state.Mode;
        _size = state.Size;
        _chunks = chunks;
        Log($"resuming with {chunks.Sum(c => c.Done)} bytes already on disk");
        return true;
    }

    private bool StateMatches(StateDto state, RemoteInfo info)
    {
        if (state.Version != StateVersion || state.Url != _options.Url)
        {
            return false;
        }
        if (state.Size != info.Size)
        {
            return false;
        }
        if (state.Mode != "chunked" && state.Mode != "single")
        {
            return false;
        }
        if (state.Mode == "chunked" && !info.Ranges)
        {
            return false;
        }
        if (!File.Exists(_partPath))
        {
            return false;
        }
        if (info.Size.HasValue && new FileInfo(_partPath).Length != info.Size.Value)
        {
            return false;
        }
        if (state.ETag != null && state.ETag != info.ETag)
        {
            return false;
        }
        if (state.LastModified != null && state.LastModified != info.LastModified)
        {
            return false;
        }
        if (state.Mode == "chunked")
        {
            if (state.Chunks.Count == 0)
            {
                return false;
            }
            long total = state.Chunks.Sum(c => c[1] - c[0] + 1);
            if (!info.Size.HasValue || total != info.Size.Value)
            {
                return false;
            }
        }
        return true;
    }

    private void SaveState()
    {
        string? statePath = _statePath;
        if (string.IsNullOrEmpty(statePath) || string.IsNullOrEmpty(_partPath))
        {
            return;
        }

        lock (_saveLock)
        {
            string stateFile = statePath!;
            var state = new StateDto
            {
                Version = StateVersion,
                Url = _options.Url,
                FinalUrl = _finalUrl,
                Size = _size,
                ETag = _etag,
                LastModified = _lastModified,
                Mode = _mode,
                Chunks = _chunks
                    .Select(c => new[] { c.Start, c.End, Volatile.Read(ref c.Done) })
                    .ToList(),
            };

            string tmp = stateFile + ".tmp";
            try
            {
                File.WriteAllText(tmp, SerializeState(state));
                Compat.MoveOverwrite(tmp, stateFile);
                _lastSave = Stopwatch.GetTimestamp();
            }
            catch (IOException ex)
            {
                Log($"could not write resume state: {ex.Message}");
            }
        }
    }

    private void ClearState(bool removePart = true)
    {
        TryDelete(_statePath);
        TryDelete(_statePath + ".tmp");
        if (removePart)
        {
            TryDelete(_partPath);
        }
    }

    private static void TryDelete(string? path)
    {
        if (string.IsNullOrEmpty(path))
        {
            return;
        }
        try
        {
            File.Delete(path);
        }
        catch (IOException)
        {
        }
        catch (UnauthorizedAccessException)
        {
        }
    }

    private void PreparePart()
    {
        if (_size.HasValue)
        {
            using (var file = new FileStream(
                _partPath, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
            {
                file.SetLength(_size.Value);
            }
        }
        else
        {
            using (var file = new FileStream(
                _partPath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
            {
            }
        }
    }

    // -- chunked mode ------------------------------------------------------- //

    private async Task RunChunkedAsync()
    {
        var pending = _chunks.Where(c => !c.Finished).ToList();
        if (pending.Count == 0)
        {
            Log("all chunks already complete");
            return;
        }

        _queue = new ConcurrentQueue<Chunk>(pending);
        int workers = Math.Max(1, Math.Min(_options.Connections, pending.Count));
        _workers = Enumerable.Range(0, workers)
            .Select(_ => Task.Run(() => WorkerAsync(_cts.Token), _cts.Token))
            .ToArray();

        await MonitorAsync().ConfigureAwait(false);

        if (_fatal is not null)
        {
            throw Wrap(_fatal);
        }
        if (_cts.IsCancellationRequested)
        {
            throw new DownloadCancelledException("cancelled");
        }
    }

    private async Task WorkerAsync(CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested && _queue.TryDequeue(out Chunk chunk))
            {
                await FetchChunkAsync(chunk, cancellationToken).ConfigureAwait(false);
                if (Compat.Elapsed(_lastSave) >= TimeSpan.FromMilliseconds(250))
                {
                    SaveState();
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            Interlocked.CompareExchange(ref _fatal, ex, null);
            _cts.Cancel();
        }
    }

    private async Task FetchChunkAsync(Chunk chunk, CancellationToken cancellationToken)
    {
        for (int attempt = 0; ; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            long start = chunk.Start + Volatile.Read(ref chunk.Done);
            if (start > chunk.End)
            {
                return;
            }

            try
            {
                await StreamRangeAsync(chunk, start, cancellationToken).ConfigureAwait(false);
                return;
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                if (attempt >= _options.Retries)
                {
                    throw new DownloadException(
                        $"chunk {chunk.Index} failed after {attempt + 1} attempts: {ex.Message}", ex);
                }
                TimeSpan delay = Backoff(attempt);
                Log(
                    $"chunk {chunk.Index}: {ex.Message} - retry {attempt + 1}/{_options.Retries} " +
                    $"in {delay.TotalSeconds:0.0}s");
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
        }
    }

    private async Task StreamRangeAsync(Chunk chunk, long start, CancellationToken cancellationToken)
    {
        using (var request = new HttpRequestMessage(HttpMethod.Get, _finalUrl))
        {
            request.Headers.TryAddWithoutValidation("Range", $"bytes={start}-{chunk.End}");
            AddHeaders(request);

            using (var response = await SendAsync(request, cancellationToken).ConfigureAwait(false))
            {
                int status = (int)response.StatusCode;

                if (status == 416)
                {
                    throw new RemoteChangedException(
                        "server says the requested range is no longer available");
                }
                if (status == 200)
                {
                    throw new RangeNotSupportedException(
                        "server ignored the Range header mid-download; rerun with --restart");
                }
                if (status != 206)
                {
                    throw new DownloadException(
                        $"HTTP {status} {response.ReasonPhrase} for chunk {chunk.Index}");
                }

                var contentRange = response.Content.Headers.ContentRange;
                if (contentRange == null || contentRange.From != start)
                {
                    throw new DownloadException(
                        $"server returned the wrong byte range for chunk {chunk.Index}");
                }
                if (contentRange.Length.HasValue && _size.HasValue
                    && contentRange.Length.Value != _size.Value)
                {
                    throw new RemoteChangedException("remote size changed during the download");
                }

                using (var stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false))
                using (var file = new FileStream(
                    _partPath, FileMode.Open, FileAccess.Write, FileShare.ReadWrite, 1,
                    FileOptions.Asynchronous))
                {
                    file.Seek(start, SeekOrigin.Begin);

                    byte[] buffer = new byte[ReadBlock];
                    long remaining = chunk.Length - Volatile.Read(ref chunk.Done);
                    while (remaining > 0)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        int want = (int)Math.Min(buffer.Length, remaining);
                        int read = await ReadWithTimeoutAsync(
                            stream, buffer, 0, want, cancellationToken).ConfigureAwait(false);
                        if (read == 0)
                        {
                            throw new DownloadException(
                                $"connection closed {remaining} bytes early on chunk {chunk.Index}");
                        }
                        await file.WriteAsync(buffer, 0, read, cancellationToken).ConfigureAwait(false);
                        Interlocked.Add(ref chunk.Done, read);
                        remaining -= read;
                    }
                }
            }
        }
    }

    // -- single-stream mode ------------------------------------------------- //

    private async Task RunSingleAsync()
    {
        _workers = new[]
        {
            Task.Run(() => SingleWorkerAsync(_cts.Token), _cts.Token),
        };

        await MonitorAsync().ConfigureAwait(false);

        if (_fatal is not null)
        {
            throw Wrap(_fatal);
        }
        if (_cts.IsCancellationRequested)
        {
            throw new DownloadCancelledException("cancelled");
        }
    }

    private async Task SingleWorkerAsync(CancellationToken cancellationToken)
    {
        try
        {
            for (int attempt = 0; ; attempt++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                long start = 0;
                if (_ranges && _size.HasValue && File.Exists(_partPath))
                {
                    start = Math.Min(new FileInfo(_partPath).Length, _size.Value);
                }

                try
                {
                    await StreamSingleAsync(start, cancellationToken).ConfigureAwait(false);
                    return;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    if (attempt >= _options.Retries)
                    {
                        throw new DownloadException(
                            $"download failed after {attempt + 1} attempts: {ex.Message}", ex);
                    }
                    TimeSpan delay = Backoff(attempt);
                    Log(
                        $"{ex.Message} - retry {attempt + 1}/{_options.Retries} " +
                        $"in {delay.TotalSeconds:0.0}s");
                    await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            Interlocked.CompareExchange(ref _fatal, ex, null);
            _cts.Cancel();
        }
    }

    private async Task StreamSingleAsync(long start, CancellationToken cancellationToken)
    {
        using (var request = new HttpRequestMessage(HttpMethod.Get, _finalUrl))
        {
            if (start > 0)
            {
                request.Headers.TryAddWithoutValidation("Range", $"bytes={start}-");
            }
            AddHeaders(request);

            using (var response = await SendAsync(request, cancellationToken).ConfigureAwait(false))
            {
                int status = (int)response.StatusCode;

                if (status == 416 && _size.HasValue)
                {
                    return;
                }
                if (status != 200 && status != 206)
                {
                    throw new DownloadException($"HTTP {status} {response.ReasonPhrase}");
                }

                FileMode mode;
                long written;
                if (status == 206)
                {
                    var contentRange = response.Content.Headers.ContentRange;
                    if (start > 0 && (contentRange == null || contentRange.From != start))
                    {
                        throw new DownloadException("server returned the wrong resume offset");
                    }
                    if (contentRange != null && contentRange.Length.HasValue)
                    {
                        _size = contentRange.Length.Value;
                    }
                    if (start > 0)
                    {
                        mode = FileMode.Open;
                        written = start;
                    }
                    else
                    {
                        mode = FileMode.Create;
                        written = 0;
                    }
                }
                else
                {
                    start = 0;
                    if (response.Content.Headers.ContentLength.HasValue)
                    {
                        _size = response.Content.Headers.ContentLength.Value;
                    }
                    mode = FileMode.Create;
                    written = 0;
                }

                Interlocked.Exchange(ref _singleDone, written);

                using (var stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false))
                using (var file = new FileStream(
                    _partPath, mode, FileAccess.Write, FileShare.ReadWrite, 1,
                    FileOptions.Asynchronous))
                {
                    if (start > 0)
                    {
                        file.Seek(start, SeekOrigin.Begin);
                    }

                    byte[] buffer = new byte[ReadBlock];
                    while (true)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        int read = await ReadWithTimeoutAsync(
                            stream, buffer, 0, buffer.Length, cancellationToken).ConfigureAwait(false);
                        if (read == 0)
                        {
                            break;
                        }
                        await file.WriteAsync(buffer, 0, read, cancellationToken).ConfigureAwait(false);
                        written += read;
                        Interlocked.Exchange(ref _singleDone, written);
                    }
                }

                if (_size.HasValue && written != _size.Value)
                {
                    throw new DownloadException(
                        $"connection closed early ({written} of {_size.Value} bytes)");
                }
            }
        }
    }

    // -- shared plumbing ---------------------------------------------------- //

    private async Task MonitorAsync()
    {
        Task all = Task.WhenAll(_workers);
        while (!all.IsCompleted)
        {
            Tick();
            try
            {
                await Task.WhenAny(all, Task.Delay(100, _cts.Token)).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        try
        {
            await all.ConfigureAwait(false);
        }
        catch
        {
            // The first failure is stored in _fatal and surfaced by the caller.
        }
        Tick();
    }

    private void Tick()
    {
        long now = Stopwatch.GetTimestamp();
        long done = Done();
        double elapsed = (now - _lastTick) / (double)Stopwatch.Frequency;
        if (elapsed >= 0.2)
        {
            double instant = Math.Max(0, (done - _lastDone) / elapsed);
            _speed = _speed <= 0 ? instant : 0.7 * _speed + 0.3 * instant;
            _lastDone = done;
            _lastTick = now;
        }

        double? eta = null;
        if (_size.HasValue && _speed > 0)
        {
            eta = Math.Max(0, (_size.Value - done) / _speed);
        }

        Emit(new DownloadProgress(done, _size, _speed, eta, WorkerCount, "downloading"));
    }

    private long Done()
    {
        if (_mode != "chunked")
        {
            return Interlocked.Read(ref _singleDone);
        }
        long total = 0;
        foreach (Chunk chunk in _chunks)
        {
            total += Volatile.Read(ref chunk.Done);
        }
        return total;
    }

    private int WorkerCount =>
        _mode == "chunked" ? Math.Max(1, Math.Min(_options.Connections, _chunks.Count)) : 1;

    private void Emit(DownloadProgress progress)
    {
        Action<DownloadProgress>? callback = _options.OnProgress;
        if (callback is null)
        {
            return;
        }
        try
        {
            lock (_progressLock)
            {
                callback(progress);
            }
        }
        catch
        {
            // A broken progress callback must not kill the download.
        }
    }

    private async Task<string?> VerifyAsync(long size)
    {
        string? maybeExpected = _options.VerifySha256;
        if (string.IsNullOrWhiteSpace(maybeExpected))
        {
            return null;
        }
        string expected = maybeExpected!;

        string actual;
        using (var sha = SHA256.Create())
        using (var file = new FileStream(
            _partPath, FileMode.Open, FileAccess.Read, FileShare.Read, 1,
            FileOptions.SequentialScan))
        {
            byte[] buffer = new byte[1024 * 1024];
            long done = 0;
            int read;
            while ((read = file.Read(buffer, 0, buffer.Length)) > 0)
            {
                sha.TransformBlock(buffer, 0, read, null, 0);
                done += read;
                Emit(new DownloadProgress(done, size, 0, null, 0, "verifying"));
            }
            sha.TransformFinalBlock(buffer, 0, 0);
            actual = Compat.Hex(sha.Hash);
        }

        if (!actual.Equals(expected.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            ClearState(removePart: false);
            throw new ChecksumMismatchException(
                $"sha256 mismatch for {_partPath}: got {actual}, expected {expected}");
        }
        return actual;
    }

    private void AddHeaders(HttpRequestMessage request)
    {
        request.Headers.TryAddWithoutValidation("Accept-Encoding", "identity");
        foreach (var header in _options.Headers)
        {
            request.Headers.TryAddWithoutValidation(header.Key, header.Value);
        }
    }

    private async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
        {
            timeout.CancelAfter(_options.Timeout);
            try
            {
                return await _client
                    .SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token)
                    .ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException(
                    $"no response within {_options.Timeout.TotalSeconds:0}s");
            }
        }
    }

    private async Task<int> ReadWithTimeoutAsync(
        Stream stream,
        byte[] buffer,
        int offset,
        int count,
        CancellationToken cancellationToken)
    {
        using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
        {
            timeout.CancelAfter(_options.Timeout);
            try
            {
                return await stream.ReadAsync(buffer, offset, count, timeout.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException(
                    $"no data received for {_options.Timeout.TotalSeconds:0}s");
            }
        }
    }

    private static TimeSpan Backoff(int attempt)
    {
        double seconds = Math.Min(0.5 * Math.Pow(2, attempt), 8.0) + Compat.NextDouble() * 0.25;
        return TimeSpan.FromSeconds(seconds);
    }

    private static DownloadException Wrap(Exception exception) =>
        exception as DownloadException ?? new DownloadException(exception.Message, exception);

    private void Log(string message)
    {
        try
        {
            _options.OnLog?.Invoke(message);
        }
        catch
        {
            // Logging must never break the transfer.
        }
    }

    // -- state file --------------------------------------------------------- //

    private static string SerializeState(StateDto state)
    {
        var sb = new StringBuilder();
        sb.Append("dlm-state ")
            .Append(state.Version.ToString(CultureInfo.InvariantCulture))
            .Append('\n');
        sb.Append("url ").Append(Encode(state.Url)).Append('\n');
        if (state.FinalUrl != null)
        {
            sb.Append("final ").Append(Encode(state.FinalUrl)).Append('\n');
        }
        if (state.Size.HasValue)
        {
            sb.Append("size ")
                .Append(state.Size.Value.ToString(CultureInfo.InvariantCulture))
                .Append('\n');
        }
        if (state.ETag != null)
        {
            sb.Append("etag ").Append(Encode(state.ETag)).Append('\n');
        }
        if (state.LastModified != null)
        {
            sb.Append("modified ").Append(Encode(state.LastModified)).Append('\n');
        }
        sb.Append("mode ").Append(state.Mode).Append('\n');
        foreach (long[] chunk in state.Chunks)
        {
            sb.Append("chunk ")
                .Append(chunk[0].ToString(CultureInfo.InvariantCulture)).Append(' ')
                .Append(chunk[1].ToString(CultureInfo.InvariantCulture)).Append(' ')
                .Append(chunk[2].ToString(CultureInfo.InvariantCulture)).Append('\n');
        }
        return sb.ToString();
    }

    private static StateDto? ParseState(string text)
    {
        var state = new StateDto();
        string[] lines = text.Split('\n');
        foreach (string raw in lines)
        {
            string line = raw.TrimEnd('\r');
            if (line.Length == 0)
            {
                continue;
            }

            int space = line.IndexOf(' ');
            string key = space < 0 ? line : line.Substring(0, space);
            string value = space < 0 ? "" : line.Substring(space + 1);

            switch (key)
            {
                case "dlm-state":
                    if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int version))
                    {
                        return null;
                    }
                    state.Version = version;
                    break;
                case "url":
                    state.Url = Decode(value);
                    break;
                case "final":
                    state.FinalUrl = Decode(value);
                    break;
                case "size":
                    if (!long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out long size))
                    {
                        return null;
                    }
                    state.Size = size;
                    break;
                case "etag":
                    state.ETag = Decode(value);
                    break;
                case "modified":
                    state.LastModified = Decode(value);
                    break;
                case "mode":
                    state.Mode = value;
                    break;
                case "chunk":
                {
                    string[] parts = value.Split(' ');
                    if (parts.Length != 3
                        || !long.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out long start)
                        || !long.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out long end)
                        || !long.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out long done))
                    {
                        return null;
                    }
                    state.Chunks.Add(new[] { start, end, done });
                    break;
                }
                default:
                    return null;
            }
        }
        return state;
    }

    private static string Encode(string value) =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes(value));

    private static string Decode(string value) =>
        Encoding.UTF8.GetString(Convert.FromBase64String(value));
}
