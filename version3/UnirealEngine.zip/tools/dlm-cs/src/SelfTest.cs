using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Dlm;

/// <summary>
/// Dependency-free end-to-end tests. Runs a real HTTP/1.1 server on a loopback
/// socket and drives the actual <see cref="Downloader"/> against it.
/// </summary>
internal static class SelfTest
{
    private static readonly byte[] Payload = CreatePayload(4 * 1024 * 1024);

    public static async Task<int> RunAsync()
    {
        var tests = new (string Name, Func<Task> Body)[]
        {
            ("probe reports size and range support", ProbeReportsSize),
            ("chunked download is byte exact", ChunkedDownload),
            ("resume continues after cancellation", ResumeAfterCancel),
            ("remote change restarts the download", RemoteChangeRestarts),
            ("no range support falls back to single stream", NoRangeFallback),
            ("retry recovers from a dropped connection", RetryRecovers),
            ("refuses to overwrite without force", OverwriteGuard),
            ("checksum mismatch keeps part and does not publish", ChecksumMismatch),
            ("checksum success", ChecksumSuccess),
            ("filename from content-disposition", DispositionFilename),
            ("split chunks cover the file exactly", SplitChunksCover),
            ("cli downloads a file", CliDownload),
        };

        int failed = 0;
        foreach ((string name, Func<Task> body) in tests)
        {
            try
            {
                await body().ConfigureAwait(false);
                Console.WriteLine($"PASS  {name}");
            }
            catch (Exception ex)
            {
                failed++;
                Console.WriteLine($"FAIL  {name}: {ex.Message}");
            }
        }

        Console.WriteLine();
        Console.WriteLine(failed == 0
            ? $"{tests.Length} passed"
            : $"{failed} of {tests.Length} failed");
        return failed == 0 ? 0 : 1;
    }

    // -- tests -------------------------------------------------------------- //

    private static async Task ProbeReportsSize()
    {
        using var server = new TestHttpServer(Payload);
        using var client = HttpProbe.CreateClient(Options(server.Url));
        RemoteInfo info = await HttpProbe.ProbeAsync(client, Options(server.Url), CancellationToken.None);

        Assert(info.Size == Payload.Length, $"size was {info.Size}");
        Assert(info.Ranges, "ranges should be supported");
        Assert(info.ETag == "\"v1\"", $"etag was {info.ETag}");
        Assert(info.FileName == "file.bin", $"filename was {info.FileName}");
    }

    private static Task ChunkedDownload() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload);
        using var downloader = new Downloader(Options(server.Url) with
        {
            Output = output,
            Connections = 4,
            ChunkSize = 512 * 1024,
        });

        DownloadResult result = await downloader.RunAsync();
        Assert(result.Size == Payload.Length, $"size was {result.Size}");
        Assert(!result.Resumed, "fresh download should not be marked resumed");
        Assert(result.Connections == 4, $"connections was {result.Connections}");
        AssertPayload(output);
        AssertClean(output);
    });

    private static Task ResumeAfterCancel() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload) { Delay = TimeSpan.FromMilliseconds(15) };
        using var cts = new CancellationTokenSource();

        DownloadOptions first = Options(server.Url) with
        {
            Output = output,
            Connections = 2,
            ChunkSize = 512 * 1024,
            OnProgress = progress =>
            {
                if (progress.Done > Payload.Length * 0.25)
                {
                    cts.Cancel();
                }
            },
        };

        using (var downloader = new Downloader(first))
        {
            await AssertThrows<DownloadCancelledException>(() => downloader.RunAsync(cts.Token));
        }

        string statePath = output + ".part.dlmstate";
        Assert(File.Exists(statePath), "resume state should survive a cancel");
        long saved = ReadStateBytes(statePath);
        Assert(saved > 0, "some bytes should have been saved");
        Assert(saved < Payload.Length, "the download should not have finished");

        using var resume = new Downloader(Options(server.Url) with
        {
            Output = output,
            Connections = 2,
            ChunkSize = 512 * 1024,
        });
        DownloadResult result = await resume.RunAsync();
        Assert(result.Resumed, "result should be marked resumed");
        AssertPayload(output);
        AssertClean(output);
    });

    private static Task RemoteChangeRestarts() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload) { Delay = TimeSpan.FromMilliseconds(15) };
        using var cts = new CancellationTokenSource();

        DownloadOptions first = Options(server.Url) with
        {
            Output = output,
            Connections = 2,
            ChunkSize = 512 * 1024,
            OnProgress = progress =>
            {
                if (progress.Done > Payload.Length * 0.25)
                {
                    cts.Cancel();
                }
            },
        };

        using (var downloader = new Downloader(first))
        {
            await AssertThrows<DownloadCancelledException>(() => downloader.RunAsync(cts.Token));
        }

        server.ETag = "\"v2\"";

        using var resume = new Downloader(Options(server.Url) with
        {
            Output = output,
            Connections = 2,
            ChunkSize = 512 * 1024,
        });
        DownloadResult result = await resume.RunAsync();
        Assert(!result.Resumed, "changed remote should restart");
        AssertPayload(output);
        AssertClean(output);
    });

    private static Task NoRangeFallback() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload) { SupportRanges = false };
        using var downloader = new Downloader(Options(server.Url) with
        {
            Output = output,
            Connections = 8,
        });

        DownloadResult result = await downloader.RunAsync();
        Assert(result.Connections == 1, $"connections was {result.Connections}");
        AssertPayload(output);
        AssertClean(output);
    });

    private static Task RetryRecovers() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload) { Flaky = true };
        var logs = new List<string>();
        using var downloader = new Downloader(Options(server.Url) with
        {
            Output = output,
            Connections = 2,
            ChunkSize = 512 * 1024,
            Retries = 3,
            OnLog = message =>
            {
                lock (logs)
                {
                    logs.Add(message);
                }
            },
        });

        await downloader.RunAsync();
        Assert(server.Dropped == 1, $"server dropped {server.Dropped} connections");
        lock (logs)
        {
            Assert(logs.Any(line => line.IndexOf("retry", StringComparison.OrdinalIgnoreCase) >= 0),
                $"a retry should have been logged; hits={server.Hits}, logs=[{string.Join(" | ", logs)}]");
        }
        AssertPayload(output);
        AssertClean(output);
    });

    private static Task OverwriteGuard() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        File.WriteAllText(output, "keep me");
        using var server = new TestHttpServer(Payload);

        using (var downloader = new Downloader(Options(server.Url) with { Output = output }))
        {
            await AssertThrows<DownloadException>(() => downloader.RunAsync());
        }
        Assert(File.ReadAllText(output) == "keep me", "existing file was modified");

        using var forced = new Downloader(Options(server.Url) with { Output = output, Force = true });
        DownloadResult result = await forced.RunAsync();
        Assert(result.Size == Payload.Length, $"size was {result.Size}");
        AssertPayload(output);
    });

    private static Task ChecksumMismatch() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload);
        using var downloader = new Downloader(Options(server.Url) with
        {
            Output = output,
            VerifySha256 = new string('0', 64),
        });

        await AssertThrows<ChecksumMismatchException>(() => downloader.RunAsync());
        Assert(!File.Exists(output), "a bad file must not be published");
        Assert(File.Exists(output + ".part"), "part file should be kept for inspection");
        Assert(!File.Exists(output + ".part.dlmstate"), "state should be cleared");
    });

    private static Task ChecksumSuccess() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        string expected;
        using (var sha = SHA256.Create())
        {
            expected = Compat.Hex(sha.ComputeHash(Payload));
        }
        using var server = new TestHttpServer(Payload);
        using var downloader = new Downloader(Options(server.Url) with
        {
            Output = output,
            VerifySha256 = expected,
        });

        DownloadResult result = await downloader.RunAsync();
        Assert(result.Sha256 == expected.ToLowerInvariant(), $"sha256 was {result.Sha256}");
        AssertPayload(output);
    });

    private static Task DispositionFilename() => WithTempDir(async dir =>
    {
        using var server = new TestHttpServer(Payload)
        {
            Disposition = "attachment; filename=\"real name.bin\"",
        };
        using var downloader = new Downloader(Options(server.Url) with { Directory = dir });

        DownloadResult result = await downloader.RunAsync();
        Assert(Path.GetFileName(result.Path) == "real name.bin",
            $"filename was {Path.GetFileName(result.Path)}");
        AssertPayload(result.Path);
    });

    private static Task SplitChunksCover()
    {
        const long size = 10L * 1024 * 1024 + 7;
        List<Chunk> chunks = HttpProbe.SplitChunks(size, 1024 * 1024);

        Assert(chunks[0].Start == 0, "first chunk should start at zero");
        Assert(chunks[chunks.Count - 1].End == size - 1, "last chunk should end at size - 1");
        for (int i = 1; i < chunks.Count; i++)
        {
            Assert(chunks[i - 1].End + 1 == chunks[i].Start, "chunks must be contiguous");
        }
        Assert(chunks.Sum(c => c.Length) == size, "chunks must cover the file exactly");
        return Task.CompletedTask;
    }

    private static Task CliDownload() => WithTempDir(async dir =>
    {
        string output = Path.Combine(dir, "file.bin");
        using var server = new TestHttpServer(Payload);

        int code = await Cli.RunAsync(new[]
        {
            server.Url, "-o", output, "-c", "3", "--chunk-size", "256K", "--quiet",
        });

        Assert(code == 0, $"exit code was {code}");
        AssertPayload(output);
        AssertClean(output);
    });

    // -- helpers ------------------------------------------------------------ //

    private static DownloadOptions Options(string url) => new()
    {
        Url = url,
        Timeout = TimeSpan.FromSeconds(5),
    };

    private static byte[] CreatePayload(int size)
    {
        var bytes = new byte[size];
        new Random(1234).NextBytes(bytes);
        return bytes;
    }

    private static async Task WithTempDir(Func<string, Task> body)
    {
        string dir = Path.Combine(Path.GetTempPath(), "dlm-cs-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            await body(dir).ConfigureAwait(false);
        }
        finally
        {
            try
            {
                Directory.Delete(dir, true);
            }
            catch (IOException)
            {
            }
        }
    }

    private static long ReadStateBytes(string path)
    {
        long total = 0;
        foreach (string line in File.ReadLines(path))
        {
            if (!line.StartsWith("chunk ", StringComparison.Ordinal))
            {
                continue;
            }
            string[] parts = line.Split(' ');
            if (parts.Length == 4
                && long.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out long done))
            {
                total += done;
            }
        }
        return total;
    }

    private static void AssertPayload(string path)
    {
        byte[] actual = File.ReadAllBytes(path);
        Assert(Compat.BytesEqual(actual, Payload), $"contents of {path} do not match");
    }

    private static void AssertClean(string output)
    {
        Assert(!File.Exists(output + ".part"), "part file should be gone");
        Assert(!File.Exists(output + ".part.dlmstate"), "state file should be gone");
    }

    private static async Task AssertThrows<T>(Func<Task> action) where T : Exception
    {
        try
        {
            await action().ConfigureAwait(false);
        }
        catch (T)
        {
            return;
        }
        catch (Exception ex)
        {
            throw new Exception($"expected {typeof(T).Name}, got {ex.GetType().Name}: {ex.Message}");
        }
        throw new Exception($"expected {typeof(T).Name}, but nothing was thrown");
    }

    private static void Assert(bool condition, string message)
    {
        if (!condition)
        {
            throw new Exception(message);
        }
    }
}

/// <summary>
/// Minimal HTTP/1.1 server used by the self-test. Supports byte ranges, a
/// one-shot mid-body disconnect and artificial delays.
/// </summary>
internal sealed class TestHttpServer : IDisposable
{
    private readonly TcpListener _listener = new TcpListener(IPAddress.Loopback, 0);
    private readonly CancellationTokenSource _cts = new CancellationTokenSource();
    private readonly Task _acceptLoop;
    private readonly byte[] _payload;
    private int _hits;
    private int _dropped;

    public TestHttpServer(byte[] payload)
    {
        _payload = payload;
        _listener.Start();
        int port = ((IPEndPoint)_listener.LocalEndpoint).Port;
        Url = $"http://127.0.0.1:{port}/file.bin";
        _acceptLoop = AcceptLoopAsync();
    }

    public string Url { get; }
    public bool SupportRanges { get; set; } = true;
    public bool Flaky { get; set; }
    public TimeSpan Delay { get; set; }
    public string? Disposition { get; set; }
    public string ETag { get; set; } = "\"v1\"";
    public int Hits => Volatile.Read(ref _hits);
    public int Dropped => Volatile.Read(ref _dropped);

    public void Dispose()
    {
        _cts.Cancel();
        try
        {
            _listener.Stop();
        }
        catch (SocketException)
        {
        }
        try
        {
            _acceptLoop.Wait(TimeSpan.FromSeconds(2));
        }
        catch (Exception)
        {
        }
        _cts.Dispose();
    }

    private async Task AcceptLoopAsync()
    {
        while (!_cts.IsCancellationRequested)
        {
            TcpClient client;
            try
            {
                client = await _listener.AcceptTcpClientAsync().ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                return;
            }
            catch (ObjectDisposedException)
            {
                return;
            }
            catch (SocketException)
            {
                return;
            }
            catch (InvalidOperationException)
            {
                return;
            }
            _ = Task.Run(() => HandleAsync(client));
        }
    }

    private async Task HandleAsync(TcpClient client)
    {
        using (client)
        {
            try
            {
                NetworkStream stream = client.GetStream();
                string? head = await ReadHeadAsync(stream).ConfigureAwait(false);
                if (head is not null)
                {
                    await ServeAsync(stream, head).ConfigureAwait(false);
                }
            }
            catch (IOException)
            {
            }
            catch (SocketException)
            {
            }
            catch (ObjectDisposedException)
            {
            }
        }
    }

    private async Task<string?> ReadHeadAsync(NetworkStream stream)
    {
        var builder = new StringBuilder();
        byte[] buffer = new byte[4096];
        while (builder.Length < 64 * 1024)
        {
            int read = await stream.ReadAsync(buffer, 0, buffer.Length, _cts.Token)
                .ConfigureAwait(false);
            if (read == 0)
            {
                return null;
            }
            builder.Append(Encoding.ASCII.GetString(buffer, 0, read));
            if (builder.ToString().IndexOf("\r\n\r\n", StringComparison.Ordinal) >= 0)
            {
                return builder.ToString();
            }
        }
        return null;
    }

    private async Task ServeAsync(NetworkStream stream, string head)
    {
        string[] lines = head.Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            lines[i] = lines[i].TrimEnd('\r');
        }

        string[] requestLine = lines[0].Split(' ');
        string method = requestLine.Length > 0 ? requestLine[0] : "";

        var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 1; i < lines.Length; i++)
        {
            int colon = lines[i].IndexOf(':');
            if (colon > 0)
            {
                headers[lines[i].Substring(0, colon).Trim()] =
                    lines[i].Substring(colon + 1).Trim();
            }
        }

        Interlocked.Increment(ref _hits);
        if (method != "GET")
        {
            await WriteResponseAsync(
                stream, 405, "Method Not Allowed", Array.Empty<byte>(), null, 0)
                .ConfigureAwait(false);
            return;
        }

        int total = _payload.Length;
        long start = 0;
        long end = total - 1;
        int status = 200;

        if (SupportRanges && headers.TryGetValue("Range", out string? rangeHeader))
        {
            Match match = Regex.Match(rangeHeader, @"^bytes=(\d+)-(\d*)$");
            if (match.Success)
            {
                start = long.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
                if (match.Groups[2].Value.Length > 0)
                {
                    end = Math.Min(
                        long.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture),
                        total - 1);
                }
                if (start >= total)
                {
                    await WriteResponseAsync(
                        stream, 416, "Range Not Satisfiable", Array.Empty<byte>(),
                        new Dictionary<string, string> { ["Content-Range"] = $"bytes */{total}" }, 0)
                        .ConfigureAwait(false);
                    return;
                }
                status = 206;
            }
        }

        int bodyLength = (int)(end - start + 1);
        byte[] body = new byte[bodyLength];
        Array.Copy(_payload, (int)start, body, 0, bodyLength);

        var extra = new Dictionary<string, string>
        {
            ["Accept-Ranges"] = SupportRanges ? "bytes" : "none",
            ["ETag"] = ETag,
        };
        if (Disposition is not null)
        {
            extra["Content-Disposition"] = Disposition;
        }
        if (status == 206)
        {
            extra["Content-Range"] = $"bytes {start}-{end}/{total}";
        }

        bool drop = Flaky
            && body.Length > 256 * 1024
            && Interlocked.CompareExchange(ref _dropped, 1, 0) == 0;
        int bodyBytes = drop ? body.Length / 3 : body.Length;

        await WriteResponseAsync(
            stream, status, status == 206 ? "Partial Content" : "OK", body, extra, bodyBytes)
            .ConfigureAwait(false);
    }

    private async Task WriteResponseAsync(
        NetworkStream stream,
        int status,
        string reason,
        byte[] body,
        Dictionary<string, string>? extra,
        int bodyBytes)
    {
        var head = new StringBuilder();
        head.Append($"HTTP/1.1 {status} {reason}\r\n");
        head.Append("Content-Type: application/octet-stream\r\n");
        head.Append("Content-Length: ")
            .Append(body.Length.ToString(CultureInfo.InvariantCulture))
            .Append("\r\n");
        head.Append("Connection: close\r\n");
        if (extra is not null)
        {
            foreach (var header in extra)
            {
                head.Append(header.Key).Append(": ").Append(header.Value).Append("\r\n");
            }
        }
        head.Append("\r\n");

        byte[] headBytes = Encoding.ASCII.GetBytes(head.ToString());
        await stream.WriteAsync(headBytes, 0, headBytes.Length).ConfigureAwait(false);

        int offset = 0;
        int remaining = bodyBytes;
        while (remaining > 0)
        {
            int count = Math.Min(64 * 1024, remaining);
            await stream.WriteAsync(body, offset, count).ConfigureAwait(false);
            offset += count;
            remaining -= count;
            if (Delay > TimeSpan.Zero)
            {
                await Task.Delay(Delay).ConfigureAwait(false);
            }
        }
        await stream.FlushAsync().ConfigureAwait(false);
    }
}
