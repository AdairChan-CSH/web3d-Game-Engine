using System.Diagnostics;
using System.Globalization;

namespace Dlm;

public static class Cli
{
    private sealed class UsageException : Exception
    {
        public UsageException(string message) : base(message) { }
    }

    public static async Task<int> RunAsync(string[] args)
    {
        if (args.Length == 1 && (args[0] == "selftest" || args[0] == "--selftest"))
        {
            return await SelfTest.RunAsync().ConfigureAwait(false);
        }

        var urls = new List<string>();
        string? inputFile = null;
        string? output = null;
        string? directory = null;
        string? sha256 = null;
        string? userAgent = null;
        int connections = 8;
        long chunkSize = 8L << 20;
        double timeout = 30;
        int retries = 5;
        bool insecure = false;
        bool force = false;
        bool restart = false;
        bool infoOnly = false;
        bool quiet = false;
        var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            List<string> tokens = Expand(args);
            for (int i = 0; i < tokens.Count; i++)
            {
                string token = tokens[i];

                string Value()
                {
                    if (i + 1 >= tokens.Count)
                    {
                        throw new UsageException($"{token} requires a value");
                    }
                    return tokens[++i];
                }

                switch (token)
                {
                    case "-h":
                    case "--help":
                        PrintHelp();
                        return 0;
                    case "--version":
                        Console.WriteLine("dlm 1.0 (C# / .NET Framework 4.8)");
                        return 0;
                    case "-i":
                    case "--input":
                        inputFile = Value();
                        break;
                    case "-o":
                    case "--output":
                        output = Value();
                        break;
                    case "-d":
                    case "--dir":
                        directory = Value();
                        break;
                    case "-c":
                    case "--connections":
                        connections = int.Parse(Value(), CultureInfo.InvariantCulture);
                        break;
                    case "--chunk-size":
                        chunkSize = HttpProbe.ParseSize(Value());
                        break;
                    case "--timeout":
                        timeout = double.Parse(Value(), CultureInfo.InvariantCulture);
                        break;
                    case "--retries":
                        retries = int.Parse(Value(), CultureInfo.InvariantCulture);
                        break;
                    case "--sha256":
                        sha256 = Value();
                        break;
                    case "-H":
                    case "--header":
                    {
                        string raw = Value();
                        int colon = raw.IndexOf(':');
                        if (colon <= 0)
                        {
                            throw new UsageException(
                                $"header must look like 'Name: value', got '{raw}'");
                        }
                        headers[raw.Substring(0, colon).Trim()] = raw.Substring(colon + 1).Trim();
                        break;
                    }
                    case "-A":
                    case "--user-agent":
                        userAgent = Value();
                        break;
                    case "-k":
                    case "--insecure":
                        insecure = true;
                        break;
                    case "-f":
                    case "--force":
                        force = true;
                        break;
                    case "--restart":
                        restart = true;
                        break;
                    case "--info":
                        infoOnly = true;
                        break;
                    case "-q":
                    case "--quiet":
                        quiet = true;
                        break;
                    default:
                        if (token.Length > 1 && token[0] == '-')
                        {
                            throw new UsageException($"unknown option {token}");
                        }
                        urls.Add(token);
                        break;
                }
            }

            if (connections < 1)
            {
                throw new UsageException("--connections must be >= 1");
            }
            if (retries < 0)
            {
                throw new UsageException("--retries must be >= 0");
            }
            if (timeout <= 0)
            {
                throw new UsageException("--timeout must be > 0");
            }
        }
        catch (UsageException ex)
        {
            Console.Error.WriteLine($"dlm: {ex.Message}");
            Console.Error.WriteLine("try 'dlm --help'");
            return 2;
        }
        catch (FormatException)
        {
            Console.Error.WriteLine("dlm: invalid numeric option value");
            return 2;
        }

        if (inputFile is not null)
        {
            try
            {
                urls.AddRange(ReadUrls(inputFile));
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                Console.Error.WriteLine($"dlm: cannot read {inputFile}: {ex.Message}");
                return 1;
            }
        }

        if (urls.Count == 0)
        {
            Console.Error.WriteLine("dlm: no URL given (pass a URL or use --input)");
            Console.Error.WriteLine("try 'dlm --help'");
            return 2;
        }
        if (urls.Count > 1 && output is not null && !Directory.Exists(output))
        {
            Console.Error.WriteLine(
                "dlm: --output must be an existing directory when downloading several URLs");
            return 2;
        }
        if (urls.Count > 1 && sha256 is not null)
        {
            Console.Error.WriteLine("dlm: --sha256 can only be used with a single URL");
            return 2;
        }

        DownloadOptions BuildOptions(string url) => new()
        {
            Url = url,
            Output = urls.Count == 1 ? output : null,
            Directory = directory ?? (urls.Count > 1 ? output : null),
            Connections = connections,
            ChunkSize = chunkSize,
            Timeout = TimeSpan.FromSeconds(timeout),
            Retries = retries,
            Headers = headers,
            UserAgent = userAgent ?? "dlm/1.0 (resumable segmented downloader)",
            Insecure = insecure,
            Force = force,
            Restart = restart,
            VerifySha256 = urls.Count == 1 ? sha256 : null,
        };

        if (infoOnly)
        {
            return await PrintInfoAsync(urls, BuildOptions).ConfigureAwait(false);
        }

        using (var cts = new CancellationTokenSource())
        {
            ConsoleCancelEventHandler handler = (_, e) =>
            {
                e.Cancel = true;
                cts.Cancel();
            };
            Console.CancelKeyPress += handler;

            var renderer = new ProgressRenderer(quiet);
            int failed = 0;

            try
            {
                for (int index = 0; index < urls.Count; index++)
                {
                    string url = urls[index];
                    if (urls.Count > 1 && !quiet)
                    {
                        Console.Error.WriteLine($"dlm: [{index + 1}/{urls.Count}] {url}");
                    }

                    DownloadOptions options = BuildOptions(url) with
                    {
                        OnProgress = renderer.Report,
                        OnLog = quiet ? null : message => Console.Error.WriteLine($"dlm: {message}"),
                    };

                    using (var downloader = new Downloader(options))
                    {
                        try
                        {
                            DownloadResult result = await downloader
                                .RunAsync(cts.Token)
                                .ConfigureAwait(false);
                            renderer.Finish();
                            PrintSummary(result);
                        }
                        catch (DownloadCancelledException)
                        {
                            renderer.Finish();
                            Console.Error.WriteLine(
                                "dlm: interrupted - rerun the same command to resume");
                            return 130;
                        }
                        catch (ChecksumMismatchException ex)
                        {
                            renderer.Finish();
                            Console.Error.WriteLine($"dlm: {ex.Message}");
                            failed++;
                        }
                        catch (DownloadException ex)
                        {
                            renderer.Finish();
                            Console.Error.WriteLine($"dlm: {ex.Message}");
                            failed++;
                        }
                        catch (OperationCanceledException)
                        {
                            renderer.Finish();
                            Console.Error.WriteLine(
                                "dlm: interrupted - rerun the same command to resume");
                            return 130;
                        }
                    }
                }
            }
            finally
            {
                Console.CancelKeyPress -= handler;
            }

            return failed == 0 ? 0 : 1;
        }
    }

    private static List<string> Expand(string[] args)
    {
        var tokens = new List<string>(args.Length);
        foreach (string arg in args)
        {
            if (arg.StartsWith("--", StringComparison.Ordinal))
            {
                int equals = arg.IndexOf('=');
                if (equals > 2)
                {
                    tokens.Add(arg.Substring(0, equals));
                    tokens.Add(arg.Substring(equals + 1));
                    continue;
                }
            }
            tokens.Add(arg);
        }
        return tokens;
    }

    private static IEnumerable<string> ReadUrls(string path)
    {
        foreach (string line in File.ReadLines(path))
        {
            string trimmed = line.Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith("#", StringComparison.Ordinal))
            {
                continue;
            }
            yield return trimmed;
        }
    }

    private static async Task<int> PrintInfoAsync(
        List<string> urls,
        Func<string, DownloadOptions> buildOptions)
    {
        int status = 0;
        using (var client = HttpProbe.CreateClient(buildOptions(urls[0])))
        {
            for (int index = 0; index < urls.Count; index++)
            {
                if (index > 0)
                {
                    Console.WriteLine();
                }

                string url = urls[index];
                try
                {
                    RemoteInfo info = await HttpProbe
                        .ProbeAsync(client, buildOptions(url), CancellationToken.None)
                        .ConfigureAwait(false);

                    Console.WriteLine($"URL:         {url}");
                    Console.WriteLine($"Final URL:   {info.FinalUrl}");
                    Console.WriteLine(
                        $"Size:        {HttpProbe.FormatBytes(info.Size)}" +
                        (info.Size.HasValue
                            ? $" ({info.Size.Value.ToString(CultureInfo.InvariantCulture)} bytes)"
                            : ""));
                    Console.WriteLine(
                        $"Ranges:      {(info.Ranges ? "yes (segmented download)" : "no (single stream)")}");
                    Console.WriteLine($"Filename:    {info.FileName ?? "-"}");
                    Console.WriteLine($"Type:        {info.ContentType ?? "-"}");
                    Console.WriteLine($"ETag:        {info.ETag ?? "-"}");
                    Console.WriteLine($"Modified:    {info.LastModified ?? "-"}");
                }
                catch (DownloadException ex)
                {
                    Console.Error.WriteLine($"dlm: {ex.Message}");
                    status = 1;
                }
            }
        }
        return status;
    }

    private static void PrintSummary(DownloadResult result)
    {
        string connections = result.Connections == 1
            ? "1 conn"
            : result.Connections.ToString(CultureInfo.InvariantCulture) + " conns";
        string resumed = result.Resumed ? ", resumed" : "";
        Console.WriteLine(
            $"saved {HttpProbe.FormatBytes(result.Size)} to {result.Path} " +
            $"in {HttpProbe.FormatTime(result.Elapsed.TotalSeconds)} " +
            $"({HttpProbe.FormatBytes((long)result.AverageSpeed)}/s, {connections}{resumed})");
        if (result.Sha256 is not null)
        {
            Console.WriteLine($"sha256 {result.Sha256}");
        }
    }

    private static void PrintHelp()
    {
        Console.WriteLine("""
            usage: dlm [options] URL [URL ...]
                   dlm -i FILE [options]
                   dlm selftest

            Segmented, resumable HTTP(S) downloader. Downloads only files you
            have the right to fetch.

            options:
              -i, --input FILE        read URLs from FILE (one per line, # comments)
              -o, --output PATH       output file (one URL) or directory (many)
              -d, --dir DIR           directory for names derived from the URL
              -c, --connections N     parallel workers (default 8)
                  --chunk-size SIZE   chunk size, e.g. 512K, 4M, 1G (default 8M)
                  --timeout SEC       per-request socket timeout (default 30)
                  --retries N         retries per chunk with backoff (default 5)
                  --sha256 HEX        expected SHA-256; mismatch fails the download
              -H, --header 'K: V'     extra request header, repeatable
              -A, --user-agent UA     User-Agent header
              -k, --insecure          do not verify TLS certificates
              -f, --force             overwrite an existing output file
                  --restart           discard partial data and state, start over
                  --info              probe only: size, ranges, ETag, filename
              -q, --quiet             no progress output
              -h, --help              show this help
                  --version           print the version

            exit codes: 0 success, 1 failure, 2 usage, 130 interrupted
            """);
    }
}

internal sealed class ProgressRenderer
{
    private const int LineWidth = 110;
    private const int BarWidth = 24;

    private readonly bool _enabled;
    private long _lastRender;
    private bool _drawn;

    public ProgressRenderer(bool quiet)
    {
        _enabled = !quiet && !Console.IsErrorRedirected;
    }

    public void Report(DownloadProgress progress)
    {
        if (!_enabled)
        {
            return;
        }

        long now = Stopwatch.GetTimestamp();
        if (progress.Phase == "downloading"
            && Compat.Elapsed(_lastRender).TotalMilliseconds < 120)
        {
            return;
        }
        _lastRender = now;

        string line;
        if (progress.Phase == "verifying")
        {
            line =
                $" verifying  {HttpProbe.FormatBytes(progress.Done)}/" +
                $"{HttpProbe.FormatBytes(progress.Total)}";
        }
        else if (progress.Total.HasValue && progress.Total.Value > 0)
        {
            long total = progress.Total.Value;
            double fraction = Math.Min(1.0, (double)progress.Done / total);
            int filled = (int)(fraction * BarWidth);
            string bar = new string('#', filled) + new string('-', BarWidth - filled);
            line = string.Format(
                CultureInfo.InvariantCulture,
                " {0,5:F1}% [{1}] {2}/{3} {4}/s eta {5} {6}c",
                fraction * 100,
                bar,
                HttpProbe.FormatBytes(progress.Done),
                HttpProbe.FormatBytes(progress.Total),
                HttpProbe.FormatBytes((long)progress.Speed),
                HttpProbe.FormatTime(progress.Eta),
                progress.Connections);
        }
        else
        {
            line = string.Format(
                CultureInfo.InvariantCulture,
                " {0} {1}/s {2}c",
                HttpProbe.FormatBytes(progress.Done),
                HttpProbe.FormatBytes((long)progress.Speed),
                progress.Connections);
        }

        Console.Error.Write("\r" + line.PadRight(LineWidth));
        _drawn = true;
    }

    public void Finish()
    {
        if (!_enabled || !_drawn)
        {
            return;
        }
        Console.Error.Write("\r" + new string(' ', LineWidth) + "\r");
        _drawn = false;
    }
}
