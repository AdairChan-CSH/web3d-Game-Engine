using System.Diagnostics;
using System.Globalization;

namespace System.Runtime.CompilerServices
{
    // Records and init-only setters need this type; .NET Framework predates it.
    internal static class IsExternalInit
    {
    }
}

namespace Dlm
{
    /// <summary>
    /// Small helpers that paper over .NET Framework vs .NET 8 API differences.
    /// </summary>
    internal static class Compat
    {
        private static readonly Random Rng = new Random();

        public static string Hex(byte[] bytes)
        {
            var sb = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes)
            {
                sb.Append(b.ToString("x2", CultureInfo.InvariantCulture));
            }
            return sb.ToString();
        }

        public static long Clamp(long value, long min, long max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        public static double NextDouble()
        {
            lock (Rng)
            {
                return Rng.NextDouble();
            }
        }

        public static TimeSpan Elapsed(long startTimestamp)
        {
            long now = Stopwatch.GetTimestamp();
            return TimeSpan.FromSeconds((now - startTimestamp) / (double)Stopwatch.Frequency);
        }

        public static void MoveOverwrite(string source, string destination)
        {
            if (File.Exists(destination))
            {
                File.Delete(destination);
            }
            File.Move(source, destination);
        }

        public static bool BytesEqual(byte[] left, byte[] right)
        {
            if (left.Length != right.Length)
            {
                return false;
            }
            for (int i = 0; i < left.Length; i++)
            {
                if (left[i] != right[i])
                {
                    return false;
                }
            }
            return true;
        }
    }
}
