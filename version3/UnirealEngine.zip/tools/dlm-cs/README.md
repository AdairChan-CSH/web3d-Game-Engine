# dlm (C#) — segmented, resumable download manager

A small command-line downloader that splits a file across several connections,
survives crashes and Ctrl+C, and verifies what it fetched.

**A single `dlm.exe`.** No `dotnet` command, no .NET runtime download, no NuGet
packages. It targets .NET Framework 4.8, which is built into Windows 10 (1903+)
and Windows 11.

```text
  63.4% [###############---------]  6.3 GiB/10.0 GiB  24.1 MiB/s eta 02:35  8c
```

## Why this exists

It is a general-purpose downloader for files you are allowed to fetch: official
demos and installers, game patches from a vendor CDN, public-domain ROMs,
emulator builds, mods, datasets, your own hosted files.

It does **not** search for or fetch commercial game ROMs. There is no index
scraper, no warez integration and no DRM circumvention in here, and none will be
added.

## Build

```console
powershell -NoProfile -ExecutionPolicy Bypass -File tools\dlm-cs\build.ps1
```

The script finds Roslyn (`csc.exe`) in Visual Studio Build Tools, references the
managed assemblies of the installed .NET Framework, and compiles `src/*.cs`
straight to `dist\dlm.exe`. It does not invoke `dotnet`, download anything, or
need an SDK. Add `-Test` to build and run the self-tests in one step.

If you have an SDK and prefer MSBuild, `Dlm.csproj` targets `net48`:

```console
dotnet build Dlm.csproj -c Release -o dist
```

Output:

```text
tools/dlm-cs/dist/
  dlm.exe        # standalone console app
```

Run it directly:

```console
tools\dlm-cs\dist\dlm.exe --help
```

Requires .NET Framework 4.8 or newer. Windows 10 1903+ and Windows 11 include
it; `winver` or the registry key
`HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full` (`Release >= 528040`)
confirms it.

## Quick start

```console
tools\dlm-cs\dist\dlm.exe https://example.com/big.iso
tools\dlm-cs\dist\dlm.exe https://example.com/big.iso -o %USERPROFILE%\Downloads\big.iso -c 16
tools\dlm-cs\dist\dlm.exe https://example.com/big.iso --sha256 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
```

Interrupt it at any point (Ctrl+C, closed laptop, killed process) and run the
same command again — it continues from the last saved offset:

```console
$ dlm https://example.com/big.iso
dlm: probing https://example.com/big.iso
dlm: resuming with 2684354560 bytes already on disk
 26.8% [######------------------]  2.5 GiB/10.0 GiB  ...
```

## Examples

**Check a URL before downloading it**

```console
$ dlm --info https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip
URL:         https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip
Final URL:   https://www.python.org/ftp/python/3.12.7/python-3.12.7-embed-amd64.zip
Size:        10.6 MiB (11062583 bytes)
Ranges:      yes (segmented download)
Filename:    python-3.12.7-embed-amd64.zip
Type:        application/zip
ETag:        "66fb7dfb-a8cd37"
Modified:    Tue, 01 Oct 2024 04:43:39 GMT
```

**Batch download**

```console
$ type urls.txt
# official demos
https://example.com/demo-1.zip
https://example.com/demo-2.zip

$ dlm -i urls.txt -d %USERPROFILE%\Downloads -c 8
```

**Headers and TLS**

```console
dlm URL -H "Referer: https://example.com/" -H "Authorization: Bearer ..."
dlm URL -A "MyApp/2.0" -k     # -k skips certificate verification
```

**Force a fresh download**

```console
dlm URL -o big.iso --restart
```

## Options

| Option | Meaning |
| --- | --- |
| `URL ...` | One or more URLs. |
| `-i, --input FILE` | Read URLs from a file (one per line, `#` comments). |
| `-o, --output PATH` | Output file for one URL; output directory for several. |
| `-d, --dir DIR` | Directory for names derived from the URL. |
| `-c, --connections N` | Parallel workers (default 8). |
| `--chunk-size SIZE` | Chunk size: `512K`, `4M`, `1G` (default `8M`). |
| `--timeout SEC` | Per-request socket timeout (default 30). |
| `--retries N` | Retries per chunk with exponential backoff (default 5). |
| `--sha256 HEX` | Expected digest; a mismatch fails the download. |
| `-H, --header 'K: V'` | Extra request header, repeatable. |
| `-A, --user-agent UA` | Override the User-Agent. |
| `-k, --insecure` | Do not verify TLS certificates. |
| `-f, --force` | Overwrite an existing output file. |
| `--restart` | Delete partial data and resume state, start at zero. |
| `--info` | Probe only: size, range support, ETag, filename. |
| `-q, --quiet` | No progress output. |

Long options also accept `--name=value`. Exit codes: `0` success, `1` failure,
`2` usage, `130` interrupted.

HTTP(S) proxies are honoured through the usual `HTTP_PROXY` / `HTTPS_PROXY` /
`NO_PROXY` environment variables.

## How it works

1. **Probe.** A `GET` with `Range: bytes=0-0` asks for one byte. The
   `Content-Range` reply gives the true size and proves the server supports
   ranges; `ETag` / `Last-Modified` are recorded. `GET` is used instead of `HEAD`
   because plenty of CDNs answer `HEAD` badly.
2. **Plan.** The file is cut into fixed-size chunks (one chunk when the file is
   smaller than `--chunk-size`). If ranges are unsupported, it falls back to a
   single stream that resumes with a trailing `Range` request when it can.
3. **Fetch.** A pool of workers pulls chunks from a queue and writes each one at
   its own offset in `<name>.part`, one file handle per worker. Failed chunks are
   retried with exponential backoff plus jitter.
4. **Persist.** `<name>.part.dlmstate` is a small plain-text file listing the
   byte count of every chunk. It is rewritten atomically (temp file + replace) at
   most every 250 ms and as each chunk completes, so a hard kill loses very
   little work.
5. **Finish.** An optional SHA-256 is computed before publishing, then `.part` is
   renamed over the final name and the state file is removed. Nothing is renamed
   until it is complete.

Resuming is refused when the remote file changed (different size, ETag or
`Last-Modified`); the partial data is discarded rather than mixing two versions.

## Layout

```text
tools/dlm-cs/
  Dlm.csproj            MSBuild project (net48), for people with an SDK
  build.ps1             standalone build with Roslyn csc, no SDK needed
  src/
    Program.cs          entry point
    Core.cs             models, probe, chunk planning, formatting
    Downloader.cs       workers, resume state, retries, checksum, finalize
    Cli.cs              argument parsing, progress rendering, batch loop
    SelfTest.cs         dependency-free end-to-end tests + test HTTP server
    Compat.cs           helpers for .NET Framework (hex, clamp, atomic move)
    GlobalUsings.cs     shared usings (implicit usings are disabled)
  dist/
    dlm.exe             standalone build output
```

The library API is usable without the CLI:

```csharp
using Dlm;

using (var downloader = new Downloader(new DownloadOptions
{
    Url = "https://example.com/big.iso",
    Output = "big.iso",
    Connections = 8,
    VerifySha256 = "9f86d081...",
    OnProgress = p => Console.Error.Write($"\r{p.Percent:F1}%"),
}))
{
    DownloadResult result = await downloader.RunAsync();
    Console.WriteLine($"{result.Path} {result.Size} {result.Sha256} {result.Resumed}");
}
```

`OnProgress` receives `DownloadProgress` (bytes done, total, speed, ETA,
connections, phase) and `OnLog` receives human-readable status lines. Both are
optional and exceptions thrown inside them are swallowed so a broken UI cannot
kill a transfer.

## Tests

```console
tools\dlm-cs\dist\dlm.exe selftest
```

12 end-to-end tests, no test framework and no NuGet. The harness starts a real
HTTP/1.1 server on a loopback `TcpListener` and drives the actual downloader
against it: probing, multi-connection downloads, byte-exact output, resume after
cancellation, restart when the remote file changes, servers without range
support, recovery from a connection dropped mid-body, overwrite protection,
checksum success and failure, `Content-Disposition` filenames, chunk coverage,
and the CLI.

Verified on this machine (Windows, .NET Framework 4.8, no .NET SDK, no `dotnet`
invocation):

- 12/12 self-tests pass.
- Live: 10.6 MiB Python embed zip over 4 connections; SHA-256 matched; valid zip
  with 35 entries.
- Live: 25.3 MiB installer hard-killed at 13.4 MiB, then resumed; the result was
  byte-identical to a clean download.

## Limits

- No HLS/DASH/segmented-manifest downloads — this is plain HTTP(S) files.
- No cookie jar or login flow; use `-H "Cookie: ..."` if a site needs one.
- HTTP/2 is not used (the .NET Framework stack speaks HTTP/1.1); range requests
  and resumption work the same.
- A server that lies about range support (advertises `206`, later returns `200`)
  aborts with a clear message; rerun with `--restart` to fall back to a single
  stream.
- Resume requires the same URL; a changed file is detected and restarted.

## Legal

Use it on content you have the right to download. The tool deliberately ships
without any site index, scraper or store integration.
