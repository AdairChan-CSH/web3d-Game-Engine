[CmdletBinding()]
param(
    [switch]$Test
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root "src"
$out = Join-Path $root "dist"
$obj = Join-Path $root "obj"

New-Item -ItemType Directory -Force -Path $out, $obj | Out-Null

# Remove artifacts from the old .NET 8 build so dist contains only the
# standalone executable.
foreach ($stale in @("Dlm.dll", "Dlm.runtimeconfig.json", "dlm.cmd", "Dlm.exe")) {
    $path = Join-Path $out $stale
    if (Test-Path $path) { Remove-Item $path -Force }
}

function Find-Csc {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        $vs = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -property installationPath 2>$null
        if ($vs) {
            $candidate = Join-Path $vs "MSBuild\Current\Bin\Roslyn\csc.exe"
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $candidate = Get-ChildItem "${env:ProgramFiles(x86)}\Microsoft Visual Studio\*\*\MSBuild\Current\Bin\Roslyn\csc.exe" -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($candidate) { return $candidate.FullName }
    return $null
}

function Find-Framework {
    foreach ($dir in @(
        (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319"),
        (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319"))) {
        if (Test-Path (Join-Path $dir "System.Net.Http.dll")) { return $dir }
    }
    return $null
}

$csc = Find-Csc
if (-not $csc) {
    throw "No C# compiler found. Install Visual Studio Build Tools (Roslyn) or the .NET SDK."
}

$framework = Find-Framework
if (-not $framework) {
    throw ".NET Framework 4.x not found. It ships with Windows 10/11; install it first."
}

$refs = Get-ChildItem $framework -Filter *.dll | Where-Object {
    try {
        [void][System.Reflection.AssemblyName]::GetAssemblyName($_.FullName)
        $true
    }
    catch {
        $false
    }
} | ForEach-Object { '/r:"' + $_.FullName + '"' }

$rsp = Join-Path $obj "refs.rsp"
Set-Content -Path $rsp -Value $refs -Encoding ASCII

$sources = Get-ChildItem $src -Filter *.cs | ForEach-Object { $_.FullName }
$exe = Join-Path $out "dlm.exe"

& $csc /nologo /target:exe /langversion:latest /nullable:enable /optimize+ "/out:$exe" "@$rsp" @sources
if ($LASTEXITCODE -ne 0) { throw "csc failed with exit code $LASTEXITCODE" }

Write-Host "Built $exe"
Write-Host "Target: .NET Framework 4.8 (built into Windows 10/11) - no dotnet runtime required."

if ($Test) {
    & $exe selftest
    exit $LASTEXITCODE
}
