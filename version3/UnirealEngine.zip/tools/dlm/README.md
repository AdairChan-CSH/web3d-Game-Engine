# dlm — segmented, resumable download manager

A small command-line downloader that splits a file across several connections,
survives crashes and Ctrl+C, and verifies what it fetched.

Plain **Python 3.9+**, standard library only — no `pip install`, no build step,
no daemon. One folder you can copy anywhere.

```text
 63.4% [###############---------]  6.3 GiB/10.0 GiB  24.1 MiB/s  eta 02:35  8c
```

## Why this exists

It is a general-purpose downloader for files you are allowed to fetch: official
demos and installers, game patches from a vendor CDN, public-domain ROMs,
emulator builds, mods, datasets, your own hosted files.

It does **not** search for or fetch commercial game ROMs. There is no index
scraper, no warez integration and no DRM circumvention in here, and none will be
added.

## Quick start

```console
cd tools/dlm

python -m dlm https://example.com/big.iso
python -m dlm https://example.com/big.iso -o ~/Downloads/big.iso -c 16
python -m dlm https://example.com/big.iso --sha256 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
```

Interrupt it at any point (Ctrl+C, closed laptop, killed process) and run the
same command again — it continues from the last saved offset:

```console
$ python -m dlm https://example.com/big.iso
dlm: probing https://example.com/big.iso
dlm: resuming with 2684354560 bytes already on disk
 26.8% [######------------------]  2.5 GiB/10.0 GiB  ...
```

## Examples

**Check a URL before downloading it**

```console
$ python -m dlm --info https://www.python.org/ftp/python/3.12.0/python-3.12.0-embed-amd64.zip
URL:         https://www.python.org/ftp/python/3.12.0/python-3.12.0-embed-amd64.zip
Final URL:   https://www.python.org/ftp/python/3.12.0/python-3.12.0-embed-amd64.zip
Size:        10.5 MiB (11030264 bytes)
Ranges:      yes (segmented download)
Filename:    python-3.12.0-embed-amd64.zip
Type:        application/zip
ETag:        "..."
Modified:    ...
```

**Batch download**

```console
$ cat urls.txt
# official demos
https://example.com/demo-1.zip
https://example.com/demo-2.zip

$ python -m dlm -i urls.txt -d ~/Downloads -c 8
```

**Headers and TLS**

```console
python -m dlm URL -H "Referer: https://example.com/" -H "Authorization: Bearer ..."
python -m dlm URL -A "MyApp/2.0" -k     # -k skips certificate verification
```

**Force a fresh download**

```console
python -m dlm URL -o big.iso --restart
```

## Options

| Option | Meaning |
| --- | --- |
| `URL ...` | One or more URLs. |
| `-i, --input FILE` | Read URLs from a file (one per line, `#` comments). |
| `-o, --output PATH` | Output file for one URL; output directory for several. |
| `-d, --dir DIR` | Directory for names derived from the URL. |
| `-c, --connections N` | Parallel workers (default 8). |
| `--chunk-size SIZE` | Chunk size: `512K`, `4M`, `1G` (default `8M`). |
| `--timeout SEC` | Per-request socket timeout (default 30). |
| `--retries N` | Retries per chunk with exponential backoff (default 5). |
| `--sha256 HEX` | Expected digest; a mismatch fails the download. |
| `-H, --header 'K: V'` | Extra request header, repeatable. |
| `-A, --user-agent UA` | Override the User-Agent. |
| `-k, --insecure` | Do not verify TLS certificates. |
| `-f, --force` | Overwrite an existing output file. |
| `--restart` | Delete partial data and resume state, start at zero. |
| `--info` | Probe only: size, range support, ETag, filename. |
| `-q, --quiet` | No progress output. |

Exit codes: `0` success, `1` failure, `130` interrupted.

HTTP(S) proxies are honoured through the usual `HTTP_PROXY` / `HTTPS_PROXY` /
`NO_PROXY` environment variables.

## How it works

1. **Probe.** A `GET` with `Range: bytes=0-0` asks for one byte. The
   `Content-Range` reply gives the true size and proves the server supports
   ranges; `ETag` / `Last-Modified` are recorded. `GET` is used instead of `HEAD`
   because plenty of CDNs answer `HEAD` badly.
2. **Plan.** The file is cut into fixed-size chunks (one chunk when the file is
   smaller than `--chunk-size`). If ranges are unsupported, it falls back to a
   single stream that resumes with a trailing `Range` request when it can.
3. **Fetch.** A pool of workers pulls chunks from a queue and writes each one at
   its own offset in `<name>.part`, using one file handle per worker. Failed
   chunks are retried with exponential backoff plus jitter.
4. **Persist.** `<name>.part.dlmstate` stores the byte count of every chunk. It
   is rewritten atomically (temp file + `os.replace`) at most once per second and
   as each chunk completes, so a hard kill loses at most about a second of work.
5. **Finish.** An optional SHA-256 is computed before publishing, then `.part` is
   renamed over the final name and the state file is removed. Nothing is renamed
   until it is complete.

Resuming is refused when the remote file changed (different size, ETag or
`Last-Modified`); the partial data is discarded rather than mixing two versions.

## Layout

```text
tools/dlm/
  dlm/
    __init__.py     public API
    __main__.py     python -m dlm
    core.py         probe, planning, workers, resume state
    cli.py          argument parsing and output
    ui.py           progress rendering
  tests/
    test_dlm.py     14 end-to-end tests
  README.md
```

The library API is usable without the CLI:

```python
from dlm import Downloader, DownloadError

result = Downloader(
    "https://example.com/big.iso",
    "big.iso",
    connections=8,
    verify_sha256="9f86d081...",
).run()
print(result.path, result.size, result.sha256, result.resumed)
```

## Tests

```console
cd tools/dlm
python -m unittest discover -s tests -v
```

The suite starts a real threaded HTTP server on `127.0.0.1` and covers: probing,
multi-connection downloads, byte-exact output, resume after cancellation, restart
when the remote file changes, servers without range support, recovery from a
connection dropped mid-body, overwrite protection, checksum success and failure,
`Content-Disposition` filenames, and the CLI.

## Limits

- No HLS/DASH/segmented-manifest downloads — this is plain HTTP(S) files.
- No cookie jar or login flow; use `-H "Cookie: ..."` if a site needs one.
- A server that lies about range support (advertises `206`, later returns `200`)
  aborts with a clear message; rerun with `--restart` to fall back to a single
  stream.
- Resume requires the same URL; a changed file is detected and restarted.

## Legal

Use it on content you have the right to download. The tool deliberately ships
without any site index, scraper or store integration.
