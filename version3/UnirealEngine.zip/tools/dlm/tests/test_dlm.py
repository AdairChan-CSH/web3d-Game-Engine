"""End-to-end tests for dlm against a real local HTTP server.

Run from ``tools/dlm``:

    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import re
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dlm import (  # noqa: E402
    Cancelled,
    ChecksumMismatch,
    DownloadError,
    Downloader,
    probe,
    split_chunks,
)
from dlm.cli import main as cli_main  # noqa: E402


# --------------------------------------------------------------------------- #
# Test server
# --------------------------------------------------------------------------- #


def make_server(
    payload: bytes,
    *,
    etag: str = '"v1"',
    support_ranges: bool = True,
    flaky: bool = False,
    delay: float = 0.0,
    disposition: str | None = None,
):
    """Return ``(httpd, state)``; ``state`` is mutable so tests can change the ETag."""

    state = {"hits": 0, "dropped": 0, "etag": etag}

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):  # silence the test output
            pass

        def do_GET(self):
            state["hits"] += 1
            total = len(payload)
            start, end, status = 0, total - 1, 200

            range_header = self.headers.get("Range")
            if support_ranges and range_header:
                match = re.match(r"bytes=(\d+)-(\d*)$", range_header.strip())
                if match:
                    start = int(match.group(1))
                    if match.group(2):
                        end = min(int(match.group(2)), total - 1)
                    if start >= total:
                        self.send_response(416)
                        self.send_header("Content-Range", f"bytes */{total}")
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    status = 206

            body = payload[start : end + 1]
            self.send_response(status)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Accept-Ranges", "bytes" if support_ranges else "none")
            self.send_header("ETag", state["etag"])
            if disposition:
                self.send_header("Content-Disposition", disposition)
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
            self.end_headers()

            try:
                if flaky and state["dropped"] == 0 and len(body) > 256 * 1024:
                    state["dropped"] += 1
                    self.wfile.write(body[: len(body) // 3])
                    self.wfile.flush()
                    self.close_connection = True
                    return
                for offset in range(0, len(body), 128 * 1024):
                    self.wfile.write(body[offset : offset + 128 * 1024])
                    if delay:
                        time.sleep(delay)
            except OSError:
                self.close_connection = True

    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    httpd.daemon_threads = True
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, state


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #


class DownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = random.Random(1234).randbytes(4 * 1024 * 1024)

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = self._tmp.name
        self.out = os.path.join(self.dir, "file.bin")

    def start(self, **kwargs):
        kwargs.setdefault("payload", self.payload)
        httpd, state = make_server(**kwargs)
        self.addCleanup(httpd.server_close)
        self.addCleanup(httpd.shutdown)
        url = f"http://127.0.0.1:{httpd.server_address[1]}/file.bin"
        return url, state

    def assert_payload(self, path, expected=None):
        expected = self.payload if expected is None else expected
        with open(path, "rb") as fh:
            self.assertEqual(fh.read(), expected)

    def assert_clean(self, path):
        self.assertFalse(os.path.exists(path + ".part"))
        self.assertFalse(os.path.exists(path + ".part.dlmstate"))

    # -- probe -------------------------------------------------------------- #

    def test_probe_reports_size_and_range_support(self):
        url, _ = self.start()
        info = probe(url, timeout=5)
        self.assertEqual(info.size, len(self.payload))
        self.assertTrue(info.ranges)
        self.assertEqual(info.etag, '"v1"')
        self.assertEqual(info.filename, "file.bin")

    # -- happy path --------------------------------------------------------- #

    def test_chunked_download(self):
        url, _ = self.start()
        result = Downloader(
            url, self.out, connections=4, chunk_size=512 * 1024, timeout=5
        ).run()
        self.assertEqual(result.size, len(self.payload))
        self.assertFalse(result.resumed)
        self.assertEqual(result.connections, 4)
        self.assert_payload(self.out)
        self.assert_clean(self.out)

    def test_single_chunk_when_file_is_small(self):
        payload = b"tiny payload" * 100
        url, _ = self.start(payload=payload)
        result = Downloader(url, self.out, connections=8, timeout=5).run()
        self.assertEqual(result.connections, 1)
        self.assert_payload(self.out, payload)

    # -- resume ------------------------------------------------------------- #

    def test_resume_after_cancel(self):
        url, _ = self.start(delay=0.02)
        cancelled = threading.Event()

        def on_progress(progress):
            if progress.done > len(self.payload) * 0.25 and not cancelled.is_set():
                cancelled.set()
                downloader.cancel()

        downloader = Downloader(
            url,
            self.out,
            connections=2,
            chunk_size=512 * 1024,
            timeout=5,
            on_progress=on_progress,
        )
        with self.assertRaises(Cancelled):
            downloader.run()

        state_path = self.out + ".part.dlmstate"
        self.assertTrue(os.path.exists(state_path), "resume state should survive a cancel")
        with open(state_path, "r", encoding="utf-8") as fh:
            state = json.load(fh)
        downloaded = sum(done for _, _, done in state["chunks"])
        self.assertGreater(downloaded, 0)
        self.assertLess(downloaded, len(self.payload))

        result = Downloader(
            url, self.out, connections=2, chunk_size=512 * 1024, timeout=5
        ).run()
        self.assertTrue(result.resumed)
        self.assert_payload(self.out)
        self.assert_clean(self.out)

    def test_remote_change_discards_partial_state(self):
        url, state = self.start(delay=0.02)
        cancelled = threading.Event()

        def on_progress(progress):
            if progress.done > len(self.payload) * 0.25 and not cancelled.is_set():
                cancelled.set()
                downloader.cancel()

        downloader = Downloader(
            url,
            self.out,
            connections=2,
            chunk_size=512 * 1024,
            timeout=5,
            on_progress=on_progress,
        )
        with self.assertRaises(Cancelled):
            downloader.run()

        state["etag"] = '"v2"'  # remote file changed between runs

        result = Downloader(
            url, self.out, connections=2, chunk_size=512 * 1024, timeout=5
        ).run()
        self.assertFalse(result.resumed)
        self.assert_payload(self.out)
        self.assert_clean(self.out)

    # -- servers that misbehave --------------------------------------------- #

    def test_no_range_support_falls_back_to_single_stream(self):
        url, _ = self.start(support_ranges=False)
        result = Downloader(url, self.out, connections=8, timeout=5).run()
        self.assertEqual(result.connections, 1)
        self.assert_payload(self.out)
        self.assert_clean(self.out)

    def test_retry_recovers_from_dropped_connection(self):
        logs = []
        url, state = self.start(flaky=True)
        result = Downloader(
            url,
            self.out,
            connections=2,
            chunk_size=512 * 1024,
            timeout=5,
            retries=3,
            on_log=logs.append,
        ).run()
        self.assertEqual(state["dropped"], 1)
        self.assertTrue(any("retry" in line for line in logs), logs)
        self.assert_payload(self.out)
        self.assert_clean(self.out)

    # -- safety ------------------------------------------------------------- #

    def test_refuses_to_overwrite_without_force(self):
        url, _ = self.start()
        with open(self.out, "wb") as fh:
            fh.write(b"keep me")
        with self.assertRaises(DownloadError):
            Downloader(url, self.out, timeout=5).run()
        with open(self.out, "rb") as fh:
            self.assertEqual(fh.read(), b"keep me")

        result = Downloader(url, self.out, timeout=5, force=True).run()
        self.assertEqual(result.size, len(self.payload))
        self.assert_payload(self.out)

    def test_checksum_mismatch_keeps_part_and_does_not_publish(self):
        url, _ = self.start()
        with self.assertRaises(ChecksumMismatch):
            Downloader(
                url,
                self.out,
                timeout=5,
                verify_sha256="0" * 64,
            ).run()
        self.assertFalse(os.path.exists(self.out))
        self.assertTrue(os.path.exists(self.out + ".part"))
        self.assertFalse(os.path.exists(self.out + ".part.dlmstate"))

    def test_checksum_success(self):
        import hashlib

        url, _ = self.start()
        expected = hashlib.sha256(self.payload).hexdigest()
        result = Downloader(
            url, self.out, timeout=5, verify_sha256=expected.upper()
        ).run()
        self.assertEqual(result.sha256, expected)
        self.assert_payload(self.out)

    # -- naming ------------------------------------------------------------- #

    def test_filename_from_content_disposition(self):
        url, _ = self.start(disposition='attachment; filename="real name.bin"')
        result = Downloader(url, directory=self.dir, timeout=5).run()
        self.assertEqual(os.path.basename(result.path), "real name.bin")
        self.assert_payload(result.path)

    # -- CLI ---------------------------------------------------------------- #

    def test_cli_downloads(self):
        url, _ = self.start()
        code = cli_main(
            [
                url,
                "-o",
                self.out,
                "-c",
                "3",
                "--chunk-size",
                "256K",
                "--quiet",
            ]
        )
        self.assertEqual(code, 0)
        self.assert_payload(self.out)

    def test_cli_info_does_not_download(self):
        url, _ = self.start()
        code = cli_main([url, "--info"])
        self.assertEqual(code, 0)

    # -- planning ----------------------------------------------------------- #

    def test_split_chunks_covers_file_exactly(self):
        chunks = split_chunks(10 * 1024 * 1024 + 7, 1024 * 1024)
        self.assertEqual(chunks[0].start, 0)
        self.assertEqual(chunks[-1].end, 10 * 1024 * 1024 + 6)
        for previous, current in zip(chunks, chunks[1:]):
            self.assertEqual(previous.end + 1, current.start)
        self.assertEqual(sum(c.length for c in chunks), 10 * 1024 * 1024 + 7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
