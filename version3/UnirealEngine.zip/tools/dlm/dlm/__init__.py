"""dlm - a small, dependency-free segmented download manager."""

from .core import (
    DEFAULT_CHUNK_SIZE,
    DEFAULT_USER_AGENT,
    Cancelled,
    ChecksumMismatch,
    Chunk,
    DownloadError,
    Downloader,
    Progress,
    RemoteChanged,
    RemoteInfo,
    Result,
    probe,
    split_chunks,
)

__version__ = "1.0"
__all__ = [
    "DEFAULT_CHUNK_SIZE",
    "DEFAULT_USER_AGENT",
    "Cancelled",
    "ChecksumMismatch",
    "Chunk",
    "DownloadError",
    "Downloader",
    "Progress",
    "RemoteChanged",
    "RemoteInfo",
    "Result",
    "probe",
    "split_chunks",
]
