"""Command line interface for :mod:`dlm`."""

from __future__ import annotations

import argparse
import os
import re
import sys
from typing import Dict, List, Optional, Sequence

from .core import (
    DEFAULT_CHUNK_SIZE,
    DEFAULT_USER_AGENT,
    Cancelled,
    ChecksumMismatch,
    DownloadError,
    Downloader,
    Result,
    probe,
)
from .ui import ProgressPrinter, human_bytes, human_time

__all__ = ["main", "parse_size"]

_SIZE_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([KMGT]?)(?:i?B)?\s*$", re.I)
_SIZE_MULT = {"": 1, "K": 1024, "M": 1024 ** 2, "G": 1024 ** 3, "T": 1024 ** 4}


def parse_size(text: str) -> int:
    """Parse ``8388608``, ``8M``, ``512K`` or ``1.5G`` into a byte count."""

    match = _SIZE_RE.match(text)
    if not match:
        raise argparse.ArgumentTypeError(f"invalid size: {text!r}")
    value = float(match.group(1)) * _SIZE_MULT[match.group(2).upper()]
    return int(value)


def _parse_header(value: str) -> tuple[str, str]:
    if ":" not in value:
        raise argparse.ArgumentTypeError(
            f"header must look like 'Name: value', got {value!r}"
        )
    name, _, val = value.partition(":")
    name = name.strip()
    if not name:
        raise argparse.ArgumentTypeError(f"empty header name in {value!r}")
    return name, val.strip()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dlm",
        description=(
            "Segmented, resumable HTTP(S) downloader. Downloads only files you "
            "have the right to fetch."
        ),
    )
    parser.add_argument("urls", nargs="*", metavar="URL", help="one or more URLs")
    parser.add_argument(
        "-i",
        "--input",
        metavar="FILE",
        help="read URLs from FILE (one per line, # comments allowed)",
    )
    parser.add_argument(
        "-o",
        "--output",
        metavar="PATH",
        help="output file (single URL) or output directory (multiple URLs)",
    )
    parser.add_argument(
        "-d",
        "--dir",
        metavar="DIR",
        help="directory used when the filename is derived from the URL",
    )
    parser.add_argument(
        "-c",
        "--connections",
        type=int,
        default=8,
        metavar="N",
        help="parallel connections / chunk workers (default: 8)",
    )
    parser.add_argument(
        "--chunk-size",
        type=parse_size,
        default=DEFAULT_CHUNK_SIZE,
        metavar="SIZE",
        help="chunk size, e.g. 4M or 16M (default: 8M)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        metavar="SEC",
        help="per-request socket timeout (default: 30)",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=5,
        metavar="N",
        help="retries per chunk before giving up (default: 5)",
    )
    parser.add_argument(
        "--sha256",
        metavar="HEX",
        help="expected SHA-256 of the finished file; mismatch fails the download",
    )
    parser.add_argument(
        "-H",
        "--header",
        action="append",
        type=_parse_header,
        default=[],
        metavar="'K: V'",
        help="extra request header, repeatable (e.g. -H 'Referer: ...')",
    )
    parser.add_argument(
        "-A",
        "--user-agent",
        default=DEFAULT_USER_AGENT,
        metavar="UA",
        help="User-Agent header",
    )
    parser.add_argument(
        "-k",
        "--insecure",
        action="store_true",
        help="do not verify TLS certificates",
    )
    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="overwrite an existing output file",
    )
    parser.add_argument(
        "--restart",
        action="store_true",
        help="discard partial data and resume state, start from zero",
    )
    parser.add_argument(
        "--info",
        action="store_true",
        help="probe the URL(s) and print size / range support, download nothing",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="suppress progress output",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="dlm 1.0",
    )
    return parser


def _read_urls(path: str) -> List[str]:
    urls: List[str] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            urls.append(line)
    return urls


def _log(message: str) -> None:
    print(f"dlm: {message}", file=sys.stderr, flush=True)


def _print_info(url: str, args: argparse.Namespace) -> int:
    try:
        info = probe(
            url,
            timeout=args.timeout,
            headers=dict(args.header),
            user_agent=args.user_agent,
            insecure=args.insecure,
        )
    except DownloadError as exc:
        _log(str(exc))
        return 1
    size = human_bytes(info.size) if info.size is not None else "unknown"
    print(f"URL:         {url}")
    print(f"Final URL:   {info.final_url}")
    print(f"Size:        {size}" + (f" ({info.size} bytes)" if info.size is not None else ""))
    print(f"Ranges:      {'yes (segmented download)' if info.ranges else 'no (single stream)'}")
    print(f"Filename:    {info.filename or '-'}")
    print(f"Type:        {info.content_type or '-'}")
    print(f"ETag:        {info.etag or '-'}")
    print(f"Modified:    {info.last_modified or '-'}")
    return 0


def _summary(result: Result) -> None:
    print(
        f"saved {human_bytes(result.size)} to {result.path} "
        f"in {human_time(result.elapsed)} "
        f"({human_bytes(result.average_speed)}/s, {result.connections} conn"
        f"{'s' if result.connections != 1 else ''}"
        f"{', resumed' if result.resumed else ''})"
    )
    if result.sha256:
        print(f"sha256 {result.sha256}")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    urls: List[str] = list(args.urls)
    if args.input:
        try:
            urls.extend(_read_urls(args.input))
        except OSError as exc:
            _log(f"cannot read {args.input}: {exc}")
            return 1
    if not urls:
        parser.error("no URL given (pass a URL or use --input)")

    if args.info:
        status = 0
        for index, url in enumerate(urls):
            if index:
                print()
            status = max(status, _print_info(url, args))
        return status

    if len(urls) > 1 and args.output and not os.path.isdir(args.output):
        parser.error("--output must be an existing directory when downloading several URLs")
    if args.sha256 and len(urls) > 1:
        parser.error("--sha256 can only be used with a single URL")

    headers: Dict[str, str] = dict(args.header)
    printer = ProgressPrinter(quiet=args.quiet)
    failed = 0

    for index, url in enumerate(urls):
        if len(urls) > 1 and not args.quiet:
            _log(f"[{index + 1}/{len(urls)}] {url}")
        downloader = Downloader(
            url,
            args.output if len(urls) == 1 else None,
            directory=args.dir or (args.output if len(urls) > 1 else None),
            connections=args.connections,
            chunk_size=args.chunk_size,
            timeout=args.timeout,
            retries=args.retries,
            headers=headers,
            user_agent=args.user_agent,
            insecure=args.insecure,
            force=args.force,
            restart=args.restart,
            verify_sha256=args.sha256 if len(urls) == 1 else None,
            on_progress=printer,
            on_log=_log if not args.quiet else None,
        )
        try:
            result = downloader.run()
        except Cancelled:
            printer.finish()
            _log("interrupted - rerun the same command to resume")
            return 130
        except ChecksumMismatch as exc:
            printer.finish()
            _log(str(exc))
            failed += 1
        except DownloadError as exc:
            printer.finish()
            _log(str(exc))
            failed += 1
        except KeyboardInterrupt:
            printer.finish()
            _log("interrupted - rerun the same command to resume")
            return 130
        else:
            printer.finish()
            _summary(result)

    return 1 if failed else 0
