"""Segmented, resumable HTTP(S) downloads using only the standard library.

The engine works in four steps:

1. **Probe** the URL with a one-byte ``Range`` request.  That tells us the real
   size, whether the server honours ranges, and gives us the ETag / Last-Modified
   values used to detect a changed remote file.
2. **Plan** the download as a list of fixed-size chunks, or as a single stream
   when the server cannot serve byte ranges.
3. **Fetch** the chunks with a pool of worker threads.  Every worker writes into
   its own region of a ``.part`` file, so progress is real and resumable.
4. **Finalise** by verifying an optional SHA-256, renaming ``.part`` to the final
   name and removing the resume state.

A JSON sidecar (``<file>.part.dlmstate``) records how many bytes each chunk has
received.  If the process dies or the user presses Ctrl+C, the next run picks up
exactly where it stopped - provided the remote file has not changed.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import queue
import random
import re
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from email.message import Message
from typing import Callable, Dict, List, Mapping, Optional

__all__ = [
    "Cancelled",
    "ChecksumMismatch",
    "Chunk",
    "DownloadError",
    "Downloader",
    "Progress",
    "RemoteChanged",
    "RemoteInfo",
    "Result",
    "probe",
]

STATE_VERSION = 1
DEFAULT_USER_AGENT = "dlm/1.0 (resumable segmented downloader)"
DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024
MIN_CHUNK_SIZE = 64 * 1024
READ_BLOCK = 256 * 1024
MAX_CHUNKS = 20_000

_CONTENT_RANGE = re.compile(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", re.I)
_BAD_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


# --------------------------------------------------------------------------- #
# Errors
# --------------------------------------------------------------------------- #


class DownloadError(Exception):
    """Base class for every recoverable download failure."""


class RangeNotSupported(DownloadError):
    """The server answered a ranged request with the full body."""


class RemoteChanged(DownloadError):
    """The file on the server no longer matches the resume state."""


class ChecksumMismatch(DownloadError):
    """The downloaded bytes do not match the expected SHA-256."""


class Cancelled(DownloadError):
    """The download was cancelled by the caller."""


# --------------------------------------------------------------------------- #
# Data holders
# --------------------------------------------------------------------------- #


@dataclass
class RemoteInfo:
    url: str
    final_url: str
    size: Optional[int]
    ranges: bool
    etag: Optional[str]
    last_modified: Optional[str]
    filename: Optional[str]
    content_type: Optional[str]


@dataclass
class Chunk:
    index: int
    start: int
    end: int  # inclusive
    done: int = 0

    @property
    def length(self) -> int:
        return self.end - self.start + 1

    @property
    def finished(self) -> bool:
        return self.done >= self.length

    def as_state(self) -> List[int]:
        return [self.start, self.end, self.done]


@dataclass
class Progress:
    done: int
    total: Optional[int]
    speed: float
    eta: Optional[float]
    connections: int
    phase: str = "downloading"

    @property
    def percent(self) -> Optional[float]:
        if not self.total:
            return None
        return min(100.0, self.done * 100.0 / self.total)


@dataclass
class Result:
    path: str
    size: int
    sha256: Optional[str]
    elapsed: float
    resumed: bool
    connections: int

    @property
    def average_speed(self) -> float:
        return self.size / self.elapsed if self.elapsed > 0 else 0.0


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _filename_from_disposition(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    msg = Message()
    msg["Content-Disposition"] = value
    name = msg.get_filename()
    if not name:
        return None
    return name.replace("\\", "/").rsplit("/", 1)[-1]


def _filename_from_url(url: str) -> Optional[str]:
    path = urllib.parse.urlsplit(url).path
    name = urllib.parse.unquote(path.rstrip("/").rsplit("/", 1)[-1])
    return name or None


def _safe_filename(name: str) -> str:
    name = _BAD_FILENAME_CHARS.sub("_", name).strip().rstrip(". ")
    if not name or name in {".", ".."}:
        return "download"
    return name[:200]


def _make_opener(insecure: bool) -> urllib.request.OpenerDirector:
    handlers = []
    if insecure:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def _status(resp) -> int:
    code = getattr(resp, "status", None)
    return code if code is not None else resp.getcode()


def probe(
    url: str,
    *,
    timeout: float = 30.0,
    headers: Optional[Mapping[str, str]] = None,
    user_agent: str = DEFAULT_USER_AGENT,
    insecure: bool = False,
    opener: Optional[urllib.request.OpenerDirector] = None,
) -> RemoteInfo:
    """Inspect *url* without downloading the body.

    Uses ``GET`` with ``Range: bytes=0-0`` rather than ``HEAD`` because a lot of
    CDNs implement ranges but answer ``HEAD`` incorrectly (or reject it).
    """

    opener = opener or _make_opener(insecure)
    req_headers = {"User-Agent": user_agent, "Accept-Encoding": "identity"}
    if headers:
        req_headers.update(headers)
    req_headers["Range"] = "bytes=0-0"
    req = urllib.request.Request(url, headers=req_headers)

    try:
        resp = opener.open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        # A server that refuses a 1-byte range still tells us the total size.
        if exc.code == 416:
            match = re.match(r"bytes\s+\*/(\d+)", exc.headers.get("Content-Range", ""))
            exc.close()
            if match:
                return RemoteInfo(
                    url=url,
                    final_url=url,
                    size=int(match.group(1)),
                    ranges=True,
                    etag=exc.headers.get("ETag"),
                    last_modified=exc.headers.get("Last-Modified"),
                    filename=_filename_from_url(url),
                    content_type=None,
                )
        code, reason = exc.code, exc.reason
        exc.close()
        raise DownloadError(f"HTTP {code} {reason} for {url}") from None
    except urllib.error.URLError as exc:
        raise DownloadError(f"cannot reach {url}: {exc.reason}") from None

    with resp:
        status = _status(resp)
        hdrs = resp.headers
        etag = hdrs.get("ETag")
        last_modified = hdrs.get("Last-Modified")
        content_type = hdrs.get("Content-Type")
        final_url = resp.geturl() or url
        filename = _filename_from_disposition(
            hdrs.get("Content-Disposition")
        ) or _filename_from_url(final_url)

        if status == 206:
            match = _CONTENT_RANGE.match(hdrs.get("Content-Range", ""))
            if not match:
                raise DownloadError(
                    "server sent 206 without a usable Content-Range header"
                )
            total = match.group(3)
            size = int(total) if total != "*" else None
            ranges = True
        elif status == 200:
            raw = hdrs.get("Content-Length")
            size = int(raw) if raw and raw.isdigit() else None
            ranges = False
        else:
            raise DownloadError(f"unexpected HTTP {status} for {url}")

    return RemoteInfo(
        url=url,
        final_url=final_url,
        size=size,
        ranges=ranges,
        etag=etag,
        last_modified=last_modified,
        filename=filename,
        content_type=content_type,
    )


def split_chunks(size: int, chunk_size: int) -> List[Chunk]:
    """Split ``[0, size)`` into contiguous chunks, growing the chunk size if the
    file would otherwise produce an unreasonable number of state entries."""

    chunk_size = max(MIN_CHUNK_SIZE, int(chunk_size))
    while size > 0 and math.ceil(size / chunk_size) > MAX_CHUNKS:
        chunk_size *= 2

    chunks: List[Chunk] = []
    start = 0
    index = 0
    while start < size:
        end = min(start + chunk_size, size) - 1
        chunks.append(Chunk(index=index, start=start, end=end))
        start = end + 1
        index += 1
    return chunks


# --------------------------------------------------------------------------- #
# Downloader
# --------------------------------------------------------------------------- #


class Downloader:
    """A single resumable download.

    ``output`` may be a file path, an existing directory, or ``None`` (the
    filename is then derived from ``Content-Disposition`` / the URL and placed
    in ``directory``).
    """

    def __init__(
        self,
        url: str,
        output: Optional[str] = None,
        *,
        directory: Optional[str] = None,
        connections: int = 8,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        timeout: float = 30.0,
        retries: int = 5,
        headers: Optional[Mapping[str, str]] = None,
        user_agent: str = DEFAULT_USER_AGENT,
        insecure: bool = False,
        force: bool = False,
        restart: bool = False,
        verify_sha256: Optional[str] = None,
        state_path: Optional[str] = None,
        on_progress: Optional[Callable[[Progress], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        if connections < 1:
            raise ValueError("connections must be >= 1")
        if retries < 0:
            raise ValueError("retries must be >= 0")
        if timeout <= 0:
            raise ValueError("timeout must be > 0")

        self.url = url
        self.output = output
        self.directory = directory
        self.connections = int(connections)
        self.chunk_size = max(MIN_CHUNK_SIZE, int(chunk_size))
        self.timeout = float(timeout)
        self.retries = int(retries)
        self.headers: Dict[str, str] = dict(headers or {})
        self.user_agent = user_agent
        self.insecure = insecure
        self.force = force
        self.restart = restart
        self.verify_sha256 = (verify_sha256 or "").strip() or None
        self.state_path = state_path
        self.on_progress = on_progress
        self.on_log = on_log

        self._opener = _make_opener(insecure)
        self._lock = threading.Lock()
        self._save_lock = threading.Lock()
        self._last_save = 0.0
        self._cancel = threading.Event()
        self._fatal: Optional[BaseException] = None
        self._threads: List[threading.Thread] = []
        self._queue: "queue.Queue[Chunk]" = queue.Queue()

        self._mode = "single"
        self._size: Optional[int] = None
        self._ranges = False
        self._chunks: List[Chunk] = []
        self._part = ""
        self._state_path: Optional[str] = None
        self._final_url = url
        self._etag: Optional[str] = None
        self._last_modified: Optional[str] = None

        self._single_done = 0
        self._resumed_bytes = 0
        self._speed = 0.0
        self._last_done = 0
        self._last_tick = time.monotonic()
        self._started = time.monotonic()

    # -- public API --------------------------------------------------------- #

    def cancel(self) -> None:
        """Ask every worker to stop. Safe to call from any thread."""

        self._cancel.set()

    def run(self) -> Result:
        self._started = time.monotonic()
        self._reset_progress()

        self._log(f"probing {self.url}")
        info = probe(
            self.url,
            timeout=self.timeout,
            headers=self.headers,
            user_agent=self.user_agent,
            insecure=self.insecure,
            opener=self._opener,
        )
        self._final_url = info.final_url
        self._etag = info.etag
        self._last_modified = info.last_modified
        self._ranges = info.ranges

        self.output = self._resolve_output(info)
        self._part = self.output + ".part"
        self._state_path = self.state_path or self._part + ".dlmstate"

        parent = os.path.dirname(self.output)
        if parent:
            os.makedirs(parent, exist_ok=True)

        if os.path.exists(self.output) and not self.force:
            raise DownloadError(
                f"refusing to overwrite {self.output} (pass force=True / --force)"
            )

        if self.restart:
            self._clear_state()

        resumed = self._restore(info)
        if not resumed:
            self._plan(info)
            self._resumed_bytes = 0
        else:
            self._resumed_bytes = (
                sum(c.done for c in self._chunks) if self._mode == "chunked" else 0
            )
        self._prepare_part()

        self._log(
            f"{'resuming' if resumed else 'downloading'} "
            f"{self._size if self._size is not None else 'unknown'} bytes "
            f"in {self._mode} mode"
        )

        try:
            if self._mode == "chunked":
                self._run_chunked()
            else:
                self._run_single()
        except Cancelled:
            self._save_state()
            raise
        except BaseException:
            self._save_state()
            raise

        size = self._size if self._size is not None else os.path.getsize(self._part)
        digest = self._verify(size)
        self._finalise(size)

        elapsed = time.monotonic() - self._started
        return Result(
            path=self.output,
            size=size,
            sha256=digest,
            elapsed=elapsed,
            resumed=resumed and self._resumed_bytes > 0,
            connections=self._worker_count(),
        )

    # -- planning / state --------------------------------------------------- #

    def _resolve_output(self, info: RemoteInfo) -> str:
        if self.output:
            out = os.path.abspath(os.path.expanduser(self.output))
            if os.path.isdir(out) or self.output.endswith(("/", "\\")):
                return os.path.join(out, _safe_filename(info.filename or "download"))
            return out
        base = os.path.abspath(os.path.expanduser(self.directory or os.getcwd()))
        return os.path.join(base, _safe_filename(info.filename or "download"))

    def _plan(self, info: RemoteInfo) -> None:
        if info.size is None:
            self._mode = "single"
            self._size = None
            self._chunks = []
            return
        self._size = info.size
        if info.ranges and info.size > 0:
            self._mode = "chunked"
            self._chunks = split_chunks(info.size, self.chunk_size)
        else:
            self._mode = "single"
            self._chunks = []

    def _restore(self, info: RemoteInfo) -> bool:
        if not self._state_path or not os.path.exists(self._state_path):
            return False
        try:
            with open(self._state_path, "r", encoding="utf-8") as fh:
                state = json.load(fh)
        except (OSError, ValueError):
            self._log("resume state is unreadable; starting over")
            self._clear_state()
            return False

        if not self._state_matches(state, info):
            self._log("remote file changed or state does not match; starting over")
            self._clear_state()
            return False

        try:
            chunks = [
                Chunk(index=i, start=int(s), end=int(e), done=int(d))
                for i, (s, e, d) in enumerate(state["chunks"])
            ]
        except (KeyError, TypeError, ValueError):
            self._log("resume state is malformed; starting over")
            self._clear_state()
            return False

        if not chunks:
            self._clear_state()
            return False
        for chunk in chunks:
            chunk.done = max(0, min(chunk.done, chunk.length))

        self._mode = state["mode"]
        self._size = state["size"]
        self._chunks = chunks
        self._log(f"resuming with {sum(c.done for c in chunks)} bytes already on disk")
        return True

    def _state_matches(self, state: Mapping, info: RemoteInfo) -> bool:
        if state.get("version") != STATE_VERSION:
            return False
        if state.get("url") != self.url:
            return False
        if state.get("size") != info.size:
            return False
        if state.get("mode") == "chunked" and not info.ranges:
            return False
        if state.get("mode") not in ("chunked", "single"):
            return False
        if not os.path.exists(self._part):
            return False
        if info.size is not None:
            try:
                if os.path.getsize(self._part) != info.size:
                    return False
            except OSError:
                return False
        for key, fresh in (("etag", info.etag), ("last_modified", info.last_modified)):
            old = state.get(key)
            if old and old != fresh:
                return False
            if old and not fresh:
                return False
        chunks = state.get("chunks") or []
        if state.get("mode") == "chunked":
            if not chunks:
                return False
            if sum(int(e) - int(s) + 1 for s, e, _ in chunks) != info.size:
                return False
        return True

    def _save_state(self) -> None:
        if not self._state_path or not self._part:
            return
        with self._save_lock:
            with self._lock:
                state = {
                    "version": STATE_VERSION,
                    "url": self.url,
                    "final_url": self._final_url,
                    "size": self._size,
                    "etag": self._etag,
                    "last_modified": self._last_modified,
                    "mode": self._mode,
                    "chunk_size": self.chunk_size,
                    "chunks": [c.as_state() for c in self._chunks],
                }
            tmp = self._state_path + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(state, fh)
                os.replace(tmp, self._state_path)
                self._last_save = time.monotonic()
            except OSError as exc:  # pragma: no cover - disk trouble
                self._log(f"could not write resume state: {exc}")

    def _clear_state(self, *, remove_part: bool = True) -> None:
        paths = []
        if self._state_path:
            paths.extend([self._state_path, self._state_path + ".tmp"])
        if remove_part and self._part:
            paths.append(self._part)
        for path in paths:
            if not path:
                continue
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            except OSError as exc:  # pragma: no cover
                self._log(f"could not remove {path}: {exc}")

    def _prepare_part(self) -> None:
        exists = os.path.exists(self._part)
        if self._size is not None:
            with open(self._part, "r+b" if exists else "w+b") as fh:
                fh.truncate(self._size)
        else:
            # Unknown length: cannot trust any existing bytes, start clean.
            with open(self._part, "wb"):
                pass

    # -- chunked mode ------------------------------------------------------- #

    def _run_chunked(self) -> None:
        pending = [c for c in self._chunks if not c.finished]
        if not pending:
            self._log("all chunks already complete")
            return

        self._queue = queue.Queue()
        for chunk in pending:
            self._queue.put(chunk)

        workers = max(1, min(self.connections, len(pending)))
        self._threads = [
            threading.Thread(target=self._worker, name=f"dlm-{i}", daemon=True)
            for i in range(workers)
        ]
        for thread in self._threads:
            thread.start()

        try:
            self._monitor()
        except KeyboardInterrupt:
            self.cancel()
            self._join_workers()
            self._save_state()
            raise Cancelled("interrupted") from None
        self._join_workers()

        if self._fatal is not None:
            if isinstance(self._fatal, DownloadError):
                raise self._fatal
            raise DownloadError(str(self._fatal)) from self._fatal
        if self._cancel.is_set():
            raise Cancelled("cancelled")

    def _worker(self) -> None:
        while not self._cancel.is_set():
            try:
                chunk = self._queue.get_nowait()
            except queue.Empty:
                return
            try:
                self._fetch_chunk(chunk)
            except Cancelled:
                return
            except Exception as exc:  # noqa: BLE001 - surfaced to the caller
                with self._lock:
                    if self._fatal is None:
                        self._fatal = exc
                self._cancel.set()
                return
            # Persist a completed chunk promptly so a hard kill loses little.
            if time.monotonic() - self._last_save >= 0.25:
                self._save_state()

    def _fetch_chunk(self, chunk: Chunk) -> None:
        attempt = 0
        while True:
            if self._cancel.is_set():
                raise Cancelled("cancelled")
            start = chunk.start + chunk.done
            if start > chunk.end:
                return
            try:
                self._stream_range(chunk, start)
                return
            except Cancelled:
                raise
            except Exception as exc:  # noqa: BLE001
                attempt += 1
                if attempt > self.retries:
                    raise DownloadError(
                        f"chunk {chunk.index} failed after {attempt} attempts: {exc}"
                    ) from exc
                delay = min(0.5 * (2 ** (attempt - 1)), 8.0) + random.random() * 0.25
                self._log(
                    f"chunk {chunk.index}: {exc} - retry {attempt}/{self.retries} "
                    f"in {delay:.1f}s"
                )
                if self._cancel.wait(delay):
                    raise Cancelled("cancelled") from None

    def _stream_range(self, chunk: Chunk, start: int) -> None:
        req = urllib.request.Request(
            self._final_url,
            headers=self._request_headers({"Range": f"bytes={start}-{chunk.end}"}),
        )
        try:
            resp = self._opener.open(req, timeout=self.timeout)
        except urllib.error.HTTPError as exc:
            code, reason = exc.code, exc.reason
            exc.close()
            if code == 416:
                raise RemoteChanged(
                    "server says the requested range is no longer available"
                ) from None
            raise DownloadError(f"HTTP {code} {reason}") from None

        with resp:
            status = _status(resp)
            if status == 200:
                raise RangeNotSupported(
                    "server ignored the Range header mid-download; restart with --restart"
                )
            if status != 206:
                raise DownloadError(f"unexpected HTTP {status} for chunk {chunk.index}")

            match = _CONTENT_RANGE.match(resp.headers.get("Content-Range", ""))
            if not match or int(match.group(1)) != start:
                raise DownloadError(
                    f"server returned the wrong byte range for chunk {chunk.index}"
                )
            total = match.group(3)
            if total != "*" and self._size is not None and int(total) != self._size:
                raise RemoteChanged("remote size changed during the download")

            remaining = chunk.length - chunk.done
            with open(self._part, "r+b") as fh:
                fh.seek(start)
                while remaining > 0:
                    if self._cancel.is_set():
                        raise Cancelled("cancelled")
                    block = resp.read(min(READ_BLOCK, remaining))
                    if not block:
                        raise DownloadError(
                            f"connection closed {remaining} bytes early on chunk "
                            f"{chunk.index}"
                        )
                    fh.write(block)
                    with self._lock:
                        chunk.done += len(block)
                    remaining -= len(block)

    # -- single-stream mode ------------------------------------------------- #

    def _run_single(self) -> None:
        self._threads = [
            threading.Thread(target=self._single_worker, name="dlm-single", daemon=True)
        ]
        self._threads[0].start()
        try:
            self._monitor()
        except KeyboardInterrupt:
            self.cancel()
            self._join_workers()
            self._save_state()
            raise Cancelled("interrupted") from None
        self._join_workers()

        if self._fatal is not None:
            if isinstance(self._fatal, DownloadError):
                raise self._fatal
            raise DownloadError(str(self._fatal)) from self._fatal
        if self._cancel.is_set():
            raise Cancelled("cancelled")

    def _single_worker(self) -> None:
        attempt = 0
        while not self._cancel.is_set():
            start = 0
            if self._ranges and self._size is not None and os.path.exists(self._part):
                start = min(os.path.getsize(self._part), self._size)
            try:
                self._stream_single(start)
                return
            except Cancelled:
                return
            except Exception as exc:  # noqa: BLE001
                attempt += 1
                if attempt > self.retries:
                    self._fatal = DownloadError(
                        f"download failed after {attempt} attempts: {exc}"
                    )
                    self._cancel.set()
                    return
                delay = min(0.5 * (2 ** (attempt - 1)), 8.0) + random.random() * 0.25
                self._log(f"{exc} - retry {attempt}/{self.retries} in {delay:.1f}s")
                if self._cancel.wait(delay):
                    return

    def _stream_single(self, start: int) -> None:
        extra = {"Range": f"bytes={start}-"} if start > 0 else {}
        req = urllib.request.Request(
            self._final_url, headers=self._request_headers(extra)
        )
        try:
            resp = self._opener.open(req, timeout=self.timeout)
        except urllib.error.HTTPError as exc:
            code, reason = exc.code, exc.reason
            exc.close()
            if code == 416 and self._size is not None:
                # Everything is already on disk.
                return
            raise DownloadError(f"HTTP {code} {reason}") from None

        with resp:
            status = _status(resp)
            if status == 206 and start > 0:
                match = _CONTENT_RANGE.match(resp.headers.get("Content-Range", ""))
                if not match or int(match.group(1)) != start:
                    raise DownloadError("server returned the wrong resume offset")
                total = match.group(3)
                if total != "*":
                    self._size = int(total)
                file_mode = "ab"
            elif status == 200:
                start = 0
                raw = resp.headers.get("Content-Length")
                if raw and raw.isdigit():
                    self._size = int(raw)
                file_mode = "wb"
            else:
                raise DownloadError(f"unexpected HTTP {status}")

            written = start
            self._single_done = start
            with open(self._part, file_mode) as fh:
                while True:
                    if self._cancel.is_set():
                        raise Cancelled("cancelled")
                    block = resp.read(READ_BLOCK)
                    if not block:
                        break
                    fh.write(block)
                    written += len(block)
                    self._single_done = written

        if self._size is not None and written != self._size:
            raise DownloadError(
                f"connection closed early ({written} of {self._size} bytes)"
            )

    # -- progress / verification / finish ----------------------------------- #

    def _request_headers(self, extra: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
        headers = {"User-Agent": self.user_agent, "Accept-Encoding": "identity"}
        headers.update(self.headers)
        if extra:
            headers.update(extra)
        return headers

    def _done(self) -> int:
        if self._mode == "chunked":
            with self._lock:
                return sum(c.done for c in self._chunks)
        return self._single_done

    def _worker_count(self) -> int:
        if self._mode == "chunked":
            return max(1, min(self.connections, len(self._chunks)))
        return 1

    def _reset_progress(self) -> None:
        self._last_tick = time.monotonic()
        self._last_done = 0
        self._speed = 0.0

    def _tick(self) -> None:
        now = time.monotonic()
        done = self._done()
        elapsed = now - self._last_tick
        if elapsed >= 0.2:
            instant = max(0.0, (done - self._last_done) / elapsed)
            self._speed = instant if self._speed <= 0 else 0.7 * self._speed + 0.3 * instant
            self._last_done = done
            self._last_tick = now
        eta = None
        if self._size and self._speed > 0:
            eta = max(0.0, (self._size - done) / self._speed)
        self._emit(
            Progress(
                done=done,
                total=self._size,
                speed=self._speed,
                eta=eta,
                connections=self._worker_count(),
                phase="downloading",
            )
        )

    def _emit(self, progress: Progress) -> None:
        if self.on_progress is None:
            return
        try:
            self.on_progress(progress)
        except Exception:  # a broken callback must not kill the download
            pass

    def _monitor(self) -> None:
        while any(t.is_alive() for t in self._threads):
            self._tick()
            if time.monotonic() - self._last_save >= 1.0:
                self._save_state()
            time.sleep(0.1)
        self._tick()

    def _join_workers(self) -> None:
        for thread in self._threads:
            thread.join(timeout=15)

    def _verify(self, size: int) -> Optional[str]:
        if not self.verify_sha256:
            return None
        digest = hashlib.sha256()
        done = 0
        with open(self._part, "rb") as fh:
            while True:
                block = fh.read(1024 * 1024)
                if not block:
                    break
                digest.update(block)
                done += len(block)
                self._emit(
                    Progress(
                        done=done,
                        total=size,
                        speed=0.0,
                        eta=None,
                        connections=0,
                        phase="verifying",
                    )
                )
        actual = digest.hexdigest()
        if actual.lower() != self.verify_sha256.lower():
            # Keep the data for inspection but drop the state so a rerun refetches.
            self._clear_state(remove_part=False)
            raise ChecksumMismatch(
                f"sha256 mismatch for {self._part}: got {actual}, "
                f"expected {self.verify_sha256}"
            )
        return actual

    def _finalise(self, size: int) -> None:
        os.replace(self._part, self.output)
        self._clear_state(remove_part=False)
        self._log(f"saved {size} bytes to {self.output}")

    def _log(self, message: str) -> None:
        if self.on_log is not None:
            try:
                self.on_log(message)
            except Exception:
                pass
