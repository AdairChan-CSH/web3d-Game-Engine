"""Terminal rendering helpers for :mod:`dlm`."""

from __future__ import annotations

import sys
import time
from typing import Optional, TextIO

from .core import Progress

__all__ = ["ProgressPrinter", "human_bytes", "human_time"]


def human_bytes(value: Optional[float]) -> str:
    if value is None:
        return "?"
    value = float(value)
    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    index = 0
    while value >= 1024 and index < len(units) - 1:
        value /= 1024
        index += 1
    if index == 0:
        return f"{int(value)} B"
    return f"{value:.1f} {units[index]}"


def human_time(seconds: Optional[float]) -> str:
    if seconds is None:
        return "--:--"
    seconds = int(max(0, seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


class ProgressPrinter:
    """Renders progress on one line when attached to a TTY.

    On a pipe (or with ``quiet``) it stays silent; the CLI prints a summary at
    the end.  ``interval`` throttles redraws so huge download speeds do not turn
    the terminal into a strobe light.
    """

    def __init__(
        self,
        stream: Optional[TextIO] = None,
        *,
        enabled: Optional[bool] = None,
        quiet: bool = False,
        interval: float = 0.15,
        bar_width: int = 24,
    ) -> None:
        self.stream = stream or sys.stderr
        if enabled is None:
            enabled = hasattr(self.stream, "isatty") and self.stream.isatty()
        self.enabled = bool(enabled) and not quiet
        self.quiet = quiet
        self.interval = interval
        self.bar_width = bar_width
        self._last = 0.0
        self._last_plain = 0.0
        self._drawn = False

    def __call__(self, progress: Progress) -> None:
        if not self.enabled:
            return
        now = time.monotonic()
        if progress.phase == "downloading" and now - self._last < self.interval:
            return
        self._last = now

        if progress.phase == "verifying":
            line = f" verifying  {human_bytes(progress.done)}/{human_bytes(progress.total)}"
            self._write(line)
            return

        if progress.total:
            fraction = min(1.0, progress.done / progress.total)
            filled = int(fraction * self.bar_width)
            bar = "#" * filled + "-" * (self.bar_width - filled)
            line = (
                f" {fraction * 100:5.1f}% [{bar}] "
                f"{human_bytes(progress.done)}/{human_bytes(progress.total)} "
                f"{human_bytes(progress.speed)}/s "
                f"eta {human_time(progress.eta)} "
                f"{progress.connections}c"
            )
        else:
            line = (
                f" {human_bytes(progress.done)} "
                f"{human_bytes(progress.speed)}/s {progress.connections}c"
            )
        self._write(line)

    def _write(self, line: str) -> None:
        width = 110
        self.stream.write("\r" + line[:width].ljust(width))
        self.stream.flush()
        self._drawn = True

    def finish(self) -> None:
        if not self.enabled or not self._drawn:
            return
        self.stream.write("\r" + " " * 110 + "\r")
        self.stream.flush()
        self._drawn = False
