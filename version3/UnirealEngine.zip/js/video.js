/* UnirealEngine — video.js
 * GameObject video textures. Local MP4/WebM/OGV bytes (or an optional URL)
 * are played by an HTMLVideoElement using the browser's own codecs. The same
 * element is returned to renderer.js for WebGL texture upload and can route
 * its sound through UE.Audio for positional playback. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  if (UE.Video) return;

  const state = { active: new Set(), lastError: '' };

  function supported() {
    return typeof document !== 'undefined' && typeof document.createElement === 'function';
  }
  function listen(element, name, fn) {
    if (element && typeof element.addEventListener === 'function') element.addEventListener(name, fn);
  }
  function sourceFor(comp) {
    if (!comp.clipId) return comp.url || '';
    const meta = UE.AssetStore.videoMeta(comp.clipId);
    if (!meta) return '';
    const bytes = UE.AssetStore.getVideo(comp.clipId);
    if (!bytes || !bytes.length) return '';
    if (typeof Blob === 'function' && typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {
      try {
        return URL.createObjectURL(new Blob([bytes], { type: meta.mime || 'video/mp4' }));
      } catch (err) { /* fall back to a data URL */ }
    }
    return UE.AssetStore.videoDataUrl(comp.clipId) || '';
  }
  function hasSpatialAudio() {
    return !!(UE.Audio && typeof UE.Audio.supported === 'function' && UE.Audio.supported() &&
      typeof UE.Audio.attachMediaElement === 'function');
  }

  /* Create/reuse the element, point it at the current clip and attach the
     runtime audio bridge. Safe to call every frame: work only happens when the
     clip reference actually changes. */
  function prepare(comp) {
    if (!comp || !supported()) return null;
    let video = comp._video;
    if (!video) {
      video = document.createElement('video');
      video.preload = 'auto';
      video.playsInline = true;
      listen(video, 'loadeddata', function () {
        if (!video.paused) comp._status = 'playing';
      });
      listen(video, 'loadedmetadata', function () {
        const item = comp.clipId && UE.AssetStore.videoItems[comp.clipId];
        if (!item) return;
        item.duration = video.duration || 0;
        item.width = video.videoWidth || 0;
        item.height = video.videoHeight || 0;
      });
      listen(video, 'error', function () {
        comp._status = 'error';
        state.lastError = 'The browser could not decode this video format';
      });
      comp._video = video;
    }
    const key = (comp.clipId || '') + '|' + (comp.url || '');
    if (key !== comp._videoSourceKey) {
      comp._videoSourceKey = key;
      if (comp._videoObjectUrl && typeof URL !== 'undefined' && URL.revokeObjectURL) {
        try { URL.revokeObjectURL(comp._videoObjectUrl); } catch (err) { /* ignore */ }
      }
      comp._videoObjectUrl = null;
      const src = sourceFor(comp);
      if (typeof src === 'string' && src.indexOf('blob:') === 0) comp._videoObjectUrl = src;
      video.src = src;
      if (typeof video.load === 'function') video.load();
    }
    sync(comp, video);
    return video;
  }

  function sync(comp, video) {
    if (!comp || !video) return;
    video.loop = !!comp.loop;
    const rate = Math.max(0.25, Math.min(4, +comp.playbackRate || 1));
    video.playbackRate = rate;
    const useAudioGraph = !!comp.spatial && hasSpatialAudio();
    if (useAudioGraph && !comp._audioHandle) {
      comp._audioHandle = UE.Audio.attachMediaElement(video, comp);
    } else if (!useAudioGraph && comp._audioHandle) {
      UE.Audio.disposeMedia(comp._audioHandle);
      comp._audioHandle = null;
    }
    video.muted = !!comp.muted;
    if (comp._audioHandle) {
      video.volume = 1;               // gain is controlled in the WebAudio graph
      UE.Audio.updateMedia(comp._audioHandle, comp);
      const p = comp.object.transform.worldPosition();
      UE.Audio.setPannerPosition(comp._audioHandle.panner, p.x, p.y, p.z);
    } else {
      video.volume = Math.max(0, Math.min(1, +comp.volume || 0));
    }
  }

  function play(comp) {
    const video = prepare(comp);
    if (!video) return Promise.resolve(false);
    state.active.add(comp);
    comp._status = 'loading';
    let result;
    try {
      result = video.play();
    } catch (err) {
      comp._status = 'error';
      state.lastError = err && err.message ? err.message : String(err);
      return Promise.resolve(false);
    }
    if (result && typeof result.then === 'function') {
      return result.then(function () {
        comp._status = 'playing';
        return true;
      }).catch(function (err) {
        comp._status = 'blocked';      // usually an autoplay-policy rejection
        state.lastError = err && err.message ? err.message : String(err);
        return false;
      });
    }
    comp._status = 'playing';
    return Promise.resolve(true);
  }
  function pause(comp) {
    if (!comp || !comp._video) return;
    try { comp._video.pause(); } catch (err) { /* ignore */ }
    comp._status = 'paused';
  }
  function stop(comp) {
    if (!comp || !comp._video) return;
    pause(comp);
    try { comp._video.currentTime = 0; } catch (err) { /* ignore */ }
    comp._status = 'idle';
    state.active.delete(comp);
  }
  function release(comp) {
    if (!comp) return;
    stop(comp);
    if (comp._audioHandle) {
      UE.Audio.disposeMedia(comp._audioHandle);
      comp._audioHandle = null;
    }
    if (comp._videoObjectUrl && typeof URL !== 'undefined' && URL.revokeObjectURL) {
      try { URL.revokeObjectURL(comp._videoObjectUrl); } catch (err) { /* ignore */ }
    }
    comp._videoObjectUrl = null;
    if (comp._video && typeof comp._video.pause === 'function') {
      try { comp._video.pause(); } catch (err) { /* ignore */ }
    }
    if (comp._video && typeof comp._video.removeAttribute === 'function') comp._video.removeAttribute('src');
    comp._video = null;
    comp._videoSourceKey = null;
  }

  function updateSources(scene) {
    if (!scene) return;
    for (const object of scene.objects) {
      if (!object.active) continue;
      const comp = object.getComponent('VideoPlayer');
      if (!comp || !comp._video) continue;
      sync(comp, comp._video);
    }
  }
  function startAll(scene) {
    if (!scene) return;
    for (const object of scene.objects) {
      const comp = object.getComponent('VideoPlayer');
      if (comp && comp.autoPlay && (comp.clipId || comp.url)) play(comp);
    }
  }
  function stopAll() {
    for (const comp of Array.from(state.active)) stop(comp);
  }
  function pauseAll() {
    for (const comp of Array.from(state.active)) pause(comp);
  }
  function resumeAll(scene) {
    if (!scene) return;
    for (const object of scene.objects) {
      const comp = object.getComponent('VideoPlayer');
      if (comp && (comp.clipId || comp.url) && comp._video && comp._status !== 'playing') play(comp);
    }
  }

  /* The renderer asks for this each frame; a video becomes a texture only once
     the browser has decoded a frame. */
  function textureFor(object) {
    if (!object || !object.active) return null;
    const comp = object.getComponent('VideoPlayer');
    if (!comp || !comp._video) return null;
    const video = comp._video;
    if (typeof video.readyState === 'number' && video.readyState < 2) return null;
    if (typeof video.videoWidth === 'number' && !video.videoWidth) return null;
    return video;
  }
  /* Renderer-facing contract: one frame description per object, or null. */
  function frameFor(object) {
    const texture = textureFor(object);
    if (!texture) return null;
    return { texture: texture, video: texture, comp: object.getComponent('VideoPlayer') };
  }
  function status(comp) {
    if (!comp || !(comp.clipId || comp.url)) return 'none';
    return comp._status || 'idle';
  }

  UE.Video = {
    supported: supported,
    prepare: prepare,
    play: play,
    pause: pause,
    stop: stop,
    release: release,
    startAll: startAll,
    stopAll: stopAll,
    pauseAll: pauseAll,
    resumeAll: resumeAll,
    updateSources: updateSources,
    textureFor: textureFor,
    frameFor: frameFor,
    status: status,
    lastError: function () { return state.lastError; }
  };
});
