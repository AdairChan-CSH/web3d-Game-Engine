/* UnirealEngine — audio.js
 * Browser-native sound runtime. WAV/MP3/OGG/M4A bytes are decoded by the
 * browser's AudioContext; playback is a WebAudio graph with an optional 3D
 * panner per AudioSource and one listener shared with the Main Camera.
 * No transcoding, plugins or server-side code. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  if (UE.Audio) return;

  const state = {
    ctx: null,
    buffers: {},          // clipId -> Promise<AudioBuffer>
    active: new Set(),    // AudioSource components with a live runtime
    media: new WeakMap(), // HTMLMediaElement -> MediaElementAudioSourceNode
    lastError: '',
    unlocked: false,
    install: false
  };

  function hasWebAudio() {
    return !!(typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext));
  }
  function context() {
    if (state.ctx) return state.ctx;
    if (!hasWebAudio()) return null;
    const Ctor = window.AudioContext || window.webkitAudioContext;
    try {
      state.ctx = new Ctor();
    } catch (err) {
      state.lastError = err && err.message ? err.message : String(err);
      return null;
    }
    return state.ctx;
  }
  function param(target, value) {
    if (target === undefined || target === null || !Number.isFinite(value)) return;
    /* Current PannerNode distance fields are plain numbers; only AudioParams
       expose setValueAtTime or a writable value property. */
    if (typeof target !== 'object' && typeof target !== 'function') return;
    if (typeof target.setValueAtTime === 'function' && state.ctx) {
      try { target.setValueAtTime(value, state.ctx.currentTime || 0); return; } catch (err) { /* fall through */ }
    }
    if ('value' in target) target.value = value;
  }
  function setNumber(target, name, value) {
    if (!target || !Number.isFinite(value)) return;
    const current = target[name];
    if (current && typeof current === 'object') param(current, value);
    else target[name] = value;
  }
  function setPosition(node, x, y, z) {
    if (!node) return;
    if (node.positionX) {
      param(node.positionX, x); param(node.positionY, y); param(node.positionZ, z);
    } else if (typeof node.setPosition === 'function') {
      node.setPosition(x, y, z);
    }
  }
  function configurePanner(panner, comp) {
    if (!panner) return;
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    if (comp.minDistance !== undefined) {
      setNumber(panner, 'refDistance', Math.max(0.01, +comp.minDistance || 0.01));
    }
    if (comp.maxDistance !== undefined) setNumber(panner, 'maxDistance', Math.max(1, +comp.maxDistance || 1));
    if (comp.rolloff !== undefined) setNumber(panner, 'rolloffFactor', Math.max(0, +comp.rolloff || 0));
  }
  function connectChain(source, gain, panner) {
    if (!source || !gain) return;
    try { source.disconnect(); } catch (err) { /* not connected yet */ }
    try { gain.disconnect(); } catch (err) { /* not connected yet */ }
    source.connect(gain);
    if (panner) {
      try { panner.disconnect(); } catch (err) { /* not connected yet */ }
      gain.connect(panner);
      panner.connect(state.ctx.destination);
    } else {
      gain.connect(state.ctx.destination);
    }
  }
  function installUnlock() {
    if (state.install || typeof document === 'undefined') return;
    state.install = true;
    const events = ['pointerdown', 'touchstart', 'keydown'];
    for (const name of events) {
      document.addEventListener(name, function () { unlock(); }, { passive: true });
    }
  }
  function unlock() {
    installUnlock();
    const ctx = context();
    if (ctx && ctx.resume) {
      try { ctx.resume(); state.unlocked = true; } catch (err) {
        state.lastError = err.message || String(err);
      }
    }
    return state.unlocked;
  }

  /* Decode once per asset id. Failed decodes are evicted so a later retry can
     succeed after the browser has finished loading its media pipeline. */
  function decode(clipId) {
    const ctx = context();
    if (!ctx) return Promise.reject(new Error(state.lastError || 'WebAudio is not available in this browser'));
    if (!clipId) return Promise.reject(new Error('No audio clip selected'));
    if (state.buffers[clipId]) return state.buffers[clipId];
    const bytes = UE.AssetStore.getAudio(clipId);
    if (!bytes || !bytes.length) return Promise.reject(new Error('Audio clip "' + clipId + '" was not found'));
    let promise;
    try {
      const copy = bytes.slice ? bytes.slice() : new Uint8Array(bytes);
      const buffer = copy.buffer instanceof ArrayBuffer ? copy.buffer : new Uint8Array(copy).buffer;
      if (ctx.decodeAudioData.length >= 2) {
        promise = new Promise(function (resolve, reject) {
          ctx.decodeAudioData(buffer, resolve, reject);
        });
      } else {
        promise = Promise.resolve(ctx.decodeAudioData(buffer));
      }
    } catch (err) {
      promise = Promise.reject(err);
    }
    promise = promise.catch(function (err) {
      delete state.buffers[clipId];
      state.lastError = err && err.message ? err.message : String(err);
      UE.log('error', 'Could not decode audio "' + clipId + '": ' + state.lastError);
      throw err;
    });
    state.buffers[clipId] = promise;
    return promise;
  }

  function createBufferRuntime(comp, buffer, offset) {
    const ctx = state.ctx;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = !!comp.loop;
    if (source.playbackRate) param(source.playbackRate, Math.max(0.1, +comp.pitch || 1));
    const gain = ctx.createGain();
    param(gain.gain, comp.muted ? 0 : Math.max(0, +comp.volume || 0));
    const panner = comp.spatial && ctx.createPanner ? ctx.createPanner() : null;
    if (panner) configurePanner(panner, comp);
    connectChain(source, gain, panner);
    const rt = {
      type: 'buffer', source: source, gain: gain, panner: panner,
      buffer: buffer, offset: offset || 0, startedAt: ctx.currentTime || 0,
      playing: true, paused: false, stopping: false
    };
    source.onended = function () {
      if (rt.stopping || comp._runtime !== rt) return;
      rt.playing = false;
      if (!source.loop) {
        comp._runtime = null;
        comp._status = 'idle';
        state.active.delete(comp);
      }
    };
    try {
      const startAt = Math.max(0, Math.min(rt.offset, Math.max(0, (buffer.duration || 0) - 0.001)));
      source.start(0, startAt);
    } catch (err) {
      state.lastError = err.message || String(err);
    }
    return rt;
  }

  function play(comp, options) {
    if (!comp || !comp.clipId) return Promise.resolve(false);
    stop(comp, true);
    const ctx = context();
    if (!ctx) return Promise.resolve(false);
    installUnlock();
    unlock();
    const token = (comp._playToken || 0) + 1;
    comp._playToken = token;
    comp._status = 'loading';
    const offset = options && options.offset ? +options.offset : 0;
    return decode(comp.clipId).then(function (buffer) {
      if (comp._playToken !== token) return false;
      comp._runtime = createBufferRuntime(comp, buffer, offset);
      comp._pausedOffset = null;
      comp._status = 'playing';
      state.active.add(comp);
      return true;
    }).catch(function () {
      if (comp._playToken === token) comp._status = 'error';
      return false;
    });
  }

  function stop(comp, keepPause) {
    if (!comp) return;
    comp._playToken = (comp._playToken || 0) + 1;
    const rt = comp._runtime;
    if (rt) {
      if (!keepPause && rt.buffer && state.ctx) {
        const elapsed = (state.ctx.currentTime || 0) - (rt.startedAt || 0);
        comp._pausedOffset = (rt.offset + Math.max(0, elapsed)) % Math.max(0.001, rt.buffer.duration || 0.001);
      }
      rt.stopping = true;
      try { if (rt.source && rt.source.stop) rt.source.stop(); } catch (err) { /* already stopped */ }
      for (const node of [rt.source, rt.gain, rt.panner]) {
        try { if (node && node.disconnect) node.disconnect(); } catch (err) { /* already disconnected */ }
      }
      comp._runtime = null;
    }
    if (!keepPause) {
      comp._pausedOffset = null;
      comp._status = 'idle';
    }
    state.active.delete(comp);
  }

  function pause(comp) {
    if (!comp || !comp._runtime) return;
    stop(comp, true);
    comp._status = 'paused';
  }
  function resume(comp) {
    if (!comp || comp._status !== 'paused') return Promise.resolve(false);
    const offset = comp._pausedOffset || 0;
    return play(comp, { offset: offset });
  }

  /* A video element can only have one MediaElementAudioSourceNode, so the node
     is cached per element and only its downstream gain/panner are rebuilt. */
  function attachMediaElement(element, settings) {
    const ctx = context();
    if (!ctx || !element || typeof ctx.createMediaElementSource !== 'function') return null;
    let source = state.media.get(element);
    if (!source) {
      try {
        source = ctx.createMediaElementSource(element);
        state.media.set(element, source);
      } catch (err) {
        state.lastError = err.message || String(err);
        return null;
      }
    }
    const gain = ctx.createGain();
    const panner = settings && settings.spatial && ctx.createPanner ? ctx.createPanner() : null;
    connectChain(source, gain, panner);
    const handle = { type: 'media', element: element, source: source, gain: gain, panner: panner };
    updateMedia(handle, settings || {});
    return handle;
  }
  function updateMedia(handle, settings) {
    if (!handle || !handle.gain) return;
    const muted = !!(settings && settings.muted);
    param(handle.gain.gain, muted ? 0 : Math.max(0, +(settings && settings.volume) || 0));
    if (handle.panner && settings) configurePanner(handle.panner, settings);
  }
  function disposeMedia(handle) {
    if (!handle) return;
    for (const node of [handle.gain, handle.panner]) {
      try { if (node && node.disconnect) node.disconnect(); } catch (err) { /* ignore */ }
    }
  }

  function updateListener(view) {
    const ctx = state.ctx;
    if (!ctx || !view || !view.eye) return;
    const eye = view.eye, forward = view.forward || { x: 0, y: 0, z: -1 }, up = view.up || { x: 0, y: 1, z: 0 };
    const listener = ctx.listener;
    if (!listener) return;
    if (listener.positionX) {
      param(listener.positionX, eye.x); param(listener.positionY, eye.y); param(listener.positionZ, eye.z);
      param(listener.forwardX, forward.x); param(listener.forwardY, forward.y); param(listener.forwardZ, forward.z);
      param(listener.upX, up.x); param(listener.upY, up.y); param(listener.upZ, up.z);
    } else if (typeof listener.setPosition === 'function') {
      listener.setPosition(eye.x, eye.y, eye.z);
      if (typeof listener.setOrientation === 'function') {
        listener.setOrientation(forward.x, forward.y, forward.z, up.x, up.y, up.z);
      }
    }
  }

  function updateSources(scene) {
    if (!scene || !state.ctx) return;
    for (const object of scene.objects) {
      if (!object.active) continue;
      const comp = object.getComponent('AudioSource');
      if (!comp) continue;
      const rt = comp._runtime;
      if (!rt) continue;
      param(rt.gain.gain, comp.muted ? 0 : Math.max(0, +comp.volume || 0));
      if (rt.source && rt.source.playbackRate) param(rt.source.playbackRate, Math.max(0.1, +comp.pitch || 1));
      if (rt.source) rt.source.loop = !!comp.loop;
      if (rt.panner) {
        configurePanner(rt.panner, comp);
        const p = object.transform.worldPosition();
        setPosition(rt.panner, p.x, p.y, p.z);
      }
    }
  }

  function startAll(scene) {
    installUnlock();
    unlock();
    if (!scene) return;
    for (const object of scene.objects) {
      const comp = object.getComponent('AudioSource');
      if (comp && comp.playOnAwake && comp.clipId) play(comp);
    }
  }
  function suspendAll() {
    const ctx = state.ctx;
    if (ctx && ctx.state === 'running' && ctx.suspend) {
      try { ctx.suspend(); } catch (err) { /* ignore */ }
    }
  }
  function resumeAll() {
    const ctx = state.ctx;
    if (ctx && ctx.state === 'suspended' && ctx.resume) {
      try { ctx.resume(); } catch (err) { /* ignore */ }
    }
  }
  function stopAll() {
    for (const comp of Array.from(state.active)) stop(comp);
  }

  function status(comp) {
    if (!comp || !comp.clipId) return 'none';
    return comp._status || (comp._runtime && comp._runtime.playing ? 'playing' : 'idle');
  }
  function reset() {
    stopAll();
    state.buffers = {};
    state.media = new WeakMap();
    const ctx = state.ctx;
    state.ctx = null;
    state.lastError = '';
    if (ctx && typeof ctx.close === 'function') {
      try { ctx.close(); } catch (err) { /* ignore */ }
    }
  }

  UE.Audio = {
    supported: hasWebAudio,
    context: context,
    unlock: unlock,
    decode: decode,
    play: play,
    stop: stop,
    pause: pause,
    resume: resume,
    startAll: startAll,
    stopAll: stopAll,
    suspendAll: suspendAll,
    resumeAll: resumeAll,
    updateListener: updateListener,
    updateSources: updateSources,
    attachMediaElement: attachMediaElement,
    updateMedia: updateMedia,
    disposeMedia: disposeMedia,
    setPannerPosition: setPosition,
    status: status,
    reset: reset,
    lastError: function () { return state.lastError; }
  };
});
