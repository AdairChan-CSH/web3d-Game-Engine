/* UnirealEngine — extras.js
 * Small, self-contained systems layered on top of the core engine:
 * object presets, FSM templates, the four network roles, texture editing and
 * keyboard/gamepad input. Everything stays in plain browser JavaScript. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;
  if (!UE.Scene || !UE.PlayMaker) throw new Error('engine.js and playmaker.js must load before extras.js');

  /* ------------------------------------------------------------ object presets */
  const OBJECT_PRESETS = [
    {
      id: 'empty', label: 'Empty GameObject', hint: 'A plain transform, useful as a group or anchor.',
      make: function (name, pos) { return UE.createEmpty(name, pos); }
    },
    {
      id: 'player', label: 'Player', hint: 'Tagged cube with rigidbody, collider and a Player network role.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'cube', '#66d9c0', pos);
        o.addComponent('Rigidbody', { mass: 2, drag: 0.1 });
        UE.applyNetworkRole(o, 'player');
        return o;
      }
    },
    {
      id: 'enemy', label: 'Enemy / NPC', hint: 'Sphere with a rigidbody and the NPC network role.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'sphere', '#ff8b6b', pos);
        o.addComponent('Rigidbody', { mass: 1.5 });
        UE.applyNetworkRole(o, 'npc');
        return o;
      }
    },
    {
      id: 'pickup', label: 'Pickup', hint: 'Small trigger collider with the Pickup network role.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'sphere', '#ffd166', pos);
        o.transform.scale = V3.create(0.5, 0.5, 0.5);
        const c = o.getComponent('Collider');
        if (c) c.isTrigger = true;
        UE.applyNetworkRole(o, 'pickup');
        return o;
      }
    },
    {
      id: 'projectile', label: 'Projectile', hint: 'Cone with no gravity and the Projectile network role.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'cone', '#b392ff', pos);
        o.transform.scale = V3.create(0.35, 0.7, 0.35);
        const rb = o.addComponent('Rigidbody', { mass: 0.2, useGravity: false });
        rb.useGravity = false;
        UE.applyNetworkRole(o, 'projectile');
        return o;
      }
    },
    {
      id: 'platform', label: 'Platform', hint: 'Wide static plane tagged Ground.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'plane', '#9aa7b6', pos);
        o.tag = 'Ground';
        o.transform.scale = V3.create(2, 1, 2);
        return o;
      }
    },
    {
      id: 'trigger', label: 'Trigger Zone', hint: 'Invisible-by-behaviour box with a trigger collider.',
      make: function (name, pos) {
        const o = UE.createPrimitive(name, 'cube', '#67e8c3', pos);
        const c = o.getComponent('Collider');
        if (c) c.isTrigger = true;
        return o;
      }
    },
    {
      id: 'camera', label: 'Main Camera', hint: 'A camera that renders the Game view.',
      make: function (name, pos) { return UE.createCamera(name, pos, { x: 18, y: 0, z: 0 }); }
    },
    {
      id: 'pipCamera', label: 'Second Camera (PiP)', hint: 'A camera whose view is drawn as an inset overlay.',
      make: function (name, pos) {
        const o = UE.createCamera(name, pos, { x: 18, y: 0, z: 0 });
        const cam = o.getComponent('Camera');
        cam.main = false;
        cam.pip = true;
        return o;
      }
    },
    {
      id: 'sun', label: 'Sun', hint: 'Global directional sun light.',
      make: function (name, pos) { return UE.createLight(name, 'sun', pos, { x: 50, y: 30, z: 0 }); }
    },
    {
      id: 'pointLight', label: 'Point Light', hint: 'Local omnidirectional light.',
      make: function (name, pos) { return UE.createLight(name, 'point', pos); }
    },
    {
      id: 'spotLight', label: 'Spot Light', hint: 'Cone light with cookie support.',
      make: function (name, pos) { return UE.createLight(name, 'spot', pos, { x: 90, y: 0, z: 0 }); }
    }
  ];
  const PRESET_BY_ID = {};
  for (const preset of OBJECT_PRESETS) PRESET_BY_ID[preset.id] = preset;

  UE.createPreset = function (id, options) {
    const preset = PRESET_BY_ID[id];
    if (!preset) return null;
    options = options || {};
    const name = options.name || preset.label;
    const pos = options.position ? V3.clone(options.position) : V3.create(0, 0.5, 0);
    const object = preset.make(name, pos);
    if (options.tag) object.tag = UE.Tags.normalize(options.tag);
    if (options.fsm && UE.applyFsmTemplate) UE.applyFsmTemplate(object, options.fsm);
    return object;
  };

  /* -------------------------------------------------------------- FSM templates */
  function st(name, actions, transitions) {
    return { name: name, actions: actions || [], transitions: transitions || [] };
  }
  const FSM_TEMPLATES = [
    {
      id: 'idle', name: 'Idle Log', hint: 'One log action, then FINISHED.',
      fsm: { name: 'Idle', start: 'Idle', variables: {}, states: [st('Idle', [{ type: 'log', message: 'Hello from PlayMaker' }])] }
    },
    {
      id: 'spin', name: 'Spin', hint: 'Rotates 90 degrees per second forever.',
      fsm: {
        name: 'Spin', start: 'Spin', variables: {},
        states: [st('Spin', [{ type: 'rotate', y: 90, duration: 4 }], [{ event: 'FINISHED', to: 'Spin' }])]
      }
    },
    {
      id: 'patrol', name: 'Patrol', hint: 'Moves between two X positions.',
      fsm: {
        name: 'Patrol', start: 'Patrol', variables: { fromX: 0, toX: 3, speed: 2 },
        states: [
          st('Patrol', [{ type: 'moveTowards', x: '$toX', y: 1, z: 0, speed: '$speed' }], [{ event: 'FINISHED', to: 'Return' }]),
          st('Return', [{ type: 'moveTowards', x: '$fromX', y: 1, z: 0, speed: '$speed' }], [{ event: 'FINISHED', to: 'Patrol' }])
        ]
      }
    },
    {
      id: 'chase', name: 'Chase Player', hint: 'Follows and looks at the first Player-tagged object.',
      fsm: {
        name: 'Chase', start: 'Chase', variables: { speed: 2.5 },
        states: [st('Chase', [
          { type: 'followObject', target: 'tag:Player', speed: '$speed', distance: 1.2 },
          { type: 'lookAt', target: 'self', lookAt: 'tag:Player' }
        ])]
      }
    },
    {
      id: 'pickup', name: 'Pickup', hint: 'Disables itself on collision and broadcasts PICKED_UP.',
      fsm: {
        name: 'Pickup', start: 'Idle', variables: {},
        states: [
          st('Idle', [], [{ event: 'OnCollisionEnter', to: 'Collect' }]),
          st('Collect', [
            { type: 'deactivate', target: 'self' },
            { type: 'broadcastEvent', event: 'PICKED_UP' },
            { type: 'sendEventToTag', tag: 'Player', event: 'PICKUP' }
          ])
        ]
      }
    },
    {
      id: 'projectile', name: 'Projectile', hint: 'Travels forward and explodes on collision.',
      fsm: {
        name: 'Projectile', start: 'Fly', variables: {},
        states: [
          st('Fly', [{ type: 'translate', x: 0, y: 0, z: -8, duration: 0 }], [{ event: 'OnCollisionEnter', to: 'Impact' }]),
          st('Impact', [{ type: 'deactivate', target: 'self' }, { type: 'broadcastEvent', event: 'IMPACT' }])
        ]
      }
    },
    {
      id: 'health', name: 'Health', hint: 'Counts down from 3 on DAMAGE and dies at zero.',
      fsm: {
        name: 'Health', start: 'Alive', variables: { health: 3 },
        states: [
          st('Alive', [], [{ event: 'DAMAGE', to: 'Hurt' }]),
          st('Hurt', [
            { type: 'setVariable', name: 'health', operation: 'add', value: '-1' },
            { type: 'ifVariable', name: 'health', compare: 'less', value: 1, event: 'DIE' }
          ], [{ event: 'DIE', to: 'Dead' }, { event: 'FINISHED', to: 'Alive' }]),
          st('Dead', [{ type: 'deactivate', target: 'self' }])
        ]
      }
    },
    {
      id: 'cameraFollow', name: 'Follow Camera', hint: 'Keeps a camera behind the Player with a height offset.',
      fsm: {
        name: 'FollowCamera', start: 'Follow', variables: { speed: 5 },
        states: [st('Follow', [{
          type: 'followObject', target: 'tag:Player', speed: '$speed', distance: 6,
          offsetX: 0, offsetY: 3, offsetZ: 0
        }, { type: 'lookAt', target: 'self', lookAt: 'tag:Player' }])]
      }
    },
    {
      id: 'networkPlayer', name: 'Network Player', hint: 'Claims ownership and broadcasts its state on start.',
      fsm: {
        name: 'NetworkPlayer', start: 'Setup', variables: {},
        states: [
          st('Setup', [
            { type: 'networkSetRole', role: 'player', target: 'self' },
            { type: 'networkClaim', target: 'self' },
            { type: 'networkBroadcast' }
          ], [{ event: 'FINISHED', to: 'Idle' }]),
          st('Idle', [{ type: 'wait', seconds: 1 }], [{ event: 'FINISHED', to: 'Idle' }])
        ]
      }
    }
  ];
  const TEMPLATE_BY_ID = {};
  for (const template of FSM_TEMPLATES) TEMPLATE_BY_ID[template.id] = template;

  UE.applyFsmTemplate = function (object, id, options) {
    const template = TEMPLATE_BY_ID[id];
    if (!object || !template) return null;
    options = options || {};
    let fsm = null;
    if (options.replace) {
      const existing = object.getComponents('PlayMakerFSM');
      for (const old of existing) object.removeComponent(old);
    }
    const data = UE.clone(template.fsm);
    if (options.name) data.name = options.name;
    data.states = data.states.map(function (state) {
      return {
        name: state.name,
        actions: state.actions.map(function (action) {
          return Object.assign(UE.PlayMaker.action(action.type), action);
        }),
        transitions: UE.clone(state.transitions)
      };
    });
    fsm = object.addComponent('PlayMakerFSM', data);
    return fsm;
  };

  /* ------------------------------------------------------------- texture tools */
  function bytesFromDataUrl(url) {
    const text = String(url || '').split(',')[1] || '';
    const binary = atob(text);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  function dataUrlFromBytes(bytes, mime) {
    let binary = '';
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    for (let i = 0; i < view.length; i++) binary += String.fromCharCode(view[i]);
    return 'data:' + (mime || 'image/png') + ';base64,' + btoa(binary);
  }
  function decodeTexture(texture) {
    if (!texture || !texture.bytes || !texture.bytes.length) return Promise.reject(new Error('Texture has no image bytes'));
    const blob = new Blob([texture.bytes], { type: texture.mime || 'image/png' });
    function draw(source) {
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, source.width || 1);
      canvas.height = Math.max(1, source.height || 1);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
      return { canvas: canvas, ctx: ctx, texture: texture };
    }
    if (typeof createImageBitmap === 'function') {
      return createImageBitmap(blob).then(draw);
    }
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(draw(img)); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('Texture could not be decoded')); };
      img.src = url;
    });
  }

  const Textures = UE.Textures = {
    list: function (scene) {
      const out = [];
      const seen = {};
      const objects = scene && scene.objects ? scene.objects : [];
      for (const object of objects) {
        const mr = object.getComponent && object.getComponent('MeshRenderer');
        if (!mr || !mr.meshId || seen[mr.meshId]) continue;
        seen[mr.meshId] = true;
        const asset = UE.AssetStore.get(mr.meshId);
        if (!asset || !asset.prims) continue;
        const meta = UE.AssetStore.meta(mr.meshId);
        asset.prims.forEach(function (prim, index) {
          const texture = prim.material && prim.material.texture;
          if (!texture || !texture.bytes || !texture.bytes.length) return;
          out.push({
            assetId: mr.meshId, assetName: (meta && meta.name) || mr.meshId, primIndex: index,
            object: object, texture: texture
          });
        });
      }
      return out;
    },
    decode: decodeTexture,
    bytesFromDataUrl: bytesFromDataUrl,
    dataUrlFromBytes: dataUrlFromBytes,
    encode: function (canvas) { return bytesFromDataUrl(canvas.toDataURL('image/png')); },
    dataUrl: function (texture) {
      return dataUrlFromBytes(texture.bytes, texture.mime || 'image/png');
    },
    update: function (texture, canvas) {
      if (!texture || !canvas) return null;
      texture.bytes = this.encode(canvas);
      texture.mime = 'image/png';
      texture.name = texture.name || 'edited-texture.png';
      return texture;
    },
    /* Commit an edit to both the decoded texture and the stored asset so the
       change survives scene export and is uploaded again by the renderer. */
    commit: function (entry, canvas) {
      if (!entry || !canvas) return false;
      const texture = entry.texture;
      if (!texture) return false;
      this.update(texture, canvas);
      const asset = UE.AssetStore && UE.AssetStore.items[entry.assetId];
      const encoded = asset && asset.prims && asset.prims[entry.primIndex];
      if (encoded && encoded.material && encoded.material.texture) {
        const url = this.dataUrlFromBytes(texture.bytes, texture.mime);
        encoded.material.texture.t = String(url).split(',')[1] || '';
        encoded.material.texture.mime = texture.mime;
        encoded.material.texture.name = texture.name;
        asset.hasTexture = true;
        asset.signature += '|edited-' + Date.now().toString(36);
      }
      return true;
    },
    apply: function (texture, operation, options) {
      options = options || {};
      return decodeTexture(texture).then(function (decoded) {
        const ctx = decoded.ctx;
        const canvas = decoded.canvas;
        const w = canvas.width, h = canvas.height;
        const color = options.color || '#ffffff';
        if (operation === 'tint') {
          ctx.save();
          ctx.globalCompositeOperation = 'source-atop';
          ctx.globalAlpha = options.opacity === undefined ? 0.35 : options.opacity;
          ctx.fillStyle = color;
          ctx.fillRect(0, 0, w, h);
          ctx.restore();
        } else if (operation === 'grayscale') {
          const image = ctx.getImageData(0, 0, w, h);
          for (let i = 0; i < image.data.length; i += 4) {
            const g = image.data[i] * 0.3 + image.data[i + 1] * 0.59 + image.data[i + 2] * 0.11;
            image.data[i] = image.data[i + 1] = image.data[i + 2] = g;
          }
          ctx.putImageData(image, 0, 0);
        } else if (operation === 'flip') {
          const copy = document.createElement('canvas');
          copy.width = w; copy.height = h;
          copy.getContext('2d').drawImage(canvas, 0, 0);
          ctx.clearRect(0, 0, w, h);
          ctx.save();
          ctx.translate(w, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(copy, 0, 0);
          ctx.restore();
        } else if (operation === 'rotate') {
          const copy = document.createElement('canvas');
          copy.width = w; copy.height = h;
          copy.getContext('2d').drawImage(canvas, 0, 0);
          canvas.width = h; canvas.height = w;
          ctx.save();
          ctx.translate(h / 2, w / 2);
          ctx.rotate(Math.PI / 2);
          ctx.drawImage(copy, -w / 2, -h / 2);
          ctx.restore();
        } else if (operation === 'pattern') {
          const size = Math.max(4, Number(options.size) || 16);
          const background = options.background || '#20262e';
          ctx.save();
          ctx.globalAlpha = options.opacity === undefined ? 0.5 : options.opacity;
          ctx.fillStyle = color;
          for (let y = 0; y < h; y += size) {
            for (let x = 0; x < w; x += size) {
              const on = options.pattern === 'stripes' ? (Math.floor(x / size) % 2 === 0)
                : options.pattern === 'dots' ? (((x / size) % 2) === 0 && ((y / size) % 2) === 0)
                  : ((Math.floor(x / size) + Math.floor(y / size)) % 2 === 0);
              if (!on) continue;
              if (options.pattern === 'dots') {
                ctx.beginPath();
                ctx.arc(x + size / 2, y + size / 2, Math.max(1, size / 4), 0, Math.PI * 2);
                ctx.fill();
              } else ctx.fillRect(x, y, size, size);
            }
          }
          ctx.restore();
          void background;
        } else if (operation === 'brush') {
          const px = (Number(options.x) || 0) * w;
          const py = (Number(options.y) || 0) * h;
          const radius = Math.max(1, Number(options.radius) || 8);
          ctx.save();
          ctx.globalAlpha = options.opacity === undefined ? 1 : options.opacity;
          ctx.fillStyle = color;
          ctx.beginPath();
          ctx.arc(px, py, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (operation === 'clear') {
          ctx.fillStyle = color;
          ctx.fillRect(0, 0, w, h);
        } else {
          return Promise.reject(new Error('Unknown texture operation: ' + operation));
        }
        return decoded;
      });
    }
  };

  /* -------------------------------------------------------------- input system */
  const DEFAULT_BINDINGS = {
    play: { key: 'p', ctrl: true, shift: false, label: 'Play' },
    pause: { key: 'p', ctrl: true, shift: true, label: 'Pause' },
    step: { key: '.', ctrl: true, label: 'Step frame' },
    stop: { key: 'escape', label: 'Stop' },
    toolMove: { key: 'w', label: 'Move tool' },
    toolRotate: { key: 'e', label: 'Rotate tool' },
    toolScale: { key: 'r', label: 'Scale tool' },
    focus: { key: 'f', label: 'Focus selection' },
    secondCamera: { key: 'c', label: 'Toggle second camera' }
  };
  const GAMEPAD_BUTTONS = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'back', 'start', 'up', 'down', 'left', 'right', 'ls', 'rs'];

  const Input = UE.Input = {
    bindings: UE.clone(DEFAULT_BINDINGS),
    deadzone: 0.22,
    gamepads: [],
    axes: [0, 0, 0, 0],
    buttons: {},
    activeIndex: 0,
    onChange: null,
    setBinding: function (action, binding) {
      if (!this.bindings[action] || !binding || !binding.key) return false;
      this.bindings[action] = {
        key: String(binding.key).toLowerCase(),
        ctrl: !!binding.ctrl, shift: !!binding.shift, alt: !!binding.alt,
        label: this.bindings[action].label
      };
      if (this.onChange) this.onChange(this.status());
      return true;
    },
    resetBindings: function () {
      this.bindings = UE.clone(DEFAULT_BINDINGS);
      if (this.onChange) this.onChange(this.status());
      return this.bindings;
    },
    matches: function (action, event) {
      const b = this.bindings[action];
      if (!b || !event) return false;
      const key = String(event.key || '').toLowerCase();
      if (key !== b.key) return false;
      return !!event.ctrlKey === !!b.ctrl && !!event.shiftKey === !!b.shift && !!event.altKey === !!b.alt;
    },
    axis: function (index) {
      const value = this.axes[index];
      return Number.isFinite(value) ? value : 0;
    },
    button: function (name) {
      return !!this.buttons[String(name).toLowerCase()];
    },
    value: function (path) {
      const text = String(path || '');
      if (text.indexOf('gamepad.axes.') === 0) return this.axis(parseInt(text.slice(13), 10) || 0);
      if (text.indexOf('gamepad.button.') === 0) return this.button(text.slice(15)) ? 1 : 0;
      if (text === 'gamepad.active') return this.gamepads.length > 0 ? 1 : 0;
      return 0;
    },
    poll: function () {
      const get = typeof navigator !== 'undefined' && navigator.getGamepads && navigator.getGamepads.bind(navigator);
      const pads = get ? Array.prototype.slice.call(get()).filter(Boolean) : [];
      this.gamepads = pads;
      this.activeIndex = pads.length ? 0 : -1;
      const pad = pads[this.activeIndex] || null;
      const previous = this.buttons;
      this.buttons = {};
      for (let i = 0; i < GAMEPAD_BUTTONS.length; i++) {
        const source = pad && pad.buttons[i] ? pad.buttons[i] : null;
        const pressed = !!(source && (source.pressed || Number(source.value) > 0.5));
        const name = GAMEPAD_BUTTONS[i];
        this.buttons[name] = pressed;
        if (pressed !== !!previous[name] && UE.PlayMaker && UE.PlayMaker.setKey) {
          UE.PlayMaker.setKey('gamepad.' + name, pressed);
        }
      }
      for (let i = 0; i < 4; i++) {
        let value = pad && pad.axes[i] ? pad.axes[i] : 0;
        if (Math.abs(value) < this.deadzone) value = 0;
        this.axes[i] = value;
      }
      return pads.length;
    },
    status: function () {
      return {
        bindings: UE.clone(this.bindings),
        deadzone: this.deadzone,
        connected: this.gamepads.length,
        buttons: Object.assign({}, this.buttons),
        axes: this.axes.slice()
      };
    },
    reset: function () {
      this.gamepads = [];
      this.axes = [0, 0, 0, 0];
      this.buttons = {};
    }
  };

  UE.Extras = {
    objectPresets: OBJECT_PRESETS,
    fsmTemplates: FSM_TEMPLATES,
    defaultBindings: UE.clone(DEFAULT_BINDINGS),
    gamepadButtons: GAMEPAD_BUTTONS.slice(),
    networkRoles: UE.NETWORK_ROLES,
    textures: Textures,
    input: Input
  };
});
