/* UnirealEngine — engine.js
 * Scene graph, components, serialization, a small fixed-step physics solver and the script runtime.
 * No DOM, no database: everything lives in plain objects and serializes to JSON. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;

  /* ------------------------------------------------------------------ logging */
  UE.onLog = null;
  UE.log = function (level, message) {
    if (typeof UE.onLog === 'function') UE.onLog(level, message);
    else if (typeof console !== 'undefined') (console[level] || console.log)(message);
  };

  /* ---------------------------------------------------------------- Transform */
  class Transform {
    constructor(object) {
      this.object = object;
      this.parent = null;
      this.children = [];
      this.position = V3.create();
      this.rotation = V3.create();       // Euler degrees, Unity ZXY order
      this.scale = V3.create(1, 1, 1);
    }
    localMatrix() {
      return UE.Mat4.compose(this.position, this.rotation, this.scale);
    }
    worldMatrix() {
      const local = this.localMatrix();
      return this.parent ? UE.Mat4.multiply(this.parent.transform.worldMatrix(), local) : local;
    }
    worldPosition() {
      const m = this.worldMatrix();
      return { x: m[12], y: m[13], z: m[14] };
    }
    worldScale() {
      const out = V3.create(1, 1, 1);
      let t = this;
      while (t) {
        out.x *= t.scale.x; out.y *= t.scale.y; out.z *= t.scale.z;
        t = t.parent ? t.parent.transform : null;
      }
      return out;
    }
    forward() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(0, 0, -1)); }
    right() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(1, 0, 0)); }
    up() { return UE.Q.rotate(UE.Q.fromEuler(this.rotation), V3.create(0, 1, 0)); }
  }

  /* ---------------------------------------------------------------- components */
  const COMPONENTS = UE.Components = {};

  class Component {
    constructor(object) { this.object = object; }
    get transform() { return this.object.transform; }
    applyJSON(props) {
      if (!props) return;
      for (const k of this.constructor.props) {
        if (props[k] !== undefined) this[k] = UE.clone(props[k]);
      }
    }
    serialize() {
      const out = {};
      for (const k of this.constructor.props) out[k] = UE.clone(this[k]);
      return out;
    }
  }
  UE.Component = Component;

  class MeshRenderer extends Component {
    constructor(object) {
      super(object);
      this.primitive = 'cube';
      this.meshId = null;                 // imported model asset (see UE.AssetStore)
      this.meshName = '';
      this.color = '#c9ced8';
      this.roughness = 0.55;
      this.emissive = 0;
      this.opacity = 1;
      this.uvScale = { x: 1, y: 1 };       // base-color texture tiling
      this.uvOffset = { x: 0, y: 0 };      // base-color texture scroll/offset
      this.castShadow = true;
    }
  }
  MeshRenderer.typeName = 'MeshRenderer';
  MeshRenderer.label = 'Mesh Renderer';
  MeshRenderer.props = ['primitive', 'meshId', 'meshName', 'color', 'roughness', 'emissive', 'opacity', 'uvScale', 'uvOffset', 'castShadow'];

  class Collider extends Component {
    constructor(object) {
      super(object);
      this.shape = 'box';
      this.size = V3.create(1, 1, 1);
      this.center = V3.create(0, 0, 0);
      this.isTrigger = false;             // report contacts without resolving them
      this.friction = 0.6;                // combined with the other collider's friction
    }
  }
  Collider.typeName = 'Collider';
  Collider.label = 'Collider';
  Collider.props = ['shape', 'size', 'center', 'isTrigger', 'friction'];

  class Rigidbody extends Component {
    constructor(object) {
      super(object);
      this.useGravity = true;
      this.gravityScale = 1;
      this.mass = 1;
      this.drag = 0;
      this.restitution = 0.3;
      this.isKinematic = false;
      this.freezePosition = { x: false, y: false, z: false };
      this.freezeRotation = { x: false, y: false, z: false };
      this.velocity = V3.create();       // runtime only, not serialized
    }
  }
  Rigidbody.typeName = 'Rigidbody';
  Rigidbody.label = 'Rigidbody';
  Rigidbody.props = ['useGravity', 'gravityScale', 'mass', 'drag', 'restitution', 'isKinematic', 'freezePosition', 'freezeRotation'];

  class Camera extends Component {
    constructor(object) {
      super(object);
      this.fov = 60;
      this.near = 0.1;
      this.far = 250;
      this.main = true;
      this.pip = false;                   // renders an inset view over the Game view
    }
  }
  Camera.typeName = 'Camera';
  Camera.label = 'Camera';
  Camera.props = ['fov', 'near', 'far', 'main', 'pip'];

  /* Replicated object marker. The browser-only transport lives in network.js.
     Owner is runtime state: it identifies the peer that currently drives the
     transform and is deliberately not serialized into the scene file. */
  class NetworkObject extends Component {
    constructor(object) {
      super(object);
      this.networkId = '';
      this.role = 'player';               // player | npc | pickup | projectile
      this.syncTransform = true;
      this.syncMesh = true;
      this.syncTag = true;
      this.syncActive = true;
      this.sendRate = 15;              // state messages per second
      this.interpolation = 12;         // remote smoothing; 0 = snap
      this.owner = '';                 // runtime peer id
      this._netClock = 0;              // runtime send timer
      this._netTarget = null;          // runtime interpolation target
    }
    ensureId() {
      if (!this.networkId) this.networkId = 'net-' + UE.uuid();
      return this.networkId;
    }
    resetRuntime() {
      this.owner = '';
      this._netClock = 0;
      this._netTarget = null;
    }
  }
  NetworkObject.typeName = 'NetworkObject';
  NetworkObject.label = 'Network Object';
  NetworkObject.props = ['networkId', 'role', 'syncTransform', 'syncMesh', 'syncTag', 'syncActive', 'sendRate', 'interpolation'];

  /* The four in-game network object kinds. A role is a small bundle of tag,
     mesh and physics defaults; it does not replace the per-object sync flags. */
  UE.NETWORK_ROLES = {
    player: {
      label: 'Player', tag: 'Player', primitive: 'cube', color: '#66d9c0',
      scale: { x: 1, y: 1, z: 1 }, sync: { transform: true, mesh: true, tag: true, active: true }
    },
    npc: {
      label: 'Enemy / NPC', tag: 'Enemy', primitive: 'sphere', color: '#ff8b6b',
      scale: { x: 1, y: 1, z: 1 }, sync: { transform: true, mesh: true, tag: true, active: true }
    },
    pickup: {
      label: 'Pickup', tag: 'Pickup', primitive: 'sphere', color: '#ffd166',
      scale: { x: 0.5, y: 0.5, z: 0.5 }, trigger: true,
      sync: { transform: true, mesh: true, tag: true, active: true }
    },
    projectile: {
      label: 'Projectile', tag: 'Projectile', primitive: 'cone', color: '#b392ff',
      scale: { x: 0.35, y: 0.7, z: 0.35 }, useGravity: false,
      sync: { transform: true, mesh: false, tag: false, active: true }
    }
  };
  UE.NETWORK_ROLE_IDS = Object.keys(UE.NETWORK_ROLES);
  UE.applyNetworkRole = function (object, role, options) {
    if (!object) return null;
    const id = UE.NETWORK_ROLES[role] ? role : 'player';
    const preset = UE.NETWORK_ROLES[id];
    options = options || {};
    let comp = object.getComponent('NetworkObject');
    if (!comp) comp = object.addComponent('NetworkObject');
    comp.role = id;
    if (options.applyDefaults !== false) {
      object.tag = preset.tag;
      if (preset.scale) object.transform.scale = V3.clone(preset.scale);
      const mr = object.getComponent('MeshRenderer');
      if (mr && preset.color) mr.color = preset.color;
      const collider = object.getComponent('Collider');
      if (collider && preset.trigger !== undefined) collider.isTrigger = preset.trigger;
      const rb = object.getComponent('Rigidbody');
      if (rb && preset.useGravity === false) rb.useGravity = false;
      if (preset.sync) {
        comp.syncTransform = preset.sync.transform;
        comp.syncMesh = preset.sync.mesh;
        comp.syncTag = preset.sync.tag;
        comp.syncActive = preset.sync.active;
      }
    }
    return comp;
  };

  class Light extends Component {
    constructor(object) {
      super(object);
      this.type = 'point';                // directional | point | spot
      this.color = '#ffe0b0';
      this.intensity = 1.4;
      this.range = 10;
      this.spotAngle = 48;                // full outer cone angle in degrees
      this.innerAngle = 26;               // full inner cone angle in degrees
      this.cookie = 'none';               // none | checker | stripes | grid | dots | rings | texture
      this.cookieTexture = null;          // data URL for an uploaded light cookie
      this.castShadow = true;             // reserved for shadow-map support
    }
  }
  Light.typeName = 'Light';
  Light.label = 'Light';
  Light.props = ['type', 'color', 'intensity', 'range', 'spotAngle', 'innerAngle', 'cookie', 'cookieTexture', 'castShadow'];

  UE.LIGHT_TYPES = [
    { value: 'directional', label: 'Directional' },
    { value: 'sun', label: 'Sun (primary light)' },
    { value: 'point', label: 'Point' },
    { value: 'spot', label: 'Spot' }
  ];
  UE.LIGHT_COOKIES = [
    { value: 'none', label: 'None' },
    { value: 'checker', label: 'Checker' },
    { value: 'stripes', label: 'Stripes' },
    { value: 'grid', label: 'Grid' },
    { value: 'dots', label: 'Dots' },
    { value: 'rings', label: 'Rings' },
    { value: 'texture', label: 'Uploaded texture' }
  ];
  UE.lightCookieLabel = function (value) {
    const found = UE.LIGHT_COOKIES.find(c => c.value === value);
    return found ? found.label : 'None';
  };

  class Script extends Component {
    constructor(object) {
      super(object);
      this.name = 'New Script';
      this.code = '// Runs every frame. Available: self, dt, time, scene, UE\nself.transform.rotation.y += 45 * dt;';
    }
    run(dt, time, scene) {
      if (this._compiledFrom !== this.code) {
        this._compiledFrom = this.code;
        this._fn = null;
        this._error = null;
        try {
          this._fn = new Function('self', 'dt', 'time', 'scene', 'UE', '"use strict";\n' + this.code);
        } catch (err) {
          this._error = err.message;
          UE.log('error', 'Script "' + this.name + '" on ' + this.object.name + ' failed to compile: ' + err.message);
        }
      }
      if (!this._fn) return;
      try {
        this._fn(this.object, dt, time, scene, UE);
        this._lastThrown = null;
      } catch (err) {
        if (this._lastThrown !== err.message) {
          this._lastThrown = err.message;
          UE.log('error', 'Script "' + this.name + '" on ' + this.object.name + ': ' + err.message);
        }
      }
    }
  }
  Script.typeName = 'Script';
  Script.label = 'Script';
  Script.props = ['name', 'code'];

  /* Browser media components. Runtime nodes/elements are deliberately excluded
     from props: only the clip reference and editable settings serialize. */
  class AudioSource extends Component {
    constructor(object) {
      super(object);
      this.clipId = null;                 // AssetStore audio id
      this.clipName = '';
      this.volume = 1;
      this.pitch = 1;
      this.loop = false;
      this.playOnAwake = true;
      this.spatial = true;                // 3D panner; false = flat stereo
      this.minDistance = 1;
      this.maxDistance = 40;
      this.rolloff = 1;
      this._runtime = null;               // WebAudio nodes, runtime only
    }
  }
  AudioSource.typeName = 'AudioSource';
  AudioSource.label = 'Audio Source';
  AudioSource.props = ['clipId', 'clipName', 'volume', 'pitch', 'loop', 'playOnAwake',
    'spatial', 'minDistance', 'maxDistance', 'rolloff'];

  class VideoPlayer extends Component {
    constructor(object) {
      super(object);
      this.clipId = null;                 // AssetStore video id
      this.clipName = '';
      this.url = '';                      // optional external URL, no server required
      this.autoPlay = true;
      this.loop = false;
      this.muted = false;
      this.volume = 1;
      this.spatial = true;                // route video audio through the 3D listener
      this.minDistance = 1;
      this.maxDistance = 40;
      this.rolloff = 1;
      this.playbackRate = 1;
      this._video = null;                 // HTMLVideoElement, runtime only
    }
  }
  VideoPlayer.typeName = 'VideoPlayer';
  VideoPlayer.label = 'Video Player';
  VideoPlayer.props = ['clipId', 'clipName', 'url', 'autoPlay', 'loop', 'muted', 'volume',
    'spatial', 'minDistance', 'maxDistance', 'rolloff', 'playbackRate'];

  for (const C of [MeshRenderer, Collider, Rigidbody, Camera, Light, Script, NetworkObject,
    AudioSource, VideoPlayer]) {
    COMPONENTS[C.typeName] = C;
  }

  UE.componentLabel = function (type) {
    const C = COMPONENTS[type];
    return (C && C.label) || type;
  };

  /* --------------------------------------------------------------- GameObject */
  class GameObject {
    constructor(name) {
      this.id = UE.uuid();
      this.name = name || 'GameObject';
      this.active = true;
      this.tag = 'Untagged';
      this.transform = new Transform(this);
      this.components = [];
      this.scene = null;
      this._scriptData = null;
    }
    get data() { return this._scriptData || (this._scriptData = {}); }
    getComponent(type) {
      for (const c of this.components) if (c.constructor.typeName === type) return c;
      return null;
    }
    getComponents(type) {
      return this.components.filter(c => !type || c.constructor.typeName === type);
    }
    addComponent(type, props) {
      const C = COMPONENTS[type];
      if (!C) throw new Error('Unknown component type: ' + type);
      const existing = this.getComponent(type);
      if (existing && type !== 'Script' && type !== 'PlayMakerFSM') return existing;
      const comp = new C(this);
      if (props) comp.applyJSON(props);
      this.components.push(comp);
      return comp;
    }
    removeComponent(comp) {
      const i = this.components.indexOf(comp);
      if (i >= 0) this.components.splice(i, 1);
      return i >= 0;
    }
    children() { return this.transform.children.map(c => c.object); }
    setParent(parent) {
      if (parent === this || (parent && parent.transform === this.transform)) return;
      if (this.transform.parent) {
        const old = this.transform.parent.transform.children;
        const i = old.indexOf(this.transform);
        if (i >= 0) old.splice(i, 1);
      }
      this.transform.parent = parent || null;
      if (parent) parent.transform.children.push(this.transform);
    }
    destroy() {
      if (this.scene) this.scene.remove(this);
    }
    toJSON() {
      return {
        id: this.id,
        name: this.name,
        active: this.active,
        tag: this.tag,
        parentId: this.transform.parent ? this.transform.parent.id : null,
        transform: {
          position: UE.clone(this.transform.position),
          rotation: UE.clone(this.transform.rotation),
          scale: UE.clone(this.transform.scale)
        },
        components: this.components.map(c => ({ type: c.constructor.typeName, props: c.serialize() }))
      };
    }
  }
  UE.GameObject = GameObject;

  /* --------------------------------------------------------------- asset store
   * Imported meshes are immutable assets. Geometry is stored as base64 Float32
   * positions/normals and Uint16 or Uint32 indices, so a scene JSON stays
   * compact and no binary files live outside the browser. Assets are shared by
   * reference. */
  const BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function bytesToBase64(bytes) {
    if (typeof btoa === 'function') {
      let out = '';
      /* Every chunk except the last must be a multiple of three bytes or btoa
       * inserts padding mid-stream and the concatenated string becomes invalid. */
      const chunk = 0x8000 - (0x8000 % 3);
      for (let i = 0; i < bytes.length; i += chunk) {
        out += btoa(String.fromCharCode.apply(null, bytes.subarray(i, i + chunk)));
      }
      return out;
    }
    let out = '';
    for (let i = 0; i < bytes.length; i += 3) {
      const a = bytes[i], b = bytes[i + 1], c = bytes[i + 2];
      out += BASE64_CHARS[a >> 2] + BASE64_CHARS[((a & 3) << 4) | ((b || 0) >> 4)] +
        (b === undefined ? '=' : BASE64_CHARS[((b & 15) << 2) | ((c || 0) >> 6)]) +
        (c === undefined ? '=' : BASE64_CHARS[c & 63]);
    }
    return out;
  }
  function base64ToBytes(text) {
    if (typeof atob === 'function') {
      const raw = atob(text);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      return bytes;
    }
    const bytes = [];
    let buffer = 0, bits = 0;
    for (const ch of text) {
      if (ch === '=') break;
      const v = BASE64_CHARS.indexOf(ch);
      if (v < 0) continue;
      buffer = (buffer << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; bytes.push((buffer >> bits) & 255); }
    }
    return new Uint8Array(bytes);
  }
  function encodeFloat32(list) {
    const f = list instanceof Float32Array ? list : new Float32Array(list);
    return bytesToBase64(new Uint8Array(f.buffer, f.byteOffset, f.byteLength));
  }
  function encodeUint16(list) {
    const u = list instanceof Uint16Array ? list : new Uint16Array(list);
    return bytesToBase64(new Uint8Array(u.buffer, u.byteOffset, u.byteLength));
  }
  function encodeUint32(list) {
    const u = list instanceof Uint32Array ? list : new Uint32Array(list);
    return bytesToBase64(new Uint8Array(u.buffer, u.byteOffset, u.byteLength));
  }
  function decodeFloat32(text) {
    const bytes = base64ToBytes(text);
    const out = new Float32Array(bytes.length >> 2);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getFloat32(i * 4, true);
    return out;
  }
  function decodeUint16(text) {
    const bytes = base64ToBytes(text);
    const out = new Uint16Array(bytes.length >> 1);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getUint16(i * 2, true);
    return out;
  }
  function decodeUint32(text) {
    const bytes = base64ToBytes(text);
    const out = new Uint32Array(bytes.length >> 2);
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (let i = 0; i < out.length; i++) out[i] = dv.getUint32(i * 4, true);
    return out;
  }
  function maxIndex(indices) {
    let max = 0;
    for (let i = 0; i < indices.length; i++) if (indices[i] > max) max = indices[i];
    return max;
  }

  /* ------------------------------------------------------------- asset helpers
   * Assets store one or more primitives. Each primitive keeps base64 buffers
   * for positions, normals, UVs and indices, plus an optional base-color
   * material whose texture is stored as compressed image bytes (base64 in
   * scene JSON). The renderer decodes the image on the GPU asynchronously. */
  function encodeUtf8(text) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(text);
    const bytes = [];
    for (let i = 0; i < text.length; i++) {
      let code = text.charCodeAt(i);
      if (code >= 0xD800 && code <= 0xDBFF && i + 1 < text.length) {
        const next = text.charCodeAt(i + 1);
        if (next >= 0xDC00 && next <= 0xDFFF) {
          code = 0x10000 + ((code - 0xD800) << 10) + (next - 0xDC00);
          i++;
        }
      }
      if (code < 0x80) bytes.push(code);
      else if (code < 0x800) bytes.push(0xC0 | (code >> 6), 0x80 | (code & 0x3F));
      else if (code < 0x10000) bytes.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 0x3F), 0x80 | (code & 0x3F));
      else bytes.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 0x3F), 0x80 | ((code >> 6) & 0x3F), 0x80 | (code & 0x3F));
    }
    return new Uint8Array(bytes);
  }
  function bytesOf(data) {
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (data && data.buffer instanceof ArrayBuffer) return new Uint8Array(data.buffer, data.byteOffset || 0, data.byteLength);
    if (typeof data === 'string') return encodeUtf8(data);
    return new Uint8Array(0);
  }
  function positionsBounds(positions) {
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i], y = positions[i + 1], z = positions[i + 2];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    return { min: [minX, minY, minZ], max: [maxX, maxY, maxZ] };
  }
  function primsBounds(prims) {
    let bounds = null;
    for (const prim of prims) {
      if (!prim.positions || !prim.positions.length) continue;
      const b = positionsBounds(prim.positions);
      if (!bounds) bounds = b;
      else {
        for (let k = 0; k < 3; k++) {
          bounds.min[k] = Math.min(bounds.min[k], b.min[k]);
          bounds.max[k] = Math.max(bounds.max[k], b.max[k]);
        }
      }
    }
    return bounds;
  }
  function materialToJSON(material) {
    if (!material) return null;
    const tex = material.texture;
    return {
      color: material.color || null,
      texture: tex && tex.bytes && tex.bytes.length
        ? { mime: tex.mime || 'image/png', name: tex.name || '', t: bytesToBase64(bytesOf(tex.bytes)) }
        : null
    };
  }
  function materialFromJSON(material) {
    if (!material) return null;
    const tex = material.texture;
    return {
      color: material.color || null,
      texture: tex && tex.t
        ? { mime: tex.mime || 'image/png', name: tex.name || '', bytes: base64ToBytes(tex.t) }
        : null
    };
  }
  function encodePrimitive(prim) {
    const positions = prim.positions;
    const vertexCount = positions.length / 3;
    const normals = prim.normals && prim.normals.length === positions.length ? prim.normals : new Array(positions.length).fill(0);
    const uvs = prim.uvs && prim.uvs.length === vertexCount * 2 ? prim.uvs : new Array(vertexCount * 2).fill(0);
    const indices = prim.indices;
    const wide = maxIndex(indices) > 65535;
    return {
      p: encodeFloat32(positions),
      n: encodeFloat32(normals),
      u: encodeFloat32(uvs),
      i: wide ? encodeUint32(indices) : encodeUint16(indices),
      indexType: wide ? 32 : 16,
      material: materialToJSON(prim.material)
    };
  }
  function decodePrimitive(src) {
    const positions = decodeFloat32(src.p);
    const normals = decodeFloat32(src.n);
    const vertexCount = positions.length / 3;
    const uvs = src.u ? decodeFloat32(src.u) : new Float32Array(vertexCount * 2);
    const wide = src.indexType === 32 || src.indexType === 'uint32';
    const indices = wide ? decodeUint32(src.i) : decodeUint16(src.i);
    const data = new Float32Array(vertexCount * 8);
    for (let i = 0; i < vertexCount; i++) {
      const o = i * 8, p = i * 3, uv = i * 2;
      data[o] = positions[p];
      data[o + 1] = positions[p + 1];
      data[o + 2] = positions[p + 2];
      data[o + 3] = normals[p];
      data[o + 4] = normals[p + 1];
      data[o + 5] = normals[p + 2];
      data[o + 6] = uvs[uv] || 0;
      data[o + 7] = uvs[uv + 1] || 0;
    }
    return {
      positions: positions,
      normals: normals,
      uvs: uvs,
      indices: indices,
      indexType: wide ? 32 : 16,
      material: materialFromJSON(src.material),
      data: data,
      triangles: indices.length / 3
    };
  }

  /* Media bytes are stored exactly like texture bytes: base64 in scene JSON and
     decoded lazily in memory. WAV headers are parsed here so metadata is testable
     without an AudioContext; MP3/OGG/MP4/WebM are decoded by the browser. */
  const MEDIA_MIME = {
    wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', m4a: 'audio/mp4',
    mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', ogv: 'video/ogg'
  };
  UE.MEDIA_FORMATS = {
    audio: ['wav', 'mp3', 'ogg', 'm4a'],
    video: ['mp4', 'm4v', 'webm', 'ogv']
  };
  function fourcc(bytes, at) {
    if (!bytes || at + 4 > bytes.length) return '';
    return String.fromCharCode(bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]);
  }
  function mediaFormat(bytes, name) {
    const b = bytesOf(bytes);
    const text = String(name || '').toLowerCase();
    const ext = text.indexOf('.') >= 0 ? text.split('.').pop() : text;
    if (fourcc(b, 0) === 'RIFF' && fourcc(b, 8) === 'WAVE') return 'wav';
    if (fourcc(b, 0) === 'OggS') return ext === 'ogv' ? 'ogv' : 'ogg';
    if (fourcc(b, 0) === 'ID3' || (b.length > 1 && b[0] === 0xFF && (b[1] & 0xE0) === 0xE0)) return 'mp3';
    if (fourcc(b, 4) === 'ftyp') return ext === 'm4a' || ext === 'm4v' ? ext : 'mp4';
    if (b.length > 3 && b[0] === 0x1A && b[1] === 0x45 && b[2] === 0xDF && b[3] === 0xA3) return 'webm';
    if (UE.MEDIA_FORMATS.audio.indexOf(ext) >= 0 || UE.MEDIA_FORMATS.video.indexOf(ext) >= 0) return ext;
    return '';
  }
  function wavInfo(bytes) {
    const b = bytesOf(bytes);
    if (fourcc(b, 0) !== 'RIFF' || fourcc(b, 8) !== 'WAVE') return null;
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    let fmt = null, dataSize = 0;
    for (let p = 12; p + 8 <= b.length;) {
      const id = fourcc(b, p);
      const size = dv.getUint32(p + 4, true);
      const body = p + 8;
      if (id === 'fmt ' && size >= 16 && body + 16 <= b.length) {
        fmt = {
          audioFormat: dv.getUint16(body, true),
          channels: dv.getUint16(body + 2, true),
          sampleRate: dv.getUint32(body + 4, true),
          byteRate: dv.getUint32(body + 8, true),
          blockAlign: dv.getUint16(body + 12, true),
          bitsPerSample: dv.getUint16(body + 14, true)
        };
      } else if (id === 'data') {
        dataSize = Math.min(size, Math.max(0, b.length - body));
      }
      p = body + size + (size % 2);
    }
    if (!fmt) return null;
    const byteRate = fmt.byteRate || (fmt.channels * fmt.sampleRate * Math.max(1, fmt.bitsPerSample) / 8);
    return {
      sampleRate: fmt.sampleRate,
      channels: fmt.channels,
      bitsPerSample: fmt.bitsPerSample,
      audioFormat: fmt.audioFormat,
      duration: byteRate > 0 ? dataSize / byteRate : 0
    };
  }
  function mediaHash(bytes) {
    let hash = 0;
    const step = Math.max(1, Math.floor(bytes.length / 4096));
    for (let i = 0; i < bytes.length; i += step) hash = ((hash * 31) | 0) + bytes[i];
    return (hash | 0).toString(36);
  }
  UE.Media = { format: mediaFormat, wavInfo: wavInfo, mime: function (format) { return MEDIA_MIME[format] || 'application/octet-stream'; } };

  const AssetStore = UE.AssetStore = {
    items: {},
    decoded: {},
    audioItems: {},
    audioDecoded: {},
    videoItems: {},
    videoDecoded: {},
    add: function (mesh, name, options) {
      options = options || {};
      if (!mesh) throw new Error('Mesh is empty');
      let source;
      if (Array.isArray(mesh.primitives) && mesh.primitives.length) {
        source = mesh.primitives;
      } else if (mesh.positions && mesh.indices) {
        source = [{
          positions: mesh.positions, normals: mesh.normals, uvs: mesh.uvs, indices: mesh.indices,
          material: mesh.material || (mesh.color ? { color: mesh.color } : null)
        }];
      } else {
        throw new Error('Mesh needs positions and indices');
      }

      let vertexCount = 0, triangleCount = 0;
      let hasTexture = false, color = null;
      const encoded = [];
      for (const src of source) {
        if (!src.positions || !src.positions.length) throw new Error('Mesh is empty');
        const pc = src.positions.length / 3;
        if (src.positions.length % 3) throw new Error('Mesh has an incomplete vertex');
        let indices = src.indices;
        if (!indices || !indices.length) {
          indices = [];
          for (let i = 0; i < pc; i++) indices.push(i);
        }
        if (indices.length % 3) throw new Error('Mesh has an incomplete triangle');
        for (let i = 0; i < indices.length; i++) {
          if (!Number.isFinite(indices[i]) || indices[i] < 0 || indices[i] >= pc) throw new Error('Mesh has an invalid triangle index');
        }
        vertexCount += pc;
        triangleCount += indices.length / 3;
        encoded.push(encodePrimitive({
          positions: src.positions, normals: src.normals, uvs: src.uvs, indices: indices, material: src.material || null
        }));
        if (src.material) {
          if (!color && src.material.color) color = src.material.color;
          if (src.material.texture && src.material.texture.bytes && src.material.texture.bytes.length) hasTexture = true;
        }
      }
      if (!vertexCount || !triangleCount) throw new Error('Mesh is empty');
      const limits = UE.MODEL_LIMITS || { maxVertices: 65535 * 99, maxTriangles: 80000 * 99 };
      if (vertexCount > limits.maxVertices) throw new Error('Mesh has ' + vertexCount.toLocaleString() + ' vertices; the import limit is ' + limits.maxVertices.toLocaleString());
      if (triangleCount > limits.maxTriangles) throw new Error('Mesh has ' + triangleCount.toLocaleString() + ' triangles; the import limit is ' + limits.maxTriangles.toLocaleString());

      const cleanName = String(name || mesh.name || 'Model');
      const textureChars = encoded.reduce(function (n, p) {
        return n + (p.material && p.material.texture ? p.material.texture.t.length : 0);
      }, 0);
      const signature = cleanName + '|' + vertexCount + '|' + triangleCount + '|' + textureChars;
      if (options.dedupe !== false) {
        for (const id of Object.keys(this.items)) {
          if (this.items[id].signature === signature) return id;
        }
      }
      const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      const bounds = mesh.bounds || primsBounds(source);
      this.items[id] = {
        id: id,
        name: cleanName,
        vertexCount: vertexCount,
        triangleCount: triangleCount,
        bounds: bounds,
        signature: signature,
        hasTexture: hasTexture,
        color: color,
        prims: encoded
      };
      return id;
    },
    has: function (id) { return !!this.items[id]; },
    get: function (id) {
      const a = this.items[id];
      if (!a) return null;
      let d = this.decoded[id];
      if (!d) {
        const prims = (a.prims || []).map(decodePrimitive);
        d = {
          prims: prims,
          bounds: a.bounds,
          triangles: a.triangleCount,
          vertexCount: a.vertexCount,
          color: a.color || null,
          hasTexture: !!a.hasTexture
        };
        if (prims.length === 1) {
          d.positions = prims[0].positions;
          d.normals = prims[0].normals;
          d.uvs = prims[0].uvs;
          d.indices = prims[0].indices;
          d.data = prims[0].data;
          d.material = prims[0].material;
        }
        this.decoded[id] = d;
      }
      return d;
    },
    meta: function (id) {
      const a = this.items[id];
      if (!a) return null;
      return {
        id: a.id, name: a.name, vertexCount: a.vertexCount, triangleCount: a.triangleCount,
        bounds: a.bounds, hasTexture: !!a.hasTexture, color: a.color || null,
        primitives: (a.prims || []).length
      };
    },
    list: function () { return Object.keys(this.items).map(id => this.meta(id)); },
    findByName: function (name) {
      for (const id of Object.keys(this.items)) if (this.items[id].name === name) return id;
      return null;
    },
    toJSON: function (ids) {
      const out = {};
      const wanted = ids ? new Set(ids) : null;
      for (const id of Object.keys(this.items)) {
        if (wanted && !wanted.has(id)) continue;
        out[id] = UE.clone(this.items[id]);
      }
      return out;
    },
    fromJSON: function (assets) {
      if (!assets || typeof assets !== 'object') return;
      for (const id of Object.keys(assets)) {
        const src = assets[id];
        if (!src) continue;
        let prims;
        if (Array.isArray(src.prims) && src.prims.length) {
          prims = src.prims.map(function (p) {
            return {
              p: p.p,
              n: p.n || encodeFloat32([]),
              u: p.u || null,
              i: p.i,
              indexType: p.indexType || 16,
              material: p.material || null
            };
          });
        } else if (src.p && src.i) {
          /* Older scenes stored one flat primitive per asset. */
          prims = [{
            p: src.p, n: src.n || encodeFloat32([]), u: null, i: src.i,
            indexType: src.indexType || (src.vertexCount > 65535 ? 32 : 16),
            material: src.color ? { color: src.color, texture: null } : null
          }];
        } else {
          continue;
        }
        this.items[id] = {
          id: id,
          name: src.name || 'Model',
          vertexCount: src.vertexCount || 0,
          triangleCount: src.triangleCount || 0,
          bounds: src.bounds || null,
          signature: src.signature || null,
          hasTexture: !!src.hasTexture || prims.some(function (p) { return !!(p.material && p.material.texture); }),
          color: src.color || null,
          prims: prims
        };
        delete this.decoded[id];
      }
    },

    /* ------------------------------------------------------------ media assets
     * Audio and video follow the mesh asset model: immutable bytes, base64 in
     * saved scenes, lazy in-memory decode, and dedupe by name + content hash. */
    addAudio: function (data, name, options) { return addMedia(this, 'audio', data, name, options); },
    addVideo: function (data, name, options) { return addMedia(this, 'video', data, name, options); },
    hasAudio: function (id) { return !!this.audioItems[id]; },
    hasVideo: function (id) { return !!this.videoItems[id]; },
    getAudio: function (id) { return decodeMedia(this, 'audio', id); },
    getVideo: function (id) { return decodeMedia(this, 'video', id); },
    audioMeta: function (id) { return mediaMeta(this, 'audio', id); },
    videoMeta: function (id) { return mediaMeta(this, 'video', id); },
    listAudio: function () { return listMedia(this, 'audio'); },
    listVideo: function () { return listMedia(this, 'video'); },
    findAudioByName: function (name) { return findMediaByName(this, 'audio', name); },
    findVideoByName: function (name) { return findMediaByName(this, 'video', name); },
    audioDataUrl: function (id) { return mediaDataUrl(this, 'audio', id); },
    videoDataUrl: function (id) { return mediaDataUrl(this, 'video', id); },
    toAudioJSON: function (ids) { return mediaToJSON(this, 'audio', ids); },
    toVideoJSON: function (ids) { return mediaToJSON(this, 'video', ids); },
    fromAudioJSON: function (assets) { mediaFromJSON(this, 'audio', assets); },
    fromVideoJSON: function (assets) { mediaFromJSON(this, 'video', assets); },
    clear: function () {
      this.items = {}; this.decoded = {};
      this.audioItems = {}; this.audioDecoded = {};
      this.videoItems = {}; this.videoDecoded = {};
    }
  };

  function mediaDataUrl(store, kind, id) {
    const a = kind === 'audio' ? store.audioItems[id] : store.videoItems[id];
    return a ? 'data:' + (a.mime || 'application/octet-stream') + ';base64,' + a.t : null;
  }
  function mediaMeta(store, kind, id) {
    const a = kind === 'audio' ? store.audioItems[id] : store.videoItems[id];
    if (!a) return null;
    return {
      id: a.id, name: a.name, format: a.format, mime: a.mime, size: a.size,
      duration: a.duration || 0, sampleRate: a.sampleRate || 0,
      channels: a.channels || 0, bitsPerSample: a.bitsPerSample || 0,
      width: a.width || 0, height: a.height || 0
    };
  }
  function listMedia(store, kind) {
    const ids = Object.keys(kind === 'audio' ? store.audioItems : store.videoItems);
    return ids.map(id => mediaMeta(store, kind, id));
  }
  function findMediaByName(store, kind, name) {
    const items = kind === 'audio' ? store.audioItems : store.videoItems;
    for (const id of Object.keys(items)) if (items[id].name === name) return id;
    return null;
  }
  function decodeMedia(store, kind, id) {
    const items = kind === 'audio' ? store.audioItems : store.videoItems;
    const cache = kind === 'audio' ? store.audioDecoded : store.videoDecoded;
    if (!items[id]) return null;
    if (!cache[id]) cache[id] = base64ToBytes(items[id].t);
    return cache[id];
  }
  function mediaToJSON(store, kind, ids) {
    const items = kind === 'audio' ? store.audioItems : store.videoItems;
    const out = {};
    const wanted = ids ? new Set(ids) : null;
    for (const id of Object.keys(items)) {
      if (wanted && !wanted.has(id)) continue;
      out[id] = UE.clone(items[id]);
    }
    return out;
  }
  function mediaFromJSON(store, kind, assets) {
    if (!assets || typeof assets !== 'object') return;
    const items = kind === 'audio' ? store.audioItems : store.videoItems;
    const cache = kind === 'audio' ? store.audioDecoded : store.videoDecoded;
    for (const id of Object.keys(assets)) {
      const src = assets[id];
      if (!src || !src.t) continue;
      const format = src.format || mediaFormat(base64ToBytes(src.t), src.name);
      items[id] = {
        id: id,
        name: src.name || 'Media',
        format: format,
        mime: src.mime || UE.Media.mime(format),
        signature: src.signature || null,
        size: src.size || 0,
        duration: src.duration || 0,
        sampleRate: src.sampleRate || 0,
        channels: src.channels || 0,
        bitsPerSample: src.bitsPerSample || 0,
        width: src.width || 0,
        height: src.height || 0,
        t: src.t
      };
      delete cache[id];
    }
  }
  function addMedia(store, kind, data, name, options) {
    options = options || {};
    const bytes = typeof data === 'string' && /^data:[^,]*;base64,/i.test(data)
      ? base64ToBytes(data.slice(data.indexOf(',') + 1))
      : bytesOf(data);
    if (!bytes.length) throw new Error(kind === 'audio' ? 'Audio file is empty' : 'Video file is empty');
    const cleanName = String(name || (kind === 'audio' ? 'Audio' : 'Video'));
    const format = options.format || mediaFormat(bytes, cleanName);
    const formats = kind === 'audio' ? UE.MEDIA_FORMATS.audio : UE.MEDIA_FORMATS.video;
    if (formats.indexOf(format) < 0) {
      throw new Error('Unsupported ' + kind + ' format: ' + (format || 'unknown'));
    }
    const signature = cleanName + '|' + format + '|' + bytes.length + '|' + mediaHash(bytes);
    const items = kind === 'audio' ? store.audioItems : store.videoItems;
    if (options.dedupe !== false) {
      for (const id of Object.keys(items)) if (items[id].signature === signature) return id;
    }
    const id = (kind === 'audio' ? 'a' : 'v') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const item = {
      id: id,
      name: cleanName,
      format: format,
      mime: options.mime || UE.Media.mime(format),
      signature: signature,
      size: bytes.length,
      duration: 0,
      sampleRate: 0,
      channels: 0,
      bitsPerSample: 0,
      width: 0,
      height: 0,
      t: bytesToBase64(bytes)
    };
    if (kind === 'audio' && format === 'wav') {
      const info = wavInfo(bytes);
      if (info) {
        item.duration = info.duration;
        item.sampleRate = info.sampleRate;
        item.channels = info.channels;
        item.bitsPerSample = info.bitsPerSample;
      }
    }
    if (options.duration) item.duration = +options.duration;
    if (options.width) item.width = +options.width;
    if (options.height) item.height = +options.height;
    items[id] = item;
    (kind === 'audio' ? store.audioDecoded : store.videoDecoded)[id] = bytes;
    return id;
  }

  /* -------------------------------------------------------------------- Scene */
  const DEFAULT_SUN = { azimuth: 38, elevation: 54, color: '#ffe9c4', intensity: 1.05, ambient: 0.34 };
  const DEFAULT_SKY = { top: '#182231', bottom: '#080a0e' };

  class Scene {
    constructor(name) {
      this.name = name || 'Untitled';
      this.objects = [];
      this.sun = UE.clone(DEFAULT_SUN);
      this.sky = UE.clone(DEFAULT_SKY);
    }
    add(object, parent) {
      if (!object) return null;
      if (object.scene && object.scene !== this) object.scene.remove(object);
      if (!this.objects.includes(object)) this.objects.push(object);
      object.scene = this;
      if (parent) object.setParent(parent);
      return object;
    }
    remove(object) {
      if (!object) return;
      for (const child of object.transform.children.slice()) this.remove(child.object);
      const i = this.objects.indexOf(object);
      if (i >= 0) this.objects.splice(i, 1);
      if (object.transform.parent) {
        const siblings = object.transform.parent.transform.children;
        const j = siblings.indexOf(object.transform);
        if (j >= 0) siblings.splice(j, 1);
      }
      object.transform.parent = null;
      object.scene = null;
    }
    roots() { return this.objects.filter(o => !o.transform.parent); }
    get(id) { return this.objects.find(o => o.id === id) || null; }
    find(name) { return this.objects.find(o => o.name === name) || null; }
    findByTag(tag) { return this.objects.find(o => o.tag === tag) || null; }
    findAllByTag(tag) { return this.objects.filter(o => o.tag === tag); }
    mainCamera() {
      for (const o of this.objects) {
        if (!o.active) continue;
        const c = o.getComponent('Camera');
        if (c && c.main) return o;
      }
      return null;
    }
    clear() {
      for (const o of this.objects.slice()) o.scene = null;
      this.objects.length = 0;
    }
    toJSON(options) {
      const includeAssets = !(options === false || (options && options.assets === false));
      const out = {
        format: 'unirealengine.scene',
        version: 2,
        name: this.name,
        sun: UE.clone(this.sun),
        sky: UE.clone(this.sky),
        objects: this.objects.map(o => o.toJSON())
      };
      if (includeAssets) {
        const ids = [], audioIds = [], videoIds = [];
        for (const object of this.objects) {
          const mr = object.getComponent('MeshRenderer');
          if (mr && mr.meshId && !ids.includes(mr.meshId)) ids.push(mr.meshId);
          const audio = object.getComponent('AudioSource');
          if (audio && audio.clipId && !audioIds.includes(audio.clipId)) audioIds.push(audio.clipId);
          const video = object.getComponent('VideoPlayer');
          if (video && video.clipId && !videoIds.includes(video.clipId)) videoIds.push(video.clipId);
        }
        const assets = UE.AssetStore.toJSON(ids);
        if (Object.keys(assets).length) out.assets = assets;
        const audioAssets = UE.AssetStore.toAudioJSON(audioIds);
        if (Object.keys(audioAssets).length) out.audioAssets = audioAssets;
        const videoAssets = UE.AssetStore.toVideoJSON(videoIds);
        if (Object.keys(videoAssets).length) out.videoAssets = videoAssets;
      }
      return out;
    }
    clone() { return Scene.fromJSON(this.toJSON()); }
    static fromJSON(data) {
      if (!data || !Array.isArray(data.objects)) throw new Error('Not a UnirealEngine scene file');
      if (data.assets) UE.AssetStore.fromJSON(data.assets);
      if (data.audioAssets) UE.AssetStore.fromAudioJSON(data.audioAssets);
      if (data.videoAssets) UE.AssetStore.fromVideoJSON(data.videoAssets);
      const scene = new Scene(data.name || 'Untitled');
      if (data.sun) scene.sun = Object.assign(UE.clone(DEFAULT_SUN), data.sun);
      if (data.sky) scene.sky = Object.assign(UE.clone(DEFAULT_SKY), data.sky);
      const map = new Map();
      const objects = data.objects || [];
      for (const src of objects) {
        const go = new GameObject(src.name || 'GameObject');
        if (src.id) go.id = src.id;
        go.active = src.active !== false;
        go.tag = src.tag || 'Untagged';
        const t = src.transform || {};
        if (t.position) go.transform.position = { x: +t.position.x || 0, y: +t.position.y || 0, z: +t.position.z || 0 };
        if (t.rotation) go.transform.rotation = { x: +t.rotation.x || 0, y: +t.rotation.y || 0, z: +t.rotation.z || 0 };
        if (t.scale) go.transform.scale = { x: t.scale.x === undefined ? 1 : +t.scale.x, y: t.scale.y === undefined ? 1 : +t.scale.y, z: t.scale.z === undefined ? 1 : +t.scale.z };
        for (const c of src.components || []) {
          try { go.addComponent(c.type, c.props); }
          catch (err) { UE.log('warn', 'Skipped component ' + c.type + ' on ' + go.name + ': ' + err.message); }
        }
        scene.add(go);
        map.set(go.id, go);
      }
      for (const src of objects) {
        if (!src.parentId) continue;
        const child = map.get(src.id), parent = map.get(src.parentId);
        if (child && parent) child.setParent(parent);
      }
      return scene;
    }
  }
  UE.Scene = Scene;

  /* ------------------------------------------------------------ primitive info */
  UE.primitiveSize = function (primitive) {
    if (primitive === 'plane') return { x: 10, y: 0.1, z: 10 };
    return { x: 1, y: 1, z: 1 };
  };
  UE.primitiveLabel = function (primitive) {
    return ({ cube: 'Cube', sphere: 'Sphere', cylinder: 'Cylinder', cone: 'Cone', plane: 'Plane', model: 'Model' })[primitive] || 'Mesh';
  };
  UE.PRIMITIVES = ['cube', 'sphere', 'cylinder', 'cone', 'plane'];

  /* ------------------------------------------------------------------- tags */
  /* Tags are plain, case-sensitive strings. This small helper keeps the editor
     popup, hierarchy filter and tests working from one definition. */
  UE.Tags = {
    BUILT_IN: ['Untagged', 'Player', 'Enemy', 'Pickup', 'Light'],
    MAX_LENGTH: 64,
    normalize: function (value) {
      const text = String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim();
      return text ? text.slice(0, this.MAX_LENGTH) : 'Untagged';
    },
    list: function (scene, extra) {
      const out = [], seen = new Set();
      const add = function (tag) {
        const value = UE.Tags.normalize(tag);
        if (!seen.has(value)) { seen.add(value); out.push(value); }
      };
      for (const tag of this.BUILT_IN) add(tag);
      if (scene && scene.objects) for (const object of scene.objects) add(object.tag);
      if (extra) for (const tag of extra) add(tag);
      return out;
    },
    counts: function (scene) {
      const out = {};
      for (const tag of this.BUILT_IN) out[tag] = 0;
      if (scene && scene.objects) {
        for (const object of scene.objects) {
          const tag = this.normalize(object.tag);
          out[tag] = (out[tag] || 0) + 1;
        }
      }
      return out;
    }
  };

  /* World-space AABB of an imported mesh, using the asset's local bounds. */
  UE.objectMeshBounds = function (object) {
    const mr = object && object.getComponent ? object.getComponent('MeshRenderer') : null;
    if (!mr || !mr.meshId) return null;
    const asset = UE.AssetStore.get(mr.meshId);
    if (!asset) return null;
    let bounds = asset.bounds;
    if (!bounds) {
      const p = asset.positions;
      let min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < p.length; i += 3) {
        for (let k = 0; k < 3; k++) {
          if (p[i + k] < min[k]) min[k] = p[i + k];
          if (p[i + k] > max[k]) max[k] = p[i + k];
        }
      }
      bounds = { min: min, max: max };
    }
    const m = object.transform.worldMatrix();
    const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < 8; i++) {
      const local = {
        x: (i & 1) ? bounds.max[0] : bounds.min[0],
        y: (i & 2) ? bounds.max[1] : bounds.min[1],
        z: (i & 4) ? bounds.max[2] : bounds.min[2]
      };
      const w = UE.Mat4.transformPoint(m, local);
      lo[0] = Math.min(lo[0], w.x); lo[1] = Math.min(lo[1], w.y); lo[2] = Math.min(lo[2], w.z);
      hi[0] = Math.max(hi[0], w.x); hi[1] = Math.max(hi[1], w.y); hi[2] = Math.max(hi[2], w.z);
    }
    return {
      cx: (lo[0] + hi[0]) / 2, cy: (lo[1] + hi[1]) / 2, cz: (lo[2] + hi[2]) / 2,
      hx: Math.max(0.01, (hi[0] - lo[0]) / 2),
      hy: Math.max(0.01, (hi[1] - lo[1]) / 2),
      hz: Math.max(0.01, (hi[2] - lo[2]) / 2)
    };
  };

  /* ------------------------------------------------------------------ physics */
  const Physics = UE.Physics = {
    gravity: -9.81,
    /* World-space AABB of an object's collider. Rotation is intentionally ignored:
       the solver is a fast, stable AABB solver, not a full 3D rigid-body engine. */
    bounds: function (object) {
      const c = object.getComponent('Collider');
      if (!c) return null;
      const p = object.transform.worldPosition();
      const s = object.transform.worldScale();
      if (c.shape === 'sphere') {
        const r = Math.max(0.02, Math.abs(c.size.x) * Math.abs(s.x) * 0.5);
        return { cx: p.x + c.center.x * s.x, cy: p.y + c.center.y * s.y, cz: p.z + c.center.z * s.z, hx: r, hy: r, hz: r };
      }
      return {
        cx: p.x + c.center.x * s.x,
        cy: p.y + c.center.y * s.y,
        cz: p.z + c.center.z * s.z,
        hx: Math.max(0.01, Math.abs(c.size.x) * Math.abs(s.x)) / 2,
        hy: Math.max(0.01, Math.abs(c.size.y) * Math.abs(s.y)) / 2,
        hz: Math.max(0.01, Math.abs(c.size.z) * Math.abs(s.z)) / 2
      };
    },
    defaultFriction: 0.6,
    step: function (scene, dt) {
      const bodies = [], statics = [], contacts = new Set();
      for (const object of scene.objects) {
        if (!object.active) continue;
        const collider = object.getComponent('Collider');
        if (!collider) continue;
        const b = this.bounds(object);
        if (!b) continue;
        const rb = object.getComponent('Rigidbody');
        b.object = object;
        b.rb = rb;
        b.collider = collider;
        if (rb && !rb.isKinematic) bodies.push(b);
        else statics.push(b);
      }

      /* Integrate linear motion. Unity-style constraints freeze an axis even
         when another body pushes against it. */
      for (const b of bodies) {
        const rb = b.rb;
        const freeze = rb.freezePosition || {};
        const gravityScale = Number.isFinite(rb.gravityScale) ? rb.gravityScale : 1;
        if (rb.useGravity && !freeze.y) rb.velocity.y += this.gravity * gravityScale * dt;
        const damp = 1 / (1 + Math.max(0, rb.drag) * dt);
        const t = b.object.transform;
        for (const axis of ['x', 'y', 'z']) {
          if (freeze[axis]) { rb.velocity[axis] = 0; continue; }
          rb.velocity[axis] *= damp;
          t.position[axis] += rb.velocity[axis] * dt;
          b['c' + axis] += rb.velocity[axis] * dt;
        }
      }

      /* Resolve contacts in a few passes. The extra passes matter for stacks:
         pushing a lower box down into the ground is corrected again in the next
         pass, which walks the separation up the stack instead of leaving the
         boxes interpenetrating. Trigger colliders still report pairs so
         PlayMaker trigger components can fire, but are never pushed apart. */
      for (let iteration = 0; iteration < 3; iteration++) {
        /* dynamic vs static */
        for (const b of bodies) {
          for (const s of statics) {
            if (!UE.AABB.overlaps(b, s)) continue;
            const pair = b.object.id < s.object.id ? b.object.id + '|' + s.object.id : s.object.id + '|' + b.object.id;
            contacts.add(pair);
            if (b.collider.isTrigger || s.collider.isTrigger) continue;
            const sep = UE.AABB.separation(b, s);
            if (sep) this._resolve(b, s, sep);
          }
          /* infinite ground plane at y = 0 */
          if (!b.collider.isTrigger && b.cy - b.hy < 0) {
            this._resolve(b, null, { axis: 'y', pen: -(b.cy - b.hy), sign: 1 });
          }
        }

        /* dynamic vs dynamic */
        for (let i = 0; i < bodies.length; i++) {
          for (let j = i + 1; j < bodies.length; j++) {
            const a = bodies[i], b = bodies[j];
            if (!UE.AABB.overlaps(a, b)) continue;
            const pair = a.object.id < b.object.id ? a.object.id + '|' + b.object.id : b.object.id + '|' + a.object.id;
            contacts.add(pair);
            if (a.collider.isTrigger || b.collider.isTrigger) continue;
            const sep = UE.AABB.separation(a, b);
            if (sep) this._resolve(a, b, sep);
          }
        }
      }

      /* settle micro-jitter (trigger bodies keep their motion) */
      for (const b of bodies) {
        if (b.collider.isTrigger) continue;
        const v = b.rb.velocity;
        if (Math.abs(v.x) < 0.02) v.x = 0;
        if (Math.abs(v.z) < 0.02) v.z = 0;
        if (b.cy - b.hy <= 0.002 && Math.abs(v.y) < 0.25) v.y = 0;
      }

      /* PlayMaker trigger components listen for enter/exit pairs. */
      if (UE.PlayMaker && UE.PlayMaker.handleContacts) UE.PlayMaker.handleContacts(scene, contacts);
    },
    /* Kinematic and static bodies have infinite mass. Frozen axes also do not
       receive impulses, matching the visible Unity Rigidbody constraints. */
    _inverseMass: function (body, axis) {
      if (!body || !body.rb || body.rb.isKinematic) return 0;
      if (body.rb.freezePosition && body.rb.freezePosition[axis]) return 0;
      return 1 / Math.max(0.01, Math.abs(body.rb.mass) || 1);
    },
    _friction: function (a, b) {
      const ca = a && a.collider, cb = b && b.collider;
      const fa = ca && Number.isFinite(ca.friction) ? ca.friction : this.defaultFriction;
      const fb = b ? (cb && Number.isFinite(cb.friction) ? cb.friction : this.defaultFriction) : fa;
      return Math.max(0, Math.min(1, (fa + fb) / 2));
    },
    /* Mass-weighted impulse + positional correction. `b` is null for the
       infinite ground plane and may be a kinematic/static body otherwise. */
    _resolve: function (a, b, sep) {
      const axis = sep.axis, sign = sep.sign;
      const invA = this._inverseMass(a, axis);
      const invB = this._inverseMass(b, axis);
      const total = invA + invB;
      if (total <= 0) return;
      const pen = Math.max(0, sep.pen);
      const moveA = sign * pen * (invA / total);
      const moveB = sign * pen * (invB / total);
      if (moveA) {
        a.object.transform.position[axis] += moveA;
        a['c' + axis] += moveA;
      }
      if (b && moveB) {
        b.object.transform.position[axis] -= moveB;
        b['c' + axis] -= moveB;
      }
      if (!a.rb) return;
      const va = a.rb.velocity[axis];
      const vb = b && b.rb ? b.rb.velocity[axis] : 0;
      const rel = (va - vb) * sign;
      if (rel < 0) {
        const e = Math.max(Number(a.rb.restitution) || 0, b && b.rb ? Number(b.rb.restitution) || 0 : 0);
        const impulse = -(1 + e) * rel / total;
        a.rb.velocity[axis] += impulse * invA * sign;
        if (b && b.rb) b.rb.velocity[axis] -= impulse * invB * sign;
        /* Coulomb-style tangential damping. The 0.5 factor keeps the
           correction stable across the three solver passes. */
        const mu = this._friction(a, b) * 0.5;
        const tangential = axis === 'x' ? ['y', 'z'] : axis === 'y' ? ['x', 'z'] : ['x', 'y'];
        for (const k of tangential) {
          const relative = a.rb.velocity[k] - (b && b.rb ? b.rb.velocity[k] : 0);
          if (!relative) continue;
          const tangentImpulse = -relative * mu / total;
          a.rb.velocity[k] += tangentImpulse * invA;
          if (b && b.rb) b.rb.velocity[k] -= tangentImpulse * invB;
        }
      }
      const staticPartner = !b || !b.rb || b.rb.isKinematic;
      if (axis === 'y' && sign > 0 && staticPartner && Math.abs(a.rb.velocity.y) < 0.9) a.rb.velocity.y = 0;
    },
    /* Used by the editor to let a scripted/physics body sit on a surface without sinking. */
    raycastDown: function (scene, origin, maxDist) {
      const ray = { origin: origin, dir: { x: 0, y: -1, z: 0 } };
      let best = null;
      for (const object of scene.objects) {
        const b = this.bounds(object);
        if (!b) continue;
        const t = UE.Ray.intersectAABB(ray.origin, ray.dir, b);
        if (t !== null && t >= 0 && t <= maxDist && (best === null || t < best.t)) best = { t: t, object: object };
      }
      return best;
    }
  };

  /* ------------------------------------------------------------- script system */
  const ScriptSystem = UE.ScriptSystem = {
    update: function (scene, dt, time) {
      for (const object of scene.objects) {
        if (!object.active) continue;
        for (const component of object.components) {
          if (component instanceof Script) component.run(dt, time, scene);
        }
      }
    }
  };

  /* ------------------------------------------------------------ scene helpers */
  UE.createPrimitive = function (name, primitive, color, position, parent) {
    const go = new GameObject(name || UE.primitiveLabel(primitive));
    go.transform.position = V3.create(position ? position.x : 0, position ? position.y : 0, position ? position.z : 0);
    go.addComponent('MeshRenderer', {
      primitive: primitive,
      color: color || '#c9ced8'
    });
    go.addComponent('Collider', {
      shape: primitive === 'sphere' ? 'sphere' : 'box',
      size: UE.primitiveSize(primitive)
    });
    if (parent) go.setParent(parent);
    return go;
  };

  UE.createEmpty = function (name, position) {
    const go = new GameObject(name || 'GameObject');
    if (position) go.transform.position = V3.clone(position);
    return go;
  };

  UE.createCamera = function (name, position, rotation) {
    const go = new GameObject(name || 'Main Camera');
    if (position) go.transform.position = V3.clone(position);
    if (rotation) go.transform.rotation = V3.clone(rotation);
    go.addComponent('Camera', { fov: 60, near: 0.1, far: 250, main: true });
    return go;
  };

  /* Build the same view object the editor uses, from any Camera component.
     Used by the Game view and by the picture-in-picture second camera. */
  UE.cameraView = function (object, aspect, overrides) {
    if (!object) return null;
    const cam = object.getComponent('Camera');
    if (!cam) return null;
    overrides = overrides || {};
    const eye = overrides.eye || object.transform.worldPosition();
    const forward = overrides.forward || object.transform.forward();
    const up = overrides.up || object.transform.up();
    const fov = Number(overrides.fov) || cam.fov || 60;
    const near = overrides.near === undefined ? (cam.near || 0.1) : overrides.near;
    const far = overrides.far === undefined ? (cam.far || 250) : overrides.far;
    aspect = Number(aspect) > 0 ? Number(aspect) : 16 / 9;
    const view = UE.Mat4.lookAt(eye, V3.add(eye, forward), up);
    const proj = UE.Mat4.perspective(fov, aspect, near, far);
    return {
      eye: eye, forward: forward, up: up, fov: fov, near: near, far: far,
      aspect: aspect, width: overrides.width || 0, height: overrides.height || 0,
      viewProj: UE.Mat4.multiply(proj, view)
    };
  };

  UE.createModel = function (name, meshId, position, color) {
    const meta = UE.AssetStore.meta(meshId);
    const go = new GameObject(name || (meta ? meta.name : 'Model'));
    if (position) go.transform.position = V3.clone(position);
    go.addComponent('MeshRenderer', {
      primitive: 'model',
      meshId: meshId,
      meshName: meta ? meta.name : '',
      color: color || '#b9c6d8'
    });
    if (meta && meta.bounds) {
      const b = meta.bounds;
      const size = { x: b.max[0] - b.min[0], y: b.max[1] - b.min[1], z: b.max[2] - b.min[2] };
      go.addComponent('Collider', {
        shape: 'box',
        size: { x: Math.max(0.05, size.x), y: Math.max(0.05, size.y), z: Math.max(0.05, size.z) },
        center: { x: (b.min[0] + b.max[0]) / 2, y: (b.min[1] + b.max[1]) / 2, z: (b.min[2] + b.max[2]) / 2 }
      });
    }
    return go;
  };

  UE.createLight = function (name, type, position, rotation, props) {
    type = type || 'point';
    const labels = { sun: 'Sun Light', directional: 'Directional Light', spot: 'Spot Light', point: 'Point Light' };
    const go = new GameObject(name || labels[type] || 'Light');
    if (position) go.transform.position = V3.clone(position);
    if (rotation) go.transform.rotation = V3.clone(rotation);
    const defaults = {
      sun: { type: 'sun', color: '#ffe2b0', intensity: 1.7, castShadow: true },
      directional: { type: 'directional', color: '#fff3d6', intensity: 1.0, castShadow: true },
      point: { type: 'point', color: '#ffd3a1', intensity: 2.6, range: 9 },
      spot: { type: 'spot', color: '#ffd9a0', intensity: 3.4, range: 14, spotAngle: 46, innerAngle: 22 }
    };
    const light = go.addComponent('Light', defaults[type] || defaults.point);
    if (props) light.applyJSON(props);
    return go;
  };

  return UE;
});
