/* UnirealEngine — network.js
 * Browser-only multiplayer for NetworkObject components.
 *
 * Transport is BroadcastChannel when the browser exposes it, with a
 * localStorage/storage-event fallback for tabs in the same browser. There is
 * no server, no socket library and no database. The manager serializes plain
 * JSON snapshots (transform, mesh, tag, active state and ownership), so the
 * same code also runs with an in-memory bus in the browser test suite. */
(function (root, factory) {
  factory(root.UE);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (UE) {
  'use strict';

  const V3 = UE.V3;
  const PROTOCOL = 'unirealengine.network.v1';
  const DEFAULT_ROOM = 'lobby';
  const HEARTBEAT_MS = 500;
  const PEER_TIMEOUT_MS = 2800;

  function clone(value) {
    if (value === undefined) return undefined;
    return JSON.parse(JSON.stringify(value));
  }
  function stamp() { return Date.now(); }
  function shortId() {
    return Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 6);
  }
  function sanitizeRoom(value) {
    const text = String(value === undefined || value === null ? '' : value)
      .replace(/[^a-z0-9_.-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 48);
    return text || DEFAULT_ROOM;
  }
  function safeNumber(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }
  function vec(value, fallback) {
    return {
      x: value && Number.isFinite(Number(value.x)) ? Number(value.x) : fallback.x,
      y: value && Number.isFinite(Number(value.y)) ? Number(value.y) : fallback.y,
      z: value && Number.isFinite(Number(value.z)) ? Number(value.z) : fallback.z
    };
  }
  function lerpVec(from, to, t) {
    from.x += (to.x - from.x) * t;
    from.y += (to.y - from.y) * t;
    from.z += (to.z - from.z) * t;
    return from;
  }
  function copyVec(target, source) { target.x = source.x; target.y = source.y; target.z = source.z; return target; }
  function closeEnough(a, b, epsilon) {
    return Math.abs(a.x - b.x) < epsilon && Math.abs(a.y - b.y) < epsilon && Math.abs(a.z - b.z) < epsilon;
  }

  /* --------------------------------------------------------------- transports */
  function browserTransport(name) {
    const channelName = 'unirealengine.network.' + name;
    const transport = { kind: 'none', onmessage: null, closed: false };

    if (typeof BroadcastChannel === 'function') {
      try {
        const channel = new BroadcastChannel(channelName);
        transport.kind = 'broadcast';
        transport.channel = channel;
        transport.post = function (message) {
          if (transport.closed) return;
          try { channel.postMessage(message); } catch (err) { transport.lastError = err.message; }
        };
        transport.close = function () {
          if (transport.closed) return;
          transport.closed = true;
          try { channel.close(); } catch (err) { /* already closed */ }
        };
        channel.onmessage = function (event) {
          if (!transport.closed && typeof transport.onmessage === 'function') transport.onmessage(event.data);
        };
        return transport;
      } catch (err) {
        transport.lastError = err.message;
      }
    }

    /* Same-browser fallback: other tabs see the storage event. */
    if (typeof window !== 'undefined' && window.localStorage) {
      const key = channelName + '.message';
      const handler = function (event) {
        if (event.key !== key || !event.newValue) return;
        try {
          const payload = JSON.parse(event.newValue);
          if (payload && payload.message && typeof transport.onmessage === 'function') transport.onmessage(payload.message);
        } catch (err) { /* ignore malformed values */ }
      };
      window.addEventListener('storage', handler);
      transport.kind = 'storage';
      transport.post = function (message) {
        if (transport.closed) return;
        try {
          window.localStorage.setItem(key, JSON.stringify({ nonce: shortId(), message: message }));
        } catch (err) { transport.lastError = err.message; }
      };
      transport.close = function () {
        if (transport.closed) return;
        transport.closed = true;
        window.removeEventListener('storage', handler);
      };
      return transport;
    }

    transport.post = function () { };
    transport.close = function () { transport.closed = true; };
    return transport;
  }

  /* Deterministic in-memory bus used by the test suite and by tools that want
     to inspect messages without a real browser channel. */
  function memoryBus() {
    const bus = {
      channels: Object.create(null),
      flush: function () {
        let guard = 0;
        let delivered = 0;
        do {
          delivered = 0;
          for (const name of Object.keys(bus.channels)) {
            const channel = bus.channels[name];
            let turns = 0;
            while (channel.queue.length && turns++ < 4000) {
              const item = channel.queue.shift();
              delivered++;
              if (item.sink.closed) continue;
              try {
                if (typeof item.sink.onmessage === 'function') item.sink.onmessage(item.message);
              } catch (err) {
                item.sink.lastError = err && err.message ? err.message : String(err);
              }
            }
          }
          guard += delivered;
        } while (delivered && guard < 100000);
        return guard;
      }
    };
    bus.channel = function (name) {
      const channel = bus.channels[name] || (bus.channels[name] = { sinks: [], queue: [] });
      const sink = {
        name: name,
        closed: false,
        onmessage: null,
        lastError: '',
        post: function (message) {
          if (sink.closed) return;
          const data = clone(message);
          for (const target of channel.sinks.slice()) {
            if (target !== sink && !target.closed) channel.queue.push({ sink: target, message: data });
          }
        },
        close: function () {
          sink.closed = true;
          const index = channel.sinks.indexOf(sink);
          if (index >= 0) channel.sinks.splice(index, 1);
        }
      };
      channel.sinks.push(sink);
      return sink;
    };
    bus.close = function () {
      for (const name of Object.keys(bus.channels)) {
        const channel = bus.channels[name];
        channel.sinks.forEach(function (sink) { sink.closed = true; });
        channel.sinks.length = 0;
        channel.queue.length = 0;
      }
    };
    return bus;
  }

  /* ------------------------------------------------------------------ manager */
  class NetworkManager {
    constructor(options) {
      options = options || {};
      this.peerId = options.peerId || ('peer-' + shortId());
      this.peerName = options.peerName || options.name || 'Player';
      this.scene = null;
      this.active = false;
      this.playing = false;
      this.room = DEFAULT_ROOM;
      this.isHost = false;
      this.hostId = '';
      this.peers = Object.create(null);
      this._transport = null;
      this._transportFactory = options.transportFactory || (options.bus
        ? function (room) { return options.bus.channel('unirealengine.network.' + room); }
        : browserTransport);
      this._onChange = typeof options.onChange === 'function' ? options.onChange : null;
      this._onLog = typeof options.onLog === 'function' ? options.onLog : null;
      this._lastHeartbeat = 0;
      this._sent = 0;
      this._received = 0;
      this.lastError = '';
    }

    _log(level, message) {
      if (this._onLog) this._onLog(level, message);
      else if (level === 'error') UE.log('error', message);
    }
    configure(options) {
      options = options || {};
      if (options.onChange !== undefined) this._onChange = typeof options.onChange === 'function' ? options.onChange : null;
      if (options.onLog !== undefined) this._onLog = typeof options.onLog === 'function' ? options.onLog : null;
      if (options.peerName) this.peerName = String(options.peerName).slice(0, 32);
      this._emit();
      return this;
    }
    _emit() {
      if (this._onChange) {
        try { this._onChange(this.status()); }
        catch (err) { this._log('error', 'Network panel update failed: ' + err.message); }
      }
    }
    notify() { this._emit(); }

    /* Bind the manager to a scene. Runtime owners are cleared, while stable
       network ids survive on the components and in the scene JSON. */
    attachScene(scene) {
      if (!scene) return;
      if (this.scene !== scene) {
        this.scene = scene;
        this._resetRuntime();
      }
      this.scan();
      this._emit();
    }
    scan() {
      if (!this.scene) return [];
      const found = [];
      for (const object of this.scene.objects) {
        const comp = object.getComponent('NetworkObject');
        if (!comp) continue;
        comp.ensureId();
        comp.sendRate = Math.max(1, Math.min(60, safeNumber(comp.sendRate, 15)));
        comp.interpolation = Math.max(0, Math.min(60, safeNumber(comp.interpolation, 12)));
        if (this.isHost && !comp.owner) comp.owner = this.peerId;
        found.push({ object: object, component: comp });
      }
      return found;
    }
    _resetRuntime() {
      if (!this.scene) return;
      for (const object of this.scene.objects) {
        const comp = object.getComponent('NetworkObject');
        if (comp) comp.resetRuntime();
      }
    }

    host(room) { return this._start(room, true); }
    join(room) { return this._start(room, false); }

    _start(room, host) {
      const wasPlaying = this.playing;
      this.leave(false);
      this.room = sanitizeRoom(room || this.room || DEFAULT_ROOM);
      this.active = true;
      this.playing = wasPlaying;
      this.isHost = !!host;
      this.hostId = host ? this.peerId : '';
      this.peers = Object.create(null);
      this.peers[this.peerId] = {
        id: this.peerId, name: this.peerName, isHost: !!host, self: true, lastSeen: stamp()
      };
      try {
        this._transport = this._transportFactory(this.room);
      } catch (err) {
        this.active = false;
        this._transport = null;
        this.lastError = err.message;
        this._log('error', 'Could not open the network room: ' + err.message);
        this._emit();
        return false;
      }
      const manager = this;
      this._transport.onmessage = function (message) { manager._receive(message); };
      this._lastHeartbeat = 0;
      this.scan();
      this._send({
        type: host ? 'hostInfo' : 'discover', isHost: !!host,
        hostId: this.isHost ? this.peerId : '', peers: this._peerSummary()
      });
      if (this.isHost) {
        this._send({ type: 'hello', isHost: true, hostId: this.peerId });
        this._announceAll();
      }
      this._log('info', (host ? 'Hosting' : 'Joining') + ' network room "' + this.room + '" as ' + this.peerName +
        ' (transport: ' + (this._transport.kind || 'custom') + ')');
      this._emit();
      return true;
    }

    leave(notify) {
      if (this.active && this._transport) {
        try { this._send({ type: 'bye' }); } catch (err) { /* closing anyway */ }
      }
      if (this._transport) {
        try { this._transport.close(); } catch (err) { /* already closed */ }
      }
      this._transport = null;
      const wasActive = this.active;
      this.active = false;
      this.playing = false;
      this.isHost = false;
      this.hostId = '';
      this.peers = Object.create(null);
      this._resetRuntime();
      if (notify !== false) {
        if (wasActive) this._log('info', 'Left network room "' + this.room + '"');
        this._emit();
      }
      return true;
    }

    setPlaying(playing) {
      const next = !!playing;
      if (this.playing === next) return;
      this.playing = next;
      if (next && this.active) {
        /* A client may have joined the room before pressing Play, so its first
           spawn announcements were ignored. Ask the host for a fresh snapshot. */
        if (!this.isHost) this._send({ type: 'discover', isHost: false, hostId: this.hostId || '' });
        this._announceAll();
        this._log('info', 'Network replication is running for room "' + this.room + '"');
      }
      this._emit();
    }

    _send(message) {
      if (!this.active || !this._transport) return false;
      const payload = Object.assign({}, message, {
        protocol: PROTOCOL,
        from: this.peerId,
        fromName: this.peerName,
        hostId: this.hostId || '',
        at: stamp()
      });
      try {
        this._transport.post(payload);
        this._sent++;
        return true;
      } catch (err) {
        this.lastError = err.message;
        this._log('warn', 'Network send failed: ' + err.message);
        return false;
      }
    }

    _peerSummary() {
      return Object.keys(this.peers).map((id) => {
        const peer = this.peers[id];
        return { id: id, name: peer.name, isHost: !!peer.isHost, self: id === this.peerId };
      });
    }

    _touch(id, name, isHost) {
      if (!id || id === this.peerId) return null;
      const peer = this.peers[id] || (this.peers[id] = {
        id: id, name: name || id, isHost: false, self: false, lastSeen: 0
      });
      peer.lastSeen = stamp();
      if (name) peer.name = name;
      if (isHost) peer.isHost = true;
      return peer;
    }

    _receive(message) {
      if (!this.active || !message || message.protocol !== PROTOCOL) return;
      if (message.from === this.peerId) return;
      this._received++;
      this._touch(message.from, message.fromName, !!message.isHost);
      if (message.isHost && !this.hostId) this.hostId = message.from;
      if (message.hostId && !this.hostId) this.hostId = message.hostId;

      switch (message.type) {
        case 'hello':
          if (this.isHost) {
            this._send({ type: 'hostInfo', isHost: true, hostId: this.peerId, peers: this._peerSummary() });
          }
          break;
        case 'discover':
          if (this.isHost) {
            this._send({ type: 'hostInfo', isHost: true, hostId: this.peerId, peers: this._peerSummary() });
            this._announceAll();
          }
          break;
        case 'hostInfo':
          if (message.hostId) this.hostId = message.hostId;
          if (this.hostId && this.peers[this.hostId]) this.peers[this.hostId].isHost = true;
          this._emit();
          break;
        case 'state':
          if (this.playing) this._applyState(message.object);
          break;
        case 'spawn':
          if (this.playing && message.object) this._instantiate(message.object);
          break;
        case 'despawn':
          if (this.playing && message.object) this._removeRemote(message.object);
          break;
        case 'owner':
          this._applyOwner(message);
          break;
        case 'event':
          this._receiveEvent(message);
          break;
        case 'bye':
          if (this.peers[message.from]) delete this.peers[message.from];
          if (this.hostId === message.from) {
            this.hostId = '';
            this._log('warn', 'The network host left room "' + this.room + '".');
          }
          this._emit();
          break;
        default:
          break;
      }
      this._emit();
    }

    _maintain(nowMs) {
      if (!this.active) return;
      if (nowMs - this._lastHeartbeat >= HEARTBEAT_MS) {
        this._lastHeartbeat = nowMs;
        this._send({ type: 'hello', isHost: this.isHost, hostId: this.hostId || '' });
      }
      let removed = false;
      for (const id of Object.keys(this.peers)) {
        if (id === this.peerId) continue;
        const peer = this.peers[id];
        if (nowMs - (peer.lastSeen || 0) > PEER_TIMEOUT_MS) {
          delete this.peers[id];
          removed = true;
          if (this.hostId === id) {
            this.hostId = '';
            this._log('warn', 'Network peer ' + id + ' timed out.');
          }
        }
      }
      if (removed) this._emit();
    }

    update(dt) {
      if (!this.active) return;
      const step = Math.max(0, Math.min(0.25, safeNumber(dt, 0)));
      this._maintain(stamp());
      if (!this.playing || !this.scene) return;
      for (const object of this.scene.objects) {
        const comp = object.getComponent('NetworkObject');
        if (!comp) continue;
        if (!this._owns(comp)) {
          this._interpolate(object, comp, step);
          continue;
        }
        comp._netClock = (comp._netClock || 0) + step;
        const rate = Math.max(1, Math.min(60, safeNumber(comp.sendRate, 15)));
        if (comp._netClock >= 1 / rate) {
          comp._netClock = 0;
          this._sendState(object, comp);
        }
      }
    }

    _owns(comp) {
      if (!this.active) return false;
      if (!comp.owner) return this.isHost;
      return comp.owner === this.peerId;
    }

    _findObject(info) {
      if (!this.scene || !info) return null;
      if (info.id) {
        const byId = this.scene.get(info.id);
        if (byId) return byId;
      }
      if (info.networkId) {
        for (const object of this.scene.objects) {
          const comp = object.getComponent('NetworkObject');
          if (comp && comp.networkId === info.networkId) return object;
        }
      }
      return null;
    }

    _describe(object) {
      const comp = object.getComponent('NetworkObject');
      if (!comp) return null;
      comp.ensureId();
      const mr = object.getComponent('MeshRenderer');
      return {
        id: object.id,
        networkId: comp.networkId,
        name: object.name,
        owner: comp.owner || '',
        active: object.active !== false,
        tag: object.tag || 'Untagged',
        transform: {
          position: clone(object.transform.position),
          rotation: clone(object.transform.rotation),
          scale: clone(object.transform.scale)
        },
        mesh: mr ? {
          primitive: mr.primitive,
          meshId: mr.meshId || null,
          meshName: mr.meshName || '',
          color: mr.color,
          roughness: mr.roughness,
          emissive: mr.emissive,
          opacity: mr.opacity,
          uvScale: clone(mr.uvScale),
          uvOffset: clone(mr.uvOffset),
          castShadow: mr.castShadow !== false
        } : null
      };
    }

    _sendState(object, comp, force) {
      if (!this.active) return false;
      if (!force && !this.playing) return false;
      if (!this._owns(comp)) return false;
      return this._send({ type: 'state', object: this._describe(object) });
    }

    _announceAll() {
      if (!this.active || !this.scene) return;
      for (const object of this.scene.objects) {
        const comp = object.getComponent('NetworkObject');
        if (!comp) continue;
        if (!this.isHost && comp.owner !== this.peerId) continue;
        const description = this._describe(object);
        if (description) this._send({ type: 'spawn', object: description });
      }
      for (const object of this.scene.objects) {
        const comp = object.getComponent('NetworkObject');
        if (!comp) continue;
        if (this.isHost || comp.owner === this.peerId) this._sendState(object, comp, true);
      }
    }

    _instantiate(description) {
      if (!this.scene || !description) return null;
      const existing = this._findObject(description);
      if (existing) return existing;
      const mesh = description.mesh || {};
      const transform = description.transform || {};
      const position = vec(transform.position, V3.create());
      const name = description.name || 'Network Object';
      let object;
      if (mesh.meshId && UE.AssetStore && UE.AssetStore.meta(mesh.meshId)) {
        object = UE.createModel(name, mesh.meshId, position, mesh.color);
      } else {
        object = UE.createPrimitive(name, mesh.primitive || 'cube', mesh.color || '#66d9c0', position);
      }
      if (description.id) object.id = description.id;
      object.transform.rotation = vec(transform.rotation, V3.create());
      object.transform.scale = vec(transform.scale, V3.create(1, 1, 1));
      object.name = name;
      object.active = description.active !== false;
      object.tag = description.tag || 'Untagged';

      const mr = object.getComponent('MeshRenderer');
      if (mr && mesh) {
        if (mesh.primitive) mr.primitive = mesh.primitive;
        if (mesh.meshId !== undefined) mr.meshId = mesh.meshId || null;
        if (mesh.meshName !== undefined) mr.meshName = mesh.meshName || '';
        if (mesh.color) mr.color = mesh.color;
        if (mesh.roughness !== undefined) mr.roughness = safeNumber(mesh.roughness, mr.roughness);
        if (mesh.emissive !== undefined) mr.emissive = safeNumber(mesh.emissive, mr.emissive);
        if (mesh.opacity !== undefined) mr.opacity = safeNumber(mesh.opacity, mr.opacity);
        if (mesh.uvScale) mr.uvScale = { x: safeNumber(mesh.uvScale.x, 1), y: safeNumber(mesh.uvScale.y, 1) };
        if (mesh.uvOffset) mr.uvOffset = { x: safeNumber(mesh.uvOffset.x, 0), y: safeNumber(mesh.uvOffset.y, 0) };
        if (mesh.castShadow !== undefined) mr.castShadow = !!mesh.castShadow;
      }

      const comp = object.addComponent('NetworkObject', { networkId: description.networkId });
      comp.owner = description.owner || '';
      comp.ensureId();
      if (!comp.owner && this.isHost) comp.owner = this.peerId;
      this.scene.add(object);
      this._log('info', 'Received network object "' + object.name + '" from ' + (description.owner || 'peer'));
      this._emit();
      return object;
    }

    _removeRemote(info) {
      const object = this._findObject(info);
      if (!object) return false;
      const comp = object.getComponent('NetworkObject');
      if (comp && comp.owner === this.peerId) return false;
      if (this.scene) this.scene.remove(object);
      this._emit();
      return true;
    }

    _applyOwner(message) {
      const object = this._findObject(message.object);
      if (!object) return;
      const comp = object.getComponent('NetworkObject');
      if (!comp) return;
      comp.owner = message.owner || '';
      this._emit();
    }

    _applyState(description) {
      if (!description) return;
      const object = this._findObject(description);
      if (!object) return;
      const comp = object.getComponent('NetworkObject');
      if (!comp) return;
      if (description.owner !== undefined) comp.owner = description.owner || '';
      if (comp.syncActive) object.active = description.active !== false;
      if (comp.syncTag) object.tag = description.tag || 'Untagged';
      if (comp.syncMesh && description.mesh) {
        const mr = object.getComponent('MeshRenderer');
        const mesh = description.mesh;
        if (mr) {
          if (mesh.primitive) mr.primitive = mesh.primitive;
          if (mesh.meshId !== undefined) mr.meshId = mesh.meshId || null;
          if (mesh.meshName !== undefined) mr.meshName = mesh.meshName || '';
          if (mesh.color) mr.color = mesh.color;
          if (mesh.roughness !== undefined) mr.roughness = safeNumber(mesh.roughness, mr.roughness);
          if (mesh.emissive !== undefined) mr.emissive = safeNumber(mesh.emissive, mr.emissive);
          if (mesh.opacity !== undefined) mr.opacity = safeNumber(mesh.opacity, mr.opacity);
          if (mesh.uvScale) mr.uvScale = { x: safeNumber(mesh.uvScale.x, 1), y: safeNumber(mesh.uvScale.y, 1) };
          if (mesh.uvOffset) mr.uvOffset = { x: safeNumber(mesh.uvOffset.x, 0), y: safeNumber(mesh.uvOffset.y, 0) };
          if (mesh.castShadow !== undefined) mr.castShadow = !!mesh.castShadow;
        }
      }
      if (comp.syncTransform && description.transform) {
        const position = vec(description.transform.position, V3.create());
        const rotation = vec(description.transform.rotation, V3.create());
        const scale = vec(description.transform.scale, V3.create(1, 1, 1));
        const rate = safeNumber(comp.interpolation, 12);
        if (rate > 0) {
          comp._netTarget = {
            position: position, rotation: rotation, scale: scale,
            rate: rate
          };
        } else {
          copyVec(object.transform.position, position);
          copyVec(object.transform.rotation, rotation);
          copyVec(object.transform.scale, scale);
          comp._netTarget = null;
        }
      }
    }

    _interpolate(object, comp, dt) {
      const target = comp._netTarget;
      if (!target) return;
      if (target.rate <= 0 || dt <= 0) {
        copyVec(object.transform.position, target.position);
        copyVec(object.transform.rotation, target.rotation);
        copyVec(object.transform.scale, target.scale);
        comp._netTarget = null;
        return;
      }
      const t = 1 - Math.exp(-target.rate * dt);
      lerpVec(object.transform.position, target.position, t);
      lerpVec(object.transform.rotation, target.rotation, t);
      lerpVec(object.transform.scale, target.scale, t);
      if (closeEnough(object.transform.position, target.position, 0.002) &&
        closeEnough(object.transform.rotation, target.rotation, 0.01) &&
        closeEnough(object.transform.scale, target.scale, 0.002)) {
        copyVec(object.transform.position, target.position);
        copyVec(object.transform.rotation, target.rotation);
        copyVec(object.transform.scale, target.scale);
        comp._netTarget = null;
      }
    }

    _receiveEvent(message) {
      if (!message || !message.event) return;
      const object = this._findObject(message.object);
      if (!object) return;
      if (UE.PlayMaker && UE.PlayMaker.sendEventToObject) {
        UE.PlayMaker.sendEventToObject(object, String(message.event));
      }
      this._emit();
    }

    claim(object) {
      if (!object) return null;
      const comp = object.getComponent('NetworkObject');
      if (!comp) return null;
      comp.owner = this.peerId;
      comp._netTarget = null;
      this._send({ type: 'owner', object: { id: object.id, networkId: comp.networkId }, owner: this.peerId });
      this._log('info', 'Took ownership of "' + object.name + '"');
      this._emit();
      return comp;
    }

    makeNetworkObject(object, options) {
      if (!object) return null;
      options = options || {};
      let comp = object.getComponent('NetworkObject');
      if (!comp) comp = object.addComponent('NetworkObject', options);
      comp.ensureId();
      if (!comp.owner || options.claim) comp.owner = this.peerId;
      if (this.active && this.playing && this.scene) {
        this._send({ type: 'spawn', object: this._describe(object) });
        this._sendState(object, comp, true);
      }
      this._emit();
      return comp;
    }

    spawn(options) {
      options = options || {};
      if (!this.scene) {
        this._log('warn', 'No scene is attached to the network manager.');
        return null;
      }
      const primitive = options.primitive || 'cube';
      const baseName = options.name || 'Network Object';
      let name = baseName;
      let index = 2;
      while (this.scene.find(name)) name = baseName + ' ' + index++;
      const position = options.position
        ? vec(options.position, V3.create())
        : { x: 0, y: primitive === 'plane' ? 0 : 0.5, z: 0 };
      const object = UE.createPrimitive(name, primitive, options.color || '#66d9c0', position);
      if (options.rotation) object.transform.rotation = vec(options.rotation, V3.create());
      if (options.scale) object.transform.scale = vec(options.scale, V3.create(1, 1, 1));
      object.tag = UE.Tags ? UE.Tags.normalize(options.tag || 'Player') : (options.tag || 'Player');
      object.active = options.active !== false;
      const comp = object.addComponent('NetworkObject', {
        networkId: options.networkId || ('net-' + UE.uuid()),
        sendRate: options.sendRate === undefined ? 15 : options.sendRate,
        interpolation: options.interpolation === undefined ? 12 : options.interpolation,
        syncTransform: options.syncTransform !== false,
        syncMesh: options.syncMesh !== false,
        syncTag: options.syncTag !== false,
        syncActive: options.syncActive !== false
      });
      comp.owner = options.owner || this.peerId;
      this.scene.add(object);
      if (this.active && this.playing) {
        this._send({ type: 'spawn', object: this._describe(object) });
        this._sendState(object, comp, true);
      }
      this._log('info', 'Spawned network object "' + object.name + '"');
      this._emit();
      return object;
    }

    despawn(object) {
      if (!object || !this.scene) return false;
      const comp = object.getComponent('NetworkObject');
      if (!comp) return false;
      if (this.active && this.playing) {
        this._send({
          type: 'despawn',
          object: { id: object.id, networkId: comp.networkId, owner: comp.owner || '' }
        });
      }
      this.scene.remove(object);
      this._emit();
      return true;
    }

    sendEvent(object, event) {
      if (!object || !event || !this.active) return false;
      const comp = object.getComponent('NetworkObject');
      if (!comp) return false;
      return this._send({
        type: 'event',
        object: { id: object.id, networkId: comp.ensureId() },
        event: String(event)
      });
    }

    broadcastNow() {
      if (!this.active) return false;
      this._announceAll();
      return true;
    }

    objects() {
      if (!this.scene) return [];
      return this.scene.objects.filter(function (object) { return !!object.getComponent('NetworkObject'); });
    }

    status() {
      const peers = Object.keys(this.peers).map((id) => {
        const peer = this.peers[id];
        return {
          id: id,
          name: peer.name,
          isHost: !!peer.isHost,
          self: id === this.peerId,
          lastSeen: peer.lastSeen
        };
      }).sort(function (a, b) {
        if (a.self !== b.self) return a.self ? -1 : 1;
        return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
      });
      return {
        active: this.active,
        playing: this.playing,
        room: this.room,
        peerId: this.peerId,
        peerName: this.peerName,
        isHost: this.isHost,
        hostId: this.hostId,
        transport: this._transport ? this._transport.kind : 'none',
        tiedToScene: !!this.scene,
        sent: this._sent,
        received: this._received,
        lastError: this.lastError,
        peers: peers,
        objects: this.objects().map((object) => {
          const comp = object.getComponent('NetworkObject');
          return {
            id: object.id,
            networkId: comp.networkId,
            name: object.name,
            owner: comp.owner || '',
            mine: comp.owner === this.peerId,
            tag: object.tag || 'Untagged',
            active: object.active !== false,
            mesh: (object.getComponent('MeshRenderer') && object.getComponent('MeshRenderer').meshName) || ''
          };
        })
      };
    }
  }

  const singleton = new NetworkManager();
  UE.Network = singleton;
  UE.Network.NetworkManager = NetworkManager;
  UE.Network.create = function (options) { return new NetworkManager(options); };
  UE.Network.memoryBus = memoryBus;
  UE.Network.PROTOCOL = PROTOCOL;
  UE.Network.DEFAULT_ROOM = DEFAULT_ROOM;
  UE.Network.sanitizeRoom = sanitizeRoom;
});
